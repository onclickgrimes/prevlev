"use strict";
(() => {
  // src/shared/types.ts
  var defaultSettings = {
    hideShorts: false,
    showMetrics: true,
    backendUrl: "",
    backendToken: "",
    aiModel: "",
    aiStreaming: false,
    aiOrigin: "http://127.0.0.1:7814"
  };

  // src/core/parse.ts
  function parseCount(text) {
    const cleaned = text.normalize("NFKC").trim().toLocaleLowerCase().replace(/\u00a0/g, " ");
    const match = cleaned.match(
      /(\d[\d.,\s]*)\s*(bilh(?:ão|ões|ao|oes)|billions?|milh(?:ão|ões|ao|oes)|millions?|mil|[kmb])?(?=\s|$|[^a-zá-ú])/i
    );
    if (!match) return void 0;
    let digits = match[1].replace(/\s/g, "");
    const suffix = match[2] ?? "";
    const factor = /^(b|bilh|billion)/.test(suffix) ? 1e9 : /^(m$|milh|million)/.test(suffix) ? 1e6 : /^(k|mil$)/.test(suffix) ? 1e3 : 1;
    if (factor === 1) {
      digits = digits.replace(/[.,]/g, "");
    } else {
      const lastDot = digits.lastIndexOf("."), lastComma = digits.lastIndexOf(",");
      if (lastDot >= 0 && lastComma >= 0) {
        const decimal = Math.max(lastDot, lastComma);
        digits = digits.slice(0, decimal).replace(/[.,]/g, "") + "." + digits.slice(decimal + 1);
      } else digits = digits.replace(",", ".");
    }
    const value = Number(digits) * factor;
    return Number.isFinite(value) && value >= 0 ? Math.round(value) : void 0;
  }
  function parseDuration(value) {
    const text = value.trim();
    const iso = text.match(
      /^PT(?:(\d+(?:\.\d+)?)H)?(?:(\d+(?:\.\d+)?)M)?(?:(\d+(?:\.\d+)?)S)?$/i
    );
    if (iso && iso.slice(1).some(Boolean))
      return Number(iso[1] ?? 0) * 3600 + Number(iso[2] ?? 0) * 60 + Number(iso[3] ?? 0);
    if (!/^\d+(?::\d{1,2}){1,2}$/.test(text)) return void 0;
    const parts = text.split(":").map(Number);
    if (parts.slice(1).some((number) => number >= 60)) return void 0;
    return parts.reduce((sum, number) => sum * 60 + number, 0);
  }
  function parsePublishedAt(text, now = Date.now()) {
    const clean = text.trim().toLowerCase();
    const relative = clean.match(
      /(?:há\s+)?(\d+)\s*(seconds?|segundos?|minutes?|minutos?|hours?|horas?|days?|dias?|weeks?|semanas?|months?|mês|meses|years?|anos?)(?:\s+ago)?/
    );
    if (relative) {
      const unit = relative[2], amount = Number(relative[1]);
      const seconds = /^(second|segundo)/.test(unit) ? 1 : /^(minute|minuto)/.test(unit) ? 60 : /^(hour|hora)/.test(unit) ? 3600 : /^(day|dia)/.test(unit) ? 86400 : /^(week|semana)/.test(unit) ? 604800 : /^(month|mês|mes)/.test(unit) ? 2629800 : 31557600;
      return new Date(now - amount * seconds * 1e3).toISOString();
    }
    if (!/\d{4}-\d{2}-\d{2}/.test(clean)) return void 0;
    const value = Date.parse(clean);
    return Number.isFinite(value) ? new Date(value).toISOString() : void 0;
  }

  // src/core/observations.ts
  var normalizedName = (value) => value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase();
  function observedLifetimeVph(video, now = Date.now()) {
    if (video.views === void 0 || !Number.isFinite(video.views) || video.views < 0 || !video.publishedAt) return void 0;
    const published = knownPublication(video.publishedAt, now);
    if (published === void 0 || published >= now) return void 0;
    const result = video.views / ((now - published) / 36e5);
    return Number.isFinite(result) ? result : void 0;
  }
  function isoBoundary(value, endOfDay) {
    if (typeof value !== "string")
      throw new Error(
        "Informe uma data ISO v\xE1lida: AAAA-MM-DD ou timestamp com fuso hor\xE1rio."
      );
    const dateOnly = /^\d{4}-\d{2}-\d{2}$/.test(value);
    const timestamp = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::(\d{2})(?:\.(\d{1,3}))?)?(Z|[+-]\d{2}:\d{2})$/.exec(
      value
    );
    if (!dateOnly && !timestamp)
      throw new Error(
        "Informe uma data ISO v\xE1lida: AAAA-MM-DD ou timestamp com fuso hor\xE1rio."
      );
    const [year, month, day] = value.slice(0, 10).split("-").map(Number);
    const leap = year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
    const days = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    if (month < 1 || month > 12 || day < 1 || day > days[month - 1])
      throw new Error("A data de publica\xE7\xE3o cont\xE9m um dia ou m\xEAs inv\xE1lido.");
    if (timestamp) {
      const zone = timestamp[8];
      if (Number(timestamp[4]) > 23 || Number(timestamp[5]) > 59 || Number(timestamp[6] ?? 0) > 59 || zone !== "Z" && (Number(zone.slice(1, 3)) > 23 || Number(zone.slice(4)) > 59))
        throw new Error("O hor\xE1rio ou fuso da data de publica\xE7\xE3o \xE9 inv\xE1lido.");
    }
    const parsed = Date.parse(
      dateOnly ? `${value}T${endOfDay ? "23:59:59.999" : "00:00:00.000"}Z` : value
    );
    if (!Number.isFinite(parsed))
      throw new Error("A data de publica\xE7\xE3o \xE9 inv\xE1lida.");
    return parsed;
  }
  function knownPublication(value, now) {
    if (!Number.isFinite(now)) return void 0;
    try {
      const timestamp = isoBoundary(value, false);
      return timestamp <= now ? timestamp : void 0;
    } catch {
      return void 0;
    }
  }
  function channelIdentity(video) {
    const explicitId = video.channelId?.trim();
    let id = explicitId && /^[A-Za-z0-9_-]{1,128}$/.test(explicitId) ? explicitId : void 0;
    let handle;
    if (video.channelUrl) {
      try {
        const url = new URL(video.channelUrl);
        if (url.protocol === "https:" && ["www.youtube.com", "youtube.com", "m.youtube.com"].includes(
          url.hostname
        ) && !url.username && !url.password && !url.port) {
          const path = decodeURIComponent(url.pathname).replace(/\/$/, "");
          const linkedId = /^\/channel\/([A-Za-z0-9_-]{1,128})$/.exec(path)?.[1];
          if (id && linkedId && id !== linkedId) return { ambiguous: true };
          id ??= linkedId;
          handle = /^\/@([\p{L}\p{N}_.\-·]{1,100})$/u.exec(path)?.[1].normalize("NFC").toLocaleLowerCase();
        }
      } catch {
      }
    }
    const name = video.channel ? normalizedName(video.channel).trim().replace(/\s+/g, " ") || void 0 : void 0;
    return { id, handle, name };
  }
  function comparableChannel(target, peer) {
    if (target.ambiguous || peer.ambiguous) return false;
    if (!target.id && !target.handle && !target.name) return true;
    if (target.id && peer.id) return target.id === peer.id;
    if (target.handle && peer.handle) return target.handle === peer.handle;
    if (target.id || target.handle || peer.id || peer.handle) return false;
    return !!target.name && target.name === peer.name;
  }

  // src/core/swipe.ts
  var SWIPE_MAX_BYTES = 4 * 1024 * 1024;

  // src/shared/storage.ts
  var getSettings = async () => {
    const stored = (await chrome.storage.local.get("settings")).settings;
    return {
      ...defaultSettings,
      ...stored && typeof stored === "object" ? stored : {}
    };
  };
  var swipeWrites = Promise.resolve();

  // src/shared/backend.ts
  function backendOrigin(value) {
    const u = new URL(value);
    if (u.username || u.password || u.search || u.hash || u.pathname !== "/")
      throw new Error(
        "Use somente a origem do backend, sem caminho, senha ou par\xE2metros."
      );
    if (u.protocol !== "https:" && !(u.protocol === "http:" && ["localhost", "127.0.0.1"].includes(u.hostname)))
      throw new Error("Use HTTPS ou HTTP local.");
    if (/(^|\.)nexlev\./i.test(u.hostname))
      throw new Error("Configure seu pr\xF3prio backend.");
    return u.origin;
  }
  async function callBackend(settings, feature, payload) {
    if (!settings.backendUrl)
      return {
        status: "not_configured",
        source: "Prevlev",
        error: "Configure um backend pr\xF3prio na aba Conex\xE3o."
      };
    const origin = backendOrigin(settings.backendUrl);
    let response;
    try {
      response = await fetch(`${origin}/v1/analyze`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...settings.backendToken ? { Authorization: `Bearer ${settings.backendToken}` } : {}
        },
        body: JSON.stringify({ feature, payload }),
        credentials: "omit",
        redirect: "error",
        signal: AbortSignal.timeout(isAiFeature(feature) ? 305e3 : 45e3)
      });
    } catch {
      throw new Error(
        "N\xE3o foi poss\xEDvel concluir a conex\xE3o com o backend Prevlev. O resultado da solicita\xE7\xE3o \xE9 incerto; nenhuma repeti\xE7\xE3o foi enviada. Confira o servi\xE7o antes de reenviar."
      );
    }
    let body;
    try {
      body = await response.json();
    } catch {
      throw new Error(
        "O backend Prevlev n\xE3o devolveu uma resposta JSON completa. O resultado da solicita\xE7\xE3o \xE9 incerto; nenhuma repeti\xE7\xE3o foi enviada."
      );
    }
    if (!body || typeof body !== "object" || Array.isArray(body))
      throw new Error("Resposta incompat\xEDvel com o contrato Prevlev.");
    if (!response.ok && !body.error)
      throw new Error(`Backend respondeu HTTP ${response.status}`);
    if (!["ok", "not_configured", "unsupported", "error"].includes(body.status) || typeof body.source !== "string")
      throw new Error("Resposta incompat\xEDvel com o contrato Prevlev.");
    return body;
  }
  function isAiFeature(feature) {
    return [
      "comment-analysis",
      "thumbnail-generation",
      "transcript-summary",
      "transcript-topics",
      "transcript-script"
    ].includes(feature);
  }

  // src/core/media.ts
  var MAX_BYTES = 50 * 1024 * 1024;
  function thumbnailUrls(videoId) {
    if (!/^[A-Za-z0-9_-]{11}$/.test(videoId))
      throw new Error("ID de v\xEDdeo inv\xE1lido.");
    return [
      "maxresdefault",
      "sddefault",
      "hqdefault",
      "mqdefault",
      "default"
    ].map((size) => `https://i.ytimg.com/vi/${videoId}/${size}.jpg`);
  }
  async function fetchThumbnail(videoId, signal) {
    const deadline = AbortSignal.timeout(12e3), combined = signal ? AbortSignal.any([signal, deadline]) : deadline;
    for (const url of thumbnailUrls(videoId)) {
      let response;
      try {
        response = await fetch(url, { credentials: "omit", redirect: "error", signal: combined });
      } catch (error) {
        if (combined.aborted) throw error;
        continue;
      }
      if (!response.ok) continue;
      const type = (response.headers.get("content-type") ?? "").split(";")[0].toLowerCase();
      if (!["image/jpeg", "image/png", "image/webp", "image/gif", "image/avif"].includes(type) || Number(response.headers.get("content-length")) > 5 * 1024 * 1024) {
        await response.body?.cancel();
        continue;
      }
      const reader = response.body?.getReader();
      if (!reader) continue;
      const chunks = [];
      let bytes = 0, tooLarge = false;
      try {
        for (; ; ) {
          const next = await reader.read();
          if (next.done) break;
          bytes += next.value.byteLength;
          if (bytes > 5 * 1024 * 1024) {
            tooLarge = true;
            await reader.cancel();
            break;
          }
          chunks.push(new Uint8Array(next.value));
        }
      } finally {
        reader.releaseLock();
      }
      combined.throwIfAborted();
      if (!tooLarge && bytes > 0) return new Blob(chunks, { type });
    }
    throw new Error("Nenhuma thumbnail p\xFAblica p\xF4de ser obtida do YouTube.");
  }

  // src/core/enrichment.ts
  var MAX_PAGE_BYTES = 3 * 1024 * 1024;
  var MAX_CHANNELS = 10;
  var TIMEOUT_MS = 8e3;
  function parsePublicChannelPage(html) {
    const result = { source: "public-youtube", warnings: [] };
    if (html.length > MAX_PAGE_BYTES)
      return {
        ...result,
        warnings: ["P\xE1gina de canal acima do limite de 3 MiB."]
      };
    for (const match of html.matchAll(/"subscriberCountText"\s*:\s*/g)) {
      const value = readLiteral(html, match.index + match[0].length);
      const text = literalText(value);
      const subscribers = text === void 0 ? void 0 : parseCount(text);
      if (subscribers !== void 0) {
        result.subscribers = subscribers;
        break;
      }
    }
    if (result.subscribers === void 0) {
      for (const match of html.matchAll(
        /"(?:content|simpleText|text)"\s*:\s*("(?:\\.|[^"\\])*")/g
      )) {
        const value = parseJsonString(match[1]);
        if (!value || !/^\s*\d[\d.,\s]*(?:bilh(?:ão|ões|ao|oes)|billions?|milh(?:ão|ões|ao|oes)|millions?|mil|[kmb])?\s+(?:de\s+)?(?:subscribers?|inscritos?|assinantes?)\s*$/iu.test(
          value
        ))
          continue;
        const subscribers = parseCount(value);
        if (subscribers !== void 0) {
          result.subscribers = subscribers;
          break;
        }
      }
    }
    for (const key of ["channelMetadataRenderer", "c4TabbedHeaderRenderer"]) {
      const match = new RegExp(`"${key}"\\s*:\\s*`).exec(html);
      if (!match) continue;
      const literal = record(readLiteral(html, match.index + match[0].length));
      const title = literalText(literal.title);
      if (title) {
        result.channelName = title;
        break;
      }
    }
    for (const match of html.matchAll(/<meta\b[^>]*>/gi)) {
      const attributes = {};
      for (const attribute of match[0].matchAll(
        /([\w:-]+)\s*=\s*(?:"([^"]*)"|'([^']*)')/g
      ))
        attributes[attribute[1].toLowerCase()] = decodeEntities(
          attribute[2] ?? attribute[3]
        );
      const key = (attributes.property ?? attributes.name ?? attributes.itemprop ?? "").toLowerCase();
      if (!result.channelName && key === "og:title" && attributes.content)
        result.channelName = attributes.content.replace(/\s+- YouTube$/, "");
      if (result.subscribers === void 0 && /^(?:subscribercount|subscriber_count|subscribers)$/.test(key))
        result.subscribers = parseCount(attributes.content ?? "");
    }
    if (result.subscribers === void 0)
      result.warnings.push(
        "Inscritos n\xE3o encontrados ou n\xE3o publicados nesta p\xE1gina; valor permanece desconhecido."
      );
    return result;
  }
  function buildChannelUrl(video) {
    if (video.channelId && /^UC[A-Za-z0-9_-]{22}$/.test(video.channelId))
      return `https://www.youtube.com/channel/${video.channelId}`;
    if (!video.channelUrl || !/^https:\/\/www\.youtube\.com\//.test(video.channelUrl) || video.channelUrl.includes("\\") || [...video.channelUrl].some(
      (character) => character.charCodeAt(0) <= 32 || character.charCodeAt(0) === 127
    ))
      return void 0;
    try {
      const url = new URL(video.channelUrl);
      if (url.protocol !== "https:" || url.hostname !== "www.youtube.com" || url.username || url.password || url.port || url.search || url.hash)
        return void 0;
      const path = decodeURIComponent(url.pathname).replace(/\/$/, "");
      const rawPath = decodeURIComponent(
        video.channelUrl.slice("https://www.youtube.com".length)
      ).replace(/\/$/, "");
      if (path !== rawPath) return void 0;
      if (/^\/channel\/UC[A-Za-z0-9_-]{22}$/.test(path))
        return `https://www.youtube.com${path}`;
      if (!/^\/@[\p{L}\p{N}_.\-·]{1,100}$/u.test(path)) return void 0;
      return new URL(path, "https://www.youtube.com").href;
    } catch {
      return void 0;
    }
  }
  async function enrichChannels(videos, fetcher, signal) {
    const enriched = videos.map((video) => ({ ...video }));
    const warnings = [];
    const urls = [
      ...new Set(
        videos.filter((video) => video.subscribers === void 0).map(buildChannelUrl).filter((url) => url !== void 0)
      )
    ];
    if (urls.length > MAX_CHANNELS)
      warnings.push(
        `Limite de ${MAX_CHANNELS} canais por a\xE7\xE3o; ${urls.length - MAX_CHANNELS} canais n\xE3o foram consultados.`
      );
    for (const url of urls.slice(0, MAX_CHANNELS)) {
      if (signal?.aborted) {
        warnings.push(
          "Enriquecimento cancelado; canais restantes n\xE3o foram consultados."
        );
        break;
      }
      const timeout = AbortSignal.timeout(TIMEOUT_MS);
      const combined = signal ? AbortSignal.any([signal, timeout]) : timeout;
      try {
        const response = await fetcher(url, {
          credentials: "omit",
          redirect: "error",
          cache: "no-store",
          headers: { Accept: "text/html" },
          signal: combined
        });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        if (response.redirected)
          throw new Error("Redirecionamento de p\xE1gina recusado.");
        const type = response.headers.get("content-type");
        if (type && !/^(?:text\/html|application\/xhtml\+xml)(?:;|$)/i.test(type))
          throw new Error("A resposta n\xE3o \xE9 uma p\xE1gina HTML.");
        const page = parsePublicChannelPage(
          await boundedText(response, combined)
        );
        for (let index = 0; index < videos.length; index++) {
          if (buildChannelUrl(videos[index]) !== url) continue;
          if (enriched[index].subscribers === void 0 && page.subscribers !== void 0)
            enriched[index].subscribers = page.subscribers;
          if (!enriched[index].channel && page.channelName)
            enriched[index].channel = page.channelName;
        }
        warnings.push(...page.warnings.map((warning) => `${url}: ${warning}`));
      } catch (error) {
        const reason = signal?.aborted ? "consulta cancelada" : timeout.aborted ? "tempo limite de 8 segundos" : error instanceof Error ? error.message : "falha de leitura";
        warnings.push(
          `${url}: ${reason}; inscritos permanecem desconhecidos quando indispon\xEDveis.`
        );
      }
    }
    return { videos: enriched, warnings };
  }
  async function boundedText(response, signal) {
    const declaredSize = response.headers.get("content-length");
    if (declaredSize && Number(declaredSize) > MAX_PAGE_BYTES) {
      await response.body?.cancel();
      throw new Error("P\xE1gina acima do limite de 3 MiB.");
    }
    if (!response.body) return "";
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let bytes = 0, text = "";
    try {
      for (; ; ) {
        signal.throwIfAborted();
        const { done, value } = await reader.read();
        if (done) break;
        bytes += value.byteLength;
        if (bytes > MAX_PAGE_BYTES)
          throw new Error("P\xE1gina acima do limite de 3 MiB.");
        text += decoder.decode(value, { stream: true });
      }
      return text + decoder.decode();
    } finally {
      await reader.cancel().catch(() => void 0);
      reader.releaseLock();
    }
  }
  function readLiteral(text, offset) {
    if (text[offset] === '"') {
      const match = /^"(?:\\.|[^"\\])*"/.exec(
        text.slice(offset, offset + 65536)
      );
      return match ? parseJsonString(match[0]) : void 0;
    }
    if (text[offset] !== "{") return void 0;
    let depth = 0, quoted = false, escaped = false;
    for (let index = offset; index < Math.min(text.length, offset + 65536); index++) {
      const character = text[index];
      if (quoted) {
        if (escaped) escaped = false;
        else if (character === "\\") escaped = true;
        else if (character === '"') quoted = false;
        continue;
      }
      if (character === '"') quoted = true;
      else if (character === "{") depth++;
      else if (character === "}" && --depth === 0) {
        try {
          return JSON.parse(text.slice(offset, index + 1));
        } catch {
          return void 0;
        }
      }
    }
    return void 0;
  }
  function parseJsonString(value) {
    try {
      const parsed = JSON.parse(value);
      return typeof parsed === "string" ? parsed : void 0;
    } catch {
      return void 0;
    }
  }
  function record(value) {
    return value !== null && typeof value === "object" ? value : {};
  }
  function literalText(value) {
    if (typeof value === "string") return value;
    const object = record(value);
    if (typeof object.simpleText === "string") return object.simpleText;
    if (Array.isArray(object.runs)) {
      const text = object.runs.map((run) => record(run).text).filter((item) => typeof item === "string").join("");
      return text || void 0;
    }
    return void 0;
  }
  function decodeEntities(text) {
    return text.replace(
      /&(?:amp|quot|apos|lt|gt|#\d+|#x[0-9a-f]+);/gi,
      (match) => {
        const named = {
          "&amp;": "&",
          "&quot;": '"',
          "&apos;": "'",
          "&lt;": "<",
          "&gt;": ">"
        };
        if (named[match.toLowerCase()]) return named[match.toLowerCase()];
        const value = match.toLowerCase().startsWith("&#x") ? parseInt(match.slice(3, -1), 16) : Number(match.slice(2, -1));
        return Number.isInteger(value) && value > 0 && value <= 1114111 ? String.fromCodePoint(value) : match;
      }
    );
  }

  // src/core/metrics.ts
  function median(values) {
    const sorted = values.filter(Number.isFinite).sort((a, b) => a - b);
    const middle = Math.floor(sorted.length / 2);
    return sorted.length ? sorted.length % 2 ? sorted[middle] : sorted[middle - 1] / 2 + sorted[middle] / 2 : void 0;
  }
  function lifetimeVph(video, now = Date.now()) {
    return observedLifetimeVph(video, now);
  }
  function outlierScore(video, baseline) {
    if (video.views === void 0 || !Number.isFinite(video.views) || video.views < 0)
      return void 0;
    const channel = channelIdentity(video);
    const values = baseline.filter(
      (other) => other.id !== video.id && other.isShort === video.isShort && comparableChannel(channel, channelIdentity(other))
    ).map((other) => other.views).filter(
      (value) => value !== void 0 && Number.isFinite(value) && value >= 0
    );
    if (values.length < 3) return void 0;
    const reference = median(values);
    return reference && reference > 0 ? video.views / reference : void 0;
  }
  function sortVideos(videos, by, now = Date.now(), baseline = videos) {
    if (by === "title")
      return [...videos].sort((a, b) => a.title.localeCompare(b.title));
    const get = (video) => {
      if (by === "recent")
        return video.publishedAt ? knownPublication(video.publishedAt, now) : void 0;
      const value = by === "views" ? video.views : by === "duration" ? video.durationSeconds : by === "subscribers" ? video.subscribers : by === "vph" ? lifetimeVph(video, now) : outlierScore(video, baseline);
      return value !== void 0 && Number.isFinite(value) && value >= 0 ? value : void 0;
    };
    return [...videos].sort((a, b) => {
      const left = get(a), right = get(b);
      const knownLeft = left !== void 0 && Number.isFinite(left), knownRight = right !== void 0 && Number.isFinite(right);
      return knownLeft && knownRight ? right - left : knownLeft ? -1 : knownRight ? 1 : 0;
    });
  }
  function inferMonetization(html) {
    const patterns = [
      ["adPlacements", /"adPlacements"\s*:\s*\[\s*\{/],
      ["playerAds", /"playerAds"\s*:\s*\[\s*\{/],
      ["adSlots", /"adSlots"\s*:\s*\[\s*\{/],
      ["music-metadata", /"musicDescriptionShelfRenderer"\s*:/]
    ];
    const markers = patterns.filter(([, pattern]) => pattern.test(html)).map(([name]) => name);
    return {
      status: markers.length ? "markers-present" : "unknown",
      confidence: "low",
      markers,
      explanation: markers.length ? "Marcadores de an\xFAncio ou m\xFAsica encontrados. Isso n\xE3o confirma participa\xE7\xE3o no YPP, monetiza\xE7\xE3o do canal nem recebimento de receita pelo criador." : "Nenhum marcador reconhecido foi encontrado nesta resposta. Aus\xEAncia de marcadores n\xE3o prova desmonetiza\xE7\xE3o."
    };
  }

  // src/core/channel-research.ts
  var MAX_BYTES2 = 3 * 1024 * 1024;
  var TIMEOUT_MS2 = 8e3;
  var VIDEO_ID = /^[A-Za-z0-9_-]{11}$/;
  var COVERAGE = "initial-public-page";
  var record2 = (value) => value !== null && typeof value === "object" && !Array.isArray(value) ? value : {};
  function literalText2(value) {
    if (typeof value === "string") return value;
    const object = record2(value);
    for (const key of ["simpleText", "content", "text"])
      if (typeof object[key] === "string") return object[key];
    if (Array.isArray(object.runs))
      return object.runs.map((run) => record2(run).text).filter((text) => typeof text === "string").join("") || void 0;
    return void 0;
  }
  function readInitialData(html) {
    if (new TextEncoder().encode(html).byteLength > MAX_BYTES2)
      throw new Error("P\xE1gina acima do limite de 3 MiB.");
    const assignments = /(?:\b(?:window\.)?ytInitialData|window\s*\[\s*["']ytInitialData["']\s*\])\s*=\s*/g;
    let candidates = 0;
    for (const match of html.matchAll(assignments)) {
      if (++candidates > 16) break;
      const start = match.index + match[0].length;
      if (html[start] !== "{") continue;
      let depth = 0, quoted = false, escaped = false;
      for (let index = start; index < html.length; index++) {
        const char = html[index];
        if (quoted) {
          if (escaped) escaped = false;
          else if (char === "\\") escaped = true;
          else if (char === '"') quoted = false;
          continue;
        }
        if (char === '"') quoted = true;
        else if (char === "{" || char === "[") depth++;
        else if ((char === "}" || char === "]") && --depth === 0) {
          try {
            return JSON.parse(html.slice(start, index + 1));
          } catch {
            break;
          }
        }
      }
    }
    return void 0;
  }
  function strings(value) {
    const result = [], pending = [value];
    let count = 0;
    while (pending.length && count++ < 1e4) {
      const item = pending.pop();
      if (typeof item === "string") result.push(item);
      else if (Array.isArray(item)) {
        for (const child of item.slice(0, 1e4).reverse()) pending.push(child);
      } else if (item !== null && typeof item === "object") {
        for (const child of Object.values(item).slice(0, 1e4).reverse())
          pending.push(child);
      }
    }
    return result;
  }
  function chosenContent(initial) {
    const contents = record2(record2(initial).contents);
    for (const rendererName of [
      "twoColumnBrowseResultsRenderer",
      "singleColumnBrowseResultsRenderer"
    ]) {
      const tabs = record2(contents[rendererName]).tabs;
      if (!Array.isArray(tabs)) continue;
      for (const item of tabs) {
        const tab = record2(record2(item).tabRenderer);
        if (tab.selected === true && tab.content)
          return { content: tab.content, scoped: true };
      }
    }
    return { content: initial, scoped: false };
  }
  function parseVideo(renderer, modern, channelUrl, now) {
    const id = modern ? renderer.contentId : renderer.videoId;
    if (typeof id !== "string" || !VIDEO_ID.test(id)) return void 0;
    if (modern && renderer.contentType && renderer.contentType !== "LOCKUP_CONTENT_TYPE_VIDEO")
      return void 0;
    const lockupMetadata = record2(
      record2(renderer.metadata).lockupMetadataViewModel
    );
    const title = literalText2(modern ? lockupMetadata.title : renderer.title);
    if (!title) return void 0;
    const metadata = modern ? strings(lockupMetadata.metadata) : [
      literalText2(renderer.viewCountText),
      literalText2(renderer.shortViewCountText),
      literalText2(renderer.publishedTimeText)
    ].filter((value) => !!value);
    const viewsText = metadata.find(
      (value) => /views|visualizaç|visualizac/i.test(value)
    );
    const publishedAt = metadata.map((value) => parsePublishedAt(value, now)).find((value) => value !== void 0);
    const overlayText = strings(
      modern ? renderer.contentImage : renderer.thumbnailOverlays
    );
    const duration = literalText2(renderer.lengthText) ?? overlayText.find((value) => /^\d+(?::\d{1,2}){1,2}$/.test(value));
    const video = {
      id,
      title,
      url: `https://www.youtube.com/watch?v=${id}`,
      channelUrl,
      views: viewsText ? parseCount(viewsText) : void 0,
      publishedAt,
      durationSeconds: duration ? parseDuration(duration) : void 0,
      isShort: false,
      thumbnail: `https://i.ytimg.com/vi/${id}/hqdefault.jpg`
    };
    return video;
  }
  function parseChannelVideos(html, channelUrl, now = Date.now()) {
    const canonical = buildChannelUrl({ id: "", title: "", url: "", channelUrl });
    if (!canonical)
      throw new Error(
        "Use uma URL p\xFAblica can\xF4nica de canal do YouTube (/ @handle ou /channel/UC...)."
      );
    const initial = readInitialData(html), info = parsePublicChannelPage(html);
    const warnings = [
      ...info.warnings,
      "Amostra limitada aos v\xEDdeos presentes no HTML inicial p\xFAblico; sem pagina\xE7\xE3o, contas ou cat\xE1logo completo.",
      "Datas e contagens p\xFAblicas podem estar arredondadas. Recentes e populares s\xE3o ordenados somente dentro desta amostra."
    ];
    if (!initial)
      warnings.push(
        "ytInitialData JSON n\xE3o encontrado; o YouTube pode exigir consentimento ou ter alterado o layout."
      );
    const chosen = chosenContent(initial);
    if (initial && !chosen.scoped)
      warnings.push(
        "A aba selecionada n\xE3o foi identificada; os cards reconhecidos podem incluir outras se\xE7\xF5es desta p\xE1gina."
      );
    const pending = [
      { value: chosen.content, depth: 0 }
    ], seen = /* @__PURE__ */ new Set(), videos = [];
    let visited = 0;
    while (pending.length && visited++ < 1e5 && videos.length < 2e3) {
      const { value, depth } = pending.pop();
      if (depth > 100) continue;
      if (Array.isArray(value)) {
        for (let index = value.length - 1; index >= 0; index--)
          pending.push({ value: value[index], depth: depth + 1 });
        continue;
      }
      const object = record2(value);
      for (const [key, child] of Object.entries(object).reverse()) {
        if (/^(?:adSlotRenderer|displayAdRenderer|inFeedAdLayoutRenderer|promotedVideoRenderer)$/.test(
          key
        ))
          continue;
        if (["videoRenderer", "gridVideoRenderer", "lockupViewModel"].includes(key)) {
          const video = parseVideo(
            record2(child),
            key === "lockupViewModel",
            canonical,
            now
          );
          if (video && !seen.has(video.id)) {
            seen.add(video.id);
            videos.push({
              ...video,
              channel: info.channelName,
              subscribers: info.subscribers,
              channelId: canonical.match(
                /\/channel\/(UC[A-Za-z0-9_-]{22})$/
              )?.[1]
            });
          }
        } else if (child && typeof child === "object")
          pending.push({ value: child, depth: depth + 1 });
      }
    }
    if (pending.length)
      warnings.push(
        "Limite de leitura estrutural atingido; a cobertura \xE9 parcial."
      );
    if (!videos.length)
      warnings.push(
        "Nenhum v\xEDdeo p\xFAblico reconhecido nesta resposta; n\xE3o significa que o canal n\xE3o tenha v\xEDdeos."
      );
    return {
      channelUrl: canonical,
      channelName: info.channelName,
      subscribers: info.subscribers,
      videos,
      recent: sortVideos(videos, "recent", now),
      popular: sortVideos(videos, "views", now),
      coverage: COVERAGE,
      warnings
    };
  }
  async function publicHtml(url, fetcher) {
    const signal = AbortSignal.timeout(TIMEOUT_MS2);
    const response = await fetcher(url, {
      credentials: "omit",
      redirect: "error",
      cache: "no-store",
      headers: { Accept: "text/html" },
      signal
    });
    if (!response.ok)
      throw new Error(`YouTube respondeu HTTP ${response.status}.`);
    if (response.redirected)
      throw new Error("Redirecionamento p\xFAblico recusado.");
    const type = response.headers.get("content-type");
    if (type && !/^(?:text\/html|application\/xhtml\+xml)(?:;|$)/i.test(type))
      throw new Error("A resposta p\xFAblica n\xE3o \xE9 HTML.");
    if (Number(response.headers.get("content-length")) > MAX_BYTES2) {
      await response.body?.cancel();
      throw new Error("P\xE1gina acima do limite de 3 MiB.");
    }
    if (!response.body) return "";
    const reader = response.body.getReader(), decoder = new TextDecoder();
    let bytes = 0, result = "";
    try {
      for (; ; ) {
        signal.throwIfAborted();
        const { done, value } = await reader.read();
        if (done) break;
        bytes += value.byteLength;
        if (bytes > MAX_BYTES2)
          throw new Error("P\xE1gina acima do limite de 3 MiB.");
        result += decoder.decode(value, { stream: true });
      }
      return result + decoder.decode();
    } finally {
      await reader.cancel().catch(() => void 0);
      reader.releaseLock();
    }
  }
  async function researchChannel(channelUrl, fetcher, order = "recent") {
    const canonical = buildChannelUrl({ id: "", title: "", url: "", channelUrl });
    if (!canonical)
      throw new Error(
        "Informe uma URL https://www.youtube.com/@handle ou /channel/UC... sem par\xE2metros."
      );
    if (!["recent", "popular"].includes(order))
      throw new Error("Ordem inv\xE1lida; use recent ou popular.");
    const result = parseChannelVideos(
      await publicHtml(`${canonical}/videos`, fetcher),
      canonical
    );
    return {
      ...result,
      videos: order === "popular" ? result.popular : result.recent
    };
  }
  async function sampleMonetization(videos, fetcher, maxSamples = 5) {
    if (!Number.isInteger(maxSamples) || maxSamples < 1 || maxSamples > 5)
      throw new Error("A amostra precisa ter entre 1 e 5 v\xEDdeos.");
    if (!Array.isArray(videos) || !videos.length || videos.length > 2e3 || videos.some(
      (video) => !video || typeof video.id !== "string" || !VIDEO_ID.test(video.id)
    ))
      throw new Error("Envie de 1 a 2000 v\xEDdeos com IDs YouTube v\xE1lidos.");
    const ids = [...new Set(videos.map((video) => video.id))].slice(
      0,
      maxSamples
    ), assessments = [];
    for (const videoId of ids) {
      const url = `https://www.youtube.com/watch?v=${videoId}`;
      try {
        assessments.push({
          ...inferMonetization(await publicHtml(url, fetcher)),
          videoId,
          url,
          source: "public-youtube"
        });
      } catch (error) {
        assessments.push({
          ...inferMonetization(""),
          videoId,
          url,
          source: "public-youtube",
          error: error instanceof Error ? error.message : "Falha de consulta p\xFAblica."
        });
      }
    }
    return {
      assessments,
      limitations: [
        "Amostra p\xFAblica an\xF4nima de at\xE9 cinco v\xEDdeos; p\xE1ginas sem an\xFAncios ou consentimento podem n\xE3o conter marcadores.",
        "Marcadores de an\xFAncios/m\xFAsica t\xEAm confian\xE7a baixa e n\xE3o confirmam YPP, receita do criador ou monetiza\xE7\xE3o oficial do canal.",
        "Aus\xEAncia de marcadores ou falha de consulta permanece desconhecida; n\xE3o significa desmonetiza\xE7\xE3o."
      ]
    };
  }

  // src/background.ts
  var ownUi = (sender) => sender.id === chrome.runtime.id && sender.url?.startsWith(chrome.runtime.getURL(""));
  var youtube = (url) => !!url && /^https:\/\/(www|studio)\.youtube\.com\//.test(url);
  var capturing = false;
  function captureMeasurement(value) {
    const item = value !== null && typeof value === "object" ? value : {};
    if (item.status !== "ok")
      throw new Error(
        typeof item.error === "string" ? item.error : "N\xE3o foi poss\xEDvel medir o card nesta p\xE1gina."
      );
    const rect = item.rect !== null && typeof item.rect === "object" ? item.rect : {};
    if (typeof item.captureStamp !== "string" || !item.captureStamp || typeof item.viewportWidth !== "number" || item.viewportWidth <= 0 || !["x", "y", "width", "height"].every(
      (key) => typeof rect[key] === "number" && Number.isFinite(rect[key])
    ) || Number(rect.width) <= 0 || Number(rect.height) <= 0 || !Array.isArray(item.redactions))
      throw new Error(
        "Medi\xE7\xE3o de captura incompat\xEDvel; recarregue a p\xE1gina do YouTube/Studio."
      );
    return item;
  }
  chrome.runtime.onMessage.addListener(
    (message, sender, sendResponse) => {
      if (sender.id !== chrome.runtime.id) return;
      if (!message || typeof message !== "object" || !("type" in message)) return;
      const m = message;
      const run = async () => {
        if (m.type === "OPEN_WORKSPACE") {
          if (!youtube(sender.tab?.url) && !ownUi(sender))
            throw new Error("Origem n\xE3o permitida.");
          await chrome.tabs.create({
            url: chrome.runtime.getURL(
              `workspace.html?tab=${sender.tab?.id ?? ""}`
            )
          });
          return { status: "ok" };
        }
        if (m.type === "REMOTE_ANALYZE") {
          if (!ownUi(sender))
            throw new Error(
              "Use a p\xE1gina da extens\xE3o para enviar dados ao backend."
            );
          return callBackend(
            await getSettings(),
            m.feature,
            m.payload
          );
        }
        if (m.type === "ENRICH_CHANNELS") {
          if (!ownUi(sender))
            throw new Error("Use a p\xE1gina da extens\xE3o para consultar canais.");
          if (!Array.isArray(m.videos) || m.videos.length > 2e3)
            throw new Error("Envie at\xE9 2000 v\xEDdeos coletados.");
          return {
            status: "ok",
            ...await enrichChannels(m.videos, fetch)
          };
        }
        if (m.type === "CHANNEL_RESEARCH") {
          if (!ownUi(sender))
            throw new Error(
              "Use a p\xE1gina da extens\xE3o para pesquisar um canal p\xFAblico."
            );
          if (typeof m.channelUrl !== "string")
            throw new Error("Informe uma URL p\xFAblica de canal.");
          if (m.order !== void 0 && m.order !== "recent" && m.order !== "popular")
            throw new Error("Ordem de canal inv\xE1lida.");
          return {
            status: "ok",
            data: await researchChannel(m.channelUrl, fetch, m.order)
          };
        }
        if (m.type === "SAMPLE_MONETIZATION") {
          if (!ownUi(sender))
            throw new Error(
              "Use a p\xE1gina da extens\xE3o para consultar uma amostra p\xFAblica."
            );
          if (!Array.isArray(m.videos) || m.maxSamples !== void 0 && typeof m.maxSamples !== "number")
            throw new Error("Informe os v\xEDdeos e o limite da amostra.");
          return {
            status: "ok",
            data: await sampleMonetization(
              m.videos,
              fetch,
              m.maxSamples
            )
          };
        }
        if (m.type === "FETCH_THUMBNAIL") {
          if (!ownUi(sender) && !youtube(sender.tab?.url)) throw new Error("Origem n\xE3o permitida.");
          if (typeof m.videoId !== "string" || !/^[-\w]{11}$/.test(m.videoId)) throw new Error("ID de v\xEDdeo inv\xE1lido.");
          const blob = await fetchThumbnail(m.videoId);
          const bytes = new Uint8Array(await blob.arrayBuffer());
          let binary = "";
          for (let i = 0; i < bytes.length; i += 8192) binary += String.fromCharCode(...bytes.subarray(i, i + 8192));
          return { status: "ok", dataUrl: `data:${blob.type};base64,${btoa(binary)}` };
        }
        if (m.type === "CAPTURE_SCREENSHOT") {
          if (!ownUi(sender) && !youtube(sender.tab?.url))
            throw new Error("Origem n\xE3o permitida.");
          if (!ownUi(sender) && m.tabId !== void 0 && m.tabId !== sender.tab?.id) throw new Error("A captura contextual pertence somente \xE0 aba de origem.");
          if (m.targetVideoId !== void 0 && (typeof m.targetVideoId !== "string" || !/^[-\w]{11}$/.test(m.targetVideoId))) throw new Error("ID do card inv\xE1lido.");
          const tab = await chrome.tabs.get(Number(m.tabId ?? sender.tab?.id));
          if (!youtube(tab.url) || tab.id === void 0)
            throw new Error("Selecione uma aba YouTube/Studio.");
          if (capturing) throw new Error("Aguarde a captura atual terminar.");
          capturing = true;
          let previous;
          try {
            [previous] = await chrome.tabs.query({
              active: true,
              windowId: tab.windowId
            });
            await chrome.tabs.update(tab.id, { active: true });
            await new Promise((r) => setTimeout(r, 180));
            const [active] = await chrome.tabs.query({
              active: true,
              windowId: tab.windowId
            });
            if (active?.id !== tab.id || active.url !== tab.url)
              throw new Error("A aba mudou durante a captura. Tente novamente.");
            const kind = m.kind ?? "video";
            if (!["video", "analytics", "latest-performance"].includes(String(kind)))
              throw new Error("Tipo de captura inv\xE1lido.");
            const measure = async () => {
              let value;
              try {
                value = await chrome.tabs.sendMessage(tab.id, {
                  type: "CAPTURE_CARD",
                  kind,
                  redact: Boolean(m.redact),
                  ...m.targetVideoId ? { targetVideoId: m.targetVideoId } : {}
                });
              } catch {
                throw new Error(
                  "Abra o painel Prevlev pela aba YouTube/Studio e recarregue a p\xE1gina para medir o card."
                );
              }
              return captureMeasurement(value);
            };
            const capture = await measure();
            const [ready] = await chrome.tabs.query({
              active: true,
              windowId: tab.windowId
            });
            if (ready?.id !== tab.id || ready.url !== tab.url)
              throw new Error("A aba mudou antes da captura. Tente novamente.");
            let dataUrl;
            try {
              dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, {
                format: "png"
              });
            } catch {
              throw new Error(
                "Clique no \xEDcone Prevlev na aba YouTube/Studio e abra o painel por ele para conceder acesso \xE0 captura."
              );
            }
            const [after] = await chrome.tabs.query({
              active: true,
              windowId: tab.windowId
            });
            if (after?.id !== tab.id || after.url !== tab.url)
              throw new Error(
                "A aba mudou durante a captura. Imagem descartada."
              );
            const measuredAfter = await measure();
            if (capture.captureStamp !== measuredAfter.captureStamp || JSON.stringify([
              capture.rect,
              capture.redactions,
              capture.viewportWidth
            ]) !== JSON.stringify([
              measuredAfter.rect,
              measuredAfter.redactions,
              measuredAfter.viewportWidth
            ]))
              throw new Error(
                "A rolagem, o layout ou os campos sens\xEDveis mudaram durante a captura. Imagem descartada."
              );
            const [verified] = await chrome.tabs.query({
              active: true,
              windowId: tab.windowId
            });
            if (verified?.id !== tab.id || verified.url !== tab.url)
              throw new Error(
                "A aba mudou durante a medi\xE7\xE3o. Imagem descartada."
              );
            return { status: "ok", dataUrl, capture };
          } finally {
            try {
              const [active] = await chrome.tabs.query({
                active: true,
                windowId: tab.windowId
              });
              if (previous?.id && previous.id !== tab.id && active?.id === tab.id)
                await chrome.tabs.update(previous.id, { active: true });
            } finally {
              capturing = false;
            }
          }
        }
        throw new Error("A\xE7\xE3o desconhecida.");
      };
      void run().then(
        sendResponse,
        (error) => sendResponse({
          status: "error",
          error: error instanceof Error ? error.message : String(error)
        })
      );
      return true;
    }
  );
})();
