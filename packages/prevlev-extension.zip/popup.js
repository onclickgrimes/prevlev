"use strict";
(() => {
  // src/shared/types.ts
  var defaultSettings = {
    hideShorts: false,
    showMetrics: true,
    backendUrl: "",
    backendToken: "",
    aiModel: "",
    aiStreaming: false,
    aiOrigin: "http://127.0.0.1:7814"
  };

  // src/core/swipe.ts
  var SWIPE_MAX_BYTES = 4 * 1024 * 1024;

  // src/shared/storage.ts
  var getSettings = async () => {
    const stored = (await chrome.storage.local.get("settings")).settings;
    return {
      ...defaultSettings,
      ...stored && typeof stored === "object" ? stored : {}
    };
  };
  var saveSettings = async (settings) => chrome.storage.local.set({ settings });
  var swipeWrites = Promise.resolve();

  // src/ui/popup.ts
  var status = document.querySelector("#status");
  async function active() {
    return (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
  }
  document.querySelector("#open").addEventListener("click", () => {
    void active().then(
      (tab) => chrome.tabs.create({
        url: chrome.runtime.getURL(`workspace.html?tab=${tab?.id ?? ""}`)
      })
    );
  });
  document.querySelector("#scan").addEventListener("click", () => {
    void (async () => {
      try {
        const tab = await active();
        if (!tab?.id) throw new Error("Abra uma aba do YouTube.");
        const r = await chrome.tabs.sendMessage(tab.id, { type: "GET_SNAPSHOT" });
        if (r.status === "error") throw new Error(r.error);
        status.textContent = "Coleta conclu\xEDda. Abra o espa\xE7o de trabalho.";
      } catch (e) {
        status.textContent = e instanceof Error ? e.message : String(e);
      }
    })();
  });
  void getSettings().then((settings) => {
    const input = document.querySelector("#shorts");
    const feed = settings.hideShortsOnFeed ?? settings.hideShorts, search = settings.hideShortsOnSearch ?? settings.hideShorts;
    input.checked = feed && search;
    input.indeterminate = feed !== search;
    input.addEventListener("change", () => {
      const checked = input.checked;
      void getSettings().then((current) => saveSettings({ ...current, hideShorts: checked, hideShortsOnFeed: checked, hideShortsOnSearch: checked })).catch(() => {
        status.textContent = "N\xE3o foi poss\xEDvel salvar as prefer\xEAncias de Shorts.";
      });
    });
  });
})();
