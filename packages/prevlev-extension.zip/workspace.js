"use strict";
(() => {
  // src/shared/types.ts
  var defaultSettings = {
    hideShorts: false,
    showMetrics: true,
    backendUrl: "",
    backendToken: "",
    aiModel: "",
    aiStreaming: false,
    aiOrigin: "http://127.0.0.1:7814"
  };

  // src/core/parse.ts
  function parseDuration(value2) {
    const text2 = value2.trim();
    const iso = text2.match(
      /^PT(?:(\d+(?:\.\d+)?)H)?(?:(\d+(?:\.\d+)?)M)?(?:(\d+(?:\.\d+)?)S)?$/i
    );
    if (iso && iso.slice(1).some(Boolean))
      return Number(iso[1] ?? 0) * 3600 + Number(iso[2] ?? 0) * 60 + Number(iso[3] ?? 0);
    if (!/^\d+(?::\d{1,2}){1,2}$/.test(text2)) return void 0;
    const parts = text2.split(":").map(Number);
    if (parts.slice(1).some((number4) => number4 >= 60)) return void 0;
    return parts.reduce((sum, number4) => sum * 60 + number4, 0);
  }
  function videoIdFromUrl(raw) {
    try {
      const url = new URL(raw, "https://www.youtube.com");
      if (!["youtube.com", "www.youtube.com", "m.youtube.com", "youtu.be"].includes(
        url.hostname
      ))
        return void 0;
      const id = url.hostname === "youtu.be" ? url.pathname.slice(1).split("/")[0] : url.searchParams.get("v") ?? url.pathname.match(/^\/(?:shorts|embed|live)\/([^/?]+)/)?.[1];
      return id && /^[\w-]{11}$/.test(id) ? id : void 0;
    } catch {
      return void 0;
    }
  }

  // src/core/export.ts
  function toCsv(rows, columns = rows.length ? Object.keys(rows[0]) : []) {
    const cell = (value2) => {
      let text2 = value2 === void 0 || value2 === null ? "" : typeof value2 === "object" ? JSON.stringify(value2) : String(value2);
      if (typeof value2 === "string" && /^[\s]*[=+@-]/.test(text2))
        text2 = `'${text2}`;
      return `"${text2.replace(/"/g, '""')}"`;
    };
    return "\uFEFF" + [
      columns.map(cell).join(","),
      ...rows.map(
        (row3) => columns.map((column) => cell(row3[column])).join(",")
      )
    ].join("\r\n");
  }

  // src/core/observations.ts
  var normalizedName = (value2) => value2.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase();
  function observedLifetimeVph(video, now2 = Date.now()) {
    if (video.views === void 0 || !Number.isFinite(video.views) || video.views < 0 || !video.publishedAt) return void 0;
    const published = knownPublication(video.publishedAt, now2);
    if (published === void 0 || published >= now2) return void 0;
    const result = video.views / ((now2 - published) / 36e5);
    return Number.isFinite(result) ? result : void 0;
  }
  function isoBoundary(value2, endOfDay) {
    if (typeof value2 !== "string")
      throw new Error(
        "Informe uma data ISO v\xE1lida: AAAA-MM-DD ou timestamp com fuso hor\xE1rio."
      );
    const dateOnly = /^\d{4}-\d{2}-\d{2}$/.test(value2);
    const timestamp3 = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::(\d{2})(?:\.(\d{1,3}))?)?(Z|[+-]\d{2}:\d{2})$/.exec(
      value2
    );
    if (!dateOnly && !timestamp3)
      throw new Error(
        "Informe uma data ISO v\xE1lida: AAAA-MM-DD ou timestamp com fuso hor\xE1rio."
      );
    const [year, month, day2] = value2.slice(0, 10).split("-").map(Number);
    const leap = year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
    const days = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    if (month < 1 || month > 12 || day2 < 1 || day2 > days[month - 1])
      throw new Error("A data de publica\xE7\xE3o cont\xE9m um dia ou m\xEAs inv\xE1lido.");
    if (timestamp3) {
      const zone = timestamp3[8];
      if (Number(timestamp3[4]) > 23 || Number(timestamp3[5]) > 59 || Number(timestamp3[6] ?? 0) > 59 || zone !== "Z" && (Number(zone.slice(1, 3)) > 23 || Number(zone.slice(4)) > 59))
        throw new Error("O hor\xE1rio ou fuso da data de publica\xE7\xE3o \xE9 inv\xE1lido.");
    }
    const parsed = Date.parse(
      dateOnly ? `${value2}T${endOfDay ? "23:59:59.999" : "00:00:00.000"}Z` : value2
    );
    if (!Number.isFinite(parsed))
      throw new Error("A data de publica\xE7\xE3o \xE9 inv\xE1lida.");
    return parsed;
  }
  function knownPublication(value2, now2) {
    if (!Number.isFinite(now2)) return void 0;
    try {
      const timestamp3 = isoBoundary(value2, false);
      return timestamp3 <= now2 ? timestamp3 : void 0;
    } catch {
      return void 0;
    }
  }
  function channelIdentity(video) {
    const explicitId = video.channelId?.trim();
    let id = explicitId && /^[A-Za-z0-9_-]{1,128}$/.test(explicitId) ? explicitId : void 0;
    let handle;
    if (video.channelUrl) {
      try {
        const url = new URL(video.channelUrl);
        if (url.protocol === "https:" && ["www.youtube.com", "youtube.com", "m.youtube.com"].includes(
          url.hostname
        ) && !url.username && !url.password && !url.port) {
          const path = decodeURIComponent(url.pathname).replace(/\/$/, "");
          const linkedId = /^\/channel\/([A-Za-z0-9_-]{1,128})$/.exec(path)?.[1];
          if (id && linkedId && id !== linkedId) return { ambiguous: true };
          id ??= linkedId;
          handle = /^\/@([\p{L}\p{N}_.\-·]{1,100})$/u.exec(path)?.[1].normalize("NFC").toLocaleLowerCase();
        }
      } catch {
      }
    }
    const name = video.channel ? normalizedName(video.channel).trim().replace(/\s+/g, " ") || void 0 : void 0;
    return { id, handle, name };
  }
  function comparableChannel(target, peer) {
    if (target.ambiguous || peer.ambiguous) return false;
    if (!target.id && !target.handle && !target.name) return true;
    if (target.id && peer.id) return target.id === peer.id;
    if (target.handle && peer.handle) return target.handle === peer.handle;
    if (target.id || target.handle || peer.id || peer.handle) return false;
    return !!target.name && target.name === peer.name;
  }
  function groupChannelIdentities(videos) {
    const identities = videos.map(channelIdentity), aliases = /* @__PURE__ */ new Map();
    for (const identity of identities) if (!identity.ambiguous && identity.id && identity.handle) {
      const ids = aliases.get(identity.handle) ?? /* @__PURE__ */ new Set();
      ids.add(identity.id);
      aliases.set(identity.handle, ids);
    }
    const grouped = /* @__PURE__ */ new Map();
    videos.forEach((video, index) => {
      const identity = identities[index];
      if (identity.ambiguous) return;
      const linkedIds = identity.handle ? aliases.get(identity.handle) : void 0;
      const id = identity.id ?? (linkedIds?.size === 1 ? [...linkedIds][0] : void 0);
      const key = id ? `id:${id}` : identity.handle ? `handle:${identity.handle}` : identity.name ? `name:${identity.name}` : void 0;
      if (key) grouped.set(video, { key, label: video.channel?.trim() || (id ?? (identity.handle ? `@${identity.handle}` : identity.name)) });
    });
    return grouped;
  }

  // src/core/swipe.ts
  var SWIPE_MAX_ITEMS = 5e3;
  var SWIPE_MAX_BYTES = 4 * 1024 * 1024;
  var plain = (value2) => value2 !== null && typeof value2 === "object" && !Array.isArray(value2);
  var normalizeSwipeText = (value2) => value2.normalize("NFD").replace(new RegExp("\\p{M}", "gu"), "").toLocaleLowerCase("pt-BR").replace(/\s+/g, " ").trim();
  var text = (value2, name, max, fallback = "") => {
    if (value2 === void 0) return fallback;
    if (typeof value2 !== "string" || value2.length > max) throw new Error(`${name} deve ser texto com at\xE9 ${max} caracteres.`);
    return value2.trim();
  };
  function date(value2, name) {
    if (value2 === void 0 || value2 === "") return void 0;
    if (typeof value2 !== "string" || value2.length > 50 || !Number.isFinite(Date.parse(value2)) || !value2.includes("T") || !/(?:Z|[+-]\d{2}:\d{2})$/.test(value2)) throw new Error(`${name} inv\xE1lida; preserve o timestamp com fuso hor\xE1rio.`);
    try {
      return new Date(isoBoundary(value2, false)).toISOString();
    } catch {
      throw new Error(`${name} inv\xE1lida; use um timestamp real com fuso hor\xE1rio.`);
    }
  }
  function safeReferenceUrl(value2) {
    if (typeof value2 !== "string" || value2.length > 4096 || !value2.trim() || value2.includes("\\") || new RegExp("\\p{Cc}", "u").test(value2)) throw new Error("Informe uma URL HTTPS v\xE1lida, sem credenciais.");
    let url;
    try {
      url = new URL(value2.trim());
    } catch {
      throw new Error("Informe uma URL HTTPS v\xE1lida, sem credenciais.");
    }
    if (url.protocol !== "https:" || url.username || url.password) throw new Error("Informe uma URL HTTPS v\xE1lida, sem credenciais.");
    return url.href;
  }
  function inferSwipeType(url) {
    if (videoIdFromUrl(url)) return "video";
    const parsed = new URL(url);
    return /(^|\.)youtube\.com$/.test(parsed.hostname) && /^\/(?:@[^/]+|channel\/[^/]+|c\/[^/]+|user\/[^/]+)\/?$/.test(parsed.pathname) ? "channel" : "other";
  }
  function thumbnail(value2) {
    const url = text(value2, "Thumbnail", 4096);
    return url ? safeReferenceUrl(url) : void 0;
  }
  function legacyImage(value2) {
    if (value2 === void 0 || value2 === "") return void 0;
    if (typeof value2 !== "string") throw new Error("Imagem antiga inv\xE1lida.");
    if (/^data:image\/(?:png|jpeg|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(value2)) return value2;
    return safeReferenceUrl(value2);
  }
  function parseSwipeTags(value2) {
    const source = typeof value2 === "string" ? value2.split(",") : value2 === void 0 ? [] : value2;
    if (!Array.isArray(source) || source.length > 100) throw new Error("Informe at\xE9 20 tags, separadas por v\xEDrgula.");
    const tags = [], seen = /* @__PURE__ */ new Set();
    for (const raw of source) {
      const tag = text(raw, "Tag", 50);
      if (!tag) continue;
      const key = normalizeSwipeText(tag);
      if (!seen.has(key)) {
        seen.add(key);
        tags.push(tag);
      }
    }
    if (tags.length > 20) throw new Error("Cada refer\xEAncia aceita at\xE9 20 tags distintas.");
    return tags;
  }
  function legacyId(value2) {
    let hash = 2166136261;
    for (const character of value2) {
      hash ^= character.codePointAt(0);
      hash = Math.imul(hash, 16777619);
    }
    return `legacy-${(hash >>> 0).toString(16)}`;
  }
  function normalizeSwipeItem(value2, index = 0) {
    if (!plain(value2)) throw new Error("Refer\xEAncia inv\xE1lida na biblioteca.");
    if (value2.source === "youtube-data-api") throw new Error("Refer\xEAncias marcadas como youtube-data-api n\xE3o podem ser persistidas na biblioteca local.");
    if (value2.source !== void 0 && !["youtube-dom", "public-page", "user-provided"].includes(String(value2.source))) throw new Error("Origem da refer\xEAncia desconhecida.");
    const title = text(value2.title, "T\xEDtulo", 1e3);
    if (!title) throw new Error("Informe um t\xEDtulo para a refer\xEAncia.");
    const url = safeReferenceUrl(value2.url), folder = text(value2.folder, "Pasta", 120, "Refer\xEAncias") || "Refer\xEAncias";
    const id = text(value2.id, "ID da refer\xEAncia", 120) || legacyId(`${url}
${index}`);
    if (new RegExp("\\p{Cc}", "u").test(id)) throw new Error("ID da refer\xEAncia inv\xE1lido.");
    const type = value2.type ?? inferSwipeType(url);
    if (!["video", "channel", "other"].includes(String(type))) throw new Error("Tipo de refer\xEAncia desconhecido.");
    const createdAt = date(value2.createdAt, "Data de cria\xE7\xE3o") ?? "", updatedAt = date(value2.updatedAt, "Data de edi\xE7\xE3o");
    const image = legacyImage(value2.image), preview = thumbnail(value2.thumbnail), notes = text(value2.notes, "Notas", 1e4);
    return { id, title, url, folder, type, tags: parseSwipeTags(value2.tags), notes, createdAt, ...updatedAt ? { updatedAt } : {}, ...preview ? { thumbnail: preview } : {}, ...image ? { image } : {}, ...value2.source ? { source: value2.source } : {} };
  }
  function ensureSwipeBudget(items) {
    if (items.length > SWIPE_MAX_ITEMS) throw new Error("A biblioteca aceita at\xE9 5000 refer\xEAncias. Exporte e remova itens antes de adicionar outros.");
    const bytes = new TextEncoder().encode(JSON.stringify({ swipe: items })).byteLength;
    if (bytes > SWIPE_MAX_BYTES) throw new Error("A biblioteca excede 4 MiB. Exporte e reduza notas ou imagens antes de salvar. Nenhum item foi truncado.");
    return bytes;
  }
  function normalizeSwipeLibrary(value2) {
    if (value2 === void 0) return [];
    if (!Array.isArray(value2)) throw new Error("A biblioteca local tem formato incompat\xEDvel; seus dados foram preservados.");
    ensureSwipeBudget(value2);
    const items = value2.map(normalizeSwipeItem);
    ensureSwipeBudget(items);
    return items;
  }
  function createSwipeReference(fields, now2 = (/* @__PURE__ */ new Date()).toISOString()) {
    return normalizeSwipeItem({ ...fields, id: crypto.randomUUID(), createdAt: now2 });
  }
  function editSwipeReference(item, fields, now2 = (/* @__PURE__ */ new Date()).toISOString()) {
    return normalizeSwipeItem({ ...item, ...fields, id: item.id, createdAt: item.createdAt, updatedAt: now2 });
  }
  function swipeIdentity(item) {
    const url = safeReferenceUrl(item.url), id = videoIdFromUrl(url);
    if (id) return `video:${id}`;
    const parsed = new URL(url);
    if (inferSwipeType(url) === "channel") return `channel:${parsed.pathname.startsWith("/@") ? parsed.pathname.toLowerCase().replace(/\/$/, "") : parsed.pathname.replace(/\/$/, "")}`;
    return url;
  }
  function mergeSwipeImport(existing, incoming) {
    const items = normalizeSwipeLibrary([...existing]), ids = new Map(items.map((item) => [item.id, item])), urls = new Set(items.map(swipeIdentity));
    let added = 0, duplicates = 0, conflicts = 0;
    for (const candidate of normalizeSwipeLibrary([...incoming])) {
      const sameId = ids.get(candidate.id), key = swipeIdentity(candidate);
      if (sameId) {
        if (swipeIdentity(sameId) === key) duplicates++;
        else conflicts++;
        continue;
      }
      if (urls.has(key)) {
        duplicates++;
        continue;
      }
      items.push(candidate);
      ids.set(candidate.id, candidate);
      urls.add(key);
      added++;
    }
    ensureSwipeBudget(items);
    return { items, added, duplicates, conflicts };
  }
  function filterSwipe(items, filter = {}) {
    const words = normalizeSwipeText(filter.query ?? "").split(" ").filter(Boolean);
    return normalizeSwipeLibrary([...items]).filter((item) => {
      if (filter.folder && normalizeSwipeText(item.folder) !== normalizeSwipeText(filter.folder)) return false;
      if (filter.tag && !item.tags.some((tag) => normalizeSwipeText(tag) === normalizeSwipeText(filter.tag))) return false;
      if (filter.type && item.type !== filter.type) return false;
      const haystack = normalizeSwipeText([item.title, item.url, item.folder, item.notes, ...item.tags].join(" "));
      return words.every((word) => haystack.includes(word));
    });
  }
  function parseSwipeImport(value2) {
    if (plain(value2) && value2.source === "youtube-data-api") throw new Error("Dados da API oficial n\xE3o podem alimentar a biblioteca local.");
    if (Array.isArray(value2)) return normalizeSwipeLibrary(value2);
    if (!plain(value2) || value2.format !== "prevlev-swipe" || value2.version !== 2 || !Array.isArray(value2.items)) throw new Error("Use um JSON Prevlev Swipe vers\xE3o 2 ou uma lista antiga de refer\xEAncias.");
    return normalizeSwipeLibrary(value2.items);
  }
  function exportSwipeJson(items, now2 = (/* @__PURE__ */ new Date()).toISOString()) {
    return JSON.stringify({ format: "prevlev-swipe", version: 2, exportedAt: date(now2, "Data da exporta\xE7\xE3o"), items: normalizeSwipeLibrary([...items]) }, null, 2);
  }
  function exportSwipeCsv(items) {
    return toCsv(normalizeSwipeLibrary([...items]).map((item) => ({ ...item })), ["id", "type", "title", "url", "folder", "tags", "notes", "thumbnail", "createdAt", "updatedAt", "source"]);
  }
  function parseSwipeCsv(input) {
    if (new TextEncoder().encode(input).byteLength > SWIPE_MAX_BYTES) throw new Error("O CSV excede 4 MiB. Nenhuma refer\xEAncia foi alterada.");
    const csv = input.replace(/^\uFEFF/, ""), rows = [];
    let row3 = [], cell = "", quoted = false, closed = false;
    const finishCell = () => {
      row3.push(cell);
      cell = "";
      closed = false;
      if (row3.length > 20) throw new Error("O CSV tem colunas demais. Use o formato exportado pelo Prevlev.");
    };
    const finishRow = () => {
      finishCell();
      if (row3.some((value2) => value2 !== "")) rows.push(row3);
      row3 = [];
      if (rows.length > SWIPE_MAX_ITEMS + 1) throw new Error("O CSV aceita at\xE9 5000 refer\xEAncias.");
    };
    for (let index = 0; index < csv.length; index++) {
      const character = csv[index];
      if (quoted) {
        if (character === '"') {
          if (csv[index + 1] === '"') {
            cell += '"';
            index++;
          } else {
            quoted = false;
            closed = true;
          }
        } else cell += character;
        continue;
      }
      if (character === ",") {
        finishCell();
        continue;
      }
      if (character === "\n" || character === "\r") {
        if (character === "\r" && csv[index + 1] === "\n") index++;
        finishRow();
        continue;
      }
      if (character === '"') {
        if (cell || closed) throw new Error("Aspas inv\xE1lidas no CSV.");
        quoted = true;
        continue;
      }
      if (closed) throw new Error("Conte\xFAdo inv\xE1lido ap\xF3s aspas no CSV.");
      cell += character;
    }
    if (quoted) throw new Error("O CSV terminou com aspas abertas.");
    if (cell || row3.length || closed) finishRow();
    const headers = rows.shift();
    if (!headers || !headers.includes("title") || !headers.includes("url") || new Set(headers).size !== headers.length) throw new Error("O CSV exige colunas title e url, sem cabe\xE7alhos duplicados.");
    const allowed = /* @__PURE__ */ new Set(["id", "type", "title", "url", "folder", "tags", "notes", "thumbnail", "createdAt", "updatedAt", "source"]);
    if (headers.some((header) => !allowed.has(header))) throw new Error("O CSV cont\xE9m uma coluna desconhecida. Use o formato exportado pelo Prevlev.");
    return normalizeSwipeLibrary(rows.map((values) => {
      if (values.length !== headers.length) throw new Error("Uma linha CSV tem quantidade diferente de colunas.");
      const item = {};
      headers.forEach((header, index) => {
        if (values[index] !== "" || header === "title" || header === "url") item[header] = values[index];
      });
      if (typeof item.tags === "string" && item.tags.trim().startsWith("[")) {
        try {
          item.tags = JSON.parse(item.tags);
        } catch {
          throw new Error("Tags JSON inv\xE1lidas no CSV.");
        }
      }
      return item;
    }));
  }

  // src/shared/storage.ts
  var getSettings = async () => {
    const stored = (await chrome.storage.local.get("settings")).settings;
    return {
      ...defaultSettings,
      ...stored && typeof stored === "object" ? stored : {}
    };
  };
  var saveSettings = async (settings) => chrome.storage.local.set({ settings });
  var getSnapshot = async () => (await chrome.storage.local.get("snapshot")).snapshot;
  var getSwipe = async () => normalizeSwipeLibrary((await chrome.storage.local.get("swipe")).swipe);
  var swipeWrites = Promise.resolve();
  function serializeSwipe(operation) {
    const locked = async () => {
      const locks = globalThis.navigator?.locks;
      if (locks) {
        let result2;
        await locks.request("prevlev-swipe-library", { mode: "exclusive" }, async () => {
          result2 = await operation();
        });
        return result2;
      }
      if (typeof document !== "undefined") throw new Error("Este navegador n\xE3o oferece bloqueio seguro entre janelas para salvar a biblioteca. Use uma vers\xE3o atual do Chrome.");
      return operation();
    };
    const result = swipeWrites.then(locked, locked);
    swipeWrites = result.catch(() => void 0);
    return result;
  }
  async function commitSwipe(items) {
    const normalized2 = normalizeSwipeLibrary(items);
    ensureSwipeBudget(normalized2);
    try {
      await chrome.storage.local.set({ swipe: normalized2 });
    } catch {
      throw new Error("O navegador n\xE3o conseguiu salvar a biblioteca local (cota ou acesso ao armazenamento). Exporte seus dados e libere espa\xE7o antes de tentar novamente.");
    }
  }
  function updateSwipe(mutator) {
    return serializeSwipe(async () => {
      const current = await getSwipe(), next = await mutator(current);
      await commitSwipe(next);
      return normalizeSwipeLibrary(next);
    });
  }
  var saveSwipe = (items) => serializeSwipe(() => commitSwipe(items));

  // src/shared/backend.ts
  function backendOrigin(value2) {
    const u = new URL(value2);
    if (u.username || u.password || u.search || u.hash || u.pathname !== "/")
      throw new Error(
        "Use somente a origem do backend, sem caminho, senha ou par\xE2metros."
      );
    if (u.protocol !== "https:" && !(u.protocol === "http:" && ["localhost", "127.0.0.1"].includes(u.hostname)))
      throw new Error("Use HTTPS ou HTTP local.");
    if (/(^|\.)nexlev\./i.test(u.hostname))
      throw new Error("Configure seu pr\xF3prio backend.");
    return u.origin;
  }
  async function callBackend(settings, feature, payload) {
    if (!settings.backendUrl)
      return {
        status: "not_configured",
        source: "Prevlev",
        error: "Configure um backend pr\xF3prio na aba Conex\xE3o."
      };
    const origin = backendOrigin(settings.backendUrl);
    let response;
    try {
      response = await fetch(`${origin}/v1/analyze`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...settings.backendToken ? { Authorization: `Bearer ${settings.backendToken}` } : {}
        },
        body: JSON.stringify({ feature, payload }),
        credentials: "omit",
        redirect: "error",
        signal: AbortSignal.timeout(isAiFeature(feature) ? 305e3 : 45e3)
      });
    } catch {
      throw new Error(
        "N\xE3o foi poss\xEDvel concluir a conex\xE3o com o backend Prevlev. O resultado da solicita\xE7\xE3o \xE9 incerto; nenhuma repeti\xE7\xE3o foi enviada. Confira o servi\xE7o antes de reenviar."
      );
    }
    let body;
    try {
      body = await response.json();
    } catch {
      throw new Error(
        "O backend Prevlev n\xE3o devolveu uma resposta JSON completa. O resultado da solicita\xE7\xE3o \xE9 incerto; nenhuma repeti\xE7\xE3o foi enviada."
      );
    }
    if (!body || typeof body !== "object" || Array.isArray(body))
      throw new Error("Resposta incompat\xEDvel com o contrato Prevlev.");
    if (!response.ok && !body.error)
      throw new Error(`Backend respondeu HTTP ${response.status}`);
    if (!["ok", "not_configured", "unsupported", "error"].includes(body.status) || typeof body.source !== "string")
      throw new Error("Resposta incompat\xEDvel com o contrato Prevlev.");
    return body;
  }
  function isAiFeature(feature) {
    return [
      "comment-analysis",
      "thumbnail-generation",
      "transcript-summary",
      "transcript-topics",
      "transcript-script"
    ].includes(feature);
  }
  async function callBackendOperation(settings, path, payload, signal) {
    if (!["/v1/youtube/search", "/v1/history", "/v1/library"].includes(path))
      throw new Error("Opera\xE7\xE3o de backend desconhecida.");
    if (!settings.backendUrl)
      return {
        status: "not_configured",
        source: "prevlev:client",
        error: "Configure e salve seu backend Prevlev na aba Conex\xE3o."
      };
    const origin = backendOrigin(settings.backendUrl);
    const requestSignal = signal ? AbortSignal.any([signal, AbortSignal.timeout(45e3)]) : AbortSignal.timeout(45e3);
    try {
      requestSignal.throwIfAborted();
      const response = await fetch(`${origin}${path}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...settings.backendToken ? { Authorization: `Bearer ${settings.backendToken}` } : {}
        },
        body: JSON.stringify(payload),
        credentials: "omit",
        redirect: "error",
        signal: requestSignal
      });
      const maxBytes = 12 * 1024 * 1024;
      if (Number(response.headers.get("content-length")) > maxBytes) {
        await response.body?.cancel();
        throw new Error("Resposta do backend excedeu o limite de leitura.");
      }
      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      let raw = "", bytes = 0;
      if (reader) {
        try {
          for (; ; ) {
            const { done, value: value2 } = await reader.read();
            if (done) break;
            bytes += value2.byteLength;
            if (bytes > maxBytes) {
              await reader.cancel();
              throw new Error("Resposta do backend excedeu o limite de leitura.");
            }
            raw += decoder.decode(value2, { stream: true });
          }
          raw += decoder.decode();
        } finally {
          reader.releaseLock();
        }
      }
      requestSignal.throwIfAborted();
      let body;
      try {
        body = JSON.parse(raw);
      } catch {
        throw new Error("O backend n\xE3o devolveu JSON completo. O resultado \xE9 incerto; consulte o hist\xF3rico antes de reenviar uma altera\xE7\xE3o. Nenhuma repeti\xE7\xE3o foi enviada.");
      }
      if (!body || typeof body !== "object" || Array.isArray(body) || !["ok", "not_configured", "unsupported", "error"].includes(body.status) || typeof body.source !== "string") throw new Error("Resposta incompat\xEDvel com o contrato Prevlev.");
      if (!response.ok && !body.error)
        throw new Error(`Backend respondeu HTTP ${response.status}. Nenhuma repeti\xE7\xE3o foi enviada.`);
      return body;
    } catch (error) {
      if (signal?.aborted)
        throw new DOMException("Solicita\xE7\xE3o cancelada. Uma opera\xE7\xE3o j\xE1 aceita pelo servidor pode ter sido conclu\xEDda.", "AbortError");
      if (error instanceof Error && error.message.startsWith("Resposta")) throw error;
      if (error instanceof Error && (error.message.startsWith("O backend") || error.message.startsWith("Backend respondeu"))) throw error;
      throw new Error("N\xE3o foi poss\xEDvel concluir a opera\xE7\xE3o no backend Prevlev. O resultado \xE9 incerto; confira o servi\xE7o antes de reenviar. Nenhuma repeti\xE7\xE3o foi enviada.");
    }
  }
  async function fetchAiCatalog(settings) {
    if (!settings.backendUrl)
      return {
        status: "not_configured",
        source: "prevlev:client",
        error: "Configure e salve o backend Prevlev antes de consultar o OmniProviders."
      };
    const origin = backendOrigin(settings.backendUrl);
    let response;
    try {
      response = await fetch(`${origin}/v1/ai/catalog`, {
        headers: settings.backendToken ? { Authorization: `Bearer ${settings.backendToken}` } : {},
        credentials: "omit",
        redirect: "error",
        signal: AbortSignal.timeout(3e4)
      });
    } catch {
      throw new Error(
        "O backend Prevlev est\xE1 offline ou n\xE3o respondeu ao cat\xE1logo. Confira o endere\xE7o e inicie npm run server na m\xE1quina do OmniProviders."
      );
    }
    let body;
    try {
      body = await response.json();
    } catch {
      throw new Error(
        "O cat\xE1logo do backend Prevlev n\xE3o retornou JSON completo. Nenhuma gera\xE7\xE3o foi solicitada."
      );
    }
    if (!body || typeof body !== "object" || Array.isArray(body))
      throw new Error("Cat\xE1logo incompat\xEDvel com o backend Prevlev.");
    if (!["ok", "not_configured", "unsupported", "error"].includes(body.status) || typeof body.source !== "string")
      throw new Error("Cat\xE1logo incompat\xEDvel com o backend Prevlev.");
    if (body.status === "ok" && (!body.data || typeof body.data.origin !== "string" || !Array.isArray(body.data.models) || body.data.models.length > 1e4 || body.data.models.some(
      (m) => !m || typeof m !== "object" || typeof m.id !== "string" || !/^[a-z][a-z0-9_-]*:[^\s]{1,400}$/i.test(m.id) || typeof m.provider !== "string" || m.provider !== m.id.slice(0, m.id.indexOf(":")) || typeof m.label !== "string" || ![m.operations, m.outputModalities, m.inputModalities].every(
        (a) => Array.isArray(a) && a.every((s) => typeof s === "string")
      ) || typeof m.streaming !== "boolean" || typeof m.textSupported !== "boolean" || typeof m.imageSupported !== "boolean" || m.textSupported && (!m.inputModalities.includes("text") || !m.outputModalities.includes("text") || !m.operations.some(
        (o) => o === "responses" || o === "chat.completions"
      )) || m.imageSupported && (!m.inputModalities.includes("text") || !m.outputModalities.includes("image") || !m.operations.includes("images.generate"))
    ) || !Array.isArray(body.data.warnings)))
      throw new Error("O backend retornou um cat\xE1logo sem capacidades v\xE1lidas.");
    return body;
  }

  // src/core/metrics.ts
  function median(values) {
    const sorted = values.filter(Number.isFinite).sort((a, b) => a - b);
    const middle = Math.floor(sorted.length / 2);
    return sorted.length ? sorted.length % 2 ? sorted[middle] : sorted[middle - 1] / 2 + sorted[middle] / 2 : void 0;
  }
  function lifetimeVph(video, now2 = Date.now()) {
    return observedLifetimeVph(video, now2);
  }
  function outlierScore(video, baseline) {
    if (video.views === void 0 || !Number.isFinite(video.views) || video.views < 0)
      return void 0;
    const channel = channelIdentity(video);
    const values = baseline.filter(
      (other) => other.id !== video.id && other.isShort === video.isShort && comparableChannel(channel, channelIdentity(other))
    ).map((other) => other.views).filter(
      (value2) => value2 !== void 0 && Number.isFinite(value2) && value2 >= 0
    );
    if (values.length < 3) return void 0;
    const reference = median(values);
    return reference && reference > 0 ? video.views / reference : void 0;
  }
  function summarizeVideos(videos, now2 = Date.now()) {
    const views = videos.map((video) => video.views).filter(
      (value2) => value2 !== void 0 && Number.isFinite(value2) && value2 >= 0
    );
    const rates = videos.map((video) => lifetimeVph(video, now2)).filter((value2) => value2 !== void 0);
    const sum = views.reduce((total2, value2) => total2 + value2, 0);
    return {
      count: videos.length,
      knownViews: views.length,
      totalViews: sum,
      meanViews: views.length ? sum / views.length : void 0,
      medianViews: median(views),
      medianVph: median(rates),
      shorts: videos.filter((video) => video.isShort).length,
      coverage: "loaded-videos"
    };
  }
  function netProfit(revenue, costPerVideo, videoCount) {
    if (![revenue, costPerVideo, videoCount].every(Number.isFinite) || costPerVideo < 0 || videoCount < 0 || !Number.isInteger(videoCount))
      throw new Error(
        "Informe receita v\xE1lida, custo n\xE3o negativo e quantidade inteira n\xE3o negativa."
      );
    const cost = costPerVideo * videoCount;
    return {
      revenue,
      cost,
      profit: revenue - cost,
      margin: revenue ? (revenue - cost) / revenue * 100 : void 0
    };
  }
  function validateVideoFilter(filter) {
    const pairs = [
      ["minViews", "maxViews", "visualiza\xE7\xF5es"],
      ["minSubscribers", "maxSubscribers", "inscritos"],
      ["minVph", "maxVph", "VPH"],
      ["minOutlier", "maxOutlier", "outlier"],
      ["minDurationSeconds", "maxDurationSeconds", "dura\xE7\xE3o em segundos"]
    ];
    for (const [minKey, maxKey, label] of pairs) {
      const min = filter[minKey], max = filter[maxKey];
      for (const value2 of [min, max]) {
        if (value2 !== void 0 && (typeof value2 !== "number" || !Number.isFinite(value2) || value2 < 0))
          throw new Error(
            `O filtro de ${label} exige valores finitos n\xE3o negativos.`
          );
      }
      if (min !== void 0 && max !== void 0 && min > max)
        throw new Error(
          `No filtro de ${label}, o m\xEDnimo n\xE3o pode superar o m\xE1ximo.`
        );
    }
    const after = filter.publishedAfter === void 0 ? void 0 : isoBoundary(filter.publishedAfter, false);
    const before = filter.publishedBefore === void 0 ? void 0 : isoBoundary(filter.publishedBefore, true);
    if (after !== void 0 && before !== void 0 && after > before)
      throw new Error(
        "A data inicial de publica\xE7\xE3o n\xE3o pode superar a data final."
      );
    if (filter.shorts !== void 0 && !["all", "only", "exclude"].includes(filter.shorts))
      throw new Error("Selecione um filtro de Shorts v\xE1lido.");
  }
  function filterVideos(videos, filter, now2 = Date.now()) {
    validateVideoFilter(filter);
    const after = filter.publishedAfter === void 0 ? void 0 : isoBoundary(filter.publishedAfter, false);
    const before = filter.publishedBefore === void 0 ? void 0 : isoBoundary(filter.publishedBefore, true);
    const query = normalize(filter.query ?? "");
    return videos.filter((video) => {
      if (query && !normalize(`${video.title} ${video.channel ?? ""}`).includes(query))
        return false;
      if (filter.channel && !normalize(
        `${video.channel ?? ""} ${video.channelId ?? ""} ${video.channelUrl ?? ""}`
      ).includes(normalize(filter.channel)))
        return false;
      if (filter.shorts === "only" && video.isShort !== true || filter.shorts === "exclude" && video.isShort !== false)
        return false;
      if (after !== void 0 || before !== void 0) {
        const published = video.publishedAt ? knownPublication(video.publishedAt, now2) : void 0;
        if (published === void 0 || after !== void 0 && published < after || before !== void 0 && published > before)
          return false;
      }
      const constraints = [
        [video.views, filter.minViews, filter.maxViews],
        [video.subscribers, filter.minSubscribers, filter.maxSubscribers],
        [
          video.durationSeconds,
          filter.minDurationSeconds,
          filter.maxDurationSeconds
        ],
        [lifetimeVph(video, now2), filter.minVph, filter.maxVph],
        [outlierScore(video, videos), filter.minOutlier, filter.maxOutlier]
      ];
      return constraints.every(
        ([value2, min, max]) => min === void 0 && max === void 0 || value2 !== void 0 && Number.isFinite(value2) && value2 >= 0 && (min === void 0 || value2 >= min) && (max === void 0 || value2 <= max)
      );
    });
  }
  function sortVideos(videos, by, now2 = Date.now(), baseline = videos) {
    if (by === "title")
      return [...videos].sort((a, b) => a.title.localeCompare(b.title));
    const get = (video) => {
      if (by === "recent")
        return video.publishedAt ? knownPublication(video.publishedAt, now2) : void 0;
      const value2 = by === "views" ? video.views : by === "duration" ? video.durationSeconds : by === "subscribers" ? video.subscribers : by === "vph" ? lifetimeVph(video, now2) : outlierScore(video, baseline);
      return value2 !== void 0 && Number.isFinite(value2) && value2 >= 0 ? value2 : void 0;
    };
    return [...videos].sort((a, b) => {
      const left = get(a), right = get(b);
      const knownLeft = left !== void 0 && Number.isFinite(left), knownRight = right !== void 0 && Number.isFinite(right);
      return knownLeft && knownRight ? right - left : knownLeft ? -1 : knownRight ? 1 : 0;
    });
  }
  function filterComments(comments, filter) {
    return comments.filter(
      (comment) => (!filter.query || normalize(comment.text).includes(normalize(filter.query))) && (!filter.author || normalize(comment.author).includes(normalize(filter.author))) && (!filter.questionsOnly || /[?？]/.test(comment.text)) && (filter.minLikes === void 0 || comment.likes !== void 0 && comment.likes >= filter.minLikes) && (filter.minReplies === void 0 || comment.replies !== void 0 && comment.replies >= filter.minReplies) && (filter.hearted === void 0 || comment.hearted === filter.hearted)
    );
  }
  function normalize(value2) {
    return value2.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase();
  }

  // src/core/research.ts
  var researchSortKeys = ["views", "vph", "outlier", "recent", "duration", "subscribers", "title", "viewsPerSubscriber"];
  var researchSortLabels = { views: "visualiza\xE7\xF5es", vph: "VPH m\xE9dio hist\xF3rico", outlier: "outlier da amostra", recent: "data de publica\xE7\xE3o", duration: "dura\xE7\xE3o", subscribers: "inscritos conhecidos", title: "t\xEDtulo", viewsPerSubscriber: "views por inscrito conhecido" };
  var researchSurfaces = ["home", "subscriptions", "search", "channel", "other"];
  function researchSurface(rawUrl) {
    try {
      const url = new URL(rawUrl);
      if (url.protocol !== "https:" || !["www.youtube.com", "youtube.com", "m.youtube.com"].includes(url.hostname) || url.username || url.password || url.port) return "other";
      if (url.pathname === "/results") return "search";
      if (url.pathname === "/feed/subscriptions") return "subscriptions";
      if (url.pathname === "/") return "home";
      if (/^\/(?:@[^/]+|channel\/[^/]+|c\/[^/]+|user\/[^/]+)(?:\/|$)/.test(url.pathname)) return "channel";
      return "other";
    } catch {
      return "other";
    }
  }
  function validateResearchFilter(filter) {
    validateVideoFilter(filter);
    if (filter.surface !== void 0 && !researchSurfaces.includes(filter.surface)) throw new Error("Contexto de pesquisa desconhecido.");
    if (filter.criteria !== void 0 && (!Array.isArray(filter.criteria) || filter.criteria.length > 2)) throw new Error("Use no m\xE1ximo dois crit\xE9rios de ordena\xE7\xE3o.");
    const keys = /* @__PURE__ */ new Set();
    for (const criterion of filter.criteria ?? []) {
      if (!criterion || !researchSortKeys.includes(criterion.key) || !["asc", "desc"].includes(criterion.direction)) throw new Error("Crit\xE9rio ou dire\xE7\xE3o de ordena\xE7\xE3o inv\xE1lidos.");
      if (keys.has(criterion.key)) throw new Error("Os dois crit\xE9rios de ordena\xE7\xE3o devem ser diferentes.");
      if (criterion.key === "viewsPerSubscriber" && filter.surface === "channel") throw new Error("A raz\xE3o views por inscrito s\xF3 est\xE1 dispon\xEDvel fora de p\xE1ginas de canal.");
      keys.add(criterion.key);
    }
    if (filter.priority !== void 0 && !["none", "views-per-subscriber"].includes(filter.priority)) throw new Error("Prioridade de pesquisa inv\xE1lida.");
    if (filter.priority === "views-per-subscriber" && filter.surface === "channel") throw new Error("A prioridade views por inscrito s\xF3 est\xE1 dispon\xEDvel fora de p\xE1ginas de canal.");
    if (filter.comparisonMode !== void 0 && !["sample-median", "sample-channel-reference"].includes(filter.comparisonMode)) throw new Error("Modo de compara\xE7\xE3o de outlier desconhecido.");
    if (filter.subscribersBelow !== void 0 && (typeof filter.subscribersBelow !== "number" || !Number.isFinite(filter.subscribersBelow) || filter.subscribersBelow <= 0)) throw new Error("O limite exclusivo de inscritos deve ser finito e positivo.");
    if (filter.subscribersBelow !== void 0 && filter.minSubscribers !== void 0 && filter.minSubscribers >= filter.subscribersBelow) throw new Error("O m\xEDnimo de inscritos deve ser menor que o limite exclusivo.");
    if (filter.publishedBeforeExclusive !== void 0) {
      const before = isoBoundary(filter.publishedBeforeExclusive, false);
      if (filter.publishedAfter !== void 0 && isoBoundary(filter.publishedAfter, false) >= before) throw new Error("O in\xEDcio da publica\xE7\xE3o deve preceder o limite final exclusivo.");
    }
    for (const key of ["hideShortsOnFeed", "hideShortsOnSearch"]) if (filter[key] !== void 0 && typeof filter[key] !== "boolean") throw new Error("As prefer\xEAncias de Shorts devem ser booleanas.");
  }
  function viewsPerSubscriber(video) {
    if (video.source === "youtube-data-api") return void 0;
    const views = count(video.views), subscribers = count(video.subscribers);
    if (views === void 0 || subscribers === void 0 || subscribers <= 0) return void 0;
    return finite(views / subscribers);
  }
  function researchComparison(video, fullBaseline, mode = "sample-median") {
    const baseline = fullBaseline.filter((item) => item.source !== "youtube-data-api");
    const identity = channelIdentity(video);
    const peers = baseline.filter((peer) => peer.id !== video.id && peer.isShort === video.isShort && comparableChannel(identity, channelIdentity(peer)) && count(peer.views) !== void 0);
    const values = peers.map((peer) => peer.views);
    const positive2 = values.filter((value2) => value2 > 0);
    const limitation = "Compara\xE7\xE3o aproximada de observa\xE7\xF5es carregadas. A refer\xEAncia completa do canal n\xE3o \xE9 conhecida; n\xE3o equivale ao \xEDndice propriet\xE1rio da Nexlev.";
    if (video.source === "youtube-data-api") return { referenceCount: 0, positiveReferenceCount: 0, method: "sample-median", provenance: "loaded-observations", limitation: "Dados da API oficial n\xE3o recebem m\xE9tricas derivadas." };
    if (mode === "sample-median") {
      const reference2 = values.length >= 3 ? sampleMedian(values) : void 0, views2 = count(video.views);
      return { score: views2 !== void 0 && reference2 !== void 0 && reference2 > 0 ? finite(views2 / reference2) : void 0, reference: reference2, referenceCount: values.length, positiveReferenceCount: positive2.length, method: "sample-median", provenance: "loaded-observations", limitation };
    }
    const method = video.isShort === true && positive2.length >= 10 ? "sample-shorts-median" : "sample-channel-mean";
    const knownIdentity = !identity.ambiguous && !!(identity.id || identity.handle || identity.name);
    const reference = knownIdentity && values.length >= 3 ? method === "sample-shorts-median" ? sampleMedian(positive2) : finite(values.reduce((sum, value2) => sum + value2 / values.length, 0)) : void 0;
    const views = count(video.views);
    return { score: views !== void 0 && reference !== void 0 && reference > 0 ? finite(views / reference) : void 0, reference, referenceCount: values.length, positiveReferenceCount: positive2.length, method, provenance: "loaded-observations", limitation };
  }
  function sortResearchVideos(videos, filter = {}, now2 = Date.now(), fullBaseline = videos) {
    validateResearchFilter(filter);
    const eligible = videos.filter((video) => video.source !== "youtube-data-api");
    const baseline = fullBaseline.filter((video) => video.source !== "youtube-data-api");
    const legacy = filter.sort === "date" ? "recent" : filter.sort;
    const criteria = filter.criteria ?? (legacy && legacy !== "default" && researchSortKeys.includes(legacy) ? [{ key: legacy, direction: legacy === "title" ? "asc" : "desc" }] : []);
    const rankedCriteria = filter.priority === "views-per-subscriber" ? [{ key: "viewsPerSubscriber", direction: "desc" }, ...criteria.filter((criterion) => criterion.key !== "viewsPerSubscriber")] : criteria;
    const scores = /* @__PURE__ */ new Map();
    for (const video of eligible) {
      const values = /* @__PURE__ */ new Map();
      for (const { key } of rankedCriteria) values.set(key, key === "title" ? video.title.normalize("NFC").toLocaleLowerCase() : key === "views" ? count(video.views) : key === "subscribers" ? count(video.subscribers) : key === "duration" ? count(video.durationSeconds) : key === "recent" ? video.publishedAt ? knownPublication(video.publishedAt, now2) : void 0 : key === "vph" ? lifetimeVph(video, now2) : key === "viewsPerSubscriber" ? viewsPerSubscriber(video) : researchComparison(video, baseline, filter.comparisonMode).score);
      scores.set(video, values);
    }
    return [...eligible].sort((left, right) => {
      for (const criterion of rankedCriteria) {
        const a = scores.get(left).get(criterion.key), b = scores.get(right).get(criterion.key);
        if (a === void 0 || b === void 0) {
          if (a !== b) return a === void 0 ? 1 : -1;
          continue;
        }
        const comparison = typeof a === "string" && typeof b === "string" ? a.localeCompare(b) : a - b;
        if (comparison) return criterion.direction === "asc" ? comparison : -comparison;
      }
      return 0;
    });
  }
  function selectResearchVideos(videos, filter = {}, now2 = Date.now()) {
    validateResearchFilter(filter);
    const baseline = videos.filter((video) => video.source !== "youtube-data-api");
    const basic = { ...filter, minOutlier: void 0, maxOutlier: void 0 };
    const selected = filterVideos(baseline, basic, now2).filter((video) => {
      if (filter.subscribersBelow !== void 0 && (count(video.subscribers) === void 0 || video.subscribers >= filter.subscribersBelow)) return false;
      if (filter.publishedBeforeExclusive !== void 0 && (!video.publishedAt || knownPublication(video.publishedAt, now2) === void 0 || knownPublication(video.publishedAt, now2) >= isoBoundary(filter.publishedBeforeExclusive, false))) return false;
      if (video.isShort === true && (filter.hideShortsOnSearch && filter.surface === "search" || filter.hideShortsOnFeed && (filter.surface === "home" || filter.surface === "subscriptions"))) return false;
      if (filter.minOutlier !== void 0 || filter.maxOutlier !== void 0) {
        const score = researchComparison(video, baseline, filter.comparisonMode).score;
        if (score === void 0 || filter.minOutlier !== void 0 && score < filter.minOutlier || filter.maxOutlier !== void 0 && score > filter.maxOutlier) return false;
      }
      return true;
    });
    return sortResearchVideos(selected, filter, now2, baseline);
  }
  function researchPresets(surface, now2 = Date.now()) {
    if (!Number.isFinite(now2) || Math.abs(now2) > 864e13) throw new Error("Instante atual inv\xE1lido para os atalhos.");
    const since = (days) => new Date(now2 - days * 864e5).toISOString();
    const sorted = (key) => ({ surface, criteria: [{ key, direction: "desc" }] });
    return [
      { id: "day-views", label: "Views nas publica\xE7\xF5es de 24 horas", description: "Publicados nas \xFAltimas 24 horas, por views observadas. N\xE3o mede tr\xE1fego nas \xFAltimas 24 horas.", available: true, filter: { ...sorted("views"), publishedAfter: since(1) } },
      { id: "week-recent", label: "Publica\xE7\xF5es recentes de 7 dias", description: "Publicados nos \xFAltimos 7 dias, mais recentes primeiro.", available: true, filter: { ...sorted("recent"), publishedAfter: since(7) } },
      { id: "million-month", label: "Um milh\xE3o em publica\xE7\xF5es de 30 dias", description: "Pelo menos 1 milh\xE3o de views e publica\xE7\xE3o nos \xFAltimos 30 dias.", available: true, filter: { ...sorted("views"), minViews: 1e6, publishedAfter: since(30) } },
      { id: "small-channel-50k", label: "50 mil views, canal abaixo de 10 mil", description: "Pelo menos 50 mil views e menos de 10 mil inscritos conhecidos.", available: true, filter: { ...sorted("views"), minViews: 5e4, subscribersBelow: 1e4 } },
      { id: "micro-channel-90d", label: "10 mil views em canal pequeno, 90 dias", description: "Pelo menos 10 mil views, menos de 5 mil inscritos e publica\xE7\xE3o nos \xFAltimos 90 dias.", available: true, filter: { ...sorted("views"), minViews: 1e4, subscribersBelow: 5e3, publishedAfter: since(90) } },
      { id: "growing-channel", label: "100 mil views, canal de 10 a 100 mil", description: "Pelo menos 100 mil views e entre 10 mil e 100 mil inscritos, incluindo os limites.", available: true, filter: { ...sorted("views"), minViews: 1e5, minSubscribers: 1e4, maxSubscribers: 1e5 } },
      { id: "lifetime-vph", label: "Maior VPH m\xE9dio desde publica\xE7\xE3o", description: "Ordena pelo VPH m\xE9dio hist\xF3rico; n\xE3o mede os \xFAltimos 60 minutos.", available: true, filter: sorted("vph") },
      { id: "sample-outlier", label: "Outlier da amostra a partir de 5\xD7", description: surface === "channel" ? "Outlier local de pelo menos 5\xD7." : "Outlier local de pelo menos 5\xD7 e canal abaixo de 50 mil inscritos.", available: true, filter: { ...sorted("outlier"), minOutlier: 5, ...surface === "channel" ? {} : { subscribersBelow: 5e4 } } },
      { id: "evergreen-vph", label: "Mais de 365 dias por VPH m\xE9dio", description: "Publicados h\xE1 mais de 365 dias, com maior VPH m\xE9dio primeiro.", available: true, filter: { ...sorted("vph"), publishedBeforeExclusive: since(365) } },
      { id: "search-shorts", label: "Shorts por VPH na busca", description: "Somente na busca: Shorts por VPH m\xE9dio hist\xF3rico.", available: surface === "search", filter: { ...sorted("vph"), shorts: "only" } },
      { id: "deep-dives", label: "Explorar v\xEDdeos longos", description: surface === "channel" ? "Na p\xE1gina de canal: dura\xE7\xE3o conhecida de pelo menos 20 minutos." : "Na busca: v\xEDdeos conhecidos como n\xE3o Shorts.", available: surface === "search" || surface === "channel", filter: { ...sorted("views"), ...surface === "channel" ? { minDurationSeconds: 1200 } : { shorts: "exclude" } } }
    ];
  }
  function researchPreset(id, surface, now2 = Date.now()) {
    const preset = researchPresets(surface, now2).find((preset2) => preset2.id === id);
    if (!preset || !preset.available) throw new Error("Atalho indispon\xEDvel neste contexto de p\xE1gina.");
    return preset;
  }
  function describeResearchFilter(filter) {
    const parts = [];
    if (filter.query) parts.push(`texto \u201C${filter.query}\u201D`);
    if (filter.channel) parts.push(`canal \u201C${filter.channel}\u201D`);
    const labels2 = { minViews: "views m\xEDnimas", maxViews: "views m\xE1ximas", minSubscribers: "inscritos m\xEDnimos", maxSubscribers: "inscritos m\xE1ximos", minDurationSeconds: "dura\xE7\xE3o m\xEDnima (s)", maxDurationSeconds: "dura\xE7\xE3o m\xE1xima (s)", minVph: "VPH m\xEDnimo", maxVph: "VPH m\xE1ximo", minOutlier: "outlier m\xEDnimo", maxOutlier: "outlier m\xE1ximo" };
    for (const key of Object.keys(labels2)) if (filter[key] !== void 0) parts.push(`${labels2[key]}: ${filter[key]}`);
    if (filter.subscribersBelow !== void 0) parts.push(`inscritos estritamente abaixo de ${filter.subscribersBelow}`);
    if (filter.publishedAfter) parts.push(`publica\xE7\xE3o a partir de ${filter.publishedAfter}`);
    if (filter.publishedBefore) parts.push(`publica\xE7\xE3o at\xE9 ${filter.publishedBefore}`);
    if (filter.publishedBeforeExclusive) parts.push(`publica\xE7\xE3o estritamente antes de ${filter.publishedBeforeExclusive}`);
    if (filter.shorts === "only") parts.push("somente Shorts");
    if (filter.shorts === "exclude") parts.push("excluir Shorts");
    if (filter.hideShortsOnFeed) parts.push("ocultar Shorts no feed e inscri\xE7\xF5es");
    if (filter.hideShortsOnSearch) parts.push("ocultar Shorts na busca");
    if (filter.priority === "views-per-subscriber") parts.push("prioridade por views / inscrito positivo conhecido");
    if (filter.criteria?.length) parts.push(`ordena\xE7\xE3o: ${filter.criteria.map((criterion) => `${researchSortLabels[criterion.key]} ${criterion.direction === "asc" ? "crescente" : "decrescente"}`).join("; depois ")}`);
    if (filter.comparisonMode) parts.push(filter.comparisonMode === "sample-channel-reference" ? "outlier pela refer\xEAncia m\xE9dia da amostra do canal (Shorts: mediana com 10 positivos)" : "outlier pela mediana da amostra, m\xEDnimo 3 refer\xEAncias");
    return parts.length ? parts.join(" \xB7 ") : "nenhum limite adicional";
  }
  function researchRows(videos, fullBaseline, filter, now2 = Date.now()) {
    return videos.filter((video) => video.source !== "youtube-data-api").map((video) => {
      const comparison = researchComparison(video, fullBaseline, filter.comparisonMode);
      return { id: video.id, title: video.title, url: video.url, channel: video.channel, source: video.source, views: count(video.views), subscribers: count(video.subscribers), publishedAt: video.publishedAt, durationSeconds: count(video.durationSeconds), lifetimeVph: lifetimeVph(video, now2), viewsPerSubscriber: viewsPerSubscriber(video), sampleOutlier: comparison.score, outlierReferenceCount: comparison.referenceCount, outlierMethod: comparison.method, outlierComparisonMode: filter.comparisonMode ?? "sample-median", outlierReference: comparison.reference ?? null, outlierReferenceStatus: comparison.reference === void 0 ? "unknown" : comparison.reference === 0 ? "zero" : "available", outlierScoreStatus: comparison.score === void 0 ? "unknown" : "available", outlierPositiveReferenceCount: comparison.positiveReferenceCount, outlierProvenance: comparison.provenance, outlierScope: "eligible-input-before-filters", outlierTargetExclusion: "same-video-id", outlierCountUnit: "observations" };
    });
  }
  function researchMarkdown(videos, fullBaseline, filter, now2 = Date.now()) {
    const escape = (text2) => String(text2 ?? "desconhecido").replace(/[\\`*_{}[\]<>#|]/g, "\\$&").replace(/\r?\n/g, " ");
    const rows = researchRows(videos, fullBaseline, filter, now2);
    return ["# Pesquisa local Prevlev", "", `${rows.length} v\xEDdeos de observa\xE7\xF5es locais; contexto: ${filter.surface ?? "n\xE3o informado"}. Modo de outlier: ${filter.comparisonMode ?? "sample-median"}.`, "", "| V\xEDdeo | Canal | Views observadas | VPH m\xE9dio hist\xF3rico | Outlier local | Refer\xEAncia | Observa\xE7\xF5es candidatas | Positivas | M\xE9todo previsto |", "| --- | --- | --- | --- | --- | --- | --- | --- | --- |", ...rows.map((row3) => `| ${escape(row3.title)} | ${escape(row3.channel)} | ${escape(row3.views)} | ${escape(row3.lifetimeVph)} | ${escape(row3.sampleOutlier)} | ${escape(row3.outlierReference)} | ${escape(row3.outlierReferenceCount)} | ${escape(row3.outlierPositiveReferenceCount)} | ${escape(row3.outlierMethod)} |`), "", "Fonte: observa\xE7\xF5es carregadas eleg\xEDveis anteriores aos filtros, com formato declarado igual ou formato desconhecido em ambos, e canal compar\xE1vel. Alvo sem identidade usa candidatos da amostra geral, mas o modo de canal n\xE3o calcula refer\xEAncia sem identidade. Todos os registros com o ID do alvo s\xE3o exclu\xEDdos; outras observa\xE7\xF5es repetidas podem ser contadas. API oficial exclu\xEDda dos c\xE1lculos derivados. A amostra pode ser parcial e n\xE3o \xE9 a refer\xEAncia completa do canal. Views n\xE3o representam tr\xE1fego no per\xEDodo; VPH \xE9 m\xE9dio desde a publica\xE7\xE3o. Receita/RPM n\xE3o estimados.", ""].join("\n");
  }
  function count(value2) {
    return typeof value2 === "number" && Number.isFinite(value2) && value2 >= 0 ? value2 : void 0;
  }
  function finite(value2) {
    return value2 !== void 0 && Number.isFinite(value2) && value2 >= 0 ? value2 : void 0;
  }
  function sampleMedian(values) {
    const result = finite(median(values));
    if (result !== void 0 || !values.length) return result;
    const sorted = [...values].sort((left, right) => left - right), middle = Math.floor(sorted.length / 2);
    return finite(sorted[middle - 1] / 2 + sorted[middle] / 2);
  }

  // src/core/media.ts
  var MAX_PIXELS = 32e6;
  var MAX_DIMENSION = 16384;
  var MAX_BYTES = 50 * 1024 * 1024;
  function positive(value2, name) {
    if (!Number.isFinite(value2) || value2 <= 0)
      throw new Error(`${name} deve ser um n\xFAmero maior que zero.`);
    return value2;
  }
  function validateDimensions(width, height) {
    positive(width, "Largura");
    positive(height, "Altura");
    if (width > MAX_DIMENSION || height > MAX_DIMENSION || width * height > MAX_PIXELS)
      throw new Error(
        "Imagem grande demais para processar com seguran\xE7a. Limite: 32 megapixels e 16384 pixels por lado."
      );
  }
  function fitDimensions(width, height, maxWidth, maxHeight) {
    positive(width, "Largura");
    positive(height, "Altura");
    positive(maxWidth, "Largura m\xE1xima");
    positive(maxHeight, "Altura m\xE1xima");
    const ratio = Math.min(1, maxWidth / width, maxHeight / height);
    return {
      width: Math.max(1, Math.round(width * ratio)),
      height: Math.max(1, Math.round(height * ratio))
    };
  }
  function createCanvas(width, height) {
    validateDimensions(width, height);
    const canvas = document.createElement("canvas");
    canvas.width = Math.round(width);
    canvas.height = Math.round(height);
    const context = canvas.getContext("2d");
    if (!context) throw new Error("O navegador n\xE3o disponibilizou o canvas 2D.");
    return { canvas, context };
  }
  function encode(canvas, type = "image/png", quality = 0.9) {
    return new Promise((resolve, reject) => {
      try {
        canvas.toBlob(
          (blob) => blob ? resolve(blob) : reject(
            new Error("O navegador n\xE3o conseguiu codificar a imagem.")
          ),
          type,
          quality
        );
      } catch (error) {
        reject(mediaError(error));
      }
    });
  }
  function mediaError(error) {
    if (error instanceof DOMException && error.name === "SecurityError")
      return new Error(
        "O navegador bloqueou a captura por origem da m\xEDdia (canvas protegido). Use uma captura da aba ou uma imagem local."
      );
    return error instanceof Error ? error : new Error("Falha ao processar a imagem.");
  }
  function loadImage(input) {
    let ownedUrl;
    let source;
    if (typeof input === "string") {
      if (/^data:image\/(?:png|jpe?g|webp);base64,/i.test(input)) source = input;
      else {
        let url;
        try {
          url = new URL(input);
        } catch {
          return Promise.reject(new Error("URL de imagem inv\xE1lida."));
        }
        if (url.protocol !== "https:" || url.hostname !== "i.ytimg.com" || url.username || url.password)
          return Promise.reject(
            new Error(
              "Use uma imagem local ou uma thumbnail p\xFAblica do YouTube."
            )
          );
        source = url.href;
      }
    } else {
      if (!/^image\/(?:png|jpeg|webp|avif|gif)$/.test(input.type))
        return Promise.reject(
          new Error(
            "Formato de imagem n\xE3o suportado. Use PNG, JPEG, WebP, AVIF ou GIF."
          )
        );
      if (input.size === 0 || input.size > MAX_BYTES)
        return Promise.reject(
          new Error("A imagem deve ter entre 1 byte e 50 MB.")
        );
      ownedUrl = URL.createObjectURL(input);
      source = ownedUrl;
    }
    return new Promise((resolve, reject) => {
      const image = new Image();
      const cleanup = () => {
        image.onload = null;
        image.onerror = null;
        if (ownedUrl) URL.revokeObjectURL(ownedUrl);
      };
      image.crossOrigin = "anonymous";
      image.onload = () => {
        cleanup();
        try {
          validateDimensions(image.naturalWidth, image.naturalHeight);
          resolve(image);
        } catch (error) {
          reject(mediaError(error));
        }
      };
      image.onerror = () => {
        cleanup();
        reject(
          new Error(
            "N\xE3o foi poss\xEDvel abrir a imagem. Verifique o arquivo ou as permiss\xF5es do CDN."
          )
        );
      };
      image.src = source;
    });
  }
  function thumbnailUrls(videoId) {
    if (!/^[A-Za-z0-9_-]{11}$/.test(videoId))
      throw new Error("ID de v\xEDdeo inv\xE1lido.");
    return [
      "maxresdefault",
      "sddefault",
      "hqdefault",
      "mqdefault",
      "default"
    ].map((size) => `https://i.ytimg.com/vi/${videoId}/${size}.jpg`);
  }
  async function fetchThumbnail(videoId, signal) {
    const deadline = AbortSignal.timeout(12e3), combined = signal ? AbortSignal.any([signal, deadline]) : deadline;
    for (const url of thumbnailUrls(videoId)) {
      let response;
      try {
        response = await fetch(url, { credentials: "omit", redirect: "error", signal: combined });
      } catch (error) {
        if (combined.aborted) throw error;
        continue;
      }
      if (!response.ok) continue;
      const type = (response.headers.get("content-type") ?? "").split(";")[0].toLowerCase();
      if (!["image/jpeg", "image/png", "image/webp", "image/gif", "image/avif"].includes(type) || Number(response.headers.get("content-length")) > 5 * 1024 * 1024) {
        await response.body?.cancel();
        continue;
      }
      const reader = response.body?.getReader();
      if (!reader) continue;
      const chunks = [];
      let bytes = 0, tooLarge = false;
      try {
        for (; ; ) {
          const next = await reader.read();
          if (next.done) break;
          bytes += next.value.byteLength;
          if (bytes > 5 * 1024 * 1024) {
            tooLarge = true;
            await reader.cancel();
            break;
          }
          chunks.push(new Uint8Array(next.value));
        }
      } finally {
        reader.releaseLock();
      }
      combined.throwIfAborted();
      if (!tooLarge && bytes > 0) return new Blob(chunks, { type });
    }
    throw new Error("Nenhuma thumbnail p\xFAblica p\xF4de ser obtida do YouTube.");
  }
  function validateRect(rect) {
    if (!Number.isFinite(rect.x) || !Number.isFinite(rect.y))
      throw new Error("Posi\xE7\xE3o de captura inv\xE1lida.");
    positive(rect.width, "Largura da captura");
    positive(rect.height, "Altura da captura");
  }
  async function cropScreenshot(dataUrl, rect, scale = 1, redactions = []) {
    validateRect(rect);
    positive(scale, "Escala da captura");
    redactions.forEach(validateRect);
    if (!/^data:image\/(?:png|jpe?g|webp);base64,/i.test(dataUrl))
      throw new Error("A captura deve ser uma imagem local v\xE1lida.");
    const image = await loadImage(dataUrl);
    const left = Math.max(0, Math.round(rect.x * scale)), top = Math.max(0, Math.round(rect.y * scale));
    const right = Math.min(
      image.naturalWidth,
      Math.round((rect.x + rect.width) * scale)
    );
    const bottom = Math.min(
      image.naturalHeight,
      Math.round((rect.y + rect.height) * scale)
    );
    if (right <= left || bottom <= top)
      throw new Error(
        "O elemento est\xE1 fora da parte vis\xEDvel da aba. Role a p\xE1gina e tente novamente."
      );
    const width = right - left, height = bottom - top;
    const { canvas, context } = createCanvas(width, height);
    context.drawImage(image, left, top, width, height, 0, 0, width, height);
    context.fillStyle = "#111827";
    for (const redaction of redactions)
      context.fillRect(
        redaction.x * scale - left,
        redaction.y * scale - top,
        redaction.width * scale,
        redaction.height * scale
      );
    return encode(canvas);
  }
  async function copyImage(blob) {
    if (!navigator.clipboard?.write || typeof ClipboardItem === "undefined")
      throw new Error(
        "C\xF3pia de imagem indispon\xEDvel. Baixe o arquivo ou permita acesso \xE0 \xE1rea de transfer\xEAncia."
      );
    let png = blob;
    if (blob.type !== "image/png") {
      const image = await loadImage(blob);
      const { canvas, context } = createCanvas(
        image.naturalWidth,
        image.naturalHeight
      );
      context.drawImage(image, 0, 0);
      png = await encode(canvas);
    }
    try {
      await navigator.clipboard.write([new ClipboardItem({ "image/png": png })]);
    } catch {
      throw new Error(
        "O navegador bloqueou a \xE1rea de transfer\xEAncia. Use o bot\xE3o novamente ou baixe a imagem."
      );
    }
  }
  function normalizeFilename(filename) {
    const normalized2 = filename.normalize("NFKC").replace(/[<>:"/\\|?*]/g, "_").replace(new RegExp("\\p{Cc}", "gu"), "_").replace(/^\.+/, "").trim().slice(0, 180);
    return normalized2 || "prevlev.png";
  }
  function downloadBlob(blob, filename) {
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = normalizeFilename(filename);
    anchor.style.display = "none";
    document.body.append(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 3e4);
  }

  // src/ui/research.ts
  var researchLabels = { views: "Visualiza\xE7\xF5es", vph: "VPH m\xE9dio hist\xF3rico", outlier: "Outlier da amostra", recent: "Data de publica\xE7\xE3o", duration: "Dura\xE7\xE3o", subscribers: "Inscritos conhecidos", title: "T\xEDtulo", viewsPerSubscriber: "Views por inscrito conhecido" };
  function initResearchTools(deps) {
    const table = document.getElementById("video-rows")?.closest(".table-wrap");
    if (!table) throw new Error("A pesquisa de v\xEDdeos n\xE3o est\xE1 dispon\xEDvel.");
    const host = document.createElement("div");
    host.id = "research-enhancements";
    const choices = researchSortKeys.map((key) => `<option value="${key}">${researchLabels[key]}</option>`).join("");
    host.innerHTML = `<details class="research-advanced"><summary>Atalhos e ordena\xE7\xE3o avan\xE7ada</summary><div class="form-grid">
    <label>Atalho por contexto<select id="research-preset"><option value="">Escolha um atalho</option></select></label>
    <label>Primeiro crit\xE9rio<select id="research-sort-primary"><option value="none">Ordem da coleta</option>${choices}</select></label>
    <label>Dire\xE7\xE3o do primeiro<select id="research-direction-primary"><option value="desc">Maior primeiro / Z\u2013A</option><option value="asc">Menor primeiro / A\u2013Z</option></select></label>
    <label>Compara\xE7\xE3o local de outlier<select id="research-comparison"><option value="sample-median">Mediana da amostra (padr\xE3o, m\xEDnimo 3)</option><option value="sample-channel-reference">Refer\xEAncia m\xE9dia da amostra do canal</option></select></label>
    <label class="toggle"><input id="research-priority" type="checkbox"> Priorizar views por inscrito conhecido, fora de canais</label>
    <label class="toggle"><input id="research-hide-feed" type="checkbox"> Ocultar Shorts no feed / inscri\xE7\xF5es ao aplicar</label>
    <label class="toggle"><input id="research-hide-search" type="checkbox"> Ocultar Shorts na busca ao aplicar</label>
    </div><div class="row"><button id="research-add-sort">Adicionar segundo crit\xE9rio</button><button id="research-remove-sort" hidden>Remover segundo crit\xE9rio</button><button id="research-reset">Limpar atalhos e ordena\xE7\xE3o avan\xE7ada</button></div>
    <div id="research-secondary" class="form-grid" hidden><label>Segundo crit\xE9rio<select id="research-sort-secondary">${choices}</select></label><label>Dire\xE7\xE3o do segundo<select id="research-direction-secondary"><option value="desc">Maior primeiro / Z\u2013A</option><option value="asc">Menor primeiro / A\u2013Z</option></select></label></div>
    <p id="research-status" role="status"></p><p id="research-context"></p><p id="research-comparison-note"></p><button id="research-export-markdown">Exportar pesquisa em Markdown</button><p>Atalhos pr\xF3prios baseados nas regras verificadas. Ordena\xE7\xF5es mant\xEAm valores desconhecidos no fim, nas duas dire\xE7\xF5es. Views/inscrito exige denominador positivo conhecido. Dados da API oficial s\xE3o exclu\xEDdos das m\xE9tricas derivadas.</p></details>`;
    table.before(host);
    const get = (id) => host.querySelector(`#research-${id}`);
    const legacy = document.getElementById("sort");
    for (const [key, label] of [["default", "Ordem da coleta"], ["viewsPerSubscriber", "Views por inscrito conhecido"]]) if (![...legacy.options].some((option) => option.value === key)) {
      const option = document.createElement("option");
      option.value = key;
      option.textContent = label;
      legacy.append(option);
    }
    const primary = get("sort-primary"), secondary = get("sort-secondary"), preset = get("preset");
    let secondEnabled = false, lastSurface = researchSurface(deps.getUrl());
    let overrides = {};
    const nativeIds = ["video-filter", "channel-filter", "min-views", "max-views", "min-subscribers", "max-subscribers", "min-duration", "max-duration", "min-vph", "max-vph", "min-outlier", "max-outlier", "published-after", "published-before", "short-filter"];
    const field = (id) => document.getElementById(id);
    function readOptions() {
      const surface = researchSurface(deps.getUrl());
      const criteria = primary.value === "none" ? [] : [{ key: primary.value, direction: get("direction-primary").value }];
      if (secondEnabled) criteria.push({ key: secondary.value, direction: get("direction-secondary").value });
      const filter = { ...overrides, surface, criteria, priority: get("priority").checked ? "views-per-subscriber" : "none", comparisonMode: get("comparison").value, hideShortsOnFeed: get("hide-feed").checked, hideShortsOnSearch: get("hide-search").checked };
      validateResearchFilter(filter);
      return filter;
    }
    function detail() {
      const mode = get("comparison").value;
      get("comparison-note").textContent = mode === "sample-median" ? "Padr\xE3o: views / mediana de pelo menos 3 v\xEDdeos compar\xE1veis carregados, excluindo o alvo. O canal completo e a f\xF3rmula propriet\xE1ria n\xE3o s\xE3o conhecidos." : "Alternativa aproximada: views / m\xE9dia dos v\xEDdeos compar\xE1veis carregados do canal conhecido. Shorts usam a mediana dos positivos com pelo menos 10 refer\xEAncias positivas; abaixo disso usam a m\xE9dia. M\xEDnimo de 3 refer\xEAncias. N\xE3o equivale ao \xEDndice propriet\xE1rio nem \xE0 m\xE9dia do canal completo.";
      const extra = [overrides.subscribersBelow === void 0 ? "" : `inscritos < ${overrides.subscribersBelow}`, overrides.publishedAfter ? `publica\xE7\xE3o \u2265 ${overrides.publishedAfter}` : "", overrides.publishedBeforeExclusive ? `publica\xE7\xE3o < ${overrides.publishedBeforeExclusive}` : ""].filter(Boolean).join(" \xB7 ");
      get("status").textContent = (preset.value ? researchPresets(researchSurface(deps.getUrl())).find((item) => item.id === preset.value)?.description ?? "" : "Filtros manuais.") + (extra ? ` Limites precisos UTC: ${extra}.` : "");
    }
    function notify() {
      try {
        readOptions();
        get("status").classList.remove("error");
        detail();
        deps.onChange();
      } catch (error) {
        get("status").textContent = error instanceof Error ? error.message : "Filtro inv\xE1lido.";
        get("status").classList.add("error");
      }
    }
    function refresh() {
      const surface = researchSurface(deps.getUrl());
      const selected = preset.value;
      const options = researchPresets(surface);
      preset.replaceChildren();
      const blank = document.createElement("option");
      blank.value = "";
      blank.textContent = "Escolha um atalho";
      preset.append(blank);
      for (const item of options) {
        const option = document.createElement("option");
        option.value = item.id;
        option.textContent = item.label;
        option.disabled = !item.available;
        preset.append(option);
      }
      if (surface !== lastSurface) {
        overrides = {};
        preset.value = "";
        get("priority").checked = false;
        if (primary.value === "viewsPerSubscriber") primary.value = "views";
        if (secondary.value === "viewsPerSubscriber") secondary.value = "title";
        lastSurface = surface;
      } else preset.value = options.find((item) => item.id === selected)?.available ? selected : "";
      get("priority").disabled = surface === "channel";
      for (const select of [primary, secondary]) for (const option of select.options) if (option.value === "viewsPerSubscriber") option.disabled = surface === "channel";
      get("context").textContent = `Contexto da coleta: ${{ home: "p\xE1gina inicial", subscriptions: "inscri\xE7\xF5es", search: "busca", channel: "canal", other: "outra p\xE1gina / origem n\xE3o reconhecida" }[surface]}. Atalhos exclusivos da busca n\xE3o s\xE3o aplicados em outros contextos.`;
      detail();
    }
    function syncLegacy() {
      legacy.value = primary.value === "recent" ? "date" : primary.value === "none" ? "default" : primary.value;
    }
    function reset() {
      overrides = {};
      preset.value = "";
      secondEnabled = false;
      get("secondary").hidden = true;
      get("remove-sort").hidden = true;
      get("add-sort").hidden = false;
      primary.value = legacy.value === "date" ? "recent" : legacy.value === "default" ? "none" : legacy.value || "views";
      secondary.value = "title";
      get("direction-primary").value = primary.value === "title" ? "asc" : "desc";
      get("direction-secondary").value = "asc";
      get("comparison").value = "sample-median";
      for (const id of ["priority", "hide-feed", "hide-search"]) get(id).checked = false;
      refresh();
    }
    preset.addEventListener("change", () => {
      if (!preset.value) {
        overrides = {};
        notify();
        return;
      }
      try {
        const chosen = researchPreset(preset.value, researchSurface(deps.getUrl()));
        for (const id of nativeIds) field(id).value = id === "short-filter" ? "all" : "";
        const map = { minViews: "min-views", maxViews: "max-views", minSubscribers: "min-subscribers", maxSubscribers: "max-subscribers", minDurationSeconds: "min-duration", maxDurationSeconds: "max-duration", minVph: "min-vph", maxVph: "max-vph", minOutlier: "min-outlier", maxOutlier: "max-outlier" };
        for (const key of Object.keys(map)) if (chosen.filter[key] !== void 0) field(map[key]).value = String(chosen.filter[key]);
        field("short-filter").value = chosen.filter.shorts === "only" ? "shorts" : chosen.filter.shorts === "exclude" ? "long" : "all";
        if (chosen.filter.publishedAfter) field("published-after").value = chosen.filter.publishedAfter.slice(0, 10);
        if (chosen.filter.publishedBeforeExclusive) field("published-before").value = chosen.filter.publishedBeforeExclusive.slice(0, 10);
        overrides = { ...chosen.filter.publishedAfter ? { publishedAfter: chosen.filter.publishedAfter } : {}, ...chosen.filter.publishedBeforeExclusive ? { publishedBeforeExclusive: chosen.filter.publishedBeforeExclusive, publishedBefore: chosen.filter.publishedBeforeExclusive } : {}, ...chosen.filter.subscribersBelow !== void 0 ? { subscribersBelow: chosen.filter.subscribersBelow } : {} };
        primary.value = chosen.filter.criteria?.[0].key ?? "views";
        get("direction-primary").value = chosen.filter.criteria?.[0].direction ?? "desc";
        secondEnabled = false;
        get("secondary").hidden = true;
        get("remove-sort").hidden = true;
        get("add-sort").hidden = false;
        get("priority").checked = false;
        get("hide-feed").checked = false;
        get("hide-search").checked = false;
        syncLegacy();
        notify();
      } catch (error) {
        get("status").textContent = error instanceof Error ? error.message : "Atalho inv\xE1lido.";
        get("status").classList.add("error");
      }
    });
    get("add-sort").addEventListener("click", () => {
      if (primary.value === "none") primary.value = "views";
      if (secondary.value === primary.value) secondary.value = primary.value === "title" ? "views" : "title";
      secondEnabled = true;
      get("secondary").hidden = false;
      get("remove-sort").hidden = false;
      get("add-sort").hidden = true;
      syncLegacy();
      notify();
    });
    get("remove-sort").addEventListener("click", () => {
      secondEnabled = false;
      get("secondary").hidden = true;
      get("remove-sort").hidden = true;
      get("add-sort").hidden = false;
      notify();
    });
    for (const id of ["sort-primary", "direction-primary", "sort-secondary", "direction-secondary", "priority", "comparison", "hide-feed", "hide-search"]) get(id).addEventListener("change", () => {
      syncLegacy();
      notify();
    });
    legacy.addEventListener("change", () => {
      primary.value = legacy.value === "date" ? "recent" : legacy.value === "default" ? "none" : legacy.value;
      get("direction-primary").value = primary.value === "title" ? "asc" : "desc";
      notify();
    });
    for (const id of nativeIds) field(id).addEventListener("input", () => {
      if (id === "published-after") delete overrides.publishedAfter;
      if (id === "published-before") {
        delete overrides.publishedBefore;
        delete overrides.publishedBeforeExclusive;
      }
      if (id === "max-subscribers" || id === "min-subscribers") delete overrides.subscribersBelow;
      preset.value = "";
      notify();
    });
    get("reset").addEventListener("click", () => {
      reset();
      notify();
    });
    get("export-markdown").addEventListener("click", () => {
      try {
        const filter = readOptions();
        downloadBlob(new Blob([researchMarkdown(deps.getVisibleVideos(), deps.getAllVideos(), filter)], { type: "text/markdown;charset=utf-8" }), "prevlev-pesquisa.md");
      } catch (error) {
        get("status").textContent = error instanceof Error ? error.message : "N\xE3o foi poss\xEDvel exportar a pesquisa.";
        get("status").classList.add("error");
      }
    });
    reset();
    return { readOptions, reset, refresh };
  }

  // src/core/transcript.ts
  var TRANSCRIPT_ROW_SELECTOR = "ytd-transcript-segment-renderer,transcript-segment-view-model,[data-transcript-segment],[data-prevlev-transcript-segment]";
  var numeric = (value2) => typeof value2 === "number" && Number.isFinite(value2) && value2 >= 0 ? value2 : typeof value2 === "string" && /^\d+(?:\.\d+)?$/.test(value2.trim()) ? Number(value2) : void 0;
  function captionTime(value2) {
    const parts = value2.trim().replace(",", ".").split(":");
    if (parts.length < 2 || parts.length > 3 || !parts.every((part, index) => index === parts.length - 1 ? /^\d{1,2}(?:\.\d{1,9})?$/.test(part) : /^\d+$/.test(part)) || parts.slice(1).some((part) => Number(part) >= 60)) return void 0;
    return parts.reduce((total2, part) => total2 * 60 + Number(part), 0);
  }
  function captionDecode(value2) {
    return value2.replace(/&(?:amp|lt|gt|quot|apos|nbsp|#\d+|#x[0-9a-f]+);/gi, (entity) => {
      const named = { "&amp;": "&", "&lt;": "<", "&gt;": ">", "&quot;": '"', "&apos;": "'", "&nbsp;": " " };
      if (named[entity.toLowerCase()]) return named[entity.toLowerCase()];
      const code = entity[2]?.toLowerCase() === "x" ? parseInt(entity.slice(3, -1), 16) : Number(entity.slice(2, -1));
      return code > 0 && code <= 1114111 && !(code >= 55296 && code <= 57343) ? String.fromCodePoint(code) : "\uFFFD";
    });
  }
  function captionFile(value2) {
    const blocks = value2.replace(/^\uFEFF/, "").replace(/\r\n?/g, "\n").split(/\n[ \t]*\n+/), segments2 = [];
    for (const block of blocks) {
      const lines3 = block.split("\n");
      if (/^(?:WEBVTT|NOTE(?:\s|$)|STYLE(?:\s|$)|REGION(?:\s|$))/.test(lines3[0]?.trim() ?? "")) continue;
      const index = lines3.findIndex((line) => line.includes("-->"));
      if (index < 0 || index > 1) continue;
      const timing = /^\s*(\d+(?::\d{1,2}){1,2}[.,]\d{1,9})\s+-->\s+(\d+(?::\d{1,2}){1,2}[.,]\d{1,9})(?:\s+.*)?$/.exec(lines3[index]);
      if (!timing) continue;
      const start = captionTime(timing[1]), end = captionTime(timing[2]);
      if (start === void 0 || end === void 0 || end <= start) continue;
      const text2 = captionDecode(lines3.slice(index + 1).join("\n").replace(/<\/?(?:c(?:\.[^\s>]*)?|v(?:\s+[^>]*)?|lang(?:\s+[^>]*)?|b|i|u|ruby|rt)>/gi, ""));
      segments2.push({ start, duration: end - start, text: text2 });
      if (segments2.length >= 5e3) break;
    }
    return validate(segments2);
  }
  function parseTranscript(input) {
    if (typeof input === "string") {
      if (input.length > 5e6) throw new Error("Transcri\xE7\xE3o acima do limite de 5 milh\xF5es de caracteres.");
      const text2 = input.trim();
      if (text2.startsWith("{") || text2.startsWith("[")) {
        try {
          return parseTranscript(JSON.parse(text2));
        } catch {
          return [];
        }
      }
      if (/^WEBVTT(?:\s|$)/.test(text2) || /\d{1,2}:\d{2}[.,]\d{1,9}\s+-->/.test(text2)) return captionFile(text2);
      if (text2.startsWith("<") && typeof DOMParser !== "undefined")
        return parseTranscript(new DOMParser().parseFromString(text2, "text/xml"));
      return [];
    }
    if (input && typeof input === "object" && input.nodeType === 9 && typeof input.querySelectorAll === "function") {
      const document2 = input;
      const xml = Array.from(document2.querySelectorAll("text[start], p[t]")).map(
        (node) => ({
          start: node.hasAttribute("start") ? numeric(node.getAttribute("start")) ?? NaN : (numeric(node.getAttribute("t")) ?? NaN) / 1e3,
          duration: node.hasAttribute("dur") ? Number(node.getAttribute("dur")) : Number(node.getAttribute("d") ?? 0) / 1e3,
          text: node.textContent ?? ""
        })
      );
      if (xml.length) return validate(xml);
      const rows = Array.from(
        document2.querySelectorAll(TRANSCRIPT_ROW_SELECTOR)
      ).filter((row3) => !row3.parentElement?.closest(TRANSCRIPT_ROW_SELECTOR));
      const readTime = (row3) => {
        if (!row3) return void 0;
        const time = row3.querySelector('.segment-timestamp,[class*="ytwTranscriptSegmentViewModelTimestamp"],[data-start],[data-start-ms]');
        for (const item of [row3, time]) {
          if (!item) continue;
          for (const [attribute, factor] of [["data-start-ms", 1e3], ["data-start", 1], ["data-start-time", 1]]) {
            const raw = numeric(item.getAttribute(attribute));
            if (raw !== void 0) return raw / factor;
          }
        }
        return captionTime(time?.textContent ?? "") ?? parseDuration(time?.textContent ?? "");
      };
      return validate(
        rows.map((row3, index) => {
          const start = readTime(row3), end = readTime(rows[index + 1]);
          return {
            start: start ?? NaN,
            duration: end !== void 0 && start !== void 0 ? Math.max(0, end - start) : 0,
            text: row3.querySelector('.segment-text,[class*="ytwTranscriptSegmentViewModelText"],[data-text]')?.textContent ?? row3.getAttribute("data-text") ?? ""
          };
        })
      );
    }
    if (!input || typeof input !== "object") return [];
    if (Array.isArray(input))
      return validate(
        input.map((entry) => {
          const item = asRecord(entry);
          return {
            start: numeric(item.start) ?? NaN,
            duration: item.duration === void 0 ? 0 : numeric(item.duration) ?? NaN,
            text: typeof item.text === "string" ? item.text : ""
          };
        })
      );
    const root = asRecord(input);
    if (Array.isArray(root.events))
      return validate(
        root.events.map((event) => {
          const item = asRecord(event);
          const segments2 = Array.isArray(item.segs) ? item.segs : [];
          return {
            start: (numeric(item.tStartMs) ?? NaN) / 1e3,
            duration: item.dDurationMs === void 0 ? 0 : (numeric(item.dDurationMs) ?? NaN) / 1e3,
            text: segments2.map((segment) => String(asRecord(segment).utf8 ?? "")).join("")
          };
        })
      );
    return [];
  }
  function transcriptText(segments2, timestamps = false) {
    return segments2.map(
      (segment) => `${timestamps ? `[${timestamp(segment.start, false)}] ` : ""}${segment.text}`
    ).join("\n");
  }
  function transcriptVtt(segments2, options = {}) {
    const resolved = resolveTranscriptEnds(segments2, options), notes = resolved.filter((segment) => segment.end === null).map((segment) => `NOTE Prevlev: trecho iniciado em ${timestamp(segment.start)} omitido porque o fim e desconhecido.
`);
    if (resolved.some((segment) => segment.endBasis === "estimated-opt-in")) notes.unshift("NOTE Prevlev: duracao final estimada por opcao explicita do usuario.\n");
    return `WEBVTT

${notes.length ? notes.join("\n") + "\n" : ""}${resolved.filter((segment) => segment.end !== null).map((segment, index) => `${index + 1}
${timestamp(segment.start)} --> ${timestamp(segment.end)}
${segment.text.replace(/-->/g, "\u2192").replace(/\r?\n\r?\n/g, "\n")}
`).join("\n")}`;
  }
  function transcriptMarkdown(segments2, title = "Transcri\xE7\xE3o", metadata) {
    const context = metadata ? safeMetadata({ ...metadata, title }) : void 0;
    return `# ${title.replace(/[\\`*_{}[\]<>#]/g, "\\$&").replace(/[\r\n]/g, " ")}

${context ? `V\xEDdeo: ${(context.videoUrl ?? "n\xE3o informado").replace(/[\\`*_{}[\]<>#]/g, "\\$&")}

Exportado em: ${context.exportedAt}

` : ""}${segments2.map((segment) => `- **${timestamp(segment.start, false)}** ${segment.text.replace(/[\\`*_{}[\]<>#]/g, "\\$&").replace(/\r?\n/g, " ")}`).join("\n")}
`;
  }
  function validate(segments2) {
    return segments2.filter(
      (segment) => Number.isFinite(segment.start) && segment.start >= 0 && Number.isFinite(segment.duration) && segment.duration >= 0 && segment.text.trim()
    ).map((segment) => ({
      ...segment,
      text: segment.text.replace(/\s+/g, " ").trim()
    })).sort((a, b) => a.start - b.start).slice(0, 5e3);
  }
  function resolveTranscriptEnds(segments2, options = {}) {
    const sorted = validate([...segments2]);
    if (options.playerEndSeconds !== void 0 && (!Number.isFinite(options.playerEndSeconds) || options.playerEndSeconds <= 0)) throw new Error("Dura\xE7\xE3o real do player inv\xE1lida.");
    if (options.estimateFinalSeconds !== void 0 && (!Number.isFinite(options.estimateFinalSeconds) || options.estimateFinalSeconds <= 0 || options.estimateFinalSeconds > 300)) throw new Error("A estimativa expl\xEDcita deve ficar entre 0 e 300 segundos.");
    return sorted.map((segment, index) => {
      const next = sorted.slice(index + 1).find((other) => other.start > segment.start)?.start;
      let end = null, endBasis = "unknown";
      if (segment.duration > 0) {
        end = segment.start + segment.duration;
        endBasis = "provided-duration";
      } else if (next !== void 0) {
        end = next;
        endBasis = "next-segment";
      } else if (options.playerEndSeconds !== void 0 && options.playerEndSeconds > segment.start) {
        end = options.playerEndSeconds;
        endBasis = "player-end";
      } else if (options.estimateFinalSeconds !== void 0) {
        end = segment.start + options.estimateFinalSeconds;
        endBasis = "estimated-opt-in";
      }
      return { ...segment, end, endBasis };
    });
  }
  function transcriptSrt(segments2, options = {}) {
    return resolveTranscriptEnds(segments2, options).filter((segment) => segment.end !== null).map((segment, index) => `${index + 1}
${timestamp(segment.start).replace(".", ",")} --> ${timestamp(segment.end).replace(".", ",")}
${segment.text}
`).join("\n");
  }
  function safeMetadata(metadata) {
    let videoUrl = null;
    try {
      const url = new URL(metadata.videoUrl ?? "");
      if (url.protocol === "https:" && ["www.youtube.com", "youtube.com", "m.youtube.com", "youtu.be", "studio.youtube.com"].includes(url.hostname) && !url.username && !url.password) videoUrl = url.href;
    } catch {
    }
    const exportedAt = metadata.exportedAt ?? (/* @__PURE__ */ new Date()).toISOString();
    if (!Number.isFinite(Date.parse(exportedAt))) throw new Error("Data de exporta\xE7\xE3o inv\xE1lida.");
    return { title: metadata.title ?? "Transcri\xE7\xE3o", videoUrl, videoId: metadata.videoId && /^[\w-]{11}$/.test(metadata.videoId) ? metadata.videoId : videoUrl ? videoIdFromUrl(videoUrl) ?? null : null, exportedAt: new Date(exportedAt).toISOString() };
  }
  function transcriptExport(segments2, metadata = {}, options = {}, plainText) {
    const resolved = resolveTranscriptEnds(segments2, options);
    return { schemaVersion: 1, kind: "transcript-export", ...safeMetadata(metadata), text: plainText ?? transcriptText(resolved), timestampsAvailable: resolved.length > 0, segments: resolved, limitations: ["Somente os trechos fornecidos ou j\xE1 observados; n\xE3o comprova transcri\xE7\xE3o completa.", ...!resolved.length ? ["Texto sem timestamps conhecidos; nenhum hor\xE1rio foi inventado."] : [], ...resolved.some((segment) => segment.end === null) ? ["H\xE1 finais desconhecidos; VTT/SRT omitem esses cues. JSON/CSV/Markdown conservam seus textos e in\xEDcios."] : [], ...resolved.some((segment) => segment.endBasis === "estimated-opt-in") ? ["H\xE1 finais estimados com op\xE7\xE3o expl\xEDcita."] : []] };
  }
  function transcriptRows(segments2, metadata = {}, options = {}) {
    const report = transcriptExport(segments2, metadata, options);
    return report.segments.map((segment) => ({ ...segment, title: report.title, videoUrl: report.videoUrl, videoId: report.videoId, exportedAt: report.exportedAt, startTimestamp: timestamp(segment.start), endTimestamp: segment.end === null ? null : timestamp(segment.end) }));
  }
  function timestamp(seconds, milliseconds = true) {
    const ms = Math.max(0, Math.round(seconds * 1e3));
    const hours = Math.floor(ms / 36e5), minutes = Math.floor(ms / 6e4) % 60, secs = Math.floor(ms / 1e3) % 60;
    return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}:${String(secs).padStart(2, "0")}${milliseconds ? `.${String(ms % 1e3).padStart(3, "0")}` : ""}`;
  }
  function asRecord(value2) {
    return value2 && typeof value2 === "object" ? value2 : {};
  }

  // src/core/midroll.ts
  var MIDROLL_INTERVAL_PRESETS = [10, 20, 30, 60, 120, 180, 240, 300, 600, 900, 1200];
  function planAdvancedMidrolls(options) {
    const { durationSeconds: duration, mode } = options;
    if (!Number.isFinite(duration) || duration < 480 || duration > 7200)
      throw new Error("Informe uma dura\xE7\xE3o entre 480 e 7200 segundos.");
    if (!["auto", "quantity", "custom", "smart"].includes(mode))
      throw new Error("Modo de planejamento inv\xE1lido.");
    const positions = [];
    const add = (position) => {
      if (!Number.isFinite(position) || position < 1 || position > duration - 1)
        throw new Error("Posi\xE7\xE3o fora dos limites do v\xEDdeo (1 segundo at\xE9 dura\xE7\xE3o \u2212 1 segundo).");
      positions.push(Math.min(Math.floor(duration - 1), Math.round(position)));
      if (positions.length > 100) throw new Error("Mais de 50 posi\xE7\xF5es solicitadas; aumente o intervalo ou reduza a quantidade.");
    };
    if (mode === "auto" || mode === "quantity") {
      const quantity = mode === "auto" ? Math.max(1, Math.floor(duration / 180)) : options.quantity;
      if (!Number.isInteger(quantity) || quantity < 1 || quantity > 50)
        throw new Error("Informe uma quantidade inteira entre 1 e 50.");
      for (let i = 1; i <= quantity; i++) add(duration * i / (quantity + 1));
    } else {
      const interval = options.intervalSeconds;
      const start = options.startSeconds ?? interval;
      if (!Number.isFinite(interval) || interval < 10 || !Number.isFinite(start) || start < 1 || start > duration - 1)
        throw new Error("Informe intervalo de pelo menos 10 segundos e in\xEDcio dentro do v\xEDdeo.");
      const snapWindow = options.snapWindowSeconds ?? 20;
      if (!Number.isFinite(snapWindow) || snapWindow < 0) throw new Error("Janela de sil\xEAncio inv\xE1lida.");
      if (mode === "smart" && !options.silences)
        throw new Error("Smart exige an\xE1lise PCM local conclu\xEDda para esta dura\xE7\xE3o.");
      const midpoints = (options.silences ?? []).filter((s) => Number.isFinite(s.start) && Number.isFinite(s.end) && s.start >= 0 && s.end <= duration && s.end > s.start).map((s) => (s.start + s.end) / 2);
      for (let position = start; position <= duration - 1; position += interval) {
        const nearest = mode === "smart" ? midpoints.filter((x) => Math.abs(x - position) <= snapWindow && x >= 1 && x <= duration - 1).sort((a, b) => Math.abs(a - position) - Math.abs(b - position))[0] : void 0;
        add(nearest ?? position);
      }
    }
    if (options.includeStart) add(1);
    if (options.includeEnd) add(duration - 1);
    if (options.includePlayhead) {
      if (options.playheadSeconds === void 0) throw new Error("Informe a posi\xE7\xE3o do playhead em segundos.");
      add(options.playheadSeconds);
    }
    const result = [...new Set(positions)].sort((a, b) => a - b);
    if (result.length > 50) throw new Error("Mais de 50 posi\xE7\xF5es solicitadas; aumente o intervalo ou reduza a quantidade.");
    return result;
  }
  async function analyzePcm(channels, sampleRate, options) {
    const { thresholdPercent, minDurationSeconds, fps, signal, onProgress } = options;
    const length = channels[0]?.length ?? 0;
    if (!Number.isFinite(sampleRate) || sampleRate < 1 || sampleRate > 192e3 || !length || !channels.length || channels.length > 8 || channels.some((c) => c.length !== length) || length * channels.length > 16e6 || length / sampleRate > 7200 || !Number.isFinite(thresholdPercent) || thresholdPercent < 0 || thresholdPercent > 100 || !Number.isFinite(minDurationSeconds) || minDurationSeconds <= 0 || !Number.isInteger(fps) || fps < 1 || fps > 120)
      throw new Error("PCM ou par\xE2metros inv\xE1lidos; limite de 2 horas, 8 canais e 16 milh\xF5es de amostras.");
    const frameSize = Math.max(1, Math.round(sampleRate / fps));
    const waveform = Array(Math.min(600, Math.ceil(length / frameSize))).fill(0);
    const silences = [];
    let start;
    const finish = (end) => {
      if (start !== void 0 && (end - start) / sampleRate >= minDurationSeconds) silences.push({ start: start / sampleRate, end: end / sampleRate });
      start = void 0;
    };
    for (let offset = 0, frame = 0; offset < length; offset += frameSize, frame++) {
      if (signal?.aborted) throw new DOMException("An\xE1lise cancelada.", "AbortError");
      const end = Math.min(length, offset + frameSize);
      let peakRms = 0;
      for (const channel of channels) {
        let sum = 0;
        for (let i = offset; i < end; i++) {
          const sample = channel[i];
          sum += Number.isFinite(sample) ? sample * sample : Infinity;
        }
        peakRms = Math.max(peakRms, Math.sqrt(sum / (end - offset)));
      }
      const bin = Math.min(waveform.length - 1, Math.floor(offset / length * waveform.length));
      waveform[bin] = Math.max(waveform[bin], Math.min(1, peakRms));
      if (peakRms <= thresholdPercent / 100) start ??= offset;
      else finish(offset);
      if (frame % 128 === 0) {
        onProgress?.(offset / length);
        await new Promise((resolve) => setTimeout(resolve, 0));
      }
    }
    if (signal?.aborted) throw new DOMException("An\xE1lise cancelada.", "AbortError");
    finish(length);
    onProgress?.(1);
    return { silences, waveform, durationSeconds: length / sampleRate };
  }

  // src/ui/midroll-tools.ts
  var MAX_PCM_SAMPLES = 16e6;
  var WAV_ERROR = "Use um arquivo WAV local PCM ou IEEE float v\xE1lido; formatos comprimidos n\xE3o s\xE3o aceitos.";
  async function preflightWav(file) {
    const read = async (offset2, length) => {
      if (offset2 < 0 || length < 0 || offset2 + length > file.size) throw new Error(WAV_ERROR);
      return new DataView(await file.slice(offset2, offset2 + length).arrayBuffer());
    };
    const text2 = (view, start, length) => Array.from({ length }, (_, i) => String.fromCharCode(view.getUint8(start + i))).join("");
    if (file.size < 44 || file.size > 50 * 1024 * 1024) throw new Error(WAV_ERROR);
    const header = await read(0, 12);
    const end = header.getUint32(4, true) + 8;
    if (text2(header, 0, 4) !== "RIFF" || text2(header, 8, 4) !== "WAVE" || end !== file.size || end < 44) throw new Error(WAV_ERROR);
    let format;
    let dataBytes;
    let offset = 12;
    for (let chunks = 0; offset + 8 <= end && chunks < 1024; chunks++) {
      const chunk = await read(offset, 8);
      const id = text2(chunk, 0, 4), size = chunk.getUint32(4, true), start = offset + 8;
      if (start + size > end || start + size + size % 2 > end) throw new Error(WAV_ERROR);
      if (id === "fmt ") {
        if (format || size < 16) throw new Error(WAV_ERROR);
        const fmt = await read(start, 16);
        const encoding = fmt.getUint16(0, true), channels = fmt.getUint16(2, true), sampleRate = fmt.getUint32(4, true), byteRate = fmt.getUint32(8, true), blockAlign = fmt.getUint16(12, true), bits = fmt.getUint16(14, true);
        if (!(encoding === 1 && [8, 16, 24, 32].includes(bits) || encoding === 3 && [32, 64].includes(bits)) || channels < 1 || channels > 8 || sampleRate < 1 || sampleRate > 192e3 || blockAlign !== channels * bits / 8 || byteRate !== sampleRate * blockAlign) throw new Error(WAV_ERROR);
        format = { channels, sampleRate, blockAlign };
      } else if (id === "data") {
        if (dataBytes !== void 0) throw new Error(WAV_ERROR);
        dataBytes = size;
      }
      offset = start + size + size % 2;
    }
    if (offset !== end || !format || !dataBytes || dataBytes % format.blockAlign !== 0) throw new Error(WAV_ERROR);
    const frames = dataBytes / format.blockAlign;
    if (frames * format.channels > MAX_PCM_SAMPLES || frames / format.sampleRate > 7200) throw new Error("WAV excede o limite de 2 horas ou 16 milh\xF5es de amostras; escolha um arquivo menor.");
    return { frames, channels: format.channels, sampleRate: format.sampleRate };
  }
  function mountMidrollTools(doc, onChange) {
    const studio = doc.querySelector("#studio");
    const audioButton = doc.querySelector("#audio-analyze");
    const audioFile = doc.querySelector("#midroll-audio");
    const duration = doc.querySelector("#duration");
    const interval = doc.querySelector("#interval");
    const info = doc.querySelector("#audio-info");
    if (!studio || !audioButton || !audioFile || !duration || !interval || !info) throw new Error("Controles de mid-roll ausentes.");
    const panel = doc.createElement("div");
    panel.id = "midroll-tools";
    panel.innerHTML = `<h3>Planejamento local de mid-roll</h3>
    <label>Modo <select id="midroll-mode"><option value="auto">Auto</option><option value="quantity">Quantidade</option><option value="custom" selected>Custom</option><option value="smart">Smart (PCM local)</option></select></label>
    <label>Quantidade <input id="midroll-quantity" type="number" min="1" max="50" value="3"></label>
    <label>Intervalo predefinido <select id="midroll-preset">${MIDROLL_INTERVAL_PRESETS.map((v) => `<option value="${v}"${v === 180 ? " selected" : ""}>${v < 60 ? `${v} s` : `${v / 60} min`}</option>`).join("")}</select></label>
    <label>In\xEDcio personalizado em segundos (vazio usa intervalo) <input id="midroll-start" type="number" min="1" step="1"></label>
    <label><input id="midroll-include-start" type="checkbox"> Incluir in\xEDcio (1 s)</label>
    <label><input id="midroll-include-end" type="checkbox"> Incluir fim (dura\xE7\xE3o \u2212 1 s)</label>
    <label><input id="midroll-include-playhead" type="checkbox"> Incluir playhead informado</label>
    <label>Playhead em segundos <input id="midroll-playhead" type="number" min="1" step="0.01"></label>
    <label>Limite de sil\xEAncio (% amplitude RMS) <input id="midroll-threshold" type="number" min="0" max="100" step="0.1" value="1"></label>
    <label>Sil\xEAncio m\xEDnimo (ms) <input id="midroll-min-silence" type="number" min="1" value="500"></label>
    <label>FPS da an\xE1lise PCM <input id="midroll-analysis-fps" type="number" min="1" max="120" value="30"></label>
    <progress id="midroll-progress" max="1" value="0"></progress><button type="button" id="midroll-cancel" disabled>Cancelar an\xE1lise</button>
    <div id="midroll-waveform" role="img" aria-label="N\xEDvel RMS por trecho do arquivo local"></div>
    <p class="muted">O Smart usa somente o arquivo local escolhido. Sem sil\xEAncio pr\xF3ximo, mant\xE9m a posi\xE7\xE3o por intervalo; n\xE3o l\xEA o waveform do Studio.</p>`;
    audioFile.accept = ".wav,audio/wav,audio/wave,audio/x-wav";
    audioFile.parentElement.before(panel);
    const input = (id) => panel.querySelector(`#${id}`);
    const mode = panel.querySelector("#midroll-mode");
    const preset = panel.querySelector("#midroll-preset");
    const progress = panel.querySelector("#midroll-progress");
    const cancel = panel.querySelector("#midroll-cancel");
    const wave = panel.querySelector("#midroll-waveform");
    let analysis;
    let controller;
    const invalidateAudio = () => {
      controller?.abort();
      analysis = void 0;
      wave.replaceChildren();
      progress.value = 0;
      info.textContent = "An\xE1lise PCM anterior descartada; analise o arquivo novamente.";
      onChange();
    };
    panel.addEventListener("change", (event) => {
      if (event.target === preset) interval.value = preset.value;
      if ([input("midroll-threshold"), input("midroll-min-silence"), input("midroll-analysis-fps")].includes(event.target)) invalidateAudio();
      else onChange();
    });
    audioFile.addEventListener("change", invalidateAudio);
    duration.addEventListener("change", onChange);
    interval.addEventListener("change", onChange);
    cancel.addEventListener("click", () => controller?.abort());
    audioButton.addEventListener("click", async () => {
      if (controller) return;
      const file = audioFile.files?.[0];
      if (!file || file.size > 50 * 1024 * 1024) {
        info.textContent = "Escolha um arquivo de \xE1udio local de at\xE9 50 MB.";
        return;
      }
      invalidateAudio();
      const current = new AbortController();
      controller = current;
      cancel.disabled = false;
      audioButton.disabled = true;
      info.textContent = "Decodificando arquivo local\u2026";
      let audio;
      try {
        const header = await preflightWav(file);
        if (current.signal.aborted) throw new DOMException("An\xE1lise cancelada.", "AbortError");
        audio = new AudioContext();
        const expectedFrames = Math.ceil(header.frames * audio.sampleRate / header.sampleRate);
        if (expectedFrames * header.channels > MAX_PCM_SAMPLES) throw new Error("O WAV excede 16 milh\xF5es de amostras ap\xF3s convers\xE3o da taxa de \xE1udio; escolha um arquivo menor.");
        const bytes = await file.arrayBuffer();
        if (current.signal.aborted) throw new DOMException("An\xE1lise cancelada.", "AbortError");
        const buffer = await audio.decodeAudioData(bytes);
        if (current.signal.aborted) throw new DOMException("An\xE1lise cancelada.", "AbortError");
        if (buffer.numberOfChannels !== header.channels || buffer.length * buffer.numberOfChannels > MAX_PCM_SAMPLES || buffer.sampleRate !== audio.sampleRate || Math.abs(buffer.length / buffer.sampleRate - header.frames / header.sampleRate) > 2 / buffer.sampleRate) throw new Error("\xC1udio decodificado diverge do cabe\xE7alho WAV; an\xE1lise cancelada.");
        info.textContent = "Analisando PCM local\u2026";
        const result = await analyzePcm(Array.from({ length: buffer.numberOfChannels }, (_, i) => buffer.getChannelData(i)), buffer.sampleRate, {
          thresholdPercent: Number(input("midroll-threshold").value),
          minDurationSeconds: Number(input("midroll-min-silence").value) / 1e3,
          fps: Number(input("midroll-analysis-fps").value),
          signal: current.signal,
          onProgress: (fraction) => {
            progress.value = fraction;
          }
        });
        if (current.signal.aborted) throw new DOMException("An\xE1lise cancelada.", "AbortError");
        analysis = result;
        duration.value = String(result.durationSeconds);
        onChange();
        const bars = result.waveform.map((level) => {
          const bar = doc.createElement("span");
          bar.style.cssText = `display:inline-block;width:2px;height:${Math.max(1, Math.round(level * 40))}px;background:currentColor;vertical-align:bottom`;
          return bar;
        });
        wave.replaceChildren(...bars);
        info.textContent = `PCM local: ${result.silences.length} sil\xEAncios em ${result.durationSeconds.toFixed(2)} s. Arquivo n\xE3o enviado; sil\xEAncio \xE9 estimado por RMS.`;
      } catch (error) {
        info.textContent = error instanceof Error ? error.message : "Falha na an\xE1lise PCM local.";
      } finally {
        if (audio) await audio.close();
        if (controller === current) controller = void 0;
        cancel.disabled = true;
        audioButton.disabled = false;
      }
    });
    return {
      getPlan() {
        const videoDuration = Number(duration.value);
        const selectedMode = mode.value;
        const matching = analysis && Math.abs(analysis.durationSeconds - videoDuration) < 0.01 ? analysis : void 0;
        const positions = planAdvancedMidrolls({ mode: selectedMode, durationSeconds: videoDuration, intervalSeconds: Number(interval.value), quantity: Number(input("midroll-quantity").value), ...input("midroll-start").value ? { startSeconds: Number(input("midroll-start").value) } : {}, includeStart: input("midroll-include-start").checked, includeEnd: input("midroll-include-end").checked, includePlayhead: input("midroll-include-playhead").checked, ...input("midroll-playhead").value ? { playheadSeconds: Number(input("midroll-playhead").value) } : {}, silences: matching?.silences });
        return { positions, mode: selectedMode, durationSeconds: videoDuration, source: selectedMode === "smart" ? `PCM local: ${audioFile.files?.[0]?.name ?? "arquivo selecionado"}; ${matching.silences.length} sil\xEAncios; limite ${input("midroll-threshold").value}% RMS, m\xEDnimo ${input("midroll-min-silence").value} ms; posi\xE7\xF5es sem sil\xEAncio pr\xF3ximo mant\xEAm intervalo` : "dura\xE7\xE3o e par\xE2metros informados", targets: positions.length, playheadSource: input("midroll-include-playhead").checked ? "posi\xE7\xE3o informada manualmente" : "n\xE3o inclu\xEDdo", analysisFps: selectedMode === "smart" ? Number(input("midroll-analysis-fps").value) : void 0 };
      }
    };
  }

  // src/ui/official-search.ts
  var SOURCE = "youtube-data-api";
  var TTL = 24 * 60 * 60 * 1e3;
  var MAX_ROWS = 75;
  var record = (value2) => value2 !== null && typeof value2 === "object" && !Array.isArray(value2) ? value2 : {};
  var invalid = () => new Error("O backend retornou dados oficiais incompat\xEDveis. Nenhum resultado foi incorporado.");
  var RFC3339 = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,9})?(?:Z|[+-]\d{2}:\d{2})$/i;
  function nullableText(value2, max = 1e3) {
    if (value2 === null) return null;
    if (typeof value2 !== "string" || value2.length > max) throw invalid();
    return value2;
  }
  function timestamp2(value2) {
    if (typeof value2 !== "string" || value2.length > 64 || !RFC3339.test(value2) || !Number.isFinite(Date.parse(value2)) || Date.now() - Date.parse(value2) > TTL || Date.parse(value2) - Date.now() > 3e5) throw invalid();
    return value2;
  }
  function nullableDate(value2) {
    const text2 = nullableText(value2, 64);
    if (text2 !== null && (!RFC3339.test(text2) || !Number.isFinite(Date.parse(text2)))) throw invalid();
    return text2;
  }
  function counter(value2) {
    if (value2 === null) return null;
    if (typeof value2 !== "string" || !/^\d{1,20}$/.test(value2) || BigInt(value2) > 18446744073709551615n) throw invalid();
    return value2;
  }
  function thumbnail2(value2) {
    const text2 = nullableText(value2, 2e3);
    if (text2 === null) return null;
    let url;
    try {
      url = new URL(text2);
    } catch {
      throw invalid();
    }
    if (url.protocol !== "https:" || url.username || url.password || url.hash || !["i.ytimg.com", "yt3.ggpht.com", "yt3.googleusercontent.com"].includes(url.hostname)) throw invalid();
    return text2;
  }
  function validateVideo(raw) {
    const item = record(raw);
    if (typeof item.id !== "string" || !/^[A-Za-z0-9_-]{11}$/.test(item.id) || item.source !== SOURCE || item.url !== `https://www.youtube.com/watch?v=${item.id}`) throw invalid();
    if (item.channelId !== null && (typeof item.channelId !== "string" || !/^UC[A-Za-z0-9_-]{22}$/.test(item.channelId))) throw invalid();
    const duration = nullableText(item.duration, 100);
    if (duration !== null && !/^P(?=.*\d)(?:\d+D)?(?:T(?:\d+H)?(?:\d+M)?(?:\d+(?:\.\d+)?S)?)?$/.test(duration)) throw invalid();
    return { id: item.id, title: nullableText(item.title), url: item.url, channelId: item.channelId, channelTitle: nullableText(item.channelTitle), publishedAt: nullableDate(item.publishedAt), duration, viewCount: counter(item.viewCount), likeCount: counter(item.likeCount), commentCount: counter(item.commentCount), thumbnail: thumbnail2(item.thumbnail), source: SOURCE, fetchedAt: timestamp2(item.fetchedAt) };
  }
  function validateChannel(raw) {
    const item = record(raw);
    if (typeof item.id !== "string" || !/^UC[A-Za-z0-9_-]{22}$/.test(item.id) || item.source !== SOURCE || item.url !== `https://www.youtube.com/channel/${item.id}` || ![true, false, null].includes(item.hiddenSubscriberCount)) throw invalid();
    const subscribers = counter(item.subscriberCount);
    if (item.hiddenSubscriberCount === true && subscribers !== null) throw invalid();
    return { id: item.id, title: nullableText(item.title), url: item.url, subscriberCount: subscribers, hiddenSubscriberCount: item.hiddenSubscriberCount, viewCount: counter(item.viewCount), videoCount: counter(item.videoCount), publishedAt: nullableDate(item.publishedAt), thumbnail: thumbnail2(item.thumbnail), source: SOURCE, fetchedAt: timestamp2(item.fetchedAt) };
  }
  function validatePage(value2, query, pageToken) {
    const item = record(value2), returnedQuery = record(item.query);
    if (item.source !== SOURCE || !Array.isArray(item.videos) || !Array.isArray(item.channels) || item.videos.length > query.maxResults || item.channels.length > query.maxResults || !Number.isInteger(item.requestCount) || Number(item.requestCount) < 1 || Number(item.requestCount) > 3 || !Array.isArray(item.warnings) || item.warnings.length > 20 || item.warnings.some((warning) => typeof warning !== "string" || warning.length > 1e3)) throw invalid();
    for (const key of ["q", "type", "order", "maxResults"]) if (returnedQuery[key] !== query[key]) throw invalid();
    if (returnedQuery.pageToken !== pageToken || query.type === "channel" && item.videos.length) throw invalid();
    const next = item.nextPageToken;
    if (next !== void 0 && (typeof next !== "string" || !next || next.length > 1e3 || [...next].some((character) => character.charCodeAt(0) < 32 || character.charCodeAt(0) === 127))) throw invalid();
    return { videos: item.videos.map(validateVideo), channels: item.channels.map(validateChannel), ...next ? { nextPageToken: next } : {}, fetchedAt: timestamp2(item.fetchedAt), requestCount: Number(item.requestCount), warnings: item.warnings };
  }
  function initOfficialSearch() {
    const section = document.getElementById("official-search");
    if (!section || section.dataset.initialized === "true") return;
    section.dataset.initialized = "true";
    section.innerHTML = `<div class="hero"><div><span class="eyebrow">FONTE OPCIONAL</span><h1>Pesquisa oficial do YouTube</h1><p>Consulte uma p\xE1gina de v\xEDdeos ou canais por a\xE7\xE3o. Os valores oficiais ficam separados da coleta local e dos indicadores do Prevlev.</p></div></div>
  <div class="card"><form id="yt-form"><div class="form-grid"><label>Fonte<select id="yt-source" required><option value="">Selecione uma fonte</option><option value="youtube-data-api">YouTube Data API</option></select></label><label>Consulta<input id="yt-q" required maxlength="200" placeholder="Ex.: astronomia" autocomplete="off"></label><label>Tipo<select id="yt-type"><option value="video">V\xEDdeos</option><option value="channel">Canais</option></select></label><label>Ordem da API<select id="yt-order"><option value="relevance">Relev\xE2ncia</option><option value="date">Data</option><option value="viewCount">Visualiza\xE7\xF5es</option></select></label><label>Itens por p\xE1gina<input id="yt-max-results" type="number" min="1" max="25" step="1" value="10" required></label></div>
  <label class="check"><input id="yt-consent" type="checkbox" required>Confirmo o envio desta consulta ao Google/YouTube e o uso da cota do projeto configurado. Li os <a href="https://www.youtube.com/t/terms" target="_blank" rel="noopener noreferrer">Termos do YouTube</a>, a <a href="https://policies.google.com/privacy" target="_blank" rel="noopener noreferrer">Privacidade do Google</a> e a <a href="https://github.com/onclickgrimes/prevlev/blob/main/docs/PRIVACY.md" target="_blank" rel="noopener noreferrer">Privacidade do Prevlev</a>.</label>
  <div class="row"><div><button id="yt-search" class="primary" type="submit">Pesquisar uma p\xE1gina</button> <button id="yt-cancel" type="button" disabled>Cancelar</button> <button id="yt-next" type="button" disabled>Pr\xF3xima p\xE1gina</button> <button id="yt-clear" type="button">Descartar resultados</button></div></div></form>
  <p id="yt-status" role="status" aria-live="polite">Selecione a fonte e confirme o envio antes de pesquisar. Nenhuma consulta autom\xE1tica \xE9 realizada.</p><p class="muted">M\xE1ximo de tr\xEAs p\xE1ginas manuais e 75 resultados nesta visualiza\xE7\xE3o. Inscritos p\xFAblicos podem estar arredondados ou ocultos. Valores ausentes aparecem como \u2014. Estat\xEDsticas dos canais est\xE3o na pesquisa do tipo Canais.</p></div>
  <div id="yt-results" class="card" hidden><h2>Dados oficiais do YouTube</h2><p id="yt-summary" class="muted"></p><p class="muted">N\xE3o representa todo o cat\xE1logo. Os dados ficam apenas nesta visualiza\xE7\xE3o, por at\xE9 24 horas, sem exporta\xE7\xE3o, importa\xE7\xE3o ou c\xE1lculos derivados.</p><ul id="yt-warnings"></ul>
  <div id="yt-videos" class="table-wrap"><table><thead><tr><th>V\xEDdeo no YouTube</th><th>Canal</th><th>Publicado em</th><th>Dura\xE7\xE3o original</th><th>Visualiza\xE7\xF5es</th><th>Gostei</th><th>Coment\xE1rios</th></tr></thead><tbody id="yt-video-rows"></tbody></table></div>
  <div id="yt-channels" class="table-wrap" hidden><table><thead><tr><th>Canal no YouTube</th><th>Inscritos oficiais</th><th>Visualiza\xE7\xF5es</th><th>V\xEDdeos</th><th>Criado em</th></tr></thead><tbody id="yt-channel-rows"></tbody></table></div></div>`;
    const element4 = (id) => section.querySelector(`#${id}`);
    const form = element4("yt-form"), source = element4("yt-source"), consent = element4("yt-consent"), q = element4("yt-q"), type = element4("yt-type"), order = element4("yt-order"), max = element4("yt-max-results"), search = element4("yt-search"), cancel = element4("yt-cancel"), next = element4("yt-next");
    let epoch = 0, active, frozen, backendIdentity, nextToken, pages = 0, requests = 0, expiresAt = 0, expiryTimer;
    let videos = [], channels = [], warnings = [];
    const status = (message, error = false) => {
      element4("yt-status").textContent = message;
      element4("yt-status").classList.toggle("error", error);
    };
    const controls = (busy) => {
      search.disabled = busy;
      cancel.disabled = !busy;
      next.disabled = busy || !nextToken || pages >= 3 || !frozen;
      for (const input of [source, consent, q, type, order, max]) input.disabled = busy;
    };
    const clearRows = () => {
      videos = [];
      channels = [];
      warnings = [];
      frozen = void 0;
      backendIdentity = void 0;
      nextToken = void 0;
      pages = 0;
      requests = 0;
      expiresAt = 0;
      if (expiryTimer) clearTimeout(expiryTimer);
      expiryTimer = void 0;
      element4("yt-video-rows").replaceChildren();
      element4("yt-channel-rows").replaceChildren();
      element4("yt-warnings").replaceChildren();
      element4("yt-summary").textContent = "";
      element4("yt-results").hidden = true;
    };
    const discard = (message) => {
      epoch++;
      active?.abort();
      active = void 0;
      clearRows();
      controls(false);
      status(message);
    };
    const expire = () => {
      if (expiresAt && Date.now() >= expiresAt) {
        discard("Os dados oficiais expiraram ap\xF3s 24 horas e foram descartados. Pesquise novamente para atualizar.");
        return true;
      }
      return false;
    };
    const format = (value2) => value2 === null ? "\u2014" : new Intl.NumberFormat("pt-BR").format(BigInt(value2));
    const cell = (row3, value2) => {
      const td = document.createElement("td");
      td.textContent = value2;
      row3.append(td);
      return td;
    };
    const link = (cell2, url, title) => {
      const a = document.createElement("a");
      a.href = url;
      a.target = "_blank";
      a.rel = "noopener noreferrer";
      a.textContent = title ?? "T\xEDtulo n\xE3o dispon\xEDvel";
      cell2.append(a);
    };
    const render2 = () => {
      element4("yt-results").hidden = false;
      element4("yt-videos").hidden = frozen?.type !== "video";
      element4("yt-channels").hidden = frozen?.type !== "channel";
      const videoRows = element4("yt-video-rows"), channelRows = element4("yt-channel-rows");
      videoRows.replaceChildren();
      channelRows.replaceChildren();
      for (const item of videos) {
        const row3 = document.createElement("tr");
        link(cell(row3, ""), item.url, item.title);
        const channelCell = cell(row3, "");
        if (item.channelId) link(channelCell, `https://www.youtube.com/channel/${item.channelId}`, item.channelTitle);
        else channelCell.textContent = item.channelTitle ?? "\u2014";
        cell(row3, item.publishedAt ?? "\u2014");
        cell(row3, item.duration ?? "\u2014");
        cell(row3, format(item.viewCount));
        cell(row3, format(item.likeCount));
        cell(row3, format(item.commentCount));
        videoRows.append(row3);
      }
      for (const item of channels) {
        const row3 = document.createElement("tr");
        link(cell(row3, ""), item.url, item.title);
        cell(row3, item.hiddenSubscriberCount === true ? "Oculto" : format(item.subscriberCount));
        cell(row3, format(item.viewCount));
        cell(row3, format(item.videoCount));
        cell(row3, item.publishedAt ?? "\u2014");
        channelRows.append(row3);
      }
      const list = element4("yt-warnings");
      list.replaceChildren();
      for (const warning of [...new Set(warnings)].slice(0, 20)) {
        const li = document.createElement("li");
        li.textContent = warning;
        list.append(li);
      }
      element4("yt-summary").textContent = `Fonte: YouTube Data API \xB7 P\xE1ginas manuais: ${pages}/3 \xB7 Solicita\xE7\xF5es HTTP: ${requests} \xB7 Descarte at\xE9: ${new Date(expiresAt).toISOString()}`;
      controls(false);
    };
    const currentQuery = () => {
      if (source.value !== SOURCE || !consent.checked) throw new Error("Selecione YouTube Data API e confirme o envio ao Google/YouTube.");
      const query = q.value.trim(), count2 = Number(max.value);
      if (!query || [...query].length > 200 || !Number.isInteger(count2) || count2 < 1 || count2 > 25) throw new Error("Informe uma consulta de at\xE9 200 caracteres e de 1 a 25 itens por p\xE1gina.");
      if (!["video", "channel"].includes(type.value) || !["relevance", "date", "viewCount"].includes(order.value)) throw new Error("Tipo ou ordem da fonte inv\xE1lida.");
      return { q: query, type: type.value, order: order.value, maxResults: count2 };
    };
    const run = async (append) => {
      if (active) return;
      if (expire() && append) return;
      let query;
      try {
        query = currentQuery();
      } catch (error) {
        status(error instanceof Error ? error.message : "Consulta inv\xE1lida.", true);
        return;
      }
      if (append && (!frozen || !nextToken || pages >= 3 || JSON.stringify(query) !== JSON.stringify(frozen))) {
        discard("A consulta mudou ou atingiu o limite. Inicie uma nova pesquisa.");
        return;
      }
      if (!append) clearRows();
      const controller = new AbortController(), requestEpoch = ++epoch, token = append ? nextToken : void 0;
      active = controller;
      controls(true);
      status("Consultando a fonte oficial. Voc\xEA pode cancelar a espera; uma solicita\xE7\xE3o aceita pode consumir cota.");
      try {
        const settings = await getSettings();
        if (requestEpoch !== epoch || controller.signal.aborted) return;
        const identity = JSON.stringify([settings.backendUrl, settings.backendToken]);
        if (append && identity !== backendIdentity) throw new Error("A conex\xE3o do backend mudou. Inicie uma nova pesquisa para manter a origem consistente.");
        const response = await callBackendOperation(settings, "/v1/youtube/search", { ...query, ...token ? { pageToken: token } : {}, apiConsent: true }, controller.signal);
        if (requestEpoch !== epoch || controller.signal.aborted) return;
        if (response.status !== "ok") throw new Error(typeof response.error === "string" ? response.error.slice(0, 2e3) : "A fonte oficial n\xE3o est\xE1 dispon\xEDvel.");
        if (response.source !== SOURCE) throw invalid();
        const page = validatePage(response.data, query, token);
        const incoming = query.type === "video" ? page.videos : page.channels, observedTimes = [page.fetchedAt, ...incoming.map((item) => item.fetchedAt)].map(Date.parse), expiry = Math.min(...observedTimes) + TTL;
        expiresAt = append ? Math.min(expiresAt, expiry) : expiry;
        frozen = query;
        backendIdentity = identity;
        pages++;
        requests += page.requestCount;
        warnings.push(...page.warnings);
        if (query.type === "video") {
          const map = new Map(videos.map((item) => [item.id, item]));
          for (const item of page.videos) map.set(item.id, item);
          videos = [...map.values()].slice(0, MAX_ROWS);
          channels = [];
        } else {
          const map = new Map(channels.map((item) => [item.id, item]));
          for (const item of page.channels) map.set(item.id, item);
          channels = [...map.values()].slice(0, MAX_ROWS);
          videos = [];
        }
        nextToken = pages < 3 ? page.nextPageToken : void 0;
        if (expiryTimer) clearTimeout(expiryTimer);
        expiryTimer = setTimeout(expire, Math.max(1, expiresAt - Date.now()));
        render2();
        status(incoming.length ? `P\xE1gina ${pages} conclu\xEDda. ${pages >= 3 ? "Limite de tr\xEAs p\xE1ginas atingido." : nextToken ? "A pr\xF3xima p\xE1gina exige outro clique." : "A API n\xE3o informou pr\xF3xima p\xE1gina."}` : "A API n\xE3o retornou resultados nesta p\xE1gina.");
      } catch (error) {
        if (requestEpoch === epoch && !controller.signal.aborted) {
          clearRows();
          status(error instanceof Error ? error.message : "N\xE3o foi poss\xEDvel concluir a pesquisa oficial.", true);
        }
      } finally {
        if (requestEpoch === epoch) {
          active = void 0;
          controls(false);
        }
      }
    };
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      void run(false);
    });
    next.addEventListener("click", () => {
      void run(true);
    });
    cancel.addEventListener("click", () => discard("Espera cancelada e resultados descartados. Uma solicita\xE7\xE3o j\xE1 aceita pelo Google pode ter consumido cota."));
    element4("yt-clear").addEventListener("click", () => discard("Resultados oficiais descartados desta visualiza\xE7\xE3o."));
    for (const input of [source, q, type, order, max]) input.addEventListener("input", () => {
      if (input === source) consent.checked = false;
      if (frozen || active) discard("A consulta mudou. Inicie uma nova pesquisa; a pr\xF3xima p\xE1gina foi invalidada.");
    });
    consent.addEventListener("change", () => {
      if (!consent.checked && (frozen || active)) discard("Consentimento desmarcado; resultados descartados.");
    });
    window.addEventListener("focus", expire);
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible") expire();
    });
  }

  // src/core/analytics.ts
  function buildAnalyticsReport(videos, options = {}) {
    const now2 = options.now ?? Date.now();
    validateNow(now2);
    const filter = { ...options.filter };
    if (options.publishedAfter !== void 0) filter.publishedAfter = options.publishedAfter;
    if (options.publishedBefore !== void 0) filter.publishedBefore = options.publishedBefore;
    validateResearchFilter(filter);
    const dates = { publishedAfter: filter.publishedAfter, publishedBefore: filter.publishedBefore, publishedBeforeExclusive: filter.publishedBeforeExclusive };
    const eligible = videos.filter((video) => video.source !== "youtube-data-api");
    const unique = deduplicateVideos(eligible, now2);
    const baseline = unique.videos.map((video) => ({ ...video, views: knownCount(video.views), subscribers: knownCount(video.subscribers), durationSeconds: knownCount(video.durationSeconds), publishedAt: validDate(video.publishedAt, now2)?.iso }));
    const included = selectResearchVideos(baseline, filter, now2);
    const dateIncludedCount = selectResearchVideos(baseline, dates, now2).length;
    const views = numbers(included.map((video) => video.views));
    const durations = numbers(included.map((video) => video.durationSeconds));
    const rates = numbers(included.map((video) => lifetimeVph(video, now2)));
    const identities = groupChannelIdentities(included);
    const channelBuckets = /* @__PURE__ */ new Map();
    const monthBuckets = /* @__PURE__ */ new Map();
    const provenance = { "youtube-dom": 0, "public-page": 0, "user-provided": 0, "youtube-data-api": 0, unspecified: 0 };
    const formats = { short: 0, long: 0, unknown: 0 };
    const rows = [];
    for (const video of included) {
      const identity = identities.get(video);
      if (identity) {
        const group = channelBuckets.get(identity.key) ?? { label: identity.label, videos: [] };
        group.videos.push(video);
        channelBuckets.set(identity.key, group);
      }
      if (video.publishedAt) {
        const month = video.publishedAt.slice(0, 7);
        const group = monthBuckets.get(month) ?? [];
        group.push(video);
        monthBuckets.set(month, group);
      }
      const source = video.source;
      if (source && Object.hasOwn(provenance, source)) provenance[source]++;
      else provenance.unspecified++;
      const format = video.isShort === true ? "short" : video.isShort === false ? "long" : "unknown";
      formats[format]++;
      const comparison = researchComparison(video, baseline, filter.comparisonMode);
      rows.push({ id: video.id, title: video.title, url: video.url, channel: video.channel, views: video.views, publishedAt: video.publishedAt, durationSeconds: video.durationSeconds, format, lifetimeVph: lifetimeVph(video, now2), outlierScore: comparison.score, outlierReferenceCount: comparison.referenceCount, outlierMethod: comparison.method, source, outlierStatus: comparison.score === void 0 ? "unknown" : "known", outlierComparisonMode: filter.comparisonMode ?? "sample-median", outlierReference: comparison.reference ?? null, outlierPositiveReferenceCount: comparison.positiveReferenceCount, outlierProvenance: comparison.provenance, outlierLimitation: comparison.limitation });
    }
    const knownDates = included.filter((video) => video.publishedAt !== void 0).length;
    const channels = [...channelBuckets].map(([key, group]) => {
      const knownViews = numbers(group.videos.map((video) => video.views));
      const knownRates = numbers(group.videos.map((video) => lifetimeVph(video, now2)));
      return { key, label: group.label, videoCount: group.videos.length, knownViews: knownViews.length, missingViews: group.videos.length - knownViews.length, totalViews: total(knownViews), meanViews: mean(knownViews), medianViews: median2(knownViews), meanLifetimeVph: mean(knownRates), medianLifetimeVph: median2(knownRates), shorts: group.videos.filter((video) => video.isShort === true).length, longs: group.videos.filter((video) => video.isShort === false).length, unknownFormats: group.videos.filter((video) => video.isShort === void 0).length };
    }).sort((left, right) => left.label.localeCompare(right.label) || left.key.localeCompare(right.key));
    const publicationMonths = [...monthBuckets].map(([month, group]) => {
      const knownViews = numbers(group.map((video) => video.views)), knownDurations = numbers(group.map((video) => video.durationSeconds));
      return { month, videoCount: group.length, knownViews: knownViews.length, missingViews: group.length - knownViews.length, totalViews: total(knownViews), knownDurationCount: knownDurations.length, missingDurationCount: group.length - knownDurations.length, totalDurationSeconds: total(knownDurations) };
    }).sort((left, right) => left.month.localeCompare(right.month));
    const publicationTimes = [...new Set(included.flatMap((video) => video.publishedAt ? [Date.parse(video.publishedAt)] : []))].sort((left, right) => left - right);
    const gaps = publicationTimes.slice(1).map((time, index) => (time - publicationTimes[index]) / 864e5);
    const limitations = [
      "A amostra cont\xE9m somente v\xEDdeos carregados ou fornecidos; n\xE3o representa o cat\xE1logo completo de um canal nem tr\xE1fego oficial.",
      "Visualiza\xE7\xF5es s\xE3o contadores observados, n\xE3o visualiza\xE7\xF5es recebidas no per\xEDodo selecionado; as datas filtram a publica\xE7\xE3o dos v\xEDdeos.",
      "VPH \xE9 a m\xE9dia de visualiza\xE7\xF5es desde a publica\xE7\xE3o, n\xE3o a contagem dos \xFAltimos 60 minutos. Datas relativas coletadas podem ser aproximadas.",
      filter.comparisonMode === "sample-channel-reference" ? "Outlier alternativo usa a m\xE9dia da amostra completa do canal conhecido anterior aos filtros, m\xEDnimo de 3 refer\xEAncias. Shorts usam mediana dos positivos com pelo menos 10 refer\xEAncias positivas; abaixo disso usam m\xE9dia. N\xE3o equivale \xE0 refer\xEAncia do canal completo nem ao \xEDndice propriet\xE1rio." : "Outlier padr\xE3o usa mediana das refer\xEAncias eleg\xEDveis da amostra anterior aos filtros, com pelo menos tr\xEAs refer\xEAncias eleg\xEDveis. N\xE3o equivale ao \xEDndice propriet\xE1rio.",
      "A compara\xE7\xE3o agrupa Shorts, n\xE3o Shorts e formato desconhecido separadamente; v\xEDdeos com formato desconhecido s\xE3o comparados entre si, sem inferir seu formato.",
      "Meses de publica\xE7\xE3o usam UTC. Intervalos s\xE3o lacunas entre datas distintas da amostra combinada, sem interpolar publica\xE7\xF5es ausentes nem prever frequ\xEAncia futura de um canal.",
      "Receita, RPM, lucro, geografia e monetiza\xE7\xE3o n\xE3o s\xE3o conhecidos por estes dados e n\xE3o s\xE3o estimados neste relat\xF3rio."
    ];
    if (videos.length !== eligible.length) limitations.push(`${videos.length - eligible.length} registros marcados como youtube-data-api foram exclu\xEDdos; o relat\xF3rio n\xE3o calcula m\xE9tricas derivadas sobre dados da API oficial.`);
    if (unique.excluded) limitations.push(`${unique.excluded} registros repetidos por ID foram exclu\xEDdos antes dos filtros e c\xE1lculos. Foi preservado o registro inteiro com observedAt completo v\xE1lido mais recente; sem esse timestamp, ou em empate, vale a primeira entrada. Contadores de registros diferentes n\xE3o foram combinados.`);
    if (unique.conflicts) limitations.push(`${unique.conflicts} duplicatas tinham contadores ou metadados conflitantes; a regra expl\xEDcita de sele\xE7\xE3o acima foi aplicada, sem somar vers\xF5es do mesmo v\xEDdeo.`);
    if (provenance.unspecified) limitations.push(`${provenance.unspecified} registros inclu\xEDdos n\xE3o declaram origem. Aus\xEAncia de origem n\xE3o foi interpretada como API oficial.`);
    if (dates.publishedAfter !== void 0 || dates.publishedBefore !== void 0 || dates.publishedBeforeExclusive !== void 0) limitations.push("O filtro de publica\xE7\xE3o exclui v\xEDdeos com datas ausentes, inv\xE1lidas ou futuras. Cobertura e totais descrevem somente os v\xEDdeos inclu\xEDdos.");
    if (included.length < baseline.length) limitations.push("Filtros locais restringem a amostra exibida. Os totais e a cobertura descrevem somente os v\xEDdeos inclu\xEDdos; a refer\xEAncia de outlier preserva a amostra completa eleg\xEDvel.");
    if (rows.some((video) => !video.publishedAt)) limitations.push("Datas ausentes, inv\xE1lidas ou futuras permanecem desconhecidas e ficam fora dos agrupamentos mensais e do c\xE1lculo de VPH.");
    if (views.length && total(views) === void 0 || durations.length && total(durations) === void 0) limitations.push("Somas fora do intervalo num\xE9rico dispon\xEDvel permanecem desconhecidas; n\xE3o foram convertidas em infinito nem zero.");
    return {
      generatedAt: new Date(now2).toISOString(),
      scope: { inputCount: videos.length, includedCount: included.length, excludedApiCount: videos.length - eligible.length, excludedDuplicateCount: unique.excluded, excludedByDateCount: baseline.length - dateIncludedCount, excludedByFilterCount: baseline.length - included.length, ...dates, filter },
      coverage: { views: coverage(included.length, views.length), publicationDate: coverage(included.length, knownDates), duration: coverage(included.length, durations.length), channel: coverage(included.length, identities.size) },
      totals: { knownViews: total(views), meanViews: mean(views), medianViews: median2(views), meanLifetimeVph: mean(rates), medianLifetimeVph: median2(rates), knownDurationSeconds: total(durations) },
      formats,
      provenance,
      channels,
      publicationMonths,
      medianPublishGapDays: median2(gaps),
      videos: rows,
      topVideos: [...rows].sort((left, right) => left.views === void 0 ? right.views === void 0 ? 0 : 1 : right.views === void 0 ? -1 : right.views - left.views).slice(0, 20),
      limitations
    };
  }
  function deriveHistoryTrend(records, now2 = Date.now()) {
    validateNow(now2);
    const warnings = [];
    const excludedApiCount = records.filter((record2) => record2.source === "youtube-data-api").length;
    const buckets = /* @__PURE__ */ new Map();
    for (const record2 of records) {
      if (record2.source === "youtube-data-api") continue;
      const date2 = record2.observedAt.includes("T") ? validDate(record2.observedAt, now2) : void 0;
      if (!record2.videoId.trim() || !date2) {
        warnings.push("Observa\xE7\xE3o sem ID ou sem timestamp completo v\xE1lido com fuso, ou com data futura, foi exclu\xEDda.");
        continue;
      }
      const key = JSON.stringify([record2.videoId, date2.iso]);
      const group = buckets.get(key) ?? [];
      group.push({ ...record2, observedAt: date2.iso, views: knownCount(record2.views), subscribers: knownCount(record2.subscribers) });
      buckets.set(key, group);
      if (record2.views !== void 0 && knownCount(record2.views) === void 0 || record2.subscribers !== void 0 && knownCount(record2.subscribers) === void 0) warnings.push("Contador absoluto inv\xE1lido permanece desconhecido; n\xE3o foi convertido em zero.");
    }
    const observations = [...buckets.values()].map((group) => {
      if (group.length === 1) return group[0];
      const views = new Set(numbers(group.map((record2) => record2.views))), subscribers = new Set(numbers(group.map((record2) => record2.subscribers)));
      if (views.size > 1 || subscribers.size > 1) warnings.push("Contadores conflitantes no mesmo instante permanecem desconhecidos; nenhuma taxa foi calculada com o valor conflitante.");
      return { ...group[0], views: views.size === 1 ? [...views][0] : void 0, subscribers: subscribers.size === 1 ? [...subscribers][0] : void 0 };
    }).sort((left, right) => Date.parse(left.observedAt) - Date.parse(right.observedAt) || left.videoId.localeCompare(right.videoId));
    const grouped = /* @__PURE__ */ new Map();
    for (const observation of observations) {
      const group = grouped.get(observation.videoId) ?? [];
      group.push(observation);
      grouped.set(observation.videoId, group);
    }
    const changes = /* @__PURE__ */ new Map();
    for (const group of grouped.values()) {
      for (const metric of ["views", "subscribers"]) {
        let previous;
        for (const observation of group) {
          const value2 = observation[metric];
          if (value2 === void 0) continue;
          if (previous) {
            const elapsedHours = (Date.parse(observation.observedAt) - Date.parse(previous.observedAt)) / 36e5;
            const delta = value2 - previous[metric];
            const key = JSON.stringify([observation.videoId, previous.observedAt, observation.observedAt]);
            const change = changes.get(key) ?? { videoId: observation.videoId, from: previous.observedAt, to: observation.observedAt, elapsedHours };
            const rate = delta / elapsedHours;
            if (metric === "views") {
              change.viewsDelta = delta;
              change.viewsPerHour = Number.isFinite(rate) ? rate : void 0;
            } else {
              change.subscribersDelta = delta;
              change.subscribersPerHour = Number.isFinite(rate) ? rate : void 0;
            }
            if (!Number.isFinite(rate)) warnings.push("Taxa fora da precis\xE3o num\xE9rica dispon\xEDvel permanece desconhecida; a diferen\xE7a observada foi preservada.");
            changes.set(key, change);
            if (delta < 0) warnings.push(`Contador de ${metric === "views" ? "visualiza\xE7\xF5es" : "inscritos"} diminuiu em ${observation.videoId}; a diferen\xE7a negativa foi preservada como poss\xEDvel revis\xE3o do contador.`);
          }
          previous = observation;
        }
      }
    }
    if (excludedApiCount) warnings.push(`${excludedApiCount} observa\xE7\xF5es da API oficial foram exclu\xEDdas das m\xE9tricas derivadas.`);
    warnings.push("Diferen\xE7as e taxas usam somente instantes realmente observados; n\xE3o h\xE1 hist\xF3rico retroativo, interpola\xE7\xE3o, previs\xE3o nem estimativa financeira.");
    return { observations, changes: [...changes.values()].sort((left, right) => Date.parse(left.to) - Date.parse(right.to) || left.videoId.localeCompare(right.videoId) || Date.parse(left.from) - Date.parse(right.from)), excludedApiCount, warnings: [...new Set(warnings)] };
  }
  function reportRows(report) {
    return report.videos.map((video) => ({ video_id: video.id, title: video.title, url: video.url, channel: video.channel, source: video.source, format: video.format, observed_views: video.views, published_at: video.publishedAt, duration_seconds: video.durationSeconds, lifetime_average_vph: video.lifetimeVph, sample_outlier: video.outlierScore, outlier_reference_count: video.outlierReferenceCount, outlier_method: video.outlierMethod, outlier_status: video.outlierStatus, outlier_comparison_mode: video.outlierComparisonMode, outlier_reference: video.outlierReference ?? "desconhecido", outlier_positive_reference_count: video.outlierPositiveReferenceCount, outlier_provenance: video.outlierProvenance, outlier_limitation: video.outlierLimitation, sample_input_count: report.scope.inputCount, sample_included_count: report.scope.includedCount, excluded_api_count: report.scope.excludedApiCount, excluded_duplicate_count: report.scope.excludedDuplicateCount, excluded_by_filter_count: report.scope.excludedByFilterCount }));
  }
  function reportMarkdown(report) {
    const value2 = (number4) => number4 === void 0 ? "desconhecido" : String(number4);
    return ["# Relat\xF3rio local Prevlev", "", `Gerado em ${report.generatedAt}. Amostra inclu\xEDda: ${report.scope.includedCount}/${report.scope.inputCount} v\xEDdeos.`, "", `Visualiza\xE7\xF5es conhecidas: ${value2(report.totals.knownViews)}. M\xE9dia: ${value2(report.totals.meanViews)}. Mediana: ${value2(report.totals.medianViews)}.`, `VPH m\xE9dio desde publica\xE7\xE3o: ${value2(report.totals.meanLifetimeVph)}. Intervalo mediano observado entre publica\xE7\xF5es: ${value2(report.medianPublishGapDays)} dias.`, "", `Modo de compara\xE7\xE3o: ${report.scope.filter?.comparisonMode ?? "sample-median"}. Exclu\xEDdos: ${report.scope.excludedApiCount} API oficial, ${report.scope.excludedDuplicateCount} duplicatas e ${report.scope.excludedByFilterCount} por filtros.`, "", `V\xEDdeos por views observadas: at\xE9 20 de ${report.scope.includedCount} inclu\xEDdos; ${report.scope.includedCount - report.topVideos.length} fora desta tabela.`, "", "| V\xEDdeo | Canal | Views observadas | VPH m\xE9dio hist\xF3rico | Outlier | M\xE9todo previsto | Denominador | Refer\xEAncias candidatas | Refer\xEAncias positivas | Proced\xEAncia |", "| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |", ...report.topVideos.map((video) => `| ${markdown(video.title)} | ${markdown(video.channel ?? "desconhecido")} | ${value2(video.views)} | ${value2(video.lifetimeVph)} | ${value2(video.outlierScore)} | ${markdown(video.outlierMethod ?? "desconhecido")} | ${value2(video.outlierReference ?? void 0)} | ${value2(video.outlierReferenceCount)} | ${video.outlierPositiveReferenceCount} | ${markdown(video.outlierProvenance)} |`), "", "## Limites dos dados", "", ...report.limitations.map((limitation) => `- ${markdown(limitation)}`), ""].join("\n");
  }
  function knownCount(value2) {
    return typeof value2 === "number" && Number.isFinite(value2) && value2 >= 0 ? value2 : void 0;
  }
  function deduplicateVideos(videos, now2) {
    const selected = [], indices = /* @__PURE__ */ new Map();
    let excluded = 0, conflicts = 0;
    const time = (video) => video.observedAt?.includes("T") ? validDate(video.observedAt, now2)?.time : void 0;
    const signature = (video) => JSON.stringify([knownCount(video.views), knownCount(video.subscribers), knownCount(video.durationSeconds), video.publishedAt, video.channelId, video.channelUrl, video.channel, video.isShort, video.source]);
    for (const video of videos) {
      const key = /^[A-Za-z0-9_-]{1,128}$/.test(video.id) ? video.id : void 0;
      const index = key === void 0 ? void 0 : indices.get(key);
      if (index === void 0) {
        if (key !== void 0) indices.set(key, selected.length);
        selected.push(video);
        continue;
      }
      excluded++;
      const previous = selected[index];
      if (signature(previous) !== signature(video)) conflicts++;
      const previousTime = time(previous), nextTime = time(video);
      if (nextTime !== void 0 && (previousTime === void 0 || nextTime > previousTime)) selected[index] = video;
    }
    return { videos: selected, excluded, conflicts };
  }
  function numbers(values) {
    return values.filter((value2) => knownCount(value2) !== void 0);
  }
  function total(values) {
    if (!values.length) return void 0;
    const sum = values.reduce((sum2, value2) => sum2 + value2, 0);
    return Number.isFinite(sum) ? sum : void 0;
  }
  function mean(values) {
    return values.length ? knownCount(values.reduce((sum, value2) => sum + value2 / values.length, 0)) : void 0;
  }
  function median2(values) {
    const value2 = median(values);
    if (value2 === void 0 || Number.isFinite(value2)) return value2;
    const sorted = [...values].sort((left, right) => left - right), middle = Math.floor(sorted.length / 2);
    return knownCount(sorted[middle - 1] / 2 + sorted[middle] / 2);
  }
  function coverage(count2, known3) {
    return { known: known3, missing: count2 - known3 };
  }
  function validateNow(now2) {
    if (!Number.isFinite(now2) || Math.abs(now2) > 864e13) throw new Error("Informe um instante atual v\xE1lido para o relat\xF3rio.");
  }
  function validDate(value2, now2) {
    if (!value2 || !/^\d{4}-\d{2}-\d{2}(?:T\d{2}:\d{2}(?::\d{2}(?:\.\d{1,3})?)?(?:Z|[+-]\d{2}:\d{2}))?$/.test(value2)) return void 0;
    try {
      validateVideoFilter({ publishedAfter: value2 });
    } catch {
      return void 0;
    }
    const time = Date.parse(value2);
    return Number.isFinite(time) && time <= now2 ? { iso: new Date(time).toISOString(), time } : void 0;
  }
  function markdown(text2) {
    return text2.replace(/[\\`*_{}[\]<>#|]/g, "\\$&").replace(/\r?\n/g, " ");
  }

  // src/ui/analytics.ts
  function initAnalyticsTools(deps) {
    const section = document.getElementById("analytics");
    if (!section || section.dataset.analyticsReady) return;
    section.dataset.analyticsReady = "true";
    section.innerHTML = `
    <div class="card"><span class="eyebrow">DADOS OBSERVADOS NO NAVEGADOR</span><h2>Analytics local</h2>
      <p>Explore a cole\xE7\xE3o carregada, a cobertura dos dados e os v\xEDdeos publicados por m\xEAs. Atualize o relat\xF3rio ap\xF3s mudar a coleta ou os filtros.</p>
      <div class="row"><label>Escopo do relat\xF3rio<select id="analytics-source"><option value="all">Toda a cole\xE7\xE3o</option><option value="filtered">Aplicar filtros da pesquisa</option></select></label><button id="analytics-refresh" class="primary">Atualizar relat\xF3rio</button></div>
      <p id="analytics-status" role="status" aria-live="polite">Atualize para calcular um relat\xF3rio com a cole\xE7\xE3o atual.</p>
      <div class="row"><button id="analytics-export-json" disabled>Exportar JSON</button><button id="analytics-export-csv" disabled>Exportar CSV</button><button id="analytics-export-markdown" disabled>Exportar Markdown</button></div>
    </div>
    <div id="analytics-result" hidden>
      <div class="card"><h3>Amostra e proced\xEAncia</h3><p id="analytics-scope"></p><p id="analytics-provenance"></p><p id="analytics-filter-summary"></p><p id="analytics-comparison"></p></div>
      <div id="analytics-totals" class="metrics"></div>
      <div class="grid two"><div class="card"><h3>Cobertura dos dados inclu\xEDdos</h3><div class="table-wrap"><table><thead><tr><th>Dado</th><th>Conhecidos</th><th>Desconhecidos</th></tr></thead><tbody id="analytics-coverage"></tbody></table></div></div>
      <div class="card"><h3>Formatos observados</h3><div id="analytics-formats"></div><p>Dura\xE7\xE3o isolada n\xE3o determina se um v\xEDdeo \xE9 Short. Formato n\xE3o informado permanece desconhecido.</p></div></div>
      <div class="card"><h3>Canais identificados</h3><p>Identidades conhecidas s\xE3o agrupadas com cautela. Nomes iguais n\xE3o unem canais com IDs distintos.</p><div class="table-wrap"><table><thead><tr><th>Canal</th><th>V\xEDdeos</th><th>Views conhecidas</th><th>Dados de views</th><th>M\xE9dia</th><th>Mediana</th><th>VPH m\xE9dio hist\xF3rico</th></tr></thead><tbody id="analytics-channels"></tbody></table></div></div>
      <div class="card"><h3>Publica\xE7\xF5es observadas por m\xEAs</h3><p>Meses em UTC; views s\xE3o os contadores atuais dos v\xEDdeos publicados no m\xEAs, n\xE3o o tr\xE1fego recebido naquele m\xEAs.</p><div class="table-wrap"><table><thead><tr><th>M\xEAs UTC</th><th>V\xEDdeos</th><th>Views conhecidas</th><th>Views ausentes</th><th>Dura\xE7\xE3o conhecida (s)</th><th>Dura\xE7\xF5es ausentes</th></tr></thead><tbody id="analytics-months"></tbody></table></div></div>
      <div class="card"><h3>At\xE9 20 v\xEDdeos por views observadas</h3><p>O outlier conserva a amostra completa eleg\xEDvel anterior aos filtros. Sem refer\xEAncia suficiente, o valor permanece desconhecido.</p><div class="table-wrap"><table><thead><tr><th>V\xEDdeo</th><th>Canal</th><th>Formato</th><th>Views observadas</th><th>VPH m\xE9dio hist\xF3rico</th><th>Outlier da amostra</th></tr></thead><tbody id="analytics-top"></tbody></table></div></div>
      <div class="card"><h3>Limites e origem dos resultados</h3><ul id="analytics-limitations"></ul></div>
    </div>`;
    const get = (id) => section.querySelector(`#analytics-${id}`);
    const source = get("source");
    const status = get("status");
    const result = get("result");
    const exports = ["json", "csv", "markdown"].map((format) => get(`export-${format}`));
    let report;
    const disableExports = (disabled) => exports.forEach((button) => {
      button.disabled = disabled;
    });
    const invalidate = () => {
      report = void 0;
      result.hidden = true;
      disableExports(true);
      status.textContent = "Escopo alterado. Atualize para recalcular o relat\xF3rio.";
      status.classList.remove("error");
    };
    source.addEventListener("change", invalidate);
    get("refresh").addEventListener("click", () => {
      try {
        const snapshot2 = deps.snapshot();
        report = buildAnalyticsReport(snapshot2.videos, source.value === "filtered" ? { filter: deps.filter() } : {});
        renderReport(report, snapshot2.warnings);
        status.textContent = `Relat\xF3rio atualizado em ${new Date(report.generatedAt).toLocaleString("pt-BR", { timeZone: "UTC" })} UTC. ${report.scope.includedCount} v\xEDdeos inclu\xEDdos.`;
        status.classList.remove("error");
        result.hidden = false;
        disableExports(false);
      } catch (error) {
        report = void 0;
        result.hidden = true;
        disableExports(true);
        status.textContent = error instanceof Error ? error.message : "N\xE3o foi poss\xEDvel calcular o relat\xF3rio.";
        status.classList.add("error");
      }
    });
    const exportFile = (format) => {
      if (!report) return;
      const content = format === "json" ? JSON.stringify(report, null, 2) : format === "csv" ? toCsv(reportRows(report)) : reportMarkdown(report);
      const mime = format === "json" ? "application/json" : format === "csv" ? "text/csv;charset=utf-8" : "text/markdown;charset=utf-8";
      downloadBlob(new Blob([content], { type: mime }), `prevlev-analytics.${format === "markdown" ? "md" : format}`);
    };
    exports.forEach((button, index) => button.addEventListener("click", () => exportFile(["json", "csv", "markdown"][index])));
    function renderReport(current, sourceWarnings) {
      const scope = current.scope;
      get("scope").textContent = `${scope.inputCount} registros recebidos \xB7 ${scope.includedCount} v\xEDdeos inclu\xEDdos \xB7 ${scope.excludedApiCount} da API oficial exclu\xEDdos \xB7 ${scope.excludedDuplicateCount} duplicatas exclu\xEDdas \xB7 ${scope.excludedByFilterCount} exclu\xEDdos pelos filtros (${scope.excludedByDateCount} por data).`;
      const names = { "youtube-dom": "p\xE1gina YouTube", "public-page": "p\xE1gina p\xFAblica", "user-provided": "fornecido pelo usu\xE1rio", "youtube-data-api": "API oficial", unspecified: "origem n\xE3o declarada" };
      get("provenance").textContent = `Origem dos v\xEDdeos inclu\xEDdos: ${Object.entries(current.provenance).map(([key, count2]) => `${names[key] ?? key}: ${count2}`).join(" \xB7 ")}.`;
      get("filter-summary").textContent = source.value === "filtered" ? `Filtros da pesquisa aplicados: ${describeResearchFilter(scope.filter ?? {})}` : "Toda a cole\xE7\xE3o eleg\xEDvel, ap\xF3s excluir dados da API oficial e duplicatas. Campos ausentes permanecem desconhecidos.";
      get("comparison").textContent = `Modo de outlier: ${scope.filter?.comparisonMode ?? "sample-median"}. A refer\xEAncia usa v\xEDdeos eleg\xEDveis e deduplicados antes dos filtros, excluindo o alvo por ID; n\xE3o representa o cat\xE1logo completo do canal.`;
      const cards = [
        ["Views conhecidas", current.totals.knownViews, "Soma dos contadores dispon\xEDveis"],
        ["M\xE9dia de views", current.totals.meanViews, "Somente contadores conhecidos"],
        ["Mediana de views", current.totals.medianViews, "Somente contadores conhecidos"],
        ["VPH m\xE9dio hist\xF3rico", current.totals.meanLifetimeVph, "Desde a publica\xE7\xE3o; n\xE3o \xFAltimos 60 min"],
        ["Mediana de VPH", current.totals.medianLifetimeVph, "Somente datas e views conhecidas"],
        ["Intervalo observado (dias)", current.medianPublishGapDays, "Mediana das lacunas na amostra combinada"],
        ["Dura\xE7\xE3o conhecida (s)", current.totals.knownDurationSeconds, "Soma das dura\xE7\xF5es dispon\xEDveis"]
      ];
      get("totals").replaceChildren(...cards.map(([title, amount, hint]) => {
        const card = element("div");
        card.className = "metric";
        card.append(element("span", title), element("strong", number(amount)), element("small", hint));
        return card;
      }));
      const coverageLabels = { views: "Visualiza\xE7\xF5es", publicationDate: "Data de publica\xE7\xE3o", duration: "Dura\xE7\xE3o", channel: "Identidade de canal" };
      get("coverage").replaceChildren(...Object.entries(current.coverage).map(([key, count2]) => row([coverageLabels[key], number(count2.known), number(count2.missing)])));
      get("formats").replaceChildren(element("p", `Shorts: ${number(current.formats.short)} \xB7 V\xEDdeos n\xE3o Shorts: ${number(current.formats.long)} \xB7 Desconhecidos: ${number(current.formats.unknown)}`));
      get("channels").replaceChildren(...current.channels.map((channel) => row([channel.label, number(channel.videoCount), number(channel.totalViews), `${number(channel.knownViews)} conhecidos / ${number(channel.missingViews)} ausentes`, number(channel.meanViews), number(channel.medianViews), number(channel.meanLifetimeVph)])));
      if (!current.channels.length) get("channels").append(emptyRow("Nenhum canal com identidade conhecida na amostra inclu\xEDda.", 7));
      get("months").replaceChildren(...current.publicationMonths.map((month) => row([month.month, number(month.videoCount), number(month.totalViews), number(month.missingViews), number(month.totalDurationSeconds), number(month.missingDurationCount)])));
      if (!current.publicationMonths.length) get("months").append(emptyRow("Nenhuma data v\xE1lida de publica\xE7\xE3o na amostra inclu\xEDda.", 6));
      get("top").replaceChildren(...current.topVideos.map((video) => {
        const videoRow = row(["", video.channel ?? "desconhecido", video.format === "short" ? "Short" : video.format === "long" ? "N\xE3o Short" : "desconhecido", number(video.views), number(video.lifetimeVph), `${video.outlierScore === void 0 ? "desconhecido" : `${number(video.outlierScore)}\xD7`} \xB7 m\xE9todo previsto ${video.outlierMethod ?? "desconhecido"} \xB7 denominador ${number(video.outlierReference ?? void 0)} \xB7 ${number(video.outlierReferenceCount)} candidatos (${number(video.outlierPositiveReferenceCount)} positivos) \xB7 origem ${video.outlierProvenance}`]);
        const id = videoIdFromUrl(video.url);
        const title = id ? element("a", video.title) : element("span", video.title);
        if (title instanceof HTMLAnchorElement && id) {
          title.href = `https://www.youtube.com/watch?v=${id}`;
          title.target = "_blank";
          title.rel = "noopener noreferrer";
        }
        videoRow.cells[0].append(title);
        return videoRow;
      }));
      if (!current.topVideos.length) get("top").append(emptyRow("Nenhum v\xEDdeo na amostra inclu\xEDda.", 6));
      get("limitations").replaceChildren(...current.limitations.map((text2) => element("li", text2)), ...sourceWarnings.map((text2) => element("li", `Aviso da coleta: ${text2}`)));
    }
  }
  function number(value2) {
    return value2 === void 0 || !Number.isFinite(value2) ? "desconhecido" : new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 2 }).format(value2);
  }
  function element(tag, text2) {
    const element4 = document.createElement(tag);
    if (text2 !== void 0) element4.textContent = text2;
    return element4;
  }
  function row(values) {
    const result = element("tr");
    result.append(...values.map((value2) => element("td", value2)));
    return result;
  }
  function emptyRow(message, columns) {
    const result = row([message]);
    result.cells[0].colSpan = columns;
    return result;
  }

  // src/ui/history.ts
  var plain2 = (value2) => value2 !== null && typeof value2 === "object" && !Array.isArray(value2);
  var number2 = (value2) => value2 === void 0 ? "\u2014" : new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 3 }).format(value2);
  var validMetric = (value2) => value2 === void 0 || typeof value2 === "number" && Number.isFinite(value2) && value2 >= 0;
  function recordsFrom(data) {
    if (!Array.isArray(data.records) || data.records.length > 15e3) throw new Error("O backend retornou uma lista de hist\xF3rico incompat\xEDvel.");
    for (const raw of data.records) {
      if (!plain2(raw) || typeof raw.id !== "string" || typeof raw.videoId !== "string" || typeof raw.title !== "string" || typeof raw.url !== "string" || typeof raw.observedAt !== "string" || !Number.isFinite(Date.parse(raw.observedAt)) || raw.recordedAt !== void 0 && (typeof raw.recordedAt !== "string" || !Number.isFinite(Date.parse(raw.recordedAt))) || !["youtube-dom", "public-page", "user-provided"].includes(String(raw.source)) || !validMetric(raw.views) || !validMetric(raw.subscribers)) throw new Error("O backend retornou observa\xE7\xF5es inv\xE1lidas ou de fonte n\xE3o permitida.");
    }
    return data.records;
  }
  function initHistoryTools(deps) {
    const section = document.getElementById("history");
    if (!section || section.dataset.initialized) return;
    section.dataset.initialized = "true";
    section.innerHTML = `<div class="card"><span class="eyebrow">AMOSTRAS SALVAS POR VOC\xCA</span><h2>Hist\xF3rico pr\xF3prio</h2><p>Registre contadores observados em momentos conhecidos. Nenhum passado \xE9 recuperado ou preenchido automaticamente. Dados da API oficial ficam fora deste armazenamento e de suas taxas.</p><p id="history-destination">Destino: confira a conex\xE3o do backend pessoal.</p><div class="row"><button id="history-record" class="primary">Registrar at\xE9 100 v\xEDdeos do filtro atual</button><button id="history-cancel" disabled>Cancelar espera</button></div><p>Salva somente metadados, contagens e origem da amostra filtrada. Preserva o hor\xE1rio da coleta quando dispon\xEDvel e marca separadamente a hora da grava\xE7\xE3o. Salvar uma coleta antiga novamente n\xE3o cria um novo instante observado.</p></div><div class="card"><div class="row"><label>ID do v\xEDdeo (opcional)<input id="history-video-id" type="text" placeholder="Vazio consulta o \xEDndice geral" maxlength="100"></label><label>Limite da consulta<input id="history-limit" type="number" min="1" max="500" step="1" value="100"></label></div><div class="row"><button id="history-list">Consultar registros</button><button id="history-export-json">Exportar escopo em JSON</button><button id="history-export-csv">Exportar escopo em CSV</button><button id="history-delete-video">Excluir v\xEDdeo informado\u2026</button><button id="history-delete-all">Excluir todo o hist\xF3rico\u2026</button></div><p>Consulta: at\xE9 500 registros. Exportar solicita todos os registros do escopo escolhido. Reten\xE7\xE3o pessoal: at\xE9 5000 registros e 10 MiB; o limite pode ser menor no servidor. Arquivos antigos sem \xEDndice s\xE3o acess\xEDveis pelo ID do v\xEDdeo.</p><p id="history-status" role="status" aria-live="polite">Nenhuma solicita\xE7\xE3o de hist\xF3rico foi enviada.</p><p id="history-scope">Nenhum registro consultado.</p><div class="table-wrap"><table><thead><tr><th>Coleta / refer\xEAncia (UTC)</th><th>Salvo em (UTC)</th><th>V\xEDdeo</th><th>Views observadas</th><th>Inscritos observados</th><th>Origem</th></tr></thead><tbody id="history-rows"></tbody></table></div><h3>Diferen\xE7as entre instantes observados</h3><p>N\xE3o s\xE3o as views da \xFAltima hora. Cada taxa usa o intervalo real entre duas contagens conhecidas do mesmo v\xEDdeo. Revis\xF5es negativas s\xE3o preservadas; aus\xEAncias n\xE3o viram zero.</p><div class="table-wrap"><table><thead><tr><th>V\xEDdeo</th><th>De / at\xE9 (UTC)</th><th>Horas</th><th>\u0394 views</th><th>Views / h no intervalo</th><th>\u0394 inscritos</th><th>Inscritos / h no intervalo</th></tr></thead><tbody id="history-trend-rows"></tbody></table></div><ul id="history-limitations"></ul></div>`;
    const field = (id) => section.querySelector(`#history-${id}`);
    const create = (tag, text2) => {
      const element4 = document.createElement(tag);
      element4.textContent = text2;
      return element4;
    };
    let busy = false, controller, responseOrigin = "";
    const status = (text2, error = false) => {
      field("status").textContent = text2;
      field("status").classList.toggle("error", error);
    };
    const destination = (settings) => {
      field("destination").textContent = settings.backendUrl ? `Destino desta instala\xE7\xE3o: ${settings.backendUrl}/v1/history. Token n\xE3o exibido. Dados persistem no computador do backend.` : "Backend n\xE3o configurado. Configure e salve a origem e o token na aba Conex\xE3o antes de registrar ou consultar.";
    };
    const setBusy = (value2) => {
      busy = value2;
      for (const control of section.querySelectorAll("input,button")) control.disabled = value2;
      field("cancel").disabled = !value2;
    };
    async function request(payload, signal, frozen) {
      const settings = frozen ?? await getSettings();
      signal.throwIfAborted();
      const before = await getSettings();
      signal.throwIfAborted();
      if (before.backendUrl !== settings.backendUrl || before.backendToken !== settings.backendToken) {
        destination(before);
        throw new Error("A conex\xE3o mudou antes do envio. Nenhuma solicita\xE7\xE3o foi enviada; confira o destino e confirme novamente.");
      }
      destination(settings);
      const result = await callBackendOperation(settings, "/v1/history", payload, signal);
      signal.throwIfAborted();
      const current = await getSettings();
      signal.throwIfAborted();
      if (current.backendUrl !== settings.backendUrl || current.backendToken !== settings.backendToken) {
        destination(current);
        throw new Error("A conex\xE3o mudou durante a solicita\xE7\xE3o. O servidor anterior pode ter conclu\xEDdo a a\xE7\xE3o; consulte-o antes de repetir.");
      }
      if (result.status !== "ok") throw new Error(result.error ?? "O hist\xF3rico n\xE3o est\xE1 dispon\xEDvel neste backend.");
      if (result.source !== "prevlev:history") throw new Error("A resposta n\xE3o pertence ao contrato de hist\xF3rico. Uma altera\xE7\xE3o aceita pode ter sido conclu\xEDda; consulte antes de repetir.");
      if (!plain2(result.data)) throw new Error("Resposta de hist\xF3rico incompat\xEDvel. Uma altera\xE7\xE3o aceita pode ter sido conclu\xEDda; consulte antes de repetir.");
      responseOrigin = settings.backendUrl;
      return result;
    }
    function render2(records, scope, total2 = records.length, limitations = []) {
      field("scope").textContent = `${scope} \xB7 Origem da resposta: ${responseOrigin} \xB7 ${records.length} de ${total2} registros retornados. Timestamps e contagens preservados.`;
      field("rows").replaceChildren();
      for (const record2 of records) {
        const row3 = document.createElement("tr"), video = document.createElement("td");
        video.append(create("span", record2.title), create("small", record2.videoId));
        row3.append(create("td", record2.observedAt), create("td", record2.recordedAt ?? "N\xE3o dispon\xEDvel no formato antigo"), video, create("td", number2(record2.views)), create("td", number2(record2.subscribers)), create("td", record2.source));
        field("rows").append(row3);
      }
      if (!records.length) {
        const row3 = document.createElement("tr"), cell = create("td", "Nenhuma observa\xE7\xE3o retornada para este escopo.");
        cell.colSpan = 6;
        row3.append(cell);
        field("rows").append(row3);
      }
      const trend = deriveHistoryTrend(records);
      field("trend-rows").replaceChildren();
      for (const change of trend.changes) {
        const row3 = document.createElement("tr");
        for (const value2 of [change.videoId, `${change.from} / ${change.to}`, number2(change.elapsedHours), number2(change.viewsDelta), number2(change.viewsPerHour), number2(change.subscribersDelta), number2(change.subscribersPerHour)]) row3.append(create("td", value2));
        field("trend-rows").append(row3);
      }
      if (!trend.changes.length) {
        const row3 = document.createElement("tr"), cell = create("td", "S\xE3o necess\xE1rios dois instantes distintos com contagens conhecidas do mesmo v\xEDdeo.");
        cell.colSpan = 7;
        row3.append(cell);
        field("trend-rows").append(row3);
      }
      field("limitations").replaceChildren(...[.../* @__PURE__ */ new Set([...limitations, ...trend.warnings])].map((text2) => create("li", text2)));
    }
    function videoId() {
      const value2 = field("video-id").value.trim();
      if (value2 && !/^[A-Za-z0-9_-]{1,100}$/.test(value2)) throw new Error("Informe somente um ID de v\xEDdeo v\xE1lido, sem URL ou caminhos.");
      return value2 || void 0;
    }
    function limit() {
      const value2 = Number(field("limit").value);
      if (!Number.isInteger(value2) || value2 < 1 || value2 > 500) throw new Error("Escolha um limite inteiro entre 1 e 500.");
      return value2;
    }
    function on2(id, work) {
      field(id).addEventListener("click", () => {
        if (busy) return;
        controller = new AbortController();
        setBusy(true);
        status("Solicita\xE7\xE3o expl\xEDcita em andamento\u2026");
        void work(controller.signal).catch((error) => status(error instanceof DOMException && error.name === "AbortError" ? "Espera cancelada. Uma a\xE7\xE3o j\xE1 aceita pelo servidor pode ter sido conclu\xEDda; consulte antes de repetir." : error instanceof Error ? error.message : String(error), true)).finally(() => {
          controller = void 0;
          setBusy(false);
        });
      });
    }
    on2("record", async (signal) => {
      const snapshot2 = deps.snapshot(), eligible = snapshot2.videos.filter((video) => video.source !== "youtube-data-api"), filter = deps.filter(), selected = selectResearchVideos(eligible, filter), chosen = selected.slice(0, 100);
      if (!chosen.length) throw new Error(snapshot2.videos.some((video) => video.source === "youtube-data-api") ? "N\xE3o h\xE1 observa\xE7\xF5es locais eleg\xEDveis; dados da API oficial n\xE3o s\xE3o enviados ao hist\xF3rico." : "Colete uma amostra local e confira seus filtros antes de registrar.");
      const videos = chosen.map((video) => {
        const record2 = { id: video.id, title: video.title, url: video.url, source: video.source ?? "user-provided" };
        for (const key of ["channel", "channelId", "channelUrl", "views", "subscribers", "observedAt"]) if (video[key] !== void 0) Object.assign(record2, { [key]: video[key] });
        return record2;
      });
      const result = await request({ action: "record", videos }, signal), data = result.data;
      render2(recordsFrom(data), "Resultado desta grava\xE7\xE3o", data.records?.length, result.limitations);
      status(`Gravados ${data.recorded ?? 0}; duplicados ${data.duplicates ?? 0}; omitidos ${data.skipped ?? 0}; removidos por reten\xE7\xE3o ${data.evicted ?? 0}. Enviados ${chosen.length} de ${selected.length} v\xEDdeos locais filtrados. ${snapshot2.videos.length - eligible.length} itens da API oficial exclu\xEDdos antes dos c\xE1lculos. Filtros aplicados: ${describeResearchFilter(filter)}.`);
    });
    on2("list", async (signal) => {
      const id = videoId(), result = await request({ action: id ? "get" : "list", ...id ? { videoId: id } : {}, limit: limit() }, signal);
      render2(recordsFrom(result.data), id ? `V\xEDdeo ${id}` : "\xCDndice geral de observa\xE7\xF5es novas", result.data.total, result.limitations);
      status("Consulta conclu\xEDda. Nenhuma nova observa\xE7\xE3o foi registrada.");
    });
    for (const format of ["json", "csv"]) on2(`export-${format}`, async (signal) => {
      const id = videoId(), result = await request({ action: "export", ...id ? { videoId: id } : {} }, signal), records = recordsFrom(result.data);
      render2(records, id ? `Exporta\xE7\xE3o do v\xEDdeo ${id}` : "Exporta\xE7\xE3o do \xEDndice novo", result.data.total, result.limitations);
      const columns = ["id", "videoId", "title", "url", "channel", "channelId", "channelUrl", "observedAt", "recordedAt", "views", "subscribers", "source"];
      const text2 = format === "json" ? JSON.stringify({ version: 1, records, limitations: result.limitations ?? [] }, null, 2) : toCsv(records.map((record2) => ({ ...record2 })), columns);
      downloadBlob(new Blob([text2], { type: format === "json" ? "application/json" : "text/csv;charset=utf-8" }), `prevlev-historico.${format}`);
      status(`${records.length} registros exportados em ${format.toUpperCase()}. Nenhum timestamp ou contador foi recalculado.`);
    });
    for (const all of [false, true]) on2(all ? "delete-all" : "delete-video", async (signal) => {
      const id = all ? void 0 : videoId();
      if (!all && !id) throw new Error("Informe o ID do v\xEDdeo que deseja excluir.");
      const frozen = await getSettings();
      signal.throwIfAborted();
      destination(frozen);
      if (!frozen.backendUrl) throw new Error("Configure o backend antes de excluir registros.");
      if (!window.confirm(all ? `Excluir todo o hist\xF3rico pessoal e os arquivos antigos reconhecidos em ${frozen.backendUrl}? Esta a\xE7\xE3o n\xE3o desfaz downloads.` : `Excluir o hist\xF3rico do v\xEDdeo ${id}, incluindo o arquivo antigo reconhecido, em ${frozen.backendUrl}?`)) {
        status("Exclus\xE3o cancelada. Nenhuma solicita\xE7\xE3o foi enviada.");
        return;
      }
      signal.throwIfAborted();
      const result = await request({ action: "delete", confirm: true, ...id ? { videoId: id } : {} }, signal, frozen);
      field("scope").textContent = "Pr\xE9via descartada ap\xF3s exclus\xE3o. Consulte novamente para conhecer os registros que permanecem neste backend.";
      for (const id2 of ["rows", "trend-rows"]) {
        const row3 = document.createElement("tr"), cell = create("td", "Nenhuma lista foi retornada pela exclus\xE3o; consulte novamente.");
        cell.colSpan = id2 === "rows" ? 6 : 7;
        row3.append(cell);
        field(id2).replaceChildren(row3);
      }
      field("limitations").replaceChildren(...(result.limitations ?? []).map((text2) => create("li", text2)));
      status(`Exclu\xEDdos ${result.data.deleted ?? 0} registros novos e ${result.data.legacyFilesDeleted ?? 0} arquivos antigos; ${result.data.legacyFilesSkipped ?? 0} arquivos antigos preservados. Consulte novamente para conferir o escopo desejado.`);
    });
    field("cancel").addEventListener("click", () => {
      controller?.abort();
    });
    window.addEventListener("pagehide", () => controller?.abort());
    void getSettings().then(destination).catch(() => status("N\xE3o foi poss\xEDvel ler a configura\xE7\xE3o local. Reabra o painel.", true));
  }

  // src/core/comments.ts
  function normalizeCommentText(value2) {
    return value2.normalize("NFC").replace(/\s+/g, " ").trim();
  }
  function validateCommentFilter(filter) {
    for (const [minimum, maximum, label] of [[filter.minLikes, filter.maxLikes, "curtidas"], [filter.minReplies, filter.maxReplies, "respostas"]]) {
      for (const value2 of [minimum, maximum]) if (value2 !== void 0 && (typeof value2 !== "number" || !Number.isFinite(value2) || !Number.isInteger(value2) || value2 < 0)) throw new Error(`O filtro de ${label} exige n\xFAmeros inteiros n\xE3o negativos.`);
      if (minimum !== void 0 && maximum !== void 0 && minimum > maximum) throw new Error(`No filtro de ${label}, o m\xEDnimo n\xE3o pode superar o m\xE1ximo.`);
    }
    if (filter.replies !== void 0 && !["any", "yes", "no"].includes(filter.replies)) throw new Error("Selecione um estado de respostas v\xE1lido.");
    if (filter.hearted !== void 0 && !["any", "yes", "no"].includes(filter.hearted)) throw new Error("Selecione um estado de cora\xE7\xE3o v\xE1lido.");
    if (filter.sort !== void 0 && !["default", "likes", "replies"].includes(filter.sort)) throw new Error("Selecione uma ordena\xE7\xE3o de coment\xE1rios v\xE1lida.");
  }
  function selectComments(comments, filter = {}) {
    validateCommentFilter(filter);
    const normalized2 = comments.map((comment) => ({ ...comment, author: normalizeCommentText(comment.author), text: normalizeCommentText(comment.text), likes: knownCount2(comment.likes), replies: knownCount2(comment.replies) }));
    const selected = filterComments(normalized2, { query: normalizeCommentText(filter.query ?? ""), author: normalizeCommentText(filter.author ?? ""), questionsOnly: filter.questionsOnly, minLikes: filter.minLikes, minReplies: filter.minReplies, hearted: filter.hearted === "yes" ? true : filter.hearted === "no" ? false : void 0 }).filter((comment) => (filter.maxLikes === void 0 || comment.likes !== void 0 && comment.likes <= filter.maxLikes) && (filter.maxReplies === void 0 || comment.replies !== void 0 && comment.replies <= filter.maxReplies) && (filter.replies === void 0 || filter.replies === "any" || comment.replies !== void 0 && (filter.replies === "yes" ? comment.replies > 0 : comment.replies === 0)));
    if (filter.sort === "likes" || filter.sort === "replies") {
      const key = filter.sort;
      selected.sort((left, right) => left[key] === void 0 ? right[key] === void 0 ? 0 : 1 : right[key] === void 0 ? -1 : right[key] - left[key]);
    }
    return selected;
  }
  function describeCommentScope(loaded, selected) {
    return {
      loadedCount: loaded.length,
      selectedCount: selected.length,
      knownLikes: selected.filter((comment) => knownCount2(comment.likes) !== void 0).length,
      knownReplies: selected.filter((comment) => knownCount2(comment.replies) !== void 0).length,
      knownHearts: selected.filter((comment) => typeof comment.hearted === "boolean").length,
      fingerprintCount: selected.filter((comment) => comment.id.startsWith("local:")).length,
      confidence: "loaded-observations",
      limitations: ["Somente coment\xE1rios efetivamente carregados e coletados nesta amostra; n\xE3o representa todos os coment\xE1rios do v\xEDdeo.", "Perguntas s\xE3o identificadas apenas por ? ou \uFF1F, sem classifica\xE7\xE3o sem\xE2ntica de frases interrogativas.", "Curtidas, respostas e cora\xE7\xE3o ausentes permanecem desconhecidos. Filtros ativos desses campos excluem valores desconhecidos.", "Contadores abreviados s\xE3o aproxima\xE7\xF5es do texto exibido na p\xE1gina; n\xE3o houve confirma\xE7\xE3o dos valores exatos por API.", "IDs locais s\xE3o fingerprints de autor e texto, n\xE3o IDs oficiais; conte\xFAdos id\xEAnticos podem coincidir e edi\xE7\xF5es podem mudar a identidade. Componentes duplicados por identidade s\xE3o contados uma vez."]
    };
  }
  function commentRows(comments) {
    return comments.map((comment) => ({ id: comment.id, author: comment.author, text: comment.text, likes: knownCount2(comment.likes), replies: knownCount2(comment.replies), hearted: comment.hearted }));
  }
  function commentsText(comments) {
    return comments.map((comment) => `${comment.author || "Autor desconhecido"}: ${comment.text}`).join("\n\n");
  }
  function knownCount2(value2) {
    return typeof value2 === "number" && Number.isFinite(value2) && Number.isInteger(value2) && value2 >= 0 ? value2 : void 0;
  }

  // src/ui/comments.ts
  function initCommentTools(deps) {
    const section = document.getElementById("comments");
    if (!section) throw new Error("A se\xE7\xE3o de coment\xE1rios n\xE3o est\xE1 dispon\xEDvel.");
    section.innerHTML = `
    <div class="card"><span class="eyebrow">COMENT\xC1RIOS CARREGADOS</span><h2>Filtrar coment\xE1rios</h2>
      <p>Explore os coment\xE1rios j\xE1 coletados. Copiar e exportar usam somente o resultado atual dos filtros.</p>
      <div class="form-grid">
        <label>Texto do coment\xE1rio<input id="comment-filter" placeholder="Palavra ou trecho"></label>
        <label>Autor<input id="comment-author" placeholder="Nome ou trecho do autor"></label>
        <label>Curtidas m\xEDnimas<input id="comment-likes" type="number" min="0" step="1" placeholder="Sem m\xEDnimo"></label>
        <label>Curtidas m\xE1ximas<input id="comment-max-likes" type="number" min="0" step="1" placeholder="Sem m\xE1ximo"></label>
        <label>Respostas m\xEDnimas<input id="comment-replies-min" type="number" min="0" step="1" placeholder="Sem m\xEDnimo"></label>
        <label>Respostas m\xE1ximas<input id="comment-replies-max" type="number" min="0" step="1" placeholder="Sem m\xE1ximo"></label>
        <label>Tem respostas?<select id="comment-replies-state"><option value="any">Qualquer estado</option><option value="yes">Com respostas conhecidas</option><option value="no">Sem respostas (zero conhecido)</option></select></label>
        <label>Cora\xE7\xE3o do criador<select id="comment-hearted"><option value="any">Qualquer estado</option><option value="yes">Com cora\xE7\xE3o conhecido</option><option value="no">Sem cora\xE7\xE3o conhecido</option></select></label>
        <label>Ordena\xE7\xE3o<select id="comment-sort"><option value="default">Ordem da coleta</option><option value="likes">Mais curtidas conhecidas</option><option value="replies">Mais respostas conhecidas</option></select></label>
      </div>
      <label class="check"><input id="comment-questions" type="checkbox"> Com ? ou \uFF1F (perguntas por pontua\xE7\xE3o)</label>
      <p id="comments-count" aria-live="polite"></p><p id="comments-error" role="status" aria-live="polite"></p>
      <div class="row"><button id="comments-copy">Copiar filtrados</button><button id="comments-export">Exportar CSV</button><button id="comments-export-json">Exportar JSON</button><button id="comments-reset">Limpar filtros</button><button id="comments-ai">Analisar filtrados com IA no backend</button></div>
      <p>A an\xE1lise com IA s\xF3 \xE9 solicitada pelo bot\xE3o e mant\xE9m as configura\xE7\xF5es e confirma\xE7\xF5es da conex\xE3o.</p>
    </div>
    <div class="card"><h3>Escopo e confian\xE7a dos dados</h3><p id="comments-scope"></p><ul id="comments-limitations"></ul></div>
    <div id="comment-list"></div>`;
    const get = (id) => section.querySelector(`#${id}`);
    const input = (id) => get(id).value;
    const count2 = (id) => input(id).trim() ? Number(input(id)) : void 0;
    const selected = () => selectComments(deps.snapshot().comments, readFilter());
    const status = get("comments-error");
    let aiRunning = false;
    function readFilter() {
      return { query: input("comment-filter"), author: input("comment-author"), questionsOnly: get("comment-questions").checked, minLikes: count2("comment-likes"), maxLikes: count2("comment-max-likes"), minReplies: count2("comment-replies-min"), maxReplies: count2("comment-replies-max"), replies: input("comment-replies-state"), hearted: input("comment-hearted"), sort: input("comment-sort") };
    }
    function setStatus(message, error = false) {
      status.textContent = message;
      status.classList.toggle("error", error);
    }
    function render2() {
      const loaded = deps.snapshot().comments;
      try {
        const comments = selected();
        const scope = describeCommentScope(loaded, comments);
        setStatus("");
        get("comments-count").textContent = `${scope.selectedCount} de ${scope.loadedCount} coment\xE1rios carregados correspondem aos filtros.`;
        get("comments-scope").textContent = `No resultado: curtidas conhecidas em ${scope.knownLikes}/${scope.selectedCount}; respostas conhecidas em ${scope.knownReplies}/${scope.selectedCount}; cora\xE7\xE3o conhecido em ${scope.knownHearts}/${scope.selectedCount}; identidades locais por fingerprint: ${scope.fingerprintCount}.`;
        get("comments-limitations").replaceChildren(...scope.limitations.map((text2) => element2("li", text2)));
        get("comment-list").replaceChildren(...comments.map((comment) => {
          const card = element2("article");
          card.className = "comment";
          card.append(element2("strong", comment.author || "Autor desconhecido"), element2("p", comment.text), element2("small", `${known(comment.likes)} curtidas \xB7 ${known(comment.replies)} respostas \xB7 ${comment.hearted === true ? "com cora\xE7\xE3o conhecido" : comment.hearted === false ? "sem cora\xE7\xE3o conhecido" : "cora\xE7\xE3o desconhecido"}`));
          return card;
        }));
        if (!comments.length) get("comment-list").append(element2("p", "Nenhum coment\xE1rio carregado corresponde ao filtro."));
        for (const id of ["comments-copy", "comments-export", "comments-export-json"]) get(id).disabled = comments.length === 0;
      } catch (error) {
        get("comment-list").replaceChildren();
        get("comments-count").textContent = `Filtros inv\xE1lidos; ${loaded.length} coment\xE1rios continuam na cole\xE7\xE3o.`;
        get("comments-scope").textContent = "Corrija os limites para visualizar, copiar ou exportar a amostra.";
        setStatus(error instanceof Error ? error.message : "N\xE3o foi poss\xEDvel aplicar os filtros.", true);
        for (const id of ["comments-copy", "comments-export", "comments-export-json"]) get(id).disabled = true;
      }
    }
    for (const field of section.querySelectorAll("input,select")) {
      field.addEventListener("input", render2);
      field.addEventListener("change", render2);
    }
    get("comments-reset").addEventListener("click", () => {
      for (const field of section.querySelectorAll("input")) {
        field.value = "";
        if (field.type === "checkbox") field.checked = false;
      }
      get("comment-replies-state").value = "any";
      get("comment-hearted").value = "any";
      get("comment-sort").value = "default";
      render2();
    });
    get("comments-copy").addEventListener("click", () => {
      void Promise.resolve().then(async () => {
        const comments = selected();
        if (!comments.length) throw new Error("Nenhum coment\xE1rio filtrado para copiar.");
        await navigator.clipboard.writeText(commentsText(comments));
        setStatus(`${comments.length} coment\xE1rios filtrados copiados.`);
      }).catch((error) => setStatus(error instanceof Error ? error.message : "N\xE3o foi poss\xEDvel copiar.", true));
    });
    const exportComments = (json) => {
      try {
        const comments = selected();
        if (!comments.length) throw new Error("Nenhum coment\xE1rio filtrado para exportar.");
        const content = json ? JSON.stringify({ source: "loaded-comments", filters: readFilter(), scope: describeCommentScope(deps.snapshot().comments, comments), comments }, null, 2) : toCsv(commentRows(comments));
        downloadBlob(new Blob([content], { type: json ? "application/json" : "text/csv;charset=utf-8" }), `prevlev-comentarios.${json ? "json" : "csv"}`);
        setStatus(`${comments.length} coment\xE1rios filtrados exportados.`);
      } catch (error) {
        setStatus(error instanceof Error ? error.message : "N\xE3o foi poss\xEDvel exportar.", true);
      }
    };
    get("comments-export").addEventListener("click", () => exportComments(false));
    get("comments-export-json").addEventListener("click", () => exportComments(true));
    get("comments-ai").addEventListener("click", () => {
      if (aiRunning) return;
      void Promise.resolve().then(async () => {
        if (!selected().length) throw new Error("Nenhum coment\xE1rio filtrado para analisar.");
        aiRunning = true;
        get("comments-ai").setAttribute("aria-busy", "true");
        try {
          await deps.onAi();
        } finally {
          aiRunning = false;
          get("comments-ai").removeAttribute("aria-busy");
        }
      }).catch((error) => setStatus(error instanceof Error ? error.message : "N\xE3o foi poss\xEDvel solicitar a an\xE1lise.", true));
    });
    render2();
    return { currentComments: selected, render: render2 };
  }
  function known(value2) {
    return value2 === void 0 ? "desconhecidas" : new Intl.NumberFormat("pt-BR").format(value2);
  }
  function element2(tag, text2) {
    const node = document.createElement(tag);
    if (text2 !== void 0) node.textContent = text2;
    return node;
  }

  // src/ui/swipe.ts
  var mounted = /* @__PURE__ */ new WeakMap();
  function initSwipeTools() {
    const section = document.getElementById("swipe");
    if (!section) throw new Error("A se\xE7\xE3o da biblioteca n\xE3o est\xE1 dispon\xEDvel.");
    const existing = mounted.get(section);
    if (existing) return existing;
    section.innerHTML = `<div class="hero"><div><span class="eyebrow">REFER\xCANCIAS DO SEU PERFIL</span><h1>Biblioteca local</h1><p>Organize v\xEDdeos, canais e links com pastas, tags e notas. Imagens externas s\xF3 s\xE3o carregadas quando voc\xEA solicita uma pr\xE9via.</p></div></div><div class="grid two"><div class="card"><h2 id="swipe-form-title">Salvar refer\xEAncia</h2><label>T\xEDtulo<input id="swipe-title" maxlength="1000"></label><label>URL HTTPS<input id="swipe-url" type="url" maxlength="4096" placeholder="https://..."></label><div class="form-grid"><label>Pasta<input id="swipe-folder" maxlength="120" value="Refer\xEAncias" list="swipe-folders"></label><datalist id="swipe-folders"></datalist><label>Tipo<select id="swipe-type"><option value="">Detectar pela URL</option><option value="video">V\xEDdeo</option><option value="channel">Canal</option><option value="other">Outra refer\xEAncia</option></select></label></div><label>Tags separadas por v\xEDrgula<input id="swipe-tags" maxlength="1000" placeholder="Roteiro, ideias, edi\xE7\xE3o"></label><label>Notas<textarea id="swipe-notes" maxlength="10000" rows="4"></textarea></label><label>URL de thumbnail opcional<input id="swipe-thumbnail" type="url" maxlength="4096" placeholder="https://..."></label><div class="row"><button id="swipe-add" class="primary">Salvar refer\xEAncia</button><button id="swipe-cancel-edit" hidden>Cancelar edi\xE7\xE3o</button></div></div><div class="card"><h2>Importar e exportar</h2><p>JSON vers\xE3o 2 preserva IDs, pastas, tags, notas e datas. Listas JSON antigas e CSV com cabe\xE7alhos title e url tamb\xE9m s\xE3o aceitos. Duplicatas mant\xEAm a vers\xE3o local; conflitos s\xE3o informados.</p><label>Importar JSON ou CSV<input id="swipe-import" type="file" accept="application/json,text/csv,.json,.csv"></label><div class="row"><button id="swipe-export">Exportar JSON</button><button id="swipe-export-csv">Exportar CSV</button></div><p id="swipe-storage">Limite pessoal: 5000 refer\xEAncias e 4 MiB. Importa\xE7\xF5es inv\xE1lidas n\xE3o alteram a biblioteca.</p><p id="swipe-status" role="status" aria-live="polite">A biblioteca permanece neste navegador. Nenhuma imagem foi solicitada.</p></div></div><div class="card"><div class="form-grid"><label>Buscar em t\xEDtulo, URL, pasta, tags e notas<input id="swipe-search" type="search" placeholder="Buscar refer\xEAncias"></label><label>Filtrar pasta<select id="swipe-filter-folder"><option value="">Todas</option></select></label><label>Filtrar tag<select id="swipe-filter-tag"><option value="">Todas</option></select></label><label>Filtrar tipo<select id="swipe-filter-type"><option value="">Todos</option><option value="video">V\xEDdeos</option><option value="channel">Canais</option><option value="other">Outras refer\xEAncias</option></select></label></div><p id="swipe-count"></p><div id="swipe-list"></div><button id="swipe-more" hidden>Mostrar mais 100</button></div>`;
    const field = (name) => section.querySelector(`#swipe-${name}`);
    const value2 = (name) => field(name).value;
    const text2 = (tag, value3) => {
      const node = document.createElement(tag);
      node.textContent = value3;
      return node;
    };
    let editingId, editingOriginal, renderEpoch = 0, visibleLimit = 100;
    const status = (message, error = false) => {
      field("status").textContent = message;
      field("status").classList.toggle("error", error);
      const notice2 = document.getElementById("notice");
      if (notice2) {
        notice2.textContent = message;
        notice2.classList.toggle("error", error);
      }
    };
    const fail2 = (error) => status(error instanceof Error ? error.message : "N\xE3o foi poss\xEDvel atualizar a biblioteca.", true);
    function resetForm() {
      editingId = void 0;
      editingOriginal = void 0;
      field("form-title").textContent = "Salvar refer\xEAncia";
      field("add").textContent = "Salvar refer\xEAncia";
      field("cancel-edit").hidden = true;
      for (const key of ["title", "url", "tags", "notes", "thumbnail"]) field(key).value = "";
      field("type").value = "";
    }
    function fields() {
      return { title: value2("title"), url: value2("url"), folder: value2("folder"), ...value2("type") ? { type: value2("type") } : {}, tags: parseSwipeTags(value2("tags")), notes: value2("notes"), thumbnail: value2("thumbnail") };
    }
    function choices(id, values) {
      const select = field(id), selected = select.value;
      select.replaceChildren();
      const all = text2("option", "Todas");
      all.value = "";
      select.append(all);
      for (const name of [.../* @__PURE__ */ new Set([...values, ...selected ? [selected] : []])].sort((a, b) => a.localeCompare(b))) {
        const option = text2("option", name);
        option.value = name;
        select.append(option);
      }
      select.value = selected;
    }
    async function render2() {
      const epoch = ++renderEpoch, items = await getSwipe();
      if (epoch !== renderEpoch) return;
      choices("filter-folder", items.map((item) => item.folder));
      choices("filter-tag", items.flatMap((item) => item.tags ?? []));
      field("folders").replaceChildren(...[...new Set(items.map((item) => item.folder))].sort().map((folder) => {
        const option = document.createElement("option");
        option.value = folder;
        return option;
      }));
      field("storage").textContent = `${items.length} de 5000 refer\xEAncias \xB7 ${(ensureSwipeBudget(items) / 1024 / 1024).toFixed(2)} de 4 MiB. A leitura n\xE3o regrava nem migra dados antigos.`;
      const filtered = filterSwipe(items, { query: value2("search"), folder: value2("filter-folder"), tag: value2("filter-tag"), type: value2("filter-type") });
      field("count").textContent = `${Math.min(visibleLimit, filtered.length)} de ${filtered.length} refer\xEAncias do filtro \xB7 ${items.length} na biblioteca.`;
      const list = field("list");
      list.replaceChildren();
      for (const item of filtered.slice(0, visibleLimit)) {
        const row3 = text2("article", "");
        row3.className = "swipe-item";
        row3.dataset.swipeId = item.id;
        const content = text2("div", ""), link = text2("a", item.title);
        link.href = item.url;
        link.target = "_blank";
        link.rel = "noopener noreferrer";
        content.append(link, text2("small", `${item.folder} \xB7 ${item.type === "video" ? "V\xEDdeo" : item.type === "channel" ? "Canal" : "Outra refer\xEAncia"} \xB7 ${item.createdAt ? new Date(item.createdAt).toLocaleDateString("pt-BR") : "data n\xE3o informada"}`));
        if (item.tags.length) content.append(text2("p", `Tags: ${item.tags.join(" \xB7 ")}`));
        if (item.notes) content.append(text2("p", item.notes));
        const actions = text2("div", "");
        actions.className = "row";
        const edit = text2("button", "Editar"), remove = text2("button", "Excluir");
        edit.addEventListener("click", () => {
          editingId = item.id;
          editingOriginal = JSON.stringify(item);
          for (const [key, val] of Object.entries({ title: item.title, url: item.url, folder: item.folder, type: item.type, tags: item.tags.join(", "), notes: item.notes, thumbnail: item.thumbnail ?? "" })) field(key).value = val;
          field("form-title").textContent = "Editar refer\xEAncia";
          field("add").textContent = "Salvar altera\xE7\xF5es";
          field("cancel-edit").hidden = false;
          field("title").focus();
          status("Edite os campos e salve. ID e data de cria\xE7\xE3o ser\xE3o preservados.");
        });
        remove.addEventListener("click", () => {
          void updateSwipe((current) => current.filter((existing2) => existing2.id !== item.id)).then(async () => {
            if (editingId === item.id) resetForm();
            await render2();
            status("Refer\xEAncia exclu\xEDda da biblioteca local.");
          }).catch(fail2);
        });
        actions.append(edit, remove);
        const move = text2("details", ""), summary = text2("summary", "Mover para pasta");
        move.append(summary);
        const folderInput = document.createElement("input");
        folderInput.value = item.folder;
        folderInput.maxLength = 120;
        folderInput.setAttribute("aria-label", "Nova pasta");
        folderInput.setAttribute("list", "swipe-folders");
        const moveButton = text2("button", "Aplicar pasta");
        moveButton.addEventListener("click", () => {
          const folder = folderInput.value;
          void updateSwipe((current) => current.map((existing2) => existing2.id === item.id ? editSwipeReference(existing2, { title: existing2.title, url: existing2.url, folder }) : existing2)).then(async () => {
            await render2();
            status("Refer\xEAncia movida para a pasta informada.");
          }).catch(fail2);
        });
        move.append(folderInput, moveButton);
        content.append(actions, move);
        const previewUrl = item.thumbnail ?? item.image;
        if (previewUrl) {
          const preview = text2("button", "Ver pr\xE9via da imagem");
          let image;
          preview.addEventListener("click", () => {
            if (image) {
              image.removeAttribute("src");
              image.remove();
              image = void 0;
              preview.textContent = "Ver pr\xE9via da imagem";
              return;
            }
            image = document.createElement("img");
            image.alt = `Pr\xE9via de ${item.title}`;
            image.referrerPolicy = "no-referrer";
            image.crossOrigin = "anonymous";
            image.style.cssText = "display:block;max-width:280px;max-height:180px;margin-top:12px";
            image.onerror = () => status("A imagem n\xE3o p\xF4de ser carregada pelo navegador. Confira a URL e as permiss\xF5es de origem.", true);
            image.src = previewUrl;
            content.append(image);
            preview.textContent = "Ocultar pr\xE9via";
          });
          content.append(preview);
        }
        row3.append(content);
        list.append(row3);
      }
      if (!filtered.length) list.append(text2("p", items.length ? "Nenhuma refer\xEAncia corresponde aos filtros." : "Sua biblioteca est\xE1 vazia. Salve um v\xEDdeo na pesquisa ou adicione um link."));
      field("more").hidden = filtered.length <= visibleLimit;
    }
    async function saveVideo2(video, folder) {
      if (video.source === "youtube-data-api") throw new Error("Dados da API oficial n\xE3o podem ser persistidos na biblioteca local.");
      const item = createSwipeReference({ title: video.title, url: video.url, folder: folder ?? value2("folder"), type: "video", ...video.thumbnail ? { thumbnail: video.thumbnail } : {}, source: video.source ?? "user-provided" });
      let added = 0;
      await updateSwipe((current) => {
        const merged = mergeSwipeImport(current, [item]);
        added = merged.added;
        return merged.items;
      });
      await render2();
      status(added ? "Refer\xEAncia salva na biblioteca local." : "Essa refer\xEAncia j\xE1 existe; a vers\xE3o local foi preservada.");
    }
    field("add").addEventListener("click", () => {
      void (async () => {
        const input = fields(), id = editingId, original = editingOriginal;
        await updateSwipe((current) => {
          if (id) {
            const item2 = current.find((item3) => item3.id === id);
            if (!item2) throw new Error("A refer\xEAncia foi removida. Cancele a edi\xE7\xE3o e atualize a biblioteca.");
            if (JSON.stringify(normalizeSwipeItem(item2)) !== original) throw new Error("A refer\xEAncia mudou desde que a edi\xE7\xE3o foi aberta. Reabra a edi\xE7\xE3o antes de salvar.");
            const edited = editSwipeReference(item2, input);
            if (current.some((other) => other.id !== id && swipeIdentity(other) === swipeIdentity(edited))) throw new Error("Outra refer\xEAncia j\xE1 usa esta URL. Nenhuma altera\xE7\xE3o foi salva.");
            return current.map((item3) => item3.id === id ? edited : item3);
          }
          const item = createSwipeReference(input), merged = mergeSwipeImport(current, [item]);
          if (!merged.added) throw new Error("Essa refer\xEAncia j\xE1 existe. Edite o item atual para alterar pastas, tags ou notas.");
          return merged.items;
        });
        resetForm();
        await render2();
        status(id ? "Altera\xE7\xF5es salvas; ID e cria\xE7\xE3o preservados." : "Refer\xEAncia salva na biblioteca local.");
      })().catch(fail2);
    });
    field("cancel-edit").addEventListener("click", resetForm);
    for (const id of ["search", "filter-folder", "filter-tag", "filter-type"]) field(id).addEventListener(id === "search" ? "input" : "change", () => {
      visibleLimit = 100;
      void render2().catch(fail2);
    });
    field("more").addEventListener("click", () => {
      visibleLimit += 100;
      void render2().catch(fail2);
    });
    field("import").addEventListener("change", () => {
      void (async () => {
        const input = field("import"), file = input.files?.[0];
        if (!file) return;
        try {
          if (file.size > SWIPE_MAX_BYTES) throw new Error("O arquivo de importa\xE7\xE3o excede 4 MiB. Nenhuma refer\xEAncia foi alterada.");
          const raw = await file.text();
          let incoming;
          if (/\.csv$/i.test(file.name) || file.type === "text/csv") incoming = parseSwipeCsv(raw);
          else {
            let parsed;
            try {
              parsed = JSON.parse(raw);
            } catch {
              throw new Error("O arquivo n\xE3o cont\xE9m JSON v\xE1lido. Nenhuma refer\xEAncia foi alterada.");
            }
            incoming = parseSwipeImport(parsed);
          }
          let summary = { added: 0, duplicates: 0, conflicts: 0 };
          await updateSwipe((current) => {
            const merged = mergeSwipeImport(current, incoming);
            summary = merged;
            return merged.items;
          });
          await render2();
          status(`${summary.added} refer\xEAncias importadas; ${summary.duplicates} duplicatas e ${summary.conflicts} conflitos de ID preservaram a vers\xE3o local.`);
        } finally {
          input.value = "";
        }
      })().catch(fail2);
    });
    for (const format of ["json", "csv"]) field(format === "json" ? "export" : "export-csv").addEventListener("click", () => {
      void (async () => {
        const items = await getSwipe(), data = format === "json" ? exportSwipeJson(items) : exportSwipeCsv(items);
        downloadBlob(new Blob([data], { type: format === "json" ? "application/json" : "text/csv;charset=utf-8" }), `prevlev-swipe.${format}`);
        status(`${items.length} refer\xEAncias exportadas em ${format.toUpperCase()}.`);
      })().catch(fail2);
    });
    const tools = { render: render2, saveVideo: saveVideo2 };
    mounted.set(section, tools);
    return tools;
  }

  // src/ui/swipe-sync.ts
  function initSwipeSync(render2) {
    const section = document.getElementById("swipe");
    if (!section) return;
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `<h2>Biblioteca no seu backend pessoal</h2><p>Transfer\xEAncia manual de refer\xEAncias. Consulte a revis\xE3o do backend e confira o destino antes de enviar. Isto n\xE3o conecta contas nem cria uma nuvem multiusu\xE1rio.</p><div class="actions"><button id="swipe-sync-read">Consultar revis\xE3o do backend</button><button id="swipe-sync-upload" disabled>Substituir biblioteca do backend\u2026</button><button id="swipe-sync-merge" disabled>Mesclar no navegador\u2026</button><button id="swipe-sync-replace" disabled>Substituir biblioteca local\u2026</button></div><p id="swipe-sync-status" role="status" aria-live="polite">Nenhuma transfer\xEAncia solicitada.</p><pre id="swipe-sync-preview"></pre>`;
    section.append(card);
    const field = (name) => card.querySelector(`#swipe-sync-${name}`);
    let remote2, busy = false;
    const identity = (s) => JSON.stringify([s.backendUrl, s.backendToken]);
    const status = (message) => {
      field("status").textContent = message;
    };
    const controls = () => {
      for (const action of ["read", "upload", "merge", "replace"]) field(action).disabled = busy || action !== "read" && !remote2;
    };
    async function readRemote(settings) {
      const result = await callBackendOperation(settings, "/v1/library", { action: "read" });
      if (result.status !== "ok" || result.source !== "prevlev:library" || !result.data || typeof result.data !== "object") throw new Error(result.error ?? "O backend n\xE3o disponibiliza uma biblioteca pessoal compat\xEDvel.");
      const data = result.data;
      if (!Array.isArray(data.items)) throw new Error("O backend n\xE3o retornou uma lista expl\xEDcita de refer\xEAncias. Nenhuma biblioteca foi alterada.");
      if (typeof data.revision !== "string" || !/^[a-f0-9]{64}$/.test(data.revision)) throw new Error("Revis\xE3o de biblioteca incompat\xEDvel.");
      return { items: normalizeSwipeLibrary(data.items), revision: data.revision, settings };
    }
    function on2(name, work) {
      field(name).addEventListener("click", () => {
        if (busy) return;
        busy = true;
        controls();
        void work().catch((error) => status(error instanceof Error ? error.message : String(error))).finally(() => {
          busy = false;
          controls();
        });
      });
    }
    async function checked() {
      if (!remote2) throw new Error("Consulte uma revis\xE3o antes de transferir.");
      const settings = await getSettings();
      if (identity(settings) !== identity(remote2.settings)) {
        remote2 = void 0;
        throw new Error("O backend mudou. Consulte a origem atual antes de transferir dados.");
      }
      return remote2;
    }
    on2("read", async () => {
      remote2 = void 0;
      const settings = await getSettings();
      if (!settings.backendUrl) throw new Error("Configure e salve o backend pessoal na aba Conex\xE3o.");
      const state = await readRemote(settings);
      if (identity(await getSettings()) !== identity(settings)) throw new Error("A conex\xE3o mudou; a pr\xE9via foi descartada.");
      remote2 = state;
      const local = await getSwipe(), merged = mergeSwipeImport(local, state.items);
      field("preview").textContent = JSON.stringify({ destination: settings.backendUrl, remoteRevision: state.revision, localItems: local.length, remoteItems: state.items.length, mergeAdds: merged.added, mergeDuplicates: merged.duplicates, mergeConflicts: merged.conflicts, remoteSample: state.items.slice(0, 20).map((x) => ({ title: x.title, folder: x.folder, tags: x.tags })) }, null, 2);
      status("Revis\xE3o consultada. Nenhuma biblioteca foi alterada. A pr\xE9via mostra at\xE9 20 refer\xEAncias; contagens abrangem a biblioteca inteira.");
    });
    on2("upload", async () => {
      const state = await checked(), items = await getSwipe(), stamp = JSON.stringify(items);
      if (!confirm(`Substituir ${state.items.length} refer\xEAncias do backend ${state.settings.backendUrl} pelas ${items.length} refer\xEAncias locais? Exporte uma c\xF3pia antes de substituir.`)) return;
      if (identity(await getSettings()) !== identity(state.settings) || JSON.stringify(await getSwipe()) !== stamp) throw new Error("A conex\xE3o ou biblioteca local mudou durante a confirma\xE7\xE3o. Consulte e revise novamente.");
      const result = await callBackendOperation(state.settings, "/v1/library", { action: "commit", baseRevision: state.revision, items });
      remote2 = void 0;
      if (result.status !== "ok" || result.source !== "prevlev:library") throw new Error(result.error ?? "Transfer\xEAncia n\xE3o confirmada. Consulte antes de repetir.");
      status(`${items.length} refer\xEAncias enviadas a ${state.settings.backendUrl}. Consulte a nova revis\xE3o antes de outra transfer\xEAncia.`);
    });
    for (const replace of [false, true]) on2(replace ? "replace" : "merge", async () => {
      const state = await checked(), current = await getSwipe(), stamp = JSON.stringify(current), merged = mergeSwipeImport(current, state.items);
      if (!confirm(replace ? `Substituir ${current.length} refer\xEAncias locais pelas ${state.items.length} refer\xEAncias da revis\xE3o consultada em ${state.settings.backendUrl}?` : `Mesclar ${merged.added} novas refer\xEAncias no navegador? ${merged.duplicates} duplicadas e ${merged.conflicts} conflitantes manter\xE3o os dados locais.`)) return;
      if (identity(await getSettings()) !== identity(state.settings)) throw new Error("A conex\xE3o mudou; nenhuma biblioteca local foi alterada.");
      const latest = await readRemote(state.settings);
      if (latest.revision !== state.revision) {
        remote2 = void 0;
        throw new Error("A biblioteca do backend mudou. Consulte e revise novamente.");
      }
      if (identity(await getSettings()) !== identity(state.settings)) throw new Error("A conex\xE3o mudou durante a consulta; nenhuma biblioteca local foi alterada.");
      await updateSwipe(async (local) => {
        if (identity(await getSettings()) !== identity(state.settings)) throw new Error("A conex\xE3o mudou enquanto aguardava o bloqueio local; nenhuma biblioteca foi alterada.");
        if (JSON.stringify(local) !== stamp) throw new Error("A biblioteca local mudou. Consulte e revise novamente.");
        return replace ? state.items : mergeSwipeImport(local, state.items).items;
      });
      remote2 = void 0;
      await render2();
      status("Transfer\xEAncia local conclu\xEDda. IDs, datas e metadados preservados. Consulte novamente para outra a\xE7\xE3o.");
    });
    controls();
  }

  // src/core/image-workflows.ts
  var ImageTimeLimit = class extends Error {
    constructor() {
      super("Tempo limite do processamento local atingido. Reduza a imagem ou tente novamente.");
    }
  };
  var now = () => performance.now();
  function cancelled() {
    return new DOMException("Processamento cancelado.", "AbortError");
  }
  function check(signal, deadline) {
    if (signal?.aborted) throw cancelled();
    if (now() >= deadline) throw new ImageTimeLimit();
  }
  function controlled(work, signal, deadline, dispose) {
    return new Promise((resolve, reject) => {
      let settled = false;
      const cleanup = () => {
        clearTimeout(timer);
        signal?.removeEventListener("abort", abort);
      };
      const fail2 = (error) => {
        if (settled) return;
        settled = true;
        cleanup();
        reject(error);
      };
      const abort = () => fail2(cancelled());
      const timer = setTimeout(() => fail2(new ImageTimeLimit()), Math.max(0, deadline - now()));
      signal?.addEventListener("abort", abort, { once: true });
      work.then((value2) => {
        if (settled) {
          dispose?.(value2);
          return;
        }
        settled = true;
        cleanup();
        resolve(value2);
      }, (error) => {
        if (!settled) {
          settled = true;
          cleanup();
          reject(error);
        }
      });
      if (signal?.aborted) abort();
    });
  }
  function dimensions(width, height) {
    if (!Number.isInteger(width) || !Number.isInteger(height) || width < 1 || height < 1 || width > 16384 || height > 16384 || width * height > 32e6) throw new Error("Imagem fora do limite local de 32 megapixels e 16384 pixels por lado.");
  }
  function optionsFor(options) {
    const targetBytes = options.targetBytes, quality = options.quality ?? 0.85, minQuality = options.minQuality ?? Math.min(0.2, quality);
    const maxWidth = options.maxWidth ?? 1280, maxHeight = options.maxHeight ?? 720, maxIterations = options.maxIterations ?? 20, maxDurationMs = options.maxDurationMs ?? 5e3, minDimension = options.minDimension ?? 32, type = options.type ?? "image/jpeg";
    if (!Number.isSafeInteger(targetBytes) || targetBytes < 1 || targetBytes > 50 * 1024 * 1024) throw new Error("A meta deve ser de 1 byte a 50 MiB.");
    if (!Number.isFinite(quality) || quality < 0.1 || quality > 1 || !Number.isFinite(minQuality) || minQuality < 0.05 || minQuality > quality) throw new Error("Qualidades inv\xE1lidas: m\xE1xima entre 0,1 e 1, m\xEDnima entre 0,05 e a m\xE1xima.");
    if (!Number.isInteger(maxIterations) || maxIterations < 1 || maxIterations > 40 || !Number.isFinite(maxDurationMs) || maxDurationMs < 10 || maxDurationMs > 15e3) throw new Error("Use de 1 a 40 tentativas e um tempo entre 10 e 15000 ms.");
    if (!Number.isInteger(minDimension) || minDimension < 1 || minDimension > 16384) throw new Error("Resolu\xE7\xE3o m\xEDnima inv\xE1lida.");
    dimensions(maxWidth, maxHeight);
    if (!["image/jpeg", "image/png", "image/webp"].includes(type)) throw new Error("Escolha JPEG, PNG ou WebP.");
    return { targetBytes, quality, minQuality, maxWidth, maxHeight, maxIterations, maxDurationMs, minDimension, type };
  }
  async function findCompressionCandidate(source, options, encode2) {
    const config = optionsFor(options);
    dimensions(source.width, source.height);
    const started = now(), deadline = started + config.maxDurationMs;
    let size = fitDimensions(source.width, source.height, config.maxWidth, config.maxHeight);
    const initial = { ...size };
    let scale = 1, quality = config.quality, iterations = 0;
    let best;
    const finish = (reason) => {
      if (!best) throw new ImageTimeLimit();
      return { ...best, targetMet: best.bytes <= config.targetBytes, iterations, elapsedMs: Math.round(now() - started), reason };
    };
    while (iterations < config.maxIterations) {
      try {
        check(options.signal, deadline);
        const candidate = { ...size, type: config.type, ...config.type === "image/png" ? {} : { quality } };
        iterations++;
        const blob = await controlled(encode2(candidate), options.signal, deadline);
        check(options.signal, deadline);
        if (blob.type !== config.type || !blob.size) throw new Error("O navegador n\xE3o codificou o formato solicitado. Nenhum arquivo foi apresentado como v\xE1lido.");
        if (!best || blob.size < best.bytes) best = { ...candidate, blob, bytes: blob.size, targetBytes: config.targetBytes };
        if (blob.size <= config.targetBytes) return finish("target-met");
        if (config.type !== "image/png" && quality > config.minQuality) {
          quality = Math.max(config.minQuality, Math.round((quality - 0.2) * 1e3) / 1e3);
          continue;
        }
        const longest = Math.max(size.width, size.height);
        if (longest <= config.minDimension) return finish("dimension-floor");
        scale = Math.max(config.minDimension / Math.max(initial.width, initial.height), scale * 0.8);
        const next = fitDimensions(source.width, source.height, initial.width * scale, initial.height * scale);
        if (next.width === size.width && next.height === size.height) return finish("dimension-floor");
        size = next;
        quality = config.quality;
      } catch (error) {
        if (error instanceof ImageTimeLimit && best) return finish("time-limit");
        throw error;
      }
    }
    return finish("iteration-limit");
  }
  async function decode(blob, signal, deadline) {
    if (!(blob instanceof Blob) || !/^image\/(png|jpeg|webp|avif|gif)$/.test(blob.type) || blob.size < 1 || blob.size > 50 * 1024 * 1024) throw new Error("Escolha uma imagem local PNG, JPEG, WebP, AVIF ou GIF de at\xE9 50 MiB.");
    check(signal, deadline);
    let result;
    if (typeof createImageBitmap === "function") {
      const bitmap = await controlled(createImageBitmap(blob, { imageOrientation: "from-image" }), signal, deadline, (value2) => value2.close());
      result = { source: bitmap, width: bitmap.width, height: bitmap.height, close: () => bitmap.close() };
    } else {
      const image = await controlled(loadImage(blob), signal, deadline);
      result = { source: image, width: image.naturalWidth, height: image.naturalHeight, close: () => {
      } };
    }
    try {
      dimensions(result.width, result.height);
      check(signal, deadline);
      return result;
    } catch (error) {
      result.close();
      throw error;
    }
  }
  function canvasAt(width, height) {
    dimensions(width, height);
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const context = canvas.getContext("2d", { willReadFrequently: true });
    if (!context) throw new Error("Canvas 2D indispon\xEDvel neste navegador.");
    return { canvas, context };
  }
  function encoded(canvas, type, quality) {
    return new Promise((resolve, reject) => {
      try {
        canvas.toBlob((blob) => blob ? resolve(blob) : reject(new Error("N\xE3o foi poss\xEDvel codificar a imagem local.")), type, quality);
      } catch {
        reject(new Error("O navegador n\xE3o conseguiu codificar a imagem local."));
      }
    });
  }
  async function compressToTarget(blob, options) {
    const config = optionsFor(options), started = now(), deadline = started + config.maxDurationMs;
    const image = await decode(blob, options.signal, deadline);
    let sourceCanvas;
    try {
      const source = canvasAt(image.width, image.height);
      sourceCanvas = source.canvas;
      source.context.drawImage(image.source, 0, 0);
      const pixels = source.context.getImageData(0, 0, image.width, image.height).data;
      let hadAlpha = false;
      for (let index = 3; index < pixels.length; index += 4) {
        if ((index & 262143) === 3) check(options.signal, deadline);
        if (pixels[index] !== 255) {
          hadAlpha = true;
          break;
        }
      }
      check(options.signal, deadline);
      if (config.type === "image/jpeg" && hadAlpha && !options.flattenBackground) throw new Error("Esta imagem tem transpar\xEAncia. Escolha PNG/WebP ou autorize explicitamente achatar sobre uma cor para JPEG.");
      if (options.flattenBackground && !/^#[0-9a-f]{6}$/i.test(options.flattenBackground)) throw new Error("Escolha uma cor de fundo hexadecimal v\xE1lida para achatar a transpar\xEAncia.");
      if (blob.type === config.type && blob.size <= config.targetBytes && image.width <= config.maxWidth && image.height <= config.maxHeight && !options.flattenBackground) {
        return { blob, bytes: blob.size, targetBytes: config.targetBytes, targetMet: true, width: image.width, height: image.height, type: config.type, iterations: 0, elapsedMs: Math.round(now() - started), reason: "original-preserved", originalBytes: blob.size, sourceWidth: image.width, sourceHeight: image.height, hadAlpha, alphaPreserved: hadAlpha, flattened: false };
      }
      const result = await findCompressionCandidate({ width: image.width, height: image.height }, { ...options, maxDurationMs: Math.max(10, deadline - now()) }, async (candidate) => {
        check(options.signal, deadline);
        const target = canvasAt(candidate.width, candidate.height);
        if (config.type === "image/jpeg" && options.flattenBackground) {
          target.context.fillStyle = options.flattenBackground;
          target.context.fillRect(0, 0, candidate.width, candidate.height);
        }
        target.context.imageSmoothingEnabled = true;
        target.context.imageSmoothingQuality = "high";
        target.context.drawImage(source.canvas, 0, 0, candidate.width, candidate.height);
        try {
          return await controlled(encoded(target.canvas, candidate.type, candidate.quality), options.signal, deadline);
        } finally {
          target.canvas.width = target.canvas.height = 1;
        }
      });
      return { ...result, elapsedMs: Math.round(now() - started), originalBytes: blob.size, sourceWidth: image.width, sourceHeight: image.height, hadAlpha, alphaPreserved: hadAlpha && config.type !== "image/jpeg", flattened: hadAlpha && config.type === "image/jpeg" };
    } finally {
      image.close();
      if (sourceCanvas) sourceCanvas.width = sourceCanvas.height = 1;
    }
  }
  function buildCyclicVersions(images, titles, channel = "Seu canal") {
    const clean = titles.map((title) => title.trim()).filter(Boolean);
    if (images.length > 6 || clean.length > 6) throw new Error("Use at\xE9 6 imagens e 6 t\xEDtulos por pr\xE9via.");
    if (!images.length) return [];
    const labels2 = clean.length ? clean : ["T\xEDtulo do v\xEDdeo"];
    return Array.from({ length: Math.max(images.length, labels2.length) }, (_, index) => ({ image: images[index % images.length], title: labels2[index % labels2.length], channel }));
  }
  function lines(context, text2, width, maxLines) {
    const words = text2.replace(/\s+/g, " ").trim().split(" "), result = [];
    let line = "";
    for (let index = 0; index < words.length; index++) {
      const next = line ? `${line} ${words[index]}` : words[index];
      if (context.measureText(next).width > width && line) {
        result.push(line);
        line = words[index];
        if (result.length === maxLines - 1) {
          line = [line, ...words.slice(index + 1)].join(" ");
          break;
        }
      } else line = next;
    }
    if (result.length < maxLines && line) result.push(line);
    return result.map((value2) => {
      let clipped = value2;
      while (clipped && context.measureText(`${clipped}\u2026`).width > width) clipped = clipped.slice(0, -1);
      return clipped === value2 ? value2 : `${clipped}\u2026`;
    });
  }
  function drawCover(context, image, x, y, width, height) {
    const scale = Math.max(width / image.width, height / image.height);
    context.save();
    context.beginPath();
    context.roundRect(x, y, width, height, 9);
    context.clip();
    context.drawImage(image.source, x + (width - image.width * scale) / 2, y + (height - image.height * scale) / 2, image.width * scale, image.height * scale);
    context.restore();
  }
  function layout(width, count2, kind) {
    const columns = kind === "desktop" ? width > 900 ? 3 : 2 : 1;
    const inset = kind === "desktop" ? 52 : 18, gap = 18, cardWidth = (width - inset - 18 - (columns - 1) * gap) / columns;
    const thumbWidth = kind === "list" ? Math.min(310, cardWidth * 0.4) : cardWidth;
    const thumbHeight = thumbWidth * 9 / 16, rowHeight = kind === "list" ? Math.max(thumbHeight + 24, 140) : thumbHeight + 137;
    return { columns, inset, gap, cardWidth, thumbWidth, thumbHeight, rowHeight, height: 184 + Math.ceil(count2 / columns) * rowHeight + 24 };
  }
  function contextCards(versions, images, position, seed, records = []) {
    const cards = versions.map((version) => ({ version, image: images.get(version.image) }));
    const observed = records.filter((record2) => record2.source !== "youtube-data-api" && typeof record2.title === "string" && record2.title.trim()).slice(0, 8);
    const surrounding = observed.length ? observed.map((record2) => ({ observed: record2 })) : [{}, {}];
    const before = position === "first" ? 0 : Math.abs(Math.trunc(seed)) % (surrounding.length + 1);
    return [...surrounding.slice(0, before), ...cards, ...surrounding.slice(before)];
  }
  function viewport(context, cards, avatar, x, y, width, kind, label, options) {
    const dark = (options.theme ?? "dark") === "dark", palette = dark ? { background: "#151820", text: "#f4f5fb", muted: "#aab4c8", surface: "#2e3544" } : { background: "#f8f9fc", text: "#1b2030", muted: "#5d687c", surface: "#e0e5ef" };
    const grid = layout(width, cards.length, kind);
    context.save();
    context.translate(x, y);
    context.fillStyle = palette.background;
    context.fillRect(0, 0, width, grid.height);
    context.fillStyle = palette.text;
    context.font = "bold 19px sans-serif";
    context.fillText(label, 18, 32);
    const feed = options.feed ?? "home", feedNames = { home: "P\xE1gina inicial", trending: "Em alta", subscriptions: "Inscri\xE7\xF5es", channel: `Canal: ${options.feedLabel || "Seu canal"}`, search: `Busca: ${options.feedLabel || "termo de exemplo"}` };
    context.fillStyle = palette.muted;
    context.font = "13px sans-serif";
    context.fillText(`${feedNames[feed]} \xB7 ${kind === "mobile" ? "celular" : kind === "list" ? "lista" : "desktop"} \xB7 ${dark ? "escuro" : "claro"}`, 18, 56, width - 36);
    context.fillStyle = palette.surface;
    context.fillRect(16, 75, width - 32, 38);
    context.fillStyle = palette.muted;
    context.fillText("Pesquisar v\xEDdeos", 30, 100);
    const chips = { home: ["Tudo", "Para voc\xEA", "Recentes"], trending: ["Em alta", "M\xFAsica", "Jogos"], subscriptions: ["Inscritos", "Hoje", "Recentes"], channel: ["V\xEDdeos", "Populares", "Recentes"], search: ["Relev\xE2ncia", "Recentes", "Filtros"] }[feed];
    for (const [index, text2] of chips.entries()) {
      context.fillStyle = index === 0 ? "#7464da" : palette.surface;
      context.fillRect(18 + index * 100, 129, 90, 29);
      context.fillStyle = index === 0 ? "#fff" : palette.text;
      context.fillText(text2, 28 + index * 100, 149);
    }
    if (kind === "desktop") {
      context.fillStyle = palette.surface;
      for (let row3 = 0; row3 < 5; row3++) context.fillRect(16, 195 + row3 * 48, 22, 23);
    }
    cards.forEach((card, index) => {
      const cardX = grid.inset + index % grid.columns * (grid.cardWidth + grid.gap), cardY = 184 + Math.floor(index / grid.columns) * grid.rowHeight;
      const textX = kind === "list" ? cardX + grid.thumbWidth + 18 : cardX + 42, textY = kind === "list" ? cardY + 21 : cardY + grid.thumbHeight + 28, textWidth = kind === "list" ? grid.cardWidth - grid.thumbWidth - 22 : grid.cardWidth - 46;
      if (card.image) drawCover(context, card.image, cardX, cardY, grid.thumbWidth, grid.thumbHeight);
      else {
        context.fillStyle = palette.surface;
        context.fillRect(cardX, cardY, grid.thumbWidth, grid.thumbHeight);
        context.fillStyle = palette.muted;
        context.font = "13px sans-serif";
        context.fillText(card.observed ? "Imagem n\xE3o carregada \xB7 amostra" : "Contexto ilustrativo", cardX + 12, cardY + grid.thumbHeight / 2, grid.thumbWidth - 24);
      }
      if (card.version) {
        const duration = (options.metadata?.duration ?? "10:00").slice(0, 20);
        context.font = "bold 12px sans-serif";
        const badgeWidth = Math.min(grid.thumbWidth - 8, context.measureText(duration).width + 12);
        context.fillStyle = "#000c";
        context.fillRect(cardX + grid.thumbWidth - badgeWidth - 5, cardY + grid.thumbHeight - 24, badgeWidth, 19);
        context.fillStyle = "#fff";
        context.fillText(duration, cardX + grid.thumbWidth - badgeWidth + 1, cardY + grid.thumbHeight - 10, badgeWidth - 8);
        if (kind !== "list") {
          context.save();
          context.beginPath();
          context.arc(cardX + 16, cardY + grid.thumbHeight + 25, 16, 0, Math.PI * 2);
          context.clip();
          if (avatar) drawCover(context, avatar, cardX, cardY + grid.thumbHeight + 9, 32, 32);
          else {
            context.fillStyle = "#7464da";
            context.fillRect(cardX, cardY + grid.thumbHeight + 9, 32, 32);
            context.fillStyle = "#fff";
            context.font = "bold 17px sans-serif";
            context.fillText((card.version.channel || "P").slice(0, 1).toUpperCase(), cardX + 10, cardY + grid.thumbHeight + 31);
          }
          context.restore();
        }
      } else if (card.observed?.durationSeconds !== void 0 && Number.isFinite(card.observed.durationSeconds) && card.observed.durationSeconds >= 0) {
        const seconds = Math.floor(card.observed.durationSeconds), duration = seconds >= 3600 ? `${Math.floor(seconds / 3600)}:${String(Math.floor(seconds % 3600 / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}` : `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, "0")}`;
        context.font = "bold 12px sans-serif";
        const badgeWidth = context.measureText(duration).width + 12;
        context.fillStyle = "#000c";
        context.fillRect(cardX + grid.thumbWidth - badgeWidth - 5, cardY + grid.thumbHeight - 24, badgeWidth, 19);
        context.fillStyle = "#fff";
        context.fillText(duration, cardX + grid.thumbWidth - badgeWidth + 1, cardY + grid.thumbHeight - 10);
      }
      context.fillStyle = palette.text;
      context.font = "bold 15px sans-serif";
      lines(context, card.version?.title || card.observed?.title || "Outro v\xEDdeo \xB7 cart\xE3o de contexto", textWidth, 2).forEach((line, row3) => context.fillText(line, textX, textY + row3 * 20));
      context.fillStyle = palette.muted;
      context.font = "12px sans-serif";
      context.fillText((card.version?.channel || (card.observed ? card.observed.channel || "Canal indispon\xEDvel" : "Canal ilustrativo")).slice(0, 80), textX, textY + 51, textWidth);
      context.fillText(card.version ? (options.metadata?.views || "Visualiza\xE7\xF5es de exemplo").slice(0, 80) : card.observed ? card.observed.views === void 0 ? "Views indispon\xEDveis" : `${new Intl.NumberFormat("pt-BR").format(card.observed.views)} visualiza\xE7\xF5es \xB7 amostra` : "Metadados ilustrativos", textX, textY + 70, textWidth);
      context.fillText(card.version ? (options.metadata?.date || "Data de exemplo").slice(0, 80) : card.observed ? `${card.observed.publishedAt?.slice(0, 10) || "Data indispon\xEDvel"} \xB7 ${card.observed.source || "amostra enviada"}` : "Sem dados de audi\xEAncia", textX, textY + 88, textWidth);
    });
    context.restore();
    return grid.height;
  }
  async function renderHomePreview(options) {
    const kind = options.context ?? "desktop", mode = options.mode ?? "gallery", theme = options.theme ?? "dark", position = options.position ?? "first";
    if (!["home", "trending", "subscriptions", "channel", "search"].includes(options.feed ?? "home")) throw new Error("Contexto de feed inv\xE1lido.");
    if (!["desktop", "mobile", "list"].includes(kind) || !["side-by-side", "original", "candidate", "gallery"].includes(mode) || !["dark", "light"].includes(theme) || !["first", "random"].includes(position)) throw new Error("Contexto ou compara\xE7\xE3o de pr\xE9via inv\xE1lidos.");
    const versions = options.candidates?.length ? options.candidates : [options.candidate];
    if (versions.length > 24) throw new Error("Use no m\xE1ximo 24 combina\xE7\xF5es de imagem e t\xEDtulo por pr\xE9via.");
    const deadline = now() + 1e4, cache = /* @__PURE__ */ new Map();
    const decodePreview = async (blob, maxWidth = 1280, maxHeight = 720) => {
      if (cache.has(blob)) return;
      const source = await decode(blob, options.signal, deadline);
      try {
        const size = fitDimensions(source.width, source.height, maxWidth, maxHeight), target = canvasAt(size.width, size.height);
        target.context.drawImage(source.source, 0, 0, size.width, size.height);
        cache.set(blob, { source: target.canvas, ...size, close: () => {
          target.canvas.width = target.canvas.height = 1;
        } });
      } finally {
        source.close();
      }
    };
    try {
      const needed = mode === "gallery" ? versions : mode === "original" ? [options.original] : mode === "candidate" ? [options.candidate] : [options.original, options.candidate];
      for (const version of needed) await decodePreview(version.image);
      if (options.avatar) await decodePreview(options.avatar, 96, 96);
      check(options.signal, deadline);
      const seed = options.seed ?? 17, panels = mode === "side-by-side" ? [[options.original], [options.candidate]] : mode === "original" ? [[options.original]] : mode === "candidate" ? [[options.candidate]] : [versions];
      const panelWidth = kind === "mobile" ? 450 : mode === "side-by-side" ? 604 : 1232, gap = 24;
      const cards = panels.map((versions2) => contextCards(versions2, cache, position, seed, options.contextVideos));
      const height = Math.ceil(Math.max(...cards.map((items) => layout(panelWidth, items.length, kind).height)) + 136), width = 1280;
      const { canvas, context } = canvasAt(width, height);
      context.fillStyle = theme === "dark" ? "#090d15" : "#e9edf5";
      context.fillRect(0, 0, width, height);
      context.fillStyle = theme === "dark" ? "#c7bfff" : "#45368a";
      context.font = "bold 21px sans-serif";
      context.fillText("Prevlev \xB7 pr\xE9via local de thumbnails e t\xEDtulos", 24, 36);
      context.font = "14px sans-serif";
      context.fillText("Composi\xE7\xE3o ilustrativa. Sem teste A/B, CTR ou previs\xE3o de desempenho.", 24, 63);
      const totalWidth = panels.length * panelWidth + (panels.length - 1) * gap, start = (width - totalWidth) / 2;
      cards.forEach((items, index) => viewport(context, items, options.avatar ? cache.get(options.avatar) : void 0, start + index * (panelWidth + gap), 90, panelWidth, kind, mode === "side-by-side" ? index === 0 ? "Original" : "Candidata" : mode === "original" ? "Original" : mode === "candidate" ? "Candidata" : "Varia\xE7\xF5es locais", options));
      context.font = "12px sans-serif";
      context.fillText(options.contextVideos?.some((video) => video.source !== "youtube-data-api") ? "Contexto: amostra carregada, sem buscar imagens; n\xE3o comprova o feed selecionado. Candidatas: arquivos e metadados do usu\xE1rio." : "Contexto ilustrativo \xB7 arquivos e metadados de exemplo do usu\xE1rio \xB7 nenhum envio", 24, height - 16, width - 48);
      return await controlled(encoded(canvas, "image/png"), options.signal, deadline);
    } finally {
      for (const image of cache.values()) image.close();
    }
  }

  // src/ui/images.ts
  function initImageTools(options = {}) {
    const host = document.getElementById("images");
    if (!host) return () => {
    };
    host.innerHTML = `<div class="card"><h2>Imagens e t\xEDtulos no contexto da p\xE1gina inicial</h2><p class="muted">Use somente seus arquivos locais. A composi\xE7\xE3o \xE9 ilustrativa: n\xE3o altera o YouTube, n\xE3o testa audi\xEAncia e n\xE3o prev\xEA CTR.</p><div class="grid two"><div><label>Imagem original (ou use as candidatas)<input id="image-file" type="file" accept="image/png,image/jpeg,image/webp,image/avif,image/gif"></label><label>T\xEDtulo original<input id="original-title" type="text" maxlength="500" value="T\xEDtulo original do v\xEDdeo"></label><label>Imagens candidatas (at\xE9 6; opcional para mudar s\xF3 o t\xEDtulo)<input id="candidate-file" type="file" accept="image/png,image/jpeg,image/webp,image/avif,image/gif" multiple></label><label>T\xEDtulo candidato<input id="preview-title" type="text" maxlength="500" value="T\xEDtulo da candidata"></label><label>Outros t\xEDtulos (um por linha; at\xE9 6 t\xEDtulos no total)<textarea id="preview-titles" rows="3" maxlength="3000" placeholder="Segunda op\xE7\xE3o de t\xEDtulo&#10;Terceira op\xE7\xE3o de t\xEDtulo"></textarea></label><label>Nome do canal<input id="preview-channel" type="text" maxlength="80" value="Seu canal"></label><label>Avatar local opcional<input id="preview-avatar" type="file" accept="image/png,image/jpeg,image/webp"></label></div><div><div class="form-grid"><label>Layout<select id="preview-context"><option value="desktop">Desktop</option><option value="mobile">Celular</option><option value="list">Lista</option></select></label><label>Tema<select id="preview-theme"><option value="dark">Escuro</option><option value="light">Claro</option></select></label><label>Posi\xE7\xE3o das varia\xE7\xF5es<select id="preview-position"><option value="first">Primeira posi\xE7\xE3o</option><option value="random">Posi\xE7\xE3o aleat\xF3ria</option></select></label><label>Compara\xE7\xE3o<select id="preview-mode"><option value="gallery">Home com varia\xE7\xF5es</option><option value="side-by-side">Original e candidata lado a lado</option><option value="original">Somente original</option><option value="candidate">Somente candidata</option></select></label><label>Fonte do contexto<select id="preview-source"><option value="loaded">Amostra carregada</option><option value="illustrative">Ilustrativo</option></select></label><label>Contexto visual<select id="preview-feed"><option value="home">P\xE1gina inicial</option><option value="trending">Em alta</option><option value="subscriptions">Inscri\xE7\xF5es</option><option value="channel">Canal</option><option value="search">Busca por termo</option></select></label></div><label>Canal ou termo do contexto (texto fornecido por voc\xEA)<input id="preview-feed-label" type="text" maxlength="120" placeholder="Canal ou termo de exemplo"></label><details id="preview-metadata" open><summary>Editar metadados ilustrativos</summary><label>Visualiza\xE7\xF5es de exemplo (texto edit\xE1vel)<input id="preview-views" type="text" maxlength="80" value="12 mil visualiza\xE7\xF5es \xB7 exemplo"></label><label>Data de exemplo<input id="preview-date" type="text" maxlength="80" value="h\xE1 2 dias \xB7 exemplo"></label><label>Dura\xE7\xE3o exibida<input id="preview-duration" type="text" maxlength="20" value="10:00"></label><div class="actions"><button id="metadata-reset">Redefinir metadados</button><button id="metadata-done">Concluir metadados</button></div></details><div class="actions"><button id="image-preview" class="primary">Gerar pr\xE9via</button><button id="preview-restore">Ver original</button><button id="preview-shuffle">Embaralhar posi\xE7\xE3o</button><button id="preview-download" disabled>Baixar pr\xE9via</button></div><p id="preview-status" class="muted" role="status"></p><div id="image-variants" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(145px,1fr));gap:8px"></div></div></div><div id="image-preview-empty" class="empty">Envie uma imagem original e gere a composi\xE7\xE3o local.</div><img id="image-output" alt="Composi\xE7\xE3o local de imagens e t\xEDtulos; metadados ilustrativos" hidden style="width:100%;height:auto;margin-top:16px"></div>
  <div class="card"><h2>Comprimir at\xE9 uma meta de tamanho</h2><p class="muted">A busca tem limite de tempo e de tentativas. Uma meta muito pequena pode ser imposs\xEDvel; o resultado informa os bytes reais, sem garantia de atingir a meta. Arquivos animados geram um \xFAnico quadro est\xE1tico quando convertidos.</p><div class="form-grid"><label>Arquivo<select id="compression-source"><option value="original">Imagem original</option><option value="candidate">Imagem da candidata selecionada</option></select></label><label>Meta (KiB = 1024 bytes)<input id="compression-target-kb" type="number" min="0.001" max="51200" step="0.001" value="2048"></label><label>Largura m\xE1xima<input id="image-width" type="number" min="1" max="16384" value="1280"></label><label>Altura m\xE1xima<input id="image-height" type="number" min="1" max="16384" value="720"></label><label>Qualidade inicial (%)<input id="image-quality" type="number" min="10" max="100" value="85"></label><label>Formato<select id="compression-format"><option value="image/jpeg">JPEG</option><option value="image/webp">WebP</option><option value="image/png">PNG</option></select></label></div><label class="toggle"><input id="flatten-alpha" type="checkbox"> Autorizar achatar transpar\xEAncia ao gerar JPEG</label><label>Cor de fundo para achatar<input id="flatten-color" type="color" value="#ffffff"></label><div class="actions"><button id="compress" class="primary">Comprimir e baixar se atingir a meta</button><button id="compression-cancel" disabled>Cancelar</button><button id="compression-download" disabled>Baixar resultado</button></div><p id="image-info" role="status" class="muted"></p><pre id="compression-result" aria-live="polite"></pre></div>
  <div class="card"><h2>Thumbnail p\xFAblica de um v\xEDdeo</h2><p class="muted">Consulta somente o CDN p\xFAblico do YouTube quando voc\xEA clicar.</p><label>ID ou URL YouTube<input id="thumbnail-id" type="text"></label><div class="actions"><button id="download-thumbnail">Baixar thumbnail</button><button id="copy-thumbnail">Copiar imagem</button></div></div>`;
    const $2 = (id) => host.querySelector(`#${id}`);
    const value2 = (id) => $2(id).value;
    const number4 = (id) => Number(value2(id));
    const show = (message, error = false) => {
      $2("image-info").textContent = message;
      options.notice?.(message, error);
    };
    const fail2 = (error) => show(error instanceof Error ? error.message : "Falha no processamento local.", true);
    const events = [];
    const listen = (id, event, callback) => {
      const element4 = $2(id);
      element4.addEventListener(event, callback);
      events.push(() => element4.removeEventListener(event, callback));
    };
    const click = (id, task) => listen(id, "click", () => {
      void Promise.resolve().then(task).catch(fail2);
    });
    let sourceChosen = false;
    $2("preview-source").value = options.contextVideos?.().some((video) => video.source !== "youtube-data-api") ? "loaded" : "illustrative";
    let original, candidates = [], avatar, variants = [], selected = 0, seed = 17;
    let previewAbort, compressionAbort, previewUrl, previewBlob, last;
    const thumbnailUrls2 = [];
    function clearPreview() {
      previewAbort?.abort();
      if (previewUrl) URL.revokeObjectURL(previewUrl);
      previewUrl = void 0;
      previewBlob = void 0;
      $2("image-output").removeAttribute("src");
      $2("image-output").hidden = true;
      $2("image-preview-empty").hidden = false;
      $2("preview-download").disabled = true;
    }
    function buildVariants() {
      const titleOptions = [value2("preview-title"), ...value2("preview-titles").split("\n")].map((title) => title.trim()).filter(Boolean);
      if (titleOptions.length > 6) throw new Error("Use at\xE9 6 t\xEDtulos no total.");
      const titles = titleOptions.length ? titleOptions : ["T\xEDtulo do v\xEDdeo"];
      const files = candidates.length ? candidates : original ? [original] : [];
      variants = buildCyclicVersions(files, titles, value2("preview-channel"));
      selected = Math.min(selected, Math.max(0, variants.length - 1));
      for (const url of thumbnailUrls2) URL.revokeObjectURL(url);
      thumbnailUrls2.length = 0;
      const gallery = $2("image-variants");
      gallery.replaceChildren();
      variants.forEach((variant, index) => {
        const button = document.createElement("button");
        button.type = "button";
        button.setAttribute("aria-pressed", String(index === selected));
        button.style.cssText = "text-align:left;min-width:0";
        const img = document.createElement("img"), url = URL.createObjectURL(variant.image);
        thumbnailUrls2.push(url);
        img.src = url;
        img.alt = `Varia\xE7\xE3o ${index + 1}`;
        img.style.cssText = "width:100%;height:70px;object-fit:cover";
        const title = document.createElement("span");
        title.textContent = `${index + 1}. ${variant.title}`;
        button.append(img, title);
        button.addEventListener("click", () => {
          selected = index;
          gallery.querySelectorAll("button").forEach((item, i) => item.setAttribute("aria-pressed", String(i === index)));
          if (previewBlob) void render2(false).catch(fail2);
        });
        gallery.append(button);
      });
    }
    async function render2(newSeed = true) {
      const originalImage = original ?? candidates[0];
      if (!originalImage) throw new Error("Escolha pelo menos uma imagem local.");
      const observed = (options.contextVideos?.() ?? []).filter((video) => video.source !== "youtube-data-api");
      if (!sourceChosen) $2("preview-source").value = observed.length ? "loaded" : "illustrative";
      buildVariants();
      if (newSeed) {
        const next = crypto.getRandomValues(new Uint32Array(1))[0];
        seed = next % 3 === seed % 3 ? next + 1 >>> 0 : next;
      }
      previewAbort?.abort();
      const controller = new AbortController();
      previewAbort = controller;
      $2("preview-status").textContent = "Compondo a pr\xE9via neste navegador\u2026";
      const settings = { original: { image: originalImage, title: value2("original-title"), channel: value2("preview-channel") }, candidate: variants[selected], candidates: variants, context: value2("preview-context"), theme: value2("preview-theme"), position: value2("preview-position"), mode: value2("preview-mode"), seed, feed: value2("preview-feed"), feedLabel: value2("preview-feed-label"), contextVideos: value2("preview-source") === "loaded" ? observed : [], metadata: { views: value2("preview-views"), date: value2("preview-date"), duration: value2("preview-duration") }, avatar, signal: controller.signal };
      try {
        const blob = await renderHomePreview(settings);
        if (controller.signal.aborted) return;
        if (previewUrl) URL.revokeObjectURL(previewUrl);
        previewUrl = URL.createObjectURL(blob);
        previewBlob = blob;
        $2("image-output").src = previewUrl;
        $2("image-output").hidden = false;
        $2("image-preview-empty").hidden = true;
        $2("preview-download").disabled = false;
        $2("preview-status").textContent = `${variants.length} varia\xE7\xF5es locais \xB7 ${value2("preview-context")} \xB7 ${value2("preview-theme")} \xB7 candidata ${selected + 1}. Fonte do contexto: ${settings.contextVideos?.length ? "amostra carregada; n\xE3o comprova o feed escolhido" : "ilustrativo, sem amostra carregada"}. Sem teste de audi\xEAncia.`;
      } catch (error) {
        if (controller.signal.aborted) return;
        throw error;
      }
    }
    listen("image-file", "change", () => {
      original = $2("image-file").files?.[0];
      clearPreview();
      selected = 0;
      try {
        buildVariants();
        show(original ? `${original.name} \xB7 ${(original.size / 1024).toFixed(1)} KiB` : "Escolha uma imagem local.");
      } catch (error) {
        fail2(error);
      }
    });
    listen("candidate-file", "change", () => {
      const files = Array.from($2("candidate-file").files ?? []);
      if (files.length > 6) {
        fail2(new Error("Selecione no m\xE1ximo 6 imagens candidatas."));
        return;
      }
      candidates = files;
      selected = 0;
      clearPreview();
      try {
        buildVariants();
      } catch (error) {
        fail2(error);
      }
    });
    listen("preview-avatar", "change", () => {
      avatar = $2("preview-avatar").files?.[0];
      clearPreview();
    });
    click("image-preview", () => render2());
    listen("preview-source", "change", () => {
      sourceChosen = true;
      if (previewBlob) void render2(false).catch(fail2);
    });
    for (const id of ["preview-context", "preview-theme", "preview-position", "preview-mode", "preview-feed"]) listen(id, "change", () => {
      if (previewBlob) void render2(false).catch(fail2);
    });
    click("preview-shuffle", async () => {
      $2("preview-position").value = "random";
      await render2(true);
    });
    click("metadata-reset", async () => {
      for (const [id, text2] of [["preview-views", "12 mil visualiza\xE7\xF5es \xB7 exemplo"], ["preview-date", "h\xE1 2 dias \xB7 exemplo"], ["preview-duration", "10:00"]]) $2(id).value = text2;
      avatar = void 0;
      $2("preview-avatar").value = "";
      if (previewBlob) await render2(false);
    });
    click("metadata-done", async () => {
      $2("preview-metadata").open = false;
      if (previewBlob) await render2(false);
    });
    click("preview-restore", async () => {
      $2("preview-mode").value = "original";
      await render2(false);
    });
    click("preview-download", () => {
      if (previewBlob) downloadBlob(previewBlob, "prevlev-previa-local.png");
    });
    click("compress", async () => {
      if (compressionAbort) throw new Error("Cancele ou aguarde a compress\xE3o atual.");
      buildVariants();
      const input = value2("compression-source") === "candidate" ? variants[selected]?.image : original ?? candidates[0];
      if (!input) throw new Error("Escolha uma imagem local para comprimir.");
      const controller = new AbortController();
      compressionAbort = controller;
      last = void 0;
      $2("compression-download").disabled = true;
      $2("compression-cancel").disabled = false;
      $2("compress").disabled = true;
      $2("compression-result").textContent = "Processando localmente\u2026";
      try {
        const result = await compressToTarget(input, { targetBytes: Math.floor(number4("compression-target-kb") * 1024), maxWidth: number4("image-width"), maxHeight: number4("image-height"), quality: number4("image-quality") / 100, type: value2("compression-format"), ...$2("flatten-alpha").checked ? { flattenBackground: value2("flatten-color") } : {}, signal: controller.signal });
        if (controller.signal.aborted) return;
        last = result;
        $2("compression-download").disabled = false;
        const quality = result.reason === "original-preserved" ? "arquivo original preservado" : result.quality === void 0 ? "PNG: qualidade n\xE3o aplic\xE1vel; confira a resolu\xE7\xE3o" : `${Math.round(result.quality * 100)}%`;
        $2("compression-result").textContent = `${result.targetMet ? "Meta atingida" : "Meta n\xE3o atingida; melhor resultado encontrado"}
Sa\xEDda: ${result.bytes} bytes (${(result.bytes / 1024).toFixed(2)} KiB) \xB7 meta ${result.targetBytes} bytes
${result.width} \xD7 ${result.height} px \xB7 ${result.type} \xB7 ${quality}
${result.iterations} tentativas \xB7 ${result.elapsedMs} ms \xB7 limite: ${result.reason}
Transpar\xEAncia: ${result.flattened ? "achatada por autoriza\xE7\xE3o" : result.alphaPreserved ? "preservada no formato de sa\xEDda" : "imagem opaca"}`;
        show(`Original: ${(result.originalBytes / 1024).toFixed(1)} KiB \xB7 Sa\xEDda: ${(result.bytes / 1024).toFixed(2)} KiB. ${result.targetMet ? "Meta atingida." : "Meta n\xE3o atingida; voc\xEA pode baixar o resultado informado."}`);
        if (result.targetMet) downloadBlob(result.blob, filename(result.type));
      } catch (error) {
        if (controller.signal.aborted) {
          $2("compression-result").textContent = "Processamento cancelado. Nenhum resultado novo foi baixado.";
          show("Compress\xE3o cancelada.");
        } else {
          $2("compression-result").textContent = error instanceof Error ? error.message : "Falha na compress\xE3o.";
          throw error;
        }
      } finally {
        if (compressionAbort === controller) compressionAbort = void 0;
        $2("compression-cancel").disabled = true;
        $2("compress").disabled = false;
      }
    });
    listen("compression-cancel", "click", () => {
      compressionAbort?.abort();
    });
    click("compression-download", () => {
      if (last) downloadBlob(last.blob, filename(last.type));
    });
    function filename(type) {
      return `prevlev-thumbnail.${type === "image/jpeg" ? "jpg" : type === "image/webp" ? "webp" : "png"}`;
    }
    function videoId() {
      const input = value2("thumbnail-id").trim(), id = videoIdFromUrl(input) ?? (/^[\w-]{11}$/.test(input) ? input : void 0);
      if (!id) throw new Error("Informe um ID ou URL YouTube v\xE1lido.");
      return id;
    }
    click("download-thumbnail", async () => {
      const id = videoId();
      downloadBlob(await fetchThumbnail(id), `prevlev-${id}.jpg`);
    });
    click("copy-thumbnail", async () => {
      await copyImage(await fetchThumbnail(videoId()));
      show("Thumbnail copiada.");
    });
    return () => {
      previewAbort?.abort();
      compressionAbort?.abort();
      for (const remove of events) remove();
      if (previewUrl) URL.revokeObjectURL(previewUrl);
      for (const url of thumbnailUrls2) URL.revokeObjectURL(url);
    };
  }

  // src/core/sponsorships.ts
  var MAX_TEXT = 1e5;
  var MAX_EVIDENCE = 200;
  var plain3 = (value2) => value2 !== null && typeof value2 === "object" && !Array.isArray(value2) ? value2 : {};
  function guardApi(value2) {
    const stack = [{ value: value2, tagged: false }], seen = /* @__PURE__ */ new WeakSet();
    let count2 = 0;
    while (stack.length) {
      if (++count2 > 5e3) throw new Error("Metadados de origem acima do limite.");
      const current = stack.pop();
      if (typeof current.value === "string") {
        const normalized2 = current.value.toLowerCase().replace(/[\s_]+/g, "-");
        if (current.tagged && (["youtube-data-api", "youtube-api"].includes(normalized2) || /^https:\/\/www\.googleapis\.com\/youtube\/v3(?:\/|$)/i.test(current.value))) throw new Error("Dados identificados como youtube-data-api n\xE3o podem alimentar esta an\xE1lise textual local.");
        continue;
      }
      if (current.value === null || typeof current.value !== "object" || seen.has(current.value)) continue;
      seen.add(current.value);
      if (Array.isArray(current.value)) {
        for (const child of current.value) if (child && typeof child === "object" || current.tagged) stack.push({ value: child, tagged: current.tagged });
      } else for (const [key, child] of Object.entries(current.value)) if (child && typeof child === "object" || /source|provenance|origin/i.test(key)) stack.push({ value: child, tagged: current.tagged || /source|provenance|origin/i.test(key) });
    }
  }
  var normalized = (value2) => value2.normalize("NFKC").replace(/\s+/g, " ").trim().toLocaleLowerCase("pt-BR");
  function lineStarts(text2) {
    const starts = [0];
    for (let i = 0; i < text2.length; i++) if (text2[i] === "\r") {
      if (text2[i + 1] === "\n") i++;
      starts.push(i + 1);
    } else if (text2[i] === "\n") starts.push(i + 1);
    return starts;
  }
  function location2(starts, offset) {
    let low = 0, high = starts.length;
    while (low + 1 < high) {
      const middle = low + high >> 1;
      if (starts[middle] <= offset) low = middle;
      else high = middle;
    }
    return { line: low + 1, column: offset - starts[low] + 1 };
  }
  function negated(text2, start) {
    return /(?:n[aã]o(?:\s+(?:[ée]|foi|est[aá]))?|not|never)\s*$/iu.test(text2.slice(Math.max(0, start - 50), start));
  }
  var genericBrand = /* @__PURE__ */ new Set(["voc\xEA", "voc\xEAs", "voce", "voces", "you", "your", "n\xF3s", "nos", "ninguem", "ningu\xE9m", "algu\xE9m", "alguem", "ningu", "nobody", "anyone", "someone", "empresa", "marca", "brand", "fabricante", "companhia", "company", "canal", "channel", "this", "este", "esta", "esse", "essa", "nosso", "nossa", "our", "um", "uma", "the", "a", "an", "patroc\xEDnio", "patrocinio", "sponsor", "sponsored"]);
  var stops = /* @__PURE__ */ new Set(["use", "using", "utilize", "acesse", "visite", "visit", "ganhe", "compre", "confira", "clique", "saiba", "para", "for", "with", "que", "agora", "hoje", "today", "thanks", "obrigado", "obrigada", "desconto", "discount", "link", "links", "em", "no", "na", "e", "and", "com", "por", "oferece", "oferecem", "offers", "oferecendo", "making", "supporting", "more", "mais", "is", "are"]);
  function brandAfter(text2, offset, marker) {
    let start = offset;
    const spacing = /^[ \t]*(?::|[-–—])?[ \t]*(?:(?:a|o|as|os)\s+)?/.exec(text2.slice(start));
    start += spacing?.[0].length ?? 0;
    const sample = text2.slice(start, start + 160);
    if (!sample || /^https?:\/\//i.test(sample)) return void 0;
    const quotePairs = { '"': '"', "'": "'", "\u201C": "\u201D", "\u2018": "\u2019" };
    if (quotePairs[sample[0]]) {
      const end2 = sample.indexOf(quotePairs[sample[0]], 1), value3 = sample.slice(1, end2);
      if (end2 > 1 && end2 <= 101 && /[\p{L}]/u.test(value3) && !/[<>\r\n]/.test(value3) && !/^https?:/i.test(value3)) return { start: start + 1, end: start + end2 };
      return void 0;
    }
    const words = [...sample.matchAll(/[^\s,;:!?\r\n]+/g)];
    let end = start, accepted = 0;
    for (let index = 0; index < Math.min(words.length, 8); index++) {
      const token = words[index][0], clean = token.replace(/[.)\]}]+$/, "");
      if (!clean || /[<>/=]/.test(clean) || /^https?:/i.test(token) || !/^[\p{L}\p{N}@&][\p{L}\p{N}_.@&+'’™®-]*$/u.test(clean)) break;
      const fold = normalized(clean), connector = ["de", "da", "do", "das", "dos", "&"].includes(fold);
      const namedThe = fold === "the" && /^The$/.test(clean) && new RegExp("^\\p{Lu}", "u").test(words[index + 1]?.[0] ?? "");
      if (index === 0 && (genericBrand.has(fold) && !namedThe || /^(?:[\p{L}\p{N}-]+\.)+[\p{L}]{2,}$/u.test(clean))) break;
      if (stops.has(fold)) break;
      if (index > 0 && !connector && /^[a-zà-ÿ]/.test(clean) && !["corp", "inc", "ltd", "co"].includes(fold)) break;
      if (index === 0 && /^oferecimento$/i.test(marker) && /^[a-zà-ÿ]/.test(clean)) break;
      end = start + (words[index].index ?? 0) + clean.length;
      accepted++;
      if (clean !== token) break;
    }
    const value2 = text2.slice(start, end);
    return accepted && /[\p{L}]/u.test(value2) ? { start, end } : void 0;
  }
  function safeUrl(raw) {
    try {
      const url = new URL(raw);
      if (!["http:", "https:"].includes(url.protocol) || url.username || url.password || !url.hostname || raw.length > 2e3) return void 0;
      for (const key of url.searchParams.keys()) if (/token|api.?key|secret|password|authorization|signature|credential|session|^auth$|^sig$|^jwt$|^bearer$|^x-amz-/i.test(key)) return void 0;
      if (/(?:token|api.?key|secret|password|authorization|signature|credential|session|auth)=/i.test(url.hash)) return void 0;
      return url.href;
    } catch {
      return void 0;
    }
  }
  function urlEnd(raw) {
    let value2 = raw.replace(/[.,;:!?]+$/, "");
    for (const [open, close] of [["(", ")"], ["[", "]"], ["{", "}"]]) while (value2.endsWith(close) && value2.split(close).length > value2.split(open).length) value2 = value2.slice(0, -1);
    return value2;
  }
  function sentence(text2, offset) {
    let start = offset, end = offset;
    while (start > 0 && !/[.!?\r\n]/.test(text2[start - 1]) && offset - start < 500) start--;
    while (end < text2.length && !/[.!?\r\n]/.test(text2[end]) && end - offset < 500) end++;
    if (/[.!?]/.test(text2[end] ?? "")) end++;
    while (start < end && /\s/.test(text2[start])) start++;
    while (end > start && /\s/.test(text2[end - 1])) end--;
    return { start, end };
  }
  function extractSponsorships(input) {
    guardApi(input);
    const text2 = plain3(input).text;
    if (typeof text2 !== "string" || !text2.trim()) throw new Error("Cole texto real para examinar as evid\xEAncias de divulga\xE7\xE3o.");
    if (text2.length > MAX_TEXT) throw new Error("O texto excede o limite de 100 mil caracteres; ele n\xE3o foi truncado.");
    const starts = lineStarts(text2), candidates = [], counts = /* @__PURE__ */ new Map(), unsafeSpans = [];
    let serial = 0, truncated = false, ignoredUnsafeLinks = 0;
    const add = (kind, start, end, negative = false) => {
      const count2 = counts.get(kind) ?? 0;
      if (count2 >= MAX_EVIDENCE) {
        truncated = true;
        return void 0;
      }
      counts.set(kind, count2 + 1);
      const key = `candidate-${++serial}`;
      candidates.push({ key, kind, start, end, negated: negative });
      return key;
    };
    const rawMentions = [];
    const markers = /(?<![\p{L}\p{N}_])(?:patrocinad[oa]\s+(?:por|pel[ao]s?)|sponsored\s+by|(?:paid\s+)?partnership\s+with|parceria(?:\s+paga)?\s+com|oferecimento(?:\s+d[aeo])?|brought\s+to\s+you\s+by)(?![\p{L}\p{N}_])/giu;
    for (const match of text2.matchAll(markers)) {
      const negative = negated(text2, match.index), markerKey = add("sponsor-marker", match.index, match.index + match[0].length, negative);
      if (!markerKey) break;
      const brand = negative ? void 0 : brandAfter(text2, match.index + match[0].length, match[0]);
      const brandKey = brand ? add("brand", brand.start, brand.end) : void 0;
      rawMentions.push({ markerKey, brandKey, brandValue: brand ? text2.slice(brand.start, brand.end) : void 0, negated: negative });
    }
    const indicatorPatterns = [["affiliate", /(?<![\p{L}\p{N}_])(?:links?\s+(?:de\s+)?afiliad[oa]s?|affiliate\s+links?|sou\s+afiliad[oa]|I\s+am\s+an?\s+affiliate|#affiliate)(?![\p{L}\p{N}_])/giu], ["disclosure", /(?<![\p{L}\p{N}_])(?:parceria\s+paga|paid\s+partnership|paid\s+promotion|(?:conte[uú]do|v[ií]deo)\s+patrocinad[oa]|#(?:ad|publi|publicidade|an[uú]ncio))(?![\p{L}\p{N}_])/giu]];
    for (const [kind, pattern] of indicatorPatterns) for (const match of text2.matchAll(pattern)) if (!add(kind, match.index, match.index + match[0].length, negated(text2, match.index))) break;
    const couponPattern = /(?<![\p{L}\p{N}_])(?:cupom(?:\s+de\s+desconto)?|c[oó]digo(?:\s+de\s+desconto)?|(?:use|using)\s+(?:the\s+)?code|promo(?:tional)?\s+code|coupon(?:\s+code)?)(?![\p{L}\p{N}_])/giu;
    const couponStops = /* @__PURE__ */ new Set(["PARA", "DE", "DESCONTO", "EXEMPLO", "NO", "NA", "EM", "USE", "LINK", "ABAIXO", "CODIGO", "C\xD3DIGO", "FONTE", "IS", "THE", "AT", "YOUR", "IN", "ON", "FOR", "CODE", "HERE", "NONE"]);
    for (const match of text2.matchAll(couponPattern)) {
      if (!add("disclosure", match.index, match.index + match[0].length, negated(text2, match.index))) break;
      let start = match.index + match[0].length;
      const spacing = /^[ \t]*(?::|=|\bé\b|\bis\b)?[ \t]*/i.exec(text2.slice(start));
      start += spacing?.[0].length ?? 0;
      const quote = /^["'“‘]/.test(text2[start] ?? "");
      if (quote) start++;
      const code = /^[\p{L}\p{N}_-]{2,40}/u.exec(text2.slice(start));
      if (!code || !/[\p{L}]/u.test(code[0]) || couponStops.has(code[0].toUpperCase()) || !quote && !/^[A-Z\d_-]+$/.test(code[0]) && !/\d/.test(code[0]) || /[\p{L}\p{N}_-]/u.test(text2[start + code[0].length] ?? "")) continue;
      add("coupon-code", start, start + code[0].length, negated(text2, match.index));
    }
    const urls = /* @__PURE__ */ new Map();
    for (const match of text2.matchAll(/https?:\/\/[^\s<>"'`]+/gi)) {
      const raw = urlEnd(match[0]), prefix = text2.slice(Math.max(0, match.index - 200), match.index), previous = text2[match.index - 1] ?? "";
      const value2 = /[\p{L}\p{N}:+.-]/u.test(previous) || /(?:javascript|data|file):[^\s]*$/i.test(prefix) ? void 0 : safeUrl(raw);
      if (!value2) {
        ignoredUnsafeLinks++;
        unsafeSpans.push({ start: match.index, end: match.index + raw.length });
        continue;
      }
      const key = add("url", match.index, match.index + raw.length);
      if (!key) break;
      urls.set(key, value2);
    }
    candidates.sort((a, b) => a.start - b.start || a.end - b.end || a.kind.localeCompare(b.kind));
    if (candidates.length > MAX_EVIDENCE) truncated = true;
    const chosen = candidates.slice(0, MAX_EVIDENCE);
    const evidence = chosen.map((candidate, index) => ({ id: `evidence-${index + 1}`, kind: candidate.kind, quote: text2.slice(candidate.start, candidate.end), start: candidate.start, end: candidate.end, ...location2(starts, candidate.start), negated: candidate.negated })), byKey = new Map(chosen.map((candidate, index) => [candidate.key, evidence[index]]));
    const brands = [], coupons = [], links = [], indicators = [], sponsorMentions = [];
    const brandMap = /* @__PURE__ */ new Map();
    const attach = (entity, ids) => {
      for (const id of ids) if (!entity.evidenceIds.includes(id)) entity.evidenceIds.push(id);
    };
    for (const mention of rawMentions) {
      const marker = byKey.get(mention.markerKey);
      if (!marker) continue;
      const name = mention.brandKey ? byKey.get(mention.brandKey) : void 0;
      let brand;
      if (name && mention.brandValue && !mention.negated) {
        const key = normalized(mention.brandValue);
        brand = brandMap.get(key);
        if (!brand) {
          brand = { id: `brand-${brands.length + 1}`, value: mention.brandValue, evidenceIds: [] };
          brandMap.set(key, brand);
          brands.push(brand);
        }
        attach(brand, [marker.id, name.id]);
      }
      sponsorMentions.push({ evidenceId: marker.id, brandId: brand?.id ?? null, brandState: mention.negated ? "negated" : brand ? "literal-name" : "unknown" });
    }
    const couponMap = /* @__PURE__ */ new Map(), indicatorMap = /* @__PURE__ */ new Map(), linkMap = /* @__PURE__ */ new Map();
    for (const [index, candidate] of chosen.entries()) {
      const proof = evidence[index];
      if (proof.kind === "coupon-code" && !proof.negated) {
        let entity = couponMap.get(proof.quote);
        if (!entity) {
          entity = { id: `coupon-${coupons.length + 1}`, value: proof.quote, evidenceIds: [] };
          couponMap.set(proof.quote, entity);
          coupons.push(entity);
        }
        attach(entity, [proof.id]);
      }
      if (proof.kind === "affiliate" || proof.kind === "disclosure") {
        const key = `${proof.kind}:${proof.negated}:${normalized(proof.quote)}`;
        let entity = indicatorMap.get(key);
        if (!entity) {
          entity = { id: `indicator-${indicators.length + 1}`, value: proof.quote, kind: proof.kind, negated: proof.negated, evidenceIds: [] };
          indicatorMap.set(key, entity);
          indicators.push(entity);
        }
        attach(entity, [proof.id]);
      }
      if (proof.kind === "url") {
        const url = urls.get(candidate.key);
        let entity = linkMap.get(url);
        if (!entity) {
          entity = { id: `link-${links.length + 1}`, value: url, url, evidenceIds: [], contextBrandIds: [], contextEvidenceIds: [], contextBasis: "unattributed" };
          linkMap.set(url, entity);
          links.push(entity);
        }
        attach(entity, [proof.id]);
        for (const mention of sponsorMentions) {
          const marker = evidence.find((item) => item.id === mention.evidenceId);
          if (mention.brandId && marker.line === proof.line && Math.abs(marker.end - proof.start) <= 180) {
            entity.contextBasis = "same-line-text";
            if (!entity.contextBrandIds.includes(mention.brandId)) entity.contextBrandIds.push(mention.brandId);
            if (!entity.contextEvidenceIds.includes(marker.id)) entity.contextEvidenceIds.push(marker.id);
          }
        }
      }
    }
    const mentionMap = /* @__PURE__ */ new Map();
    for (const proof of evidence) if (!["brand", "url"].includes(proof.kind)) {
      let span = sentence(text2, proof.start);
      if (unsafeSpans.some((unsafe) => unsafe.start < span.end && unsafe.end > span.start)) span = { start: proof.start, end: proof.end };
      const key = `${span.start}:${span.end}`;
      let mention = mentionMap.get(key);
      if (!mention) {
        mention = { excerpt: text2.slice(span.start, span.end), ...span, line: location2(starts, span.start).line, evidenceIds: [] };
        mentionMap.set(key, mention);
      }
      if (!mention.evidenceIds.includes(proof.id)) mention.evidenceIds.push(proof.id);
    }
    const warnings = [];
    if (truncated) warnings.push("Limite de 200 evid\xEAncias atingido; resultados posteriores podem ter sido omitidos.");
    if (ignoredUnsafeLinks) warnings.push(`${ignoredUnsafeLinks} links com formato inseguro, credenciais ou par\xE2metros sens\xEDveis foram omitidos.`);
    return { version: 1, source: "literal-text-evidence", inputSource: ["youtube-dom", "public-page", "user-provided"].includes(String(input.source)) ? String(input.source) : "unspecified", inputCharacters: text2.length, evidence, brands, coupons, links, indicators, sponsorMentions, mentions: [...mentionMap.values()].slice(0, MAX_EVIDENCE), estimatedRevenue: null, truncated, ignoredUnsafeLinks, limitations: ["Somente marcadores e nomes literais no texto fornecido; n\xE3o comprova patroc\xEDnio, contrato, afilia\xE7\xE3o ou receita.", "Marca desconhecida permanece desconhecida. Dom\xEDnios n\xE3o s\xE3o usados para adivinhar marcas.", "Contexto de link na mesma linha \xE9 uma refer\xEAncia textual para revis\xE3o, n\xE3o prova de propriedade ou rela\xE7\xE3o comercial.", "Links n\xE3o s\xE3o abertos e nenhum servi\xE7o remoto \xE9 consultado. N\xE3o estima valores de contratos.", "\xCDndices start/end usam [in\xEDcio,fim) em unidades UTF-16 do texto original; linhas e colunas come\xE7am em 1."], warnings };
  }
  function sponsorshipRows(report) {
    return report.evidence.map((proof) => ({ id: proof.id, kind: proof.kind, line: proof.line, column: proof.column, start: proof.start, end: proof.end, quote: proof.quote, negated: proof.negated, brands: report.brands.filter((entity) => entity.evidenceIds.includes(proof.id)).map((entity) => entity.value).join("; "), coupons: report.coupons.filter((entity) => entity.evidenceIds.includes(proof.id)).map((entity) => entity.value).join("; "), links: report.links.filter((entity) => entity.evidenceIds.includes(proof.id)).map((entity) => entity.url).join("; ") }));
  }
  function sponsorshipMarkdown(report) {
    const lines3 = ["# Evid\xEAncias textuais de divulga\xE7\xE3o", "", `Origem declarada: ${JSON.stringify(report.inputSource)}`, `Texto: ${report.inputCharacters} unidades UTF-16. Receita estimada: desconhecida.`, ...report.limitations.map((value2) => `- ${value2}`), ""];
    for (const proof of report.evidence) {
      const fence = "`".repeat(Math.max(3, ...[...proof.quote.matchAll(/`+/g)].map((match) => match[0].length + 1)));
      lines3.push(`## ${proof.id} \xB7 ${proof.kind}`, `Linha ${proof.line}, coluna ${proof.column}; intervalo [${proof.start}, ${proof.end}). Nega\xE7\xE3o literal: ${proof.negated ? "sim" : "n\xE3o"}.`, "", `${fence}text`, proof.quote, fence, "");
    }
    return lines3.join("\n");
  }

  // src/ui/sponsorships.ts
  function initSponsorshipTools() {
    const section = document.getElementById("sponsorships");
    if (!section || section.dataset.sponsorReady) return;
    section.dataset.sponsorReady = "true";
    section.innerHTML = `<div class="card"><span class="eyebrow">LEITURA LOCAL DE TEXTO</span><h2>Evid\xEAncias de divulga\xE7\xE3o</h2><p>Cole uma descri\xE7\xE3o ou transcri\xE7\xE3o para localizar marcadores, nomes literais, cupons e links. Cada resultado preserva o trecho e sua posi\xE7\xE3o no original. Isso n\xE3o comprova patroc\xEDnio, contrato, afilia\xE7\xE3o ou receita.</p>
  <label>Origem declarada<select id="sponsor-source"><option value="user-provided">Texto fornecido por mim</option><option value="youtube-dom">Texto observado na p\xE1gina</option><option value="public-page">Texto de uma p\xE1gina p\xFAblica</option><option value="youtube-data-api">Dados da API oficial (n\xE3o permitido nesta an\xE1lise)</option></select></label>
  <label>Descri\xE7\xE3o ou transcri\xE7\xE3o original<textarea id="sponsor-text" rows="9" maxlength="100000" placeholder="Cole o texto real para analisar. Nenhum conte\xFAdo \xE9 enviado a servidores."></textarea></label>
  <div class="row"><button id="sponsor-analyze" class="primary">Analisar texto localmente</button><button id="sponsor-clear">Limpar texto e resultados</button></div><p id="sponsor-status" role="status" aria-live="polite">Cole at\xE9 100 mil caracteres e clique em Analisar. N\xE3o h\xE1 consulta autom\xE1tica, abertura de links ou estimativa financeira.</p>
  <div class="row"><button id="sponsor-export-json" disabled>Exportar JSON</button><button id="sponsor-export-csv" disabled>Exportar CSV</button><button id="sponsor-export-markdown" disabled>Exportar Markdown</button></div></div>
  <div id="sponsor-result" hidden><div class="grid two"><div class="card"><h3>Marcas nomeadas no texto</h3><ul id="sponsor-brands"></ul><h3>Marca desconhecida ou nega\xE7\xE3o literal</h3><ul id="sponsor-unknown"></ul></div><div class="card"><h3>Cupons expl\xEDcitos</h3><ul id="sponsor-coupons"></ul><h3>Indicadores de divulga\xE7\xE3o e afilia\xE7\xE3o</h3><ul id="sponsor-indicators"></ul></div></div>
  <div class="card"><h3>Links presentes no texto</h3><p>N\xE3o s\xE3o abertos automaticamente. Uma refer\xEAncia na mesma linha s\xF3 indica contexto para revis\xE3o; n\xE3o comprova que o link pertence \xE0 marca.</p><ul id="sponsor-links"></ul></div>
  <div class="card"><h3>Evid\xEAncias originais</h3><p>Linhas e colunas come\xE7am em 1. Os intervalos [in\xEDcio, fim) usam \xEDndices UTF-16 do texto colado.</p><div class="table-wrap"><table><thead><tr><th>Tipo literal</th><th>Trecho exato</th><th>Linha / coluna</th><th>Intervalo</th><th>Nega\xE7\xE3o</th></tr></thead><tbody id="sponsor-evidence"></tbody></table></div></div><div class="card"><h3>Limites desta leitura</h3><ul id="sponsor-limits"></ul></div></div>`;
    const get = (id) => section.querySelector(`#sponsor-${id}`);
    const text2 = get("text"), source = get("source"), status = get("status"), result = get("result"), exports = ["json", "csv", "markdown"].map((format) => get(`export-${format}`));
    let report;
    const invalidate = (message) => {
      report = void 0;
      result.hidden = true;
      exports.forEach((button) => {
        button.disabled = true;
      });
      for (const id of ["brands", "unknown", "coupons", "indicators", "links", "evidence", "limits"]) get(id).replaceChildren();
      status.textContent = message;
      status.classList.remove("error");
    };
    const listItem = (id, value2) => {
      const li = document.createElement("li");
      li.textContent = value2;
      get(id).append(li);
      return li;
    };
    const labels2 = { "sponsor-marker": "Marcador de patroc\xEDnio/parceria", "brand": "Nome literal", "coupon-code": "C\xF3digo expl\xEDcito", "affiliate": "Indicador de afilia\xE7\xE3o", "disclosure": "Indicador de divulga\xE7\xE3o", "url": "Link expl\xEDcito" };
    get("analyze").addEventListener("click", () => {
      invalidate("Analisando o texto localmente\u2026");
      try {
        report = extractSponsorships({ text: text2.value, source: source.value });
        for (const entity of report.brands) listItem("brands", `${entity.value} \xB7 ${entity.evidenceIds.join(", ")}`);
        if (!report.brands.length) listItem("brands", "Nenhuma marca literal reconhecida. Isso n\xE3o demonstra aus\xEAncia de patroc\xEDnio.");
        for (const mention of report.sponsorMentions.filter((item) => item.brandState !== "literal-name")) listItem("unknown", `${mention.brandState === "negated" ? "Nega\xE7\xE3o literal; n\xE3o tratada como patroc\xEDnio confirmado" : "Marca desconhecida; n\xE3o foi inferida por dom\xEDnio"} \xB7 ${mention.evidenceId}`);
        if (!report.sponsorMentions.some((item) => item.brandState !== "literal-name")) listItem("unknown", "Nenhum marcador com marca desconhecida ou nega\xE7\xE3o foi reconhecido.");
        for (const entity of report.coupons) listItem("coupons", `${entity.value} \xB7 ${entity.evidenceIds.join(", ")}`);
        if (!report.coupons.length) listItem("coupons", "Nenhum c\xF3digo expl\xEDcito reconhecido.");
        for (const entity of report.indicators) listItem("indicators", `${entity.value}${entity.negated ? " \xB7 nega\xE7\xE3o literal" : ""} \xB7 ${entity.evidenceIds.join(", ")}`);
        if (!report.indicators.length) listItem("indicators", "Nenhum indicador literal reconhecido.");
        for (const entity of report.links) {
          const li = listItem("links", ""), anchor = document.createElement("a");
          anchor.href = entity.url;
          anchor.target = "_blank";
          anchor.rel = "noopener noreferrer";
          anchor.textContent = entity.url;
          li.append(anchor);
          const context = entity.contextBrandIds.map((id) => report.brands.find((brand) => brand.id === id)?.value).filter(Boolean);
          li.append(document.createTextNode(` \xB7 ${entity.evidenceIds.join(", ")} \xB7 ${context.length ? `contexto na mesma linha: ${context.join(", ")} (revisar)` : "sem marca atribu\xEDda"}`));
        }
        if (!report.links.length) listItem("links", "Nenhum link HTTP/HTTPS seguro foi reconhecido.");
        for (const proof of report.evidence) {
          const row3 = document.createElement("tr");
          for (const value2 of [labels2[proof.kind] ?? proof.kind, proof.quote, `${proof.line} / ${proof.column}`, `[${proof.start}, ${proof.end})`, proof.negated ? "Literal negativa" : "N\xE3o reconhecida"]) {
            const cell = document.createElement("td");
            cell.textContent = value2;
            row3.append(cell);
          }
          get("evidence").append(row3);
        }
        for (const value2 of [...report.limitations, ...report.warnings]) listItem("limits", value2);
        result.hidden = false;
        exports.forEach((button) => {
          button.disabled = false;
        });
        status.textContent = `Leitura local conclu\xEDda: ${report.evidence.length} evid\xEAncias textuais. Receita e valores de contrato permanecem desconhecidos.`;
      } catch (error) {
        invalidate(error instanceof Error ? error.message : "N\xE3o foi poss\xEDvel analisar o texto.");
        status.classList.add("error");
      }
    });
    text2.addEventListener("input", () => invalidate("O texto mudou. Analise novamente para manter os trechos e posi\xE7\xF5es consistentes."));
    source.addEventListener("change", () => invalidate("A origem mudou. Analise novamente."));
    get("clear").addEventListener("click", () => {
      text2.value = "";
      invalidate("Texto e resultados removidos desta visualiza\xE7\xE3o.");
    });
    exports.forEach((button, index) => button.addEventListener("click", () => {
      if (!report) return;
      const format = ["json", "csv", "markdown"][index], content = format === "json" ? JSON.stringify(report, null, 2) : format === "csv" ? toCsv(sponsorshipRows(report)) : sponsorshipMarkdown(report), mime = format === "json" ? "application/json" : format === "csv" ? "text/csv;charset=utf-8" : "text/markdown;charset=utf-8";
      downloadBlob(new Blob([content], { type: mime }), `prevlev-sponsorship-evidence.${format === "markdown" ? "md" : format}`);
    }));
  }

  // src/ui/collection.ts
  function initCollectionTools(deps) {
    const parent = document.getElementById("research");
    if (!parent) return;
    const section = document.createElement("div");
    section.className = "card";
    section.id = "collection-tools";
    section.innerHTML = `<h2>Coleta assistida por rolagem</h2><p>Carrega apenas o que a interface nativa disponibilizar durante esta a\xE7\xE3o. A coleta tem limites e n\xE3o confirma que o cat\xE1logo ou os coment\xE1rios est\xE3o completos.</p><div class="form-grid"><label>Itens<select id="collection-kind"><option value="videos">V\xEDdeos</option><option value="comments">Coment\xE1rios</option></select></label><label>M\xE1ximo de itens<input id="collection-max" type="number" min="1" max="500" value="100"></label><label>M\xE1ximo de rolagens<input id="collection-steps" type="number" min="1" max="30" value="10"></label><label>Prazo (segundos)<input id="collection-timeout" type="number" min="1" max="60" value="30"></label></div><div class="actions"><button id="collection-start">Iniciar coleta limitada</button><button id="collection-cancel" disabled>Cancelar coleta</button><button id="collection-use" disabled>Usar esta coleta no painel</button></div><p id="collection-status" role="status" aria-live="polite">Nenhuma coleta assistida iniciada.</p>`;
    parent.append(section);
    const get = (id) => section.querySelector(`#collection-${id}`);
    let active, pending, timer, epoch = 0, starting = false;
    const status = (text2) => {
      get("status").textContent = text2;
    };
    const controls = () => {
      get("start").disabled = starting || !!active;
      get("cancel").disabled = !active;
      get("use").disabled = !pending;
      for (const id of ["kind", "max", "steps", "timeout"]) get(id).disabled = starting || !!active;
    };
    const stopTimer = () => {
      if (timer) clearTimeout(timer);
      timer = void 0;
    };
    async function send(tabId, message) {
      const reply = await chrome.tabs.sendMessage(tabId, message);
      if (!reply || reply.status !== "ok") throw new Error(reply?.error ?? "A aba n\xE3o reconheceu a coleta. Recarregue-a ap\xF3s atualizar a extens\xE3o.");
      return reply;
    }
    function progress(reply) {
      const p = reply.collection;
      if (!p || typeof p.jobId !== "string" || !["running", "completed", "stopped", "cancelled", "error", "idle"].includes(p.phase) || !Number.isInteger(p.collectedCount) || !Number.isInteger(p.steps)) throw new Error("A aba retornou progresso incompat\xEDvel.");
      return p;
    }
    async function cancel(reason = "Cancelamento solicitado. A coleta parcial ficar\xE1 dispon\xEDvel quando a aba confirmar.") {
      const job = active;
      if (!job) return;
      stopTimer();
      try {
        const reply = await send(job.tabId, { type: "CANCEL_COLLECTION", jobId: job.jobId });
        if (active?.epoch !== job.epoch) return;
        status(reason);
        await poll(job, reply);
      } catch (error) {
        active = void 0;
        controls();
        deps.notice(error instanceof Error ? error.message : String(error), true);
      }
    }
    async function poll(job, initial) {
      if (active?.epoch !== job.epoch) return;
      try {
        let reply = initial ?? await send(job.tabId, { type: "COLLECTION_STATUS", jobId: job.jobId, includeResults: true });
        if (active?.epoch !== job.epoch) return;
        const p = progress(reply);
        if (p.jobId !== job.jobId || p.url !== job.url || p.videoId !== job.videoId) throw new Error("O contexto da coleta mudou. O resultado n\xE3o foi aplicado.");
        status(`${p.collectedCount}/${p.maxItems} itens \xB7 ${p.steps}/${p.maxSteps} rolagens \xB7 ${p.phase}${p.reason ? ` \xB7 ${p.reason}` : ""}`);
        if (p.phase !== "running" && !reply.snapshot && p.collectedCount > 0) {
          reply = await send(job.tabId, { type: "COLLECTION_STATUS", jobId: job.jobId, includeResults: true });
          if (active?.epoch !== job.epoch) return;
        }
        if (p.phase === "running") {
          if (Date.now() > job.deadline) {
            await cancel("Prazo do painel atingido; cancelamento solicitado \xE0 aba.");
            return;
          }
          timer = setTimeout(() => {
            void poll(job);
          }, 400);
          return;
        }
        active = void 0;
        stopTimer();
        if (job.adoptable && reply.snapshot && p.collectedCount > 0 && reply.snapshot.url === job.url && reply.snapshot.videoId === job.videoId) {
          pending = reply.snapshot;
          status(`${get("status").textContent} \xB7 Coleta parcial/pr\xF3pria; clique em Usar para atualizar o painel.`);
        }
        controls();
      } catch (error) {
        active = void 0;
        stopTimer();
        controls();
        deps.notice(error instanceof Error ? error.message : String(error), true);
      }
    }
    get("start").addEventListener("click", () => {
      if (active || starting) return;
      void (async () => {
        const maxItems = Number(get("max").value), maxSteps = Number(get("steps").value), timeoutMs = Number(get("timeout").value) * 1e3, kind = get("kind").value;
        if (!Number.isInteger(maxItems) || maxItems < 1 || maxItems > 500 || !Number.isInteger(maxSteps) || maxSteps < 1 || maxSteps > 30 || !Number.isInteger(timeoutMs) || timeoutMs < 1e3 || timeoutMs > 6e4 || !["videos", "comments"].includes(kind)) throw new Error("Informe limites v\xE1lidos: at\xE9 500 itens, 30 rolagens e 60 segundos.");
        const tabId = deps.targetTab();
        starting = true;
        pending = void 0;
        controls();
        status("Iniciando a\xE7\xE3o expl\xEDcita na aba selecionada\u2026");
        const reply = await send(tabId, { type: "START_COLLECTION", kind, maxItems, maxSteps, timeoutMs }), p = progress(reply);
        starting = false;
        active = { tabId, jobId: p.jobId, kind: p.kind, url: p.url, videoId: p.videoId, epoch: ++epoch, deadline: Date.now() + timeoutMs + 5e3, adoptable: true };
        controls();
        await poll(active, reply);
      })().catch((error) => {
        starting = false;
        controls();
        deps.notice(error instanceof Error ? error.message : String(error), true);
      });
    });
    get("cancel").addEventListener("click", () => {
      void cancel();
    });
    get("use").addEventListener("click", () => {
      void (async () => {
        if (!pending) return;
        const next = pending, current = deps.snapshot();
        if (current.url === next.url && current.videoId === next.videoId) {
          const videos = new Map(current.videos.map((v) => [v.id, v])), comments = new Map(current.comments.map((c) => [c.id, c]));
          for (const v of next.videos) videos.set(v.id, v);
          for (const c of next.comments) comments.set(c.id, c);
          await deps.adopt({ ...current, ...next, videos: [...videos.values()], comments: [...comments.values()] });
        } else await deps.adopt(next);
        pending = void 0;
        controls();
        deps.notice("Coleta assistida aplicada ao painel. Campos ausentes permanecem desconhecidos.");
      })().catch((error) => deps.notice(error instanceof Error ? error.message : String(error), true));
    });
    document.getElementById("tab-select")?.addEventListener("change", () => {
      pending = void 0;
      controls();
      if (active) {
        active.adoptable = false;
        void cancel("A sele\xE7\xE3o de aba mudou; a coleta anterior foi cancelada e n\xE3o ser\xE1 aplicada.");
      }
    });
    window.addEventListener("pagehide", () => {
      stopTimer();
      if (active) void chrome.tabs.sendMessage(active.tabId, { type: "CANCEL_COLLECTION", jobId: active.jobId }).catch(() => {
      });
      active = void 0;
    });
    controls();
  }

  // src/core/niche.ts
  var DEFAULT_NICHE_THRESHOLDS = { viralViews: 1e5, smallSubs: 1e4, mediumSubs: 1e5, newDays: 90, recentDays: 7, outlier: 5, vph: 1e3, channelViews: 1e6, channelVideos: 10 };
  var day = 864e5;
  var known2 = (value2) => value2 !== void 0 && Number.isFinite(value2) && value2 >= 0 ? value2 : void 0;
  function buildNicheReport(input, options = {}) {
    const now2 = options.now ?? Date.now();
    if (!Number.isFinite(now2) || Math.abs(now2) > 864e13) throw new Error("Instante atual inv\xE1lido.");
    const thresholds = { ...DEFAULT_NICHE_THRESHOLDS, ...options.thresholds };
    if (Object.values(thresholds).some((value2) => !Number.isFinite(value2) || value2 < 0) || !Number.isInteger(thresholds.channelVideos) || thresholds.mediumSubs < thresholds.smallSubs) throw new Error("Limiares devem ser n\xE3o negativos; inscritos m\xE9dios devem ser ao menos os inscritos pequenos e quantidade de v\xEDdeos deve ser inteira.");
    const preset = options.preset ?? "all", period = options.period ?? "all", duration = options.duration ?? "all", channels = options.channels ?? [];
    if (!["all", "viral-small", "medium", "new", "recent", "500k", "1m", "high-outlier", "high-vph", "manyviews-fewvideos"].includes(preset) || !["all", "week", "month", "3m", "year"].includes(period) || !["all", "under1", "1to4", "4to10", "10to20", "20to60", "over60"].includes(duration)) throw new Error("Filtro de nicho inv\xE1lido.");
    const eligible = input.filter((video) => video.source !== "youtube-data-api");
    const baseline = [], indices = /* @__PURE__ */ new Map();
    let duplicates = 0;
    const observed = (video) => video.observedAt?.includes("T") ? knownPublication(video.observedAt, now2) : void 0;
    for (const video of eligible) {
      const index = /^[A-Za-z0-9_-]{1,128}$/.test(video.id) ? indices.get(video.id) : void 0;
      if (index === void 0) {
        if (/^[A-Za-z0-9_-]{1,128}$/.test(video.id)) indices.set(video.id, baseline.length);
        baseline.push(video);
      } else {
        duplicates++;
        const previous = observed(baseline[index]), next = observed(video);
        if (next !== void 0 && (previous === void 0 || next > previous)) baseline[index] = video;
      }
    }
    const identities = groupChannelIdentities(baseline);
    const available = /* @__PURE__ */ new Map();
    const groups = /* @__PURE__ */ new Map();
    for (const video of baseline) {
      const identity = identities.get(video);
      if (identity) {
        available.set(identity.key, identity.label);
        const group = groups.get(identity.key) ?? [];
        group.push(video);
        groups.set(identity.key, group);
      }
    }
    const rows = baseline.map((video) => {
      const views = known2(video.views), subscribers = known2(video.subscribers), published = video.publishedAt ? knownPublication(video.publishedAt, now2) : void 0;
      const comparison = researchComparison(video, baseline);
      const ratio = views !== void 0 && subscribers !== void 0 && subscribers > 0 ? views / subscribers : void 0;
      return { id: video.id, title: video.title, url: video.url, channel: video.channel, channelKey: identities.get(video)?.key, views, subscribers, publishedAt: published === void 0 ? void 0 : new Date(published).toISOString(), durationSeconds: known2(video.durationSeconds), lifetimeVph: lifetimeVph(video, now2), outlier: comparison.score, outlierReferences: comparison.referenceCount, viewsPerSubscriber: ratio !== void 0 && Number.isFinite(ratio) ? ratio : void 0, source: video.source };
    });
    const periodDays = { all: Infinity, week: 7, month: 30, "3m": 90, year: 365 };
    const bounds = { under1: [0, 60], "1to4": [60, 240], "4to10": [240, 600], "10to20": [600, 1200], "20to60": [1200, 3600], over60: [3600, Infinity] };
    const within = (row3, days) => row3.publishedAt !== void 0 && now2 - Date.parse(row3.publishedAt) <= days * day;
    const included = rows.filter((row3) => {
      if (channels.length && (!row3.channelKey || !channels.includes(row3.channelKey))) return false;
      if (period !== "all" && !within(row3, periodDays[period])) return false;
      if (duration !== "all") {
        const [min, max] = bounds[duration];
        if (row3.durationSeconds === void 0 || row3.durationSeconds < min || row3.durationSeconds >= max) return false;
      }
      switch (preset) {
        case "viral-small":
          return row3.views !== void 0 && row3.views >= thresholds.viralViews && row3.subscribers !== void 0 && row3.subscribers <= thresholds.smallSubs;
        case "medium":
          return row3.subscribers !== void 0 && row3.subscribers > thresholds.smallSubs && row3.subscribers <= thresholds.mediumSubs;
        case "new":
          return within(row3, thresholds.newDays);
        case "recent":
          return within(row3, thresholds.recentDays);
        case "500k":
          return row3.views !== void 0 && row3.views >= 5e5;
        case "1m":
          return row3.views !== void 0 && row3.views >= 1e6;
        case "high-outlier":
          return row3.outlier !== void 0 && row3.outlier >= thresholds.outlier;
        case "high-vph":
          return row3.lifetimeVph !== void 0 && row3.lifetimeVph >= thresholds.vph;
        case "manyviews-fewvideos": {
          const group = row3.channelKey ? groups.get(row3.channelKey) : void 0;
          if (!group || group.length > thresholds.channelVideos || group.some((video) => known2(video.views) === void 0)) return false;
          const sum = group.reduce((total2, video) => total2 + video.views, 0);
          return Number.isFinite(sum) && sum >= thresholds.channelViews;
        }
        default:
          return true;
      }
    });
    const coverage2 = {};
    for (const [name, predicate] of Object.entries({ views: (r) => r.views !== void 0, subscribers: (r) => r.subscribers !== void 0, publicationDate: (r) => r.publishedAt !== void 0, duration: (r) => r.durationSeconds !== void 0, channel: (r) => r.channelKey !== void 0, vph: (r) => r.lifetimeVph !== void 0, outlier: (r) => r.outlier !== void 0, viewsPerSubscriber: (r) => r.viewsPerSubscriber !== void 0 })) {
      const count2 = included.filter(predicate).length;
      coverage2[name] = { known: count2, unknown: included.length - count2 };
    }
    const byChannel = /* @__PURE__ */ new Map();
    for (const row3 of included) if (row3.channelKey) {
      const group = byChannel.get(row3.channelKey) ?? [];
      group.push(row3);
      byChannel.set(row3.channelKey, group);
    }
    const channelReports = [...byChannel].map(([key, group]) => {
      const months = /* @__PURE__ */ new Map();
      for (const row3 of group) if (row3.publishedAt) {
        const month = row3.publishedAt.slice(0, 7);
        months.set(month, (months.get(month) ?? 0) + 1);
      }
      const knownDates = group.filter((row3) => row3.publishedAt !== void 0).length;
      const viewValues = group.flatMap((row3) => row3.views === void 0 ? [] : [row3.views]);
      const subValues = group.flatMap((row3) => row3.subscribers === void 0 ? [] : [row3.subscribers]);
      const sumViews = viewValues.reduce((sum, value2) => sum + value2, 0);
      return { key, label: available.get(key) ?? key, videoCount: group.length, knownViews: viewValues.length, unknownViews: group.length - viewValues.length, totalViews: viewValues.length && Number.isFinite(sumViews) ? sumViews : void 0, knownSubscribers: subValues.length, unknownSubscribers: group.length - subValues.length, minSubscribers: subValues.length ? subValues.reduce((minimum, value2) => Math.min(minimum, value2)) : void 0, maxSubscribers: subValues.length ? subValues.reduce((maximum, value2) => Math.max(maximum, value2)) : void 0, knownDates, unknownDates: group.length - knownDates, uploads30: group.filter((row3) => within(row3, 30)).length, uploads90: group.filter((row3) => within(row3, 90)).length, uploads365: group.filter((row3) => within(row3, 365)).length, months: [...months].sort(([a], [b]) => a.localeCompare(b)).map(([month, count2]) => ({ month, count: count2 })) };
    }).sort((a, b) => a.label.localeCompare(b.label) || a.key.localeCompare(b.key));
    return { generatedAt: new Date(now2).toISOString(), options: { preset, period, duration, channels, thresholds }, scope: { input: input.length, excludedApi: input.length - eligible.length, duplicates, eligible: baseline.length, included: included.length }, availableChannels: [...available].map(([key, label]) => ({ key, label })).sort((a, b) => a.label.localeCompare(b.label) || a.key.localeCompare(b.key)), coverage: coverage2, distribution: { atLeast2: included.filter((row3) => row3.outlier !== void 0 && row3.outlier >= 2).length, atLeast5: included.filter((row3) => row3.outlier !== void 0 && row3.outlier >= 5).length, known: coverage2.outlier.known, unknown: coverage2.outlier.unknown }, channels: channelReports, videos: included, limitations: ["Somente registros carregados ou fornecidos; n\xE3o \xE9 \xEDndice global nem cat\xE1logo completo.", "Per\xEDodos filtram data de publica\xE7\xE3o; m\xEAs = 30 dias, 3 meses = 90 dias e ano = 365 dias, contados a partir do instante do c\xE1lculo. Contadores de views n\xE3o s\xE3o tr\xE1fego do per\xEDodo.", "Uploads por canal s\xE3o somente publica\xE7\xF5es observadas entre os v\xEDdeos inclu\xEDdos, n\xE3o frequ\xEAncia global; datas ausentes n\xE3o s\xE3o contadas. Meses usam UTC. Views de canal somam apenas contadores conhecidos dos v\xEDdeos inclu\xEDdos; inscritos exibem a faixa de valores observados, sem som\xE1-los.", "Outlier usa mediana da amostra eleg\xEDvel anterior aos filtros, mesmo canal e formato, excluindo o alvo e exigindo tr\xEAs refer\xEAncias; sem refer\xEAncia v\xE1lida permanece desconhecido. VPH \xE9 m\xE9dia desde publica\xE7\xE3o.", "Views por inscrito usa contador conhecido de views e denominador conhecido maior que zero; n\xE3o \xE9 taxa de convers\xE3o.", "Duplicatas por ID conservam registro inteiro com observedAt v\xE1lido mais recente, ou o primeiro em empate/aus\xEAncia. Registros da API oficial s\xE3o exclu\xEDdos antes de c\xE1lculos e agrupamentos.", "O preset muitas views/poucos v\xEDdeos exige views conhecidas em todos os v\xEDdeos do canal eleg\xEDvel; os limiares s\xE3o configur\xE1veis e descrevem esta amostra."] };
  }
  function nicheRows(report) {
    return report.videos.map((v) => ({ video_id: v.id, title: v.title, url: v.url, channel: v.channel, channel_key: v.channelKey, source: v.source, views: v.views, subscribers: v.subscribers, published_at: v.publishedAt, duration_seconds: v.durationSeconds, lifetime_average_vph: v.lifetimeVph, sample_outlier: v.outlier, outlier_references: v.outlierReferences, views_per_subscriber: v.viewsPerSubscriber }));
  }
  function nicheMarkdown(report) {
    const escape = (text2) => text2.replace(/[\\`*_{}[\]<>#|]/g, "\\$&").replace(/\r?\n/g, " ");
    const value2 = (v) => v === void 0 ? "desconhecido" : String(v);
    return ["# Nicho local Prevlev", "", `Gerado: ${report.generatedAt}; inclu\xEDdos ${report.scope.included}/${report.scope.input}; API exclu\xEDdos: ${report.scope.excludedApi}; duplicatas: ${report.scope.duplicates}.`, `Filtros e limiares: ${escape(JSON.stringify(report.options))}`, "", `Outliers \u22652\xD7: ${report.distribution.atLeast2}; \u22655\xD7: ${report.distribution.atLeast5}; conhecidos: ${report.distribution.known}; desconhecidos: ${report.distribution.unknown}.`, "", "| V\xEDdeo | Canal | Views | Views/inscrito |", "| --- | --- | --- | --- |", ...report.videos.map((v) => `| ${escape(v.title)} | ${escape(v.channel ?? "desconhecido")} | ${value2(v.views)} | ${value2(v.viewsPerSubscriber)} |`), "", "## Publica\xE7\xF5es observadas por canal", ...report.channels.map((c) => `- ${escape(c.label)}: views conhecidas ${value2(c.totalViews)} (${c.knownViews} conhecidos, ${c.unknownViews} desconhecidos), inscritos observados ${value2(c.minSubscribers)}\u2013${value2(c.maxSubscribers)} (${c.knownSubscribers} conhecidos, ${c.unknownSubscribers} desconhecidos); 30d ${c.uploads30}, 90d ${c.uploads90}, 365d ${c.uploads365}; datas desconhecidas ${c.unknownDates}; meses UTC ${c.months.map((m) => `${m.month}: ${m.count}`).join(", ") || "desconhecido"}.`), "", "## Cobertura", ...Object.entries(report.coverage).map(([key, c]) => `- ${key}: ${c.known} conhecidos, ${c.unknown} desconhecidos.`), "", "## Limites", ...report.limitations.map((text2) => `- ${escape(text2)}`), ""].join("\n");
  }

  // src/ui/niche.ts
  var instances = /* @__PURE__ */ new WeakMap();
  function initNicheTools(deps) {
    const section = document.getElementById("niche");
    if (!section) return { invalidate: () => {
    }, reset: () => {
    } };
    const existing = instances.get(section);
    if (existing) return existing;
    section.dataset.nicheReady = "true";
    section.innerHTML = `<div class="card"><span class="eyebrow">AMOSTRA LOCAL CARREGADA</span><h2>Explorador de nicho</h2>
    <p>A an\xE1lise usa apenas v\xEDdeos carregados ou fornecidos, sem registros da API oficial. Atualize ap\xF3s alterar a cole\xE7\xE3o ou os filtros.</p>
    <div class="row"><label>Preset<select id="niche-preset"><option value="all">Todos</option><option value="viral-small">Viral em canal pequeno</option><option value="medium">Canal m\xE9dio</option><option value="new">Novos</option><option value="recent">Recentes</option><option value="500k">500 mil views ou mais</option><option value="1m">1 milh\xE3o de views ou mais</option><option value="high-outlier">Alto outlier</option><option value="high-vph">Alto VPH hist\xF3rico</option><option value="manyviews-fewvideos">Muitas views, poucos v\xEDdeos</option></select></label>
    <label>Publica\xE7\xE3o<select id="niche-period"><option value="all">Todo o per\xEDodo</option><option value="week">7 dias</option><option value="month">30 dias</option><option value="3m">90 dias</option><option value="year">365 dias</option></select></label>
    <label>Dura\xE7\xE3o<select id="niche-duration"><option value="all">Todas</option><option value="under1">Menos de 1 min</option><option value="1to4">1 a menos de 4 min</option><option value="4to10">4 a menos de 10 min</option><option value="10to20">10 a menos de 20 min</option><option value="20to60">20 a menos de 60 min</option><option value="over60">60 min ou mais</option></select></label></div>
    <details><summary>Limiares configur\xE1veis dos presets</summary><p>Valores locais escolhidos para explora\xE7\xE3o; n\xE3o s\xE3o defini\xE7\xF5es oficiais. Canal m\xE9dio: acima do limite pequeno at\xE9 o limite m\xE9dio, inclusive.</p><div id="niche-thresholds" class="row"></div></details>
    <fieldset><legend>Canais (nenhum selecionado = todos)</legend><div id="niche-channels">Atualize para carregar canais da amostra.</div></fieldset>
    <div class="row"><button id="niche-refresh" class="primary">Atualizar an\xE1lise</button><button id="niche-reset">Redefinir filtros</button><button id="niche-export-json" disabled>Exportar JSON</button><button id="niche-export-csv" disabled>Exportar CSV</button><button id="niche-export-markdown" disabled>Exportar Markdown</button></div><p id="niche-status" role="status" aria-live="polite">Atualize para analisar a cole\xE7\xE3o atual.</p></div>
    <div id="niche-result" hidden><div class="card"><h3>Amostra e distribui\xE7\xE3o</h3><p id="niche-scope"></p><p id="niche-distribution"></p><p>Outlier usa a mediana da amostra eleg\xEDvel anterior aos filtros; VPH \xE9 m\xE9dia desde publica\xE7\xE3o.</p></div>
    <div class="card"><h3>Cobertura dos v\xEDdeos inclu\xEDdos</h3><table><thead><tr><th>Dado</th><th>Conhecidos</th><th>Desconhecidos</th></tr></thead><tbody id="niche-coverage"></tbody></table></div>
    <div class="card"><h3>Publica\xE7\xF5es observadas por canal</h3><p>Contagens da amostra inclu\xEDda, por data de publica\xE7\xE3o, at\xE9 o instante da an\xE1lise. Meses em UTC; datas desconhecidas ficam de fora.</p><div class="table-wrap"><table><thead><tr><th>Canal</th><th>V\xEDdeos</th><th>Views conhecidas / cobertura</th><th>Inscritos observados / cobertura</th><th>30 dias</th><th>90 dias</th><th>365 dias</th><th>Datas desconhecidas</th><th>Meses observados</th></tr></thead><tbody id="niche-timeline"></tbody></table></div></div>
    <div class="card"><h3>V\xEDdeos inclu\xEDdos</h3><div class="table-wrap"><table><thead><tr><th>V\xEDdeo</th><th>Canal</th><th>Views</th><th>Inscritos</th><th>Views/inscrito</th><th>VPH hist\xF3rico</th><th>Outlier</th></tr></thead><tbody id="niche-videos"></tbody></table></div></div><div class="card"><h3>Limites</h3><ul id="niche-limitations"></ul></div></div>`;
    const get = (id) => section.querySelector(`#niche-${id}`);
    const thresholdLabels = { viralViews: "Views m\xEDnimas viral", smallSubs: "Inscritos m\xE1ximos pequeno", mediumSubs: "Inscritos m\xE1ximos m\xE9dio", newDays: "Novos: dias m\xE1ximos", recentDays: "Recentes: dias m\xE1ximos", outlier: "Outlier m\xEDnimo (\xD7)", vph: "VPH hist\xF3rico m\xEDnimo", channelViews: "Views m\xEDnimas do canal na amostra", channelVideos: "V\xEDdeos m\xE1ximos do canal na amostra" };
    for (const key of Object.keys(DEFAULT_NICHE_THRESHOLDS)) {
      const label = document.createElement("label");
      label.textContent = thresholdLabels[key];
      const input = document.createElement("input");
      input.type = "number";
      input.min = "0";
      input.step = key === "channelVideos" ? "1" : "any";
      input.id = `niche-threshold-${key}`;
      input.value = String(DEFAULT_NICHE_THRESHOLDS[key]);
      label.append(input);
      get("thresholds").append(label);
    }
    const exports = ["json", "csv", "markdown"].map((format) => get(`export-${format}`));
    let report;
    const invalidate = () => {
      report = void 0;
      get("result").hidden = true;
      exports.forEach((button) => {
        button.disabled = true;
      });
      for (const id of ["scope", "distribution", "coverage", "timeline", "videos", "limitations"]) get(id).replaceChildren();
      get("status").textContent = "Filtros alterados. Atualize para recalcular.";
    };
    const invalidateSnapshot = () => {
      invalidate();
      get("channels").textContent = "Atualize para carregar canais da amostra.";
      get("status").textContent = "Cole\xE7\xE3o alterada. Atualize para recalcular.";
    };
    section.addEventListener("change", (event) => {
      if (event.target.matches("select, input")) invalidate();
    });
    get("thresholds").addEventListener("input", invalidate);
    const selected = () => [...get("channels").querySelectorAll("input:checked")].map((input) => input.value);
    get("refresh").addEventListener("click", () => {
      try {
        const thresholds = { ...DEFAULT_NICHE_THRESHOLDS };
        for (const key of Object.keys(thresholds)) {
          const input = get(`threshold-${key}`);
          if (!input.value.trim()) throw new Error("Preencha todos os limiares.");
          thresholds[key] = input.valueAsNumber;
        }
        const selectedChannels = selected();
        report = buildNicheReport(deps.snapshot().videos, { preset: get("preset").value, period: get("period").value, duration: get("duration").value, channels: selectedChannels, thresholds });
        const current = report;
        const channelChoices = [...current.availableChannels, ...selectedChannels.filter((key) => !current.availableChannels.some((channel) => channel.key === key)).map((key) => ({ key, label: "Canal indispon\xEDvel na cole\xE7\xE3o atual" }))];
        get("channels").replaceChildren(...channelChoices.map((channel) => {
          const label = document.createElement("label"), input = document.createElement("input");
          input.type = "checkbox";
          input.value = channel.key;
          input.checked = selectedChannels.includes(channel.key);
          label.append(input, document.createTextNode(` ${channel.label} (${channel.key}) `));
          return label;
        }));
        get("scope").textContent = `${current.scope.input} registros \xB7 ${current.scope.excludedApi} da API exclu\xEDdos \xB7 ${current.scope.duplicates} duplicatas exclu\xEDdas \xB7 ${current.scope.eligible} eleg\xEDveis \xB7 ${current.scope.included} inclu\xEDdos.`;
        get("distribution").textContent = `Outliers \u22652\xD7: ${current.distribution.atLeast2}; \u22655\xD7: ${current.distribution.atLeast5}; conhecidos: ${current.distribution.known}; desconhecidos: ${current.distribution.unknown}.`;
        const coverageLabels = { views: "Views", subscribers: "Inscritos", publicationDate: "Publica\xE7\xE3o", duration: "Dura\xE7\xE3o", channel: "Canal", vph: "VPH", outlier: "Outlier", viewsPerSubscriber: "Views/inscrito" };
        get("coverage").replaceChildren(...Object.entries(current.coverage).map(([key, count2]) => row2([coverageLabels[key], String(count2.known), String(count2.unknown)])));
        get("timeline").replaceChildren(...current.channels.map((channel) => row2([channel.label, String(channel.videoCount), `${number3(channel.totalViews)} (${channel.knownViews} conhecidos, ${channel.unknownViews} desconhecidos)`, `${number3(channel.minSubscribers)}\u2013${number3(channel.maxSubscribers)} (${channel.knownSubscribers} conhecidos, ${channel.unknownSubscribers} desconhecidos)`, String(channel.uploads30), String(channel.uploads90), String(channel.uploads365), String(channel.unknownDates), channel.months.map((month) => `${month.month}: ${month.count}`).join(", ") || "desconhecido"])));
        get("videos").replaceChildren(...current.videos.map((video) => row2([video.title, video.channel ?? "desconhecido", number3(video.views), number3(video.subscribers), number3(video.viewsPerSubscriber), number3(video.lifetimeVph), video.outlier === void 0 ? "desconhecido" : `${number3(video.outlier)}\xD7 (${video.outlierReferences} refs)`])));
        get("limitations").replaceChildren(...current.limitations.map((text2) => {
          const li = document.createElement("li");
          li.textContent = text2;
          return li;
        }));
        get("result").hidden = false;
        exports.forEach((button) => {
          button.disabled = false;
        });
        get("status").textContent = `An\xE1lise atualizada: ${current.scope.included} v\xEDdeos inclu\xEDdos.`;
      } catch (error) {
        invalidate();
        get("status").textContent = error instanceof Error ? error.message : "N\xE3o foi poss\xEDvel calcular a an\xE1lise.";
      }
    });
    const reset = () => {
      for (const id of ["preset", "period", "duration"]) get(id).value = "all";
      for (const key of Object.keys(DEFAULT_NICHE_THRESHOLDS)) get(`threshold-${key}`).value = String(DEFAULT_NICHE_THRESHOLDS[key]);
      get("channels").querySelectorAll("input").forEach((input) => {
        input.checked = false;
      });
      invalidate();
    };
    get("reset").addEventListener("click", reset);
    exports.forEach((button, index) => button.addEventListener("click", () => {
      if (!report) return;
      const format = ["json", "csv", "markdown"][index];
      const content = format === "json" ? JSON.stringify(report, null, 2) : format === "csv" ? toCsv(nicheRows(report), ["video_id", "title", "url", "channel", "channel_key", "source", "views", "subscribers", "published_at", "duration_seconds", "lifetime_average_vph", "sample_outlier", "outlier_references", "views_per_subscriber"]) : nicheMarkdown(report);
      downloadBlob(new Blob([content], { type: format === "json" ? "application/json" : format === "csv" ? "text/csv;charset=utf-8" : "text/markdown;charset=utf-8" }), `prevlev-nicho.${format === "markdown" ? "md" : format}`);
    }));
    const tools = { invalidate: invalidateSnapshot, reset };
    instances.set(section, tools);
    return tools;
  }
  function number3(value2) {
    return value2 === void 0 ? "desconhecido" : new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 2 }).format(value2);
  }
  function row2(values) {
    const tr = document.createElement("tr");
    for (const value2 of values) {
      const td = document.createElement("td");
      td.textContent = value2;
      tr.append(td);
    }
    return tr;
  }

  // src/core/visual-similarity.ts
  var VISUAL_LIMITS = { candidates: 20, fileBytes: 10 * 1024 * 1024, totalBytes: 50 * 1024 * 1024, pixels: 2e7, dimension: 16384, durationMs: 15e3 };
  var algorithm = "dHash 64-bit; lumin\xE2ncia; transpar\xEAncia sobre branco";
  var abortError = () => new DOMException("Compara\xE7\xE3o cancelada.", "AbortError");
  var TimeLimit = class extends Error {
    constructor() {
      super("Tempo limite da compara\xE7\xE3o local atingido.");
    }
  };
  function check2(signal, deadline) {
    if (signal?.aborted) throw abortError();
    if (performance.now() >= deadline) throw new TimeLimit();
  }
  function controlled2(promise, signal, deadline, dispose) {
    return new Promise((resolve, reject) => {
      let done = false;
      const cleanup = () => {
        clearTimeout(timer);
        signal?.removeEventListener("abort", onAbort);
      };
      const fail2 = (error) => {
        if (done) return;
        done = true;
        cleanup();
        reject(error);
      };
      const onAbort = () => fail2(abortError());
      const timer = setTimeout(() => fail2(new TimeLimit()), Math.max(0, deadline - performance.now()));
      signal?.addEventListener("abort", onAbort, { once: true });
      if (signal?.aborted) onAbort();
      promise.then((value2) => {
        if (done) {
          dispose?.(value2);
          return;
        }
        done = true;
        cleanup();
        resolve(value2);
      }, (error) => {
        if (!done) {
          done = true;
          cleanup();
          reject(error);
        }
      });
    });
  }
  function hashPixels(data) {
    if (data.length !== 9 * 8 * 4) throw new Error("Pixels inv\xE1lidos para dHash.");
    const brightness = (pixel) => {
      const i = pixel * 4, alpha = data[i + 3] / 255;
      return (0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2]) * alpha + 255 * (1 - alpha);
    };
    let hash = 0n;
    for (let y = 0; y < 8; y++) for (let x = 0; x < 8; x++) hash = hash << 1n | (brightness(y * 9 + x) > brightness(y * 9 + x + 1) ? 1n : 0n);
    return hash.toString(16).padStart(16, "0");
  }
  function hammingDistance(a, b) {
    if (!/^[\da-f]{16}$/i.test(a) || !/^[\da-f]{16}$/i.test(b)) throw new Error("Hash visual inv\xE1lido.");
    let bits = BigInt(`0x${a}`) ^ BigInt(`0x${b}`), distance = 0;
    while (bits) {
      distance++;
      bits &= bits - 1n;
    }
    return distance;
  }
  function validateFile(file) {
    if (!file.size || file.size > VISUAL_LIMITS.fileBytes) throw new Error("Arquivo vazio ou acima de 10 MiB.");
    if (!["image/png", "image/jpeg", "image/webp"].includes(file.type)) throw new Error("Formato n\xE3o suportado: use PNG, JPEG ou WebP est\xE1tico.");
  }
  function validateDimensions2(width, height) {
    if (!width || !height) throw new Error("Dimens\xF5es inv\xE1lidas no cabe\xE7alho da imagem.");
    if (width > VISUAL_LIMITS.dimension || height > VISUAL_LIMITS.dimension || width * height > VISUAL_LIMITS.pixels) throw new Error("Imagem excede 20 megapixels ou 16384 pixels por lado.");
  }
  function inspectImageHeader(buffer, type, checkWork = () => {
  }) {
    const b = new Uint8Array(buffer), view = new DataView(buffer);
    const bad = () => {
      throw new Error("Cabe\xE7alho de imagem inv\xE1lido ou formato incompat\xEDvel.");
    };
    const tag = (offset, text2) => offset + text2.length <= b.length && Array.from(text2).every((c, i) => b[offset + i] === c.charCodeAt(0));
    const bounds = (pos, size) => pos >= 0 && size >= 0 && pos + size <= b.length;
    const u24 = (pos) => b[pos] + b[pos + 1] * 256 + b[pos + 2] * 65536;
    if (type === "image/png") {
      if (b.length < 33 || ![137, 80, 78, 71, 13, 10, 26, 10].every((v, i) => b[i] === v) || view.getUint32(8) !== 13 || !tag(12, "IHDR")) return bad();
      validateDimensions2(view.getUint32(16), view.getUint32(20));
      let offset = 8, ihdr = 0, idat = false, ended = false, iterations = 0;
      while (bounds(offset, 12)) {
        if ((iterations++ & 1023) === 0) checkWork();
        const size = view.getUint32(offset);
        if (!bounds(offset + 8, size + 4)) return bad();
        if (tag(offset + 4, "IHDR") && ++ihdr !== 1) return bad();
        if (tag(offset + 4, "acTL") || tag(offset + 4, "fcTL") || tag(offset + 4, "fdAT")) throw new Error("Imagens animadas n\xE3o s\xE3o suportadas.");
        if (tag(offset + 4, "IDAT")) idat = true;
        offset += size + 12;
        if (tag(offset - size - 8, "IEND")) {
          if (size !== 0) return bad();
          ended = true;
          break;
        }
      }
      if (!ended || !idat || offset !== b.length) return bad();
      return;
    }
    if (type === "image/jpeg") {
      if (b.length < 4 || b[0] !== 255 || b[1] !== 216) return bad();
      let offset = 2, found = false, iterations = 0;
      while (offset < b.length) {
        if ((iterations++ & 1023) === 0) checkWork();
        if (b[offset++] !== 255) return bad();
        while (offset < b.length && b[offset] === 255) offset++;
        if (offset >= b.length) return bad();
        const marker = b[offset++];
        if (marker === 218) {
          if (!found || !bounds(offset, 2) || view.getUint16(offset) < 2 || !bounds(offset, view.getUint16(offset))) return bad();
          return;
        }
        if (marker === 217 || marker === 0 || marker === 216) return bad();
        if (marker === 1 || marker >= 208 && marker <= 215) continue;
        if (!bounds(offset, 2)) return bad();
        const size = view.getUint16(offset);
        if (size < 2 || !bounds(offset, size)) return bad();
        if ([192, 193, 194, 195, 197, 198, 199, 201, 202, 203, 205, 206, 207].includes(marker)) {
          if (found || size < 8) return bad();
          validateDimensions2(view.getUint16(offset + 5), view.getUint16(offset + 3));
          found = true;
        }
        offset += size;
      }
      return bad();
    }
    if (type === "image/webp") {
      if (b.length < 20 || !tag(0, "RIFF") || !tag(8, "WEBP") || view.getUint32(4, true) + 8 !== b.length) return bad();
      let offset = 12, canvasWidth = 0, canvasHeight = 0, imageWidth = 0, imageHeight = 0, extended = false, iterations = 0;
      while (bounds(offset, 8)) {
        if ((iterations++ & 1023) === 0) checkWork();
        const size = view.getUint32(offset + 4, true), pos = offset + 8;
        if (!bounds(pos, size + size % 2)) return bad();
        if (tag(offset, "VP8X")) {
          if (extended || offset !== 12 || size !== 10) return bad();
          extended = true;
          if (b[pos] & 2) throw new Error("Imagens animadas n\xE3o s\xE3o suportadas.");
          canvasWidth = 1 + u24(pos + 4);
          canvasHeight = 1 + u24(pos + 7);
          validateDimensions2(canvasWidth, canvasHeight);
        }
        if (tag(offset, "ANIM") || tag(offset, "ANMF")) throw new Error("Imagens animadas n\xE3o s\xE3o suportadas.");
        if (tag(offset, "VP8 ") || tag(offset, "VP8L")) {
          if (imageWidth) return bad();
          if (tag(offset, "VP8 ")) {
            if (size < 10 || (b[pos] & 1) !== 0 || b[pos + 3] !== 157 || b[pos + 4] !== 1 || b[pos + 5] !== 42) return bad();
            imageWidth = view.getUint16(pos + 6, true) & 16383;
            imageHeight = view.getUint16(pos + 8, true) & 16383;
          } else {
            if (size < 5 || b[pos] !== 47) return bad();
            const packed = view.getUint32(pos + 1, true);
            imageWidth = (packed & 16383) + 1;
            imageHeight = (packed >>> 14 & 16383) + 1;
          }
          validateDimensions2(imageWidth, imageHeight);
        }
        offset = pos + size + size % 2;
      }
      if (offset !== b.length || !imageWidth || extended && (imageWidth !== canvasWidth || imageHeight !== canvasHeight)) return bad();
      return;
    }
    return bad();
  }
  async function inspect(file, signal, deadline) {
    check2(signal, deadline);
    validateFile(file);
    const bytes = await controlled2(file.arrayBuffer(), signal, deadline);
    check2(signal, deadline);
    inspectImageHeader(bytes, file.type, () => check2(signal, deadline));
    check2(signal, deadline);
    const digestBytes = await controlled2(crypto.subtle.digest("SHA-256", bytes), signal, deadline);
    const digest = Array.from(new Uint8Array(digestBytes), (b) => b.toString(16).padStart(2, "0")).join("");
    let bitmap;
    try {
      bitmap = await controlled2(createImageBitmap(new Blob([bytes], { type: file.type })), signal, deadline, (value2) => value2.close());
    } catch (error) {
      if (error instanceof TimeLimit || error instanceof DOMException && error.name === "AbortError") throw error;
      throw new Error("Imagem inv\xE1lida ou n\xE3o decodific\xE1vel.");
    }
    try {
      check2(signal, deadline);
      validateDimensions2(bitmap.width, bitmap.height);
      const canvas = document.createElement("canvas");
      canvas.width = 9;
      canvas.height = 8;
      const context = canvas.getContext("2d");
      if (!context) throw new Error("Canvas 2D indispon\xEDvel.");
      context.fillStyle = "#fff";
      context.fillRect(0, 0, 9, 8);
      context.drawImage(bitmap, 0, 0, 9, 8);
      const hash = hashPixels(context.getImageData(0, 0, 9, 8).data);
      check2(signal, deadline);
      return { hash, digest };
    } finally {
      bitmap.close();
    }
  }
  async function compareLocalImages(reference, candidates, options = {}) {
    const duration = options.durationMs ?? VISUAL_LIMITS.durationMs;
    if (!Number.isFinite(duration) || duration <= 0 || duration > VISUAL_LIMITS.durationMs) throw new Error("Limite de tempo inv\xE1lido.");
    if (!reference || !candidates.length || candidates.length > VISUAL_LIMITS.candidates) throw new Error("Selecione uma refer\xEAncia e de 1 a 20 candidatas locais.");
    if ([reference, ...candidates].reduce((sum, file) => sum + file.size, 0) > VISUAL_LIMITS.totalBytes) throw new Error("Os arquivos somados excedem 50 MiB.");
    const deadline = performance.now() + duration, signal = options.signal;
    const base = await inspect(reference, signal, deadline);
    const seen = /* @__PURE__ */ new Map([[base.digest, `Refer\xEAncia: ${reference.name}`]]), matches = [], invalid2 = [];
    for (let index = 0; index < candidates.length; index++) {
      const file = candidates[index];
      check2(signal, deadline);
      try {
        const item = await inspect(file, signal, deadline), distance = hammingDistance(base.hash, item.hash), duplicateOf = seen.get(item.digest);
        if (!duplicateOf) seen.set(item.digest, file.name);
        matches.push({ index, name: file.name, distance, similarity: (64 - distance) / 64 * 100, hash: item.hash, ...duplicateOf ? { duplicateOf } : {} });
      } catch (error) {
        if (error instanceof TimeLimit || error instanceof DOMException && error.name === "AbortError") throw error;
        invalid2.push({ index, name: file.name, error: error instanceof Error ? error.message : "Falha ao ler imagem." });
      }
    }
    check2(signal, deadline);
    matches.sort((a, b) => a.distance - b.distance || a.index - b.index);
    return { algorithm, reference: reference.name, matches, invalid: invalid2 };
  }
  function visualReportCsv(report) {
    const rows = report.matches.map((m) => ({ referencia: report.reference, arquivo: m.name, estado: "comparado", distancia: m.distance, similaridade_percentual: m.similarity, hash: m.hash, duplicado_de: m.duplicateOf ?? "", erro: "" }));
    rows.push(...report.invalid.map((item) => ({ referencia: report.reference, arquivo: item.name, estado: "inv\xE1lido", erro: item.error })));
    return toCsv(rows, ["referencia", "arquivo", "estado", "distancia", "similaridade_percentual", "hash", "duplicado_de", "erro"]);
  }
  function visualReportJson(report) {
    return JSON.stringify(report, null, 2);
  }

  // src/core/card-composition.ts
  var MAX_BYTES2 = 10 * 1024 * 1024;
  var MAX_PIXELS2 = 2e7;
  var MAX_SIDE = 8192;
  var TYPES = ["image/png", "image/jpeg", "image/webp"];
  function cardCompositionDimensions(format, scale) {
    if (format !== "card" && format !== "short" || scale !== 1 && scale !== 2) throw new Error("Formato ou escala inv\xE1lidos.");
    return format === "card" ? { width: 640 * scale, height: 600 * scale } : { width: 440 * scale, height: 820 * scale };
  }
  function validateCardComposition(image, options) {
    cardCompositionDimensions(options.format, options.scale);
    if (!(image instanceof Blob) || image.size === 0 || image.size > MAX_BYTES2 || !TYPES.includes(image.type)) throw new Error("Use imagem local PNG, JPEG ou WebP est\xE1tica de at\xE9 10 MiB.");
    if (!["light", "dark", "custom", "transparent"].includes(options.background)) throw new Error("Fundo inv\xE1lido.");
    if (options.background === "custom" && !/^#[0-9a-f]{6}$/i.test(options.color ?? "")) throw new Error("Escolha uma cor de fundo v\xE1lida.");
    const m = options.metadata;
    if (!m || typeof m.title !== "string" || !m.title.trim() || m.title.length > 500 || m.channel !== void 0 && (typeof m.channel !== "string" || m.channel.length > 120) || m.id !== void 0 && !/^[A-Za-z0-9_-]{11}$/.test(m.id) || m.views !== void 0 && (!Number.isSafeInteger(m.views) || m.views < 0) || !["youtube-dom", "public-page", "user-provided", "unspecified"].includes(m.source)) throw new Error("Metadados inv\xE1lidos para a composi\xE7\xE3o.");
  }
  function lines2(ctx, input, width, maximum) {
    const words = input.trim().replace(/\s+/g, " ").split(" "), result = [];
    let line = "";
    for (const word of words) {
      const next = line ? `${line} ${word}` : word;
      if (line && ctx.measureText(next).width > width) {
        result.push(line);
        line = word;
      } else line = next;
      if (result.length === maximum) break;
    }
    if (result.length < maximum && line) result.push(line);
    return result.map((text2) => {
      let clipped = text2;
      while (clipped && ctx.measureText(clipped).width > width) clipped = clipped.slice(0, -1);
      return clipped.length < text2.length ? `${clipped.slice(0, -1)}\u2026` : clipped;
    });
  }
  function assertComposerDimensions(buffer, type) {
    const b = new Uint8Array(buffer), view = new DataView(buffer);
    const limit = (width, height) => {
      if (!width || !height || width > MAX_SIDE || height > MAX_SIDE || width * height > MAX_PIXELS2) throw new Error("Imagem excede 20 megapixels ou 8192 pixels por lado.");
    };
    if (type === "image/png") {
      limit(view.getUint32(16), view.getUint32(20));
      return;
    }
    if (type === "image/jpeg") {
      let offset2 = 2;
      while (offset2 < b.length) {
        offset2++;
        while (b[offset2] === 255) offset2++;
        const marker = b[offset2++];
        if (marker === 218) break;
        if (marker === 1 || marker >= 208 && marker <= 215) continue;
        const size = view.getUint16(offset2);
        if ([192, 193, 194, 195, 197, 198, 199, 201, 202, 203, 205, 206, 207].includes(marker)) {
          limit(view.getUint16(offset2 + 5), view.getUint16(offset2 + 3));
          return;
        }
        offset2 += size;
      }
      throw new Error("Cabe\xE7alho de imagem inv\xE1lido.");
    }
    let offset = 12;
    const tag = (pos) => String.fromCharCode(...b.subarray(pos, pos + 4));
    const u24 = (pos) => b[pos] + b[pos + 1] * 256 + b[pos + 2] * 65536;
    while (offset < b.length) {
      const kind = tag(offset), size = view.getUint32(offset + 4, true), pos = offset + 8;
      if (kind === "VP8X") limit(1 + u24(pos + 4), 1 + u24(pos + 7));
      if (kind === "VP8 ") limit(view.getUint16(pos + 6, true) & 16383, view.getUint16(pos + 8, true) & 16383);
      if (kind === "VP8L") {
        const packed = view.getUint32(pos + 1, true);
        limit((packed & 16383) + 1, (packed >>> 14 & 16383) + 1);
      }
      offset = pos + size + size % 2;
    }
  }
  async function composeCard(image, options) {
    validateCardComposition(image, options);
    const bytes = await image.arrayBuffer();
    inspectImageHeader(bytes, image.type);
    assertComposerDimensions(bytes, image.type);
    const bitmap = await createImageBitmap(new Blob([bytes], { type: image.type }));
    try {
      if (!bitmap.width || !bitmap.height || bitmap.width > MAX_SIDE || bitmap.height > MAX_SIDE || bitmap.width * bitmap.height > MAX_PIXELS2) throw new Error("Imagem decodificada excede 20 megapixels ou 8192 pixels por lado.");
      const dimensions2 = cardCompositionDimensions(options.format, options.scale);
      const canvas = document.createElement("canvas");
      canvas.width = dimensions2.width;
      canvas.height = dimensions2.height;
      const ctx = canvas.getContext("2d");
      if (!ctx) throw new Error("Canvas 2D indispon\xEDvel.");
      ctx.scale(options.scale, options.scale);
      const width = dimensions2.width / options.scale, height = dimensions2.height / options.scale;
      const light = options.background === "light";
      if (options.background !== "transparent") {
        ctx.fillStyle = options.background === "custom" ? options.color : light ? "#eeeeef" : "#101116";
        ctx.fillRect(0, 0, width, height);
      }
      const x = 24, y = 24, w = width - 48, h = height - 48;
      ctx.fillStyle = light ? "#ffffff" : "#252631";
      ctx.fillRect(x, y, w, h);
      const imageHeight = options.format === "card" ? 333 : 600;
      const ratio = Math.max(w / bitmap.width, imageHeight / bitmap.height);
      ctx.save();
      ctx.beginPath();
      ctx.rect(x, y, w, imageHeight);
      ctx.clip();
      ctx.drawImage(bitmap, x + (w - bitmap.width * ratio) / 2, y + (imageHeight - bitmap.height * ratio) / 2, bitmap.width * ratio, bitmap.height * ratio);
      ctx.restore();
      ctx.fillStyle = light ? "#171820" : "#f7f7fa";
      ctx.font = "bold 25px sans-serif";
      lines2(ctx, options.metadata.title, w - 32, 2).forEach((line, index) => ctx.fillText(line, x + 16, y + imageHeight + 37 + index * 29));
      ctx.fillStyle = light ? "#40434c" : "#d4d4dd";
      ctx.font = "16px sans-serif";
      const label = [options.metadata.channel, options.metadata.views === void 0 ? void 0 : `${options.metadata.views.toLocaleString("pt-BR")} views informadas`].filter(Boolean).join(" \xB7 ");
      if (label) ctx.fillText(lines2(ctx, label, w - 32, 1)[0], x + 16, y + imageHeight + 106);
      ctx.font = "13px sans-serif";
      const origins = { "youtube-dom": "p\xE1gina observada", "public-page": "p\xE1gina p\xFAblica", "user-provided": "informado pelo usu\xE1rio", unspecified: "origem n\xE3o declarada" };
      ctx.fillText(`Metadados: ${origins[options.metadata.source]}${options.metadata.id ? ` \xB7 ID ${options.metadata.id}` : ""}`, x + 16, y + h - 43, w - 32);
      ctx.fillText("COMPOSI\xC7\xC3O LOCAL \xB7 IMAGEM FORNECIDA", x + 16, y + h - 22, w - 32);
      return await new Promise((resolve, reject) => canvas.toBlob((blob) => blob ? resolve(blob) : reject(new Error("Falha ao codificar PNG.")), "image/png"));
    } finally {
      bitmap.close();
    }
  }

  // src/ui/card-composition.ts
  function initCardCompositionTools(deps) {
    const host = document.getElementById("card-composition");
    if (!host) return { invalidateSnapshot: () => {
    }, dispose: () => {
    } };
    host.innerHTML = `<div class="card"><h2>Compor card ou Short</h2>
    <p>Crie uma ilustra\xE7\xE3o com sua imagem local e metadados fornecidos ou escolhidos da coleta. \xC9 uma composi\xE7\xE3o, n\xE3o uma captura da p\xE1gina ou comprova\xE7\xE3o de analytics. Use PNG, JPEG ou WebP est\xE1ticos de at\xE9 10 MiB.</p>
    <label>Imagem local <input id="card-compose-file" type="file" accept="image/png,image/jpeg,image/webp"></label>
    <label>Origem dos metadados <select id="card-compose-source"><option value="manual">Informados por voc\xEA</option><option value="snapshot">V\xEDdeo da coleta carregada</option></select></label>
    <div id="card-compose-snapshot" hidden><button type="button" id="card-compose-load">Listar v\xEDdeos da coleta</button><label>V\xEDdeo <select id="card-compose-video"><option value="">Selecione um v\xEDdeo</option></select></label><p id="card-compose-provenance"></p></div>
    <div id="card-compose-manual"><label>T\xEDtulo <input id="card-compose-title" maxlength="500"></label><label>Canal (opcional) <input id="card-compose-channel" maxlength="120"></label></div>
    <div class="row"><label>Formato <select id="card-compose-format"><option value="card">Card</option><option value="short">Short</option></select></label><label>Fundo <select id="card-compose-background"><option value="dark">Escuro</option><option value="light">Claro</option><option value="custom">Cor personalizada</option><option value="transparent">Transparente</option></select></label><label>Cor personalizada <input type="color" id="card-compose-color" value="#654d8c"></label><label>Escala <select id="card-compose-scale"><option value="1">1\xD7</option><option value="2">2\xD7</option></select></label></div>
    <div class="actions"><button type="button" id="card-compose-render" class="primary">Gerar composi\xE7\xE3o</button><button type="button" id="card-compose-download" disabled>Baixar PNG</button></div><p id="card-compose-status" role="status" aria-live="polite"></p><img id="card-compose-output" alt="Composi\xE7\xE3o local de card ou Short" hidden style="max-width:100%;height:auto"></div>`;
    const get = (id) => host.querySelector(`#card-compose-${id}`);
    const file = get("file"), source = get("source"), video = get("video"), snapshotArea = get("snapshot"), manualArea = get("manual"), status = get("status"), output = get("output"), download = get("download");
    const renderButton = get("render");
    let videos = [], serial = 0, result, url, disposed = false, inFlight = false;
    const clear = () => {
      serial++;
      result = void 0;
      download.disabled = true;
      output.hidden = true;
      output.removeAttribute("src");
      if (url) URL.revokeObjectURL(url);
      url = void 0;
    };
    const sourceLabel = { "youtube-dom": "p\xE1gina YouTube observada", "public-page": "p\xE1gina p\xFAblica", "user-provided": "informado pelo usu\xE1rio", unspecified: "origem n\xE3o declarada" };
    const selected = () => videos[Number(video.value)] && video.value !== "" ? videos[Number(video.value)] : void 0;
    const updateProvenance = () => {
      const item = selected();
      const origin = item?.source ?? "unspecified";
      get("provenance").textContent = item ? `ID ${item.id} \xB7 ${sourceLabel[origin]} \xB7 ${item.observedAt ? `observado em ${item.observedAt}` : "data da observa\xE7\xE3o desconhecida"}. Dados preservados da sele\xE7\xE3o; a imagem \xE9 fornecida por voc\xEA.` : "Nenhum v\xEDdeo selecionado.";
    };
    const changed = () => {
      clear();
      snapshotArea.hidden = source.value !== "snapshot";
      manualArea.hidden = source.value !== "manual";
      updateProvenance();
      status.textContent = "Sele\xE7\xE3o alterada. Gere novamente.";
    };
    host.addEventListener("input", changed);
    host.addEventListener("change", changed);
    get("load").addEventListener("click", () => {
      clear();
      videos = deps.snapshot().videos.filter((item) => item.source !== "youtube-data-api" && /^[A-Za-z0-9_-]{11}$/.test(item.id) && typeof item.title === "string" && !!item.title.trim()).slice(0, 500).map((item) => ({ ...item }));
      video.replaceChildren(new Option("Selecione um v\xEDdeo", ""), ...videos.map((item, index) => new Option(`${item.title} \xB7 ${item.id}`, String(index))));
      updateProvenance();
      status.textContent = `${videos.length} v\xEDdeo(s) eleg\xEDveis listados (limite 500); selecione um. Dados da API oficial s\xE3o exclu\xEDdos.`;
    });
    renderButton.addEventListener("click", () => {
      if (inFlight || disposed) return;
      void (async () => {
        clear();
        const mine = serial, image = file.files?.[0], item = selected();
        if (!image) {
          status.textContent = "Escolha uma imagem local.";
          return;
        }
        if (source.value === "snapshot" && !item) {
          status.textContent = "Liste e selecione um v\xEDdeo da coleta.";
          return;
        }
        if (item?.source === "youtube-data-api") {
          status.textContent = "Dados da API oficial n\xE3o s\xE3o aceitos nesta composi\xE7\xE3o.";
          return;
        }
        const metadata = source.value === "snapshot" && item ? { id: item.id, title: item.title, channel: item.channel, views: item.views, source: item.source ?? "unspecified" } : { title: get("title").value, channel: get("channel").value, source: "user-provided" };
        const options = { metadata, format: get("format").value, background: get("background").value, color: get("color").value, scale: Number(get("scale").value) };
        inFlight = true;
        renderButton.disabled = true;
        status.textContent = "Gerando composi\xE7\xE3o local\u2026";
        try {
          const blob = await composeCard(image, options);
          if (mine !== serial || disposed) return;
          result = blob;
          url = URL.createObjectURL(blob);
          output.src = url;
          output.hidden = false;
          download.disabled = false;
          status.textContent = `Composi\xE7\xE3o local pronta \xB7 ${metadata.id ? `ID ${metadata.id} \xB7 ` : ""}metadados: ${sourceLabel[metadata.source]} \xB7 imagem local fornecida.`;
        } catch (error) {
          if (mine === serial && !disposed) status.textContent = error instanceof Error ? error.message : "N\xE3o foi poss\xEDvel compor a imagem.";
        } finally {
          inFlight = false;
          if (!disposed) renderButton.disabled = false;
        }
      })();
    });
    download.addEventListener("click", () => {
      if (result) downloadBlob(result, "prevlev-composicao-local.png");
    });
    return {
      invalidateSnapshot() {
        if (disposed) return;
        clear();
        videos = [];
        video.replaceChildren(new Option("Selecione um v\xEDdeo", ""));
        updateProvenance();
        status.textContent = "Coleta alterada. Liste e selecione um v\xEDdeo novamente.";
      },
      dispose() {
        if (disposed) return;
        disposed = true;
        clear();
        videos = [];
        host.removeEventListener("input", changed);
        host.removeEventListener("change", changed);
        host.replaceChildren();
      }
    };
  }

  // src/ui/visual-similarity.ts
  function initVisualSimilarityTools() {
    const host = document.getElementById("visual-similarity");
    if (!host) return () => {
    };
    host.innerHTML = `<div class="card"><h2>Similaridade visual local</h2><p>Compare uma imagem de refer\xEAncia com at\xE9 20 imagens locais. O dHash de 64 bits compara padr\xF5es de lumin\xE2ncia, n\xE3o cores ou significado; imagens diferentes podem ter o mesmo hash. A transpar\xEAncia \xE9 composta sobre branco. Use PNG, JPEG ou WebP est\xE1tico. Limites: 10 MiB por arquivo, 50 MiB no total, 20 megapixels por imagem e 15 segundos.</p><label>Imagem de refer\xEAncia<input id="visual-reference" type="file" accept="image/png,image/jpeg,image/webp"></label><label>Imagens candidatas<input id="visual-candidates" type="file" accept="image/png,image/jpeg,image/webp" multiple></label><div class="actions"><button id="visual-compare" class="primary">Comparar imagens</button><button id="visual-cancel" disabled>Cancelar</button><button id="visual-csv" disabled>Exportar CSV</button><button id="visual-json" disabled>Exportar JSON</button></div><p id="visual-status" role="status" aria-live="polite"></p><div id="visual-results"></div></div>`;
    const get = (id) => host.querySelector(`#visual-${id}`);
    const reference = get("reference"), candidates = get("candidates"), compare = get("compare"), cancel = get("cancel"), csv = get("csv"), json = get("json"), status = get("status"), results = get("results");
    let controller, report, urls = [], disposed = false;
    const clean = () => {
      for (const url of urls) URL.revokeObjectURL(url);
      urls = [];
      results.replaceChildren();
      report = void 0;
      csv.disabled = true;
      json.disabled = true;
    };
    const changed = () => {
      controller?.abort();
      clean();
      status.textContent = "Sele\xE7\xE3o alterada. Compare novamente.";
    };
    const run = async () => {
      if (controller) return;
      clean();
      const base = reference.files?.[0], files = Array.from(candidates.files ?? []);
      if (!base) {
        status.textContent = "Selecione uma imagem de refer\xEAncia local.";
        return;
      }
      const active = new AbortController();
      controller = active;
      compare.disabled = true;
      cancel.disabled = false;
      status.textContent = "Comparando imagens locais\u2026";
      try {
        const next = await compareLocalImages(base, files, { signal: active.signal });
        if (active.signal.aborted || disposed) return;
        report = next;
        const ref = document.createElement("p");
        ref.textContent = `Refer\xEAncia: ${next.reference}`;
        results.append(ref);
        const refImage = document.createElement("img");
        refImage.src = URL.createObjectURL(base);
        urls.push(refImage.src);
        refImage.alt = "Imagem de refer\xEAncia";
        refImage.style.cssText = "width:160px;max-height:100px;object-fit:contain";
        results.append(refImage);
        const list = document.createElement("ol");
        for (const match of next.matches) {
          const li = document.createElement("li"), img = document.createElement("img"), label = document.createElement("span");
          img.src = URL.createObjectURL(files[match.index]);
          urls.push(img.src);
          img.alt = `Pr\xE9via: ${match.name}`;
          img.style.cssText = "width:120px;max-height:80px;object-fit:contain;vertical-align:middle;margin-right:8px";
          label.textContent = `${match.name}: ${match.similarity.toFixed(2)}% \xB7 dist\xE2ncia ${match.distance}/64${match.duplicateOf ? ` \xB7 bytes duplicados de ${match.duplicateOf}` : ""}`;
          li.append(img, label);
          list.append(li);
        }
        results.append(list);
        if (next.invalid.length) {
          const heading = document.createElement("p");
          heading.textContent = "Arquivos ignorados:";
          results.append(heading);
          const errors = document.createElement("ul");
          for (const invalid2 of next.invalid) {
            const li = document.createElement("li");
            li.textContent = `${invalid2.name}: ${invalid2.error}`;
            errors.append(li);
          }
          results.append(errors);
        }
        csv.disabled = false;
        json.disabled = false;
        status.textContent = `${next.matches.length} imagem(ns) comparada(s); ${next.invalid.length} inv\xE1lida(s). Ordem por menor dist\xE2ncia de Hamming.`;
      } catch (error) {
        if (disposed) return;
        status.textContent = active.signal.aborted ? "Compara\xE7\xE3o cancelada." : error instanceof Error ? error.message : "Falha na compara\xE7\xE3o local.";
      } finally {
        if (controller === active) controller = void 0;
        if (!disposed) {
          compare.disabled = false;
          cancel.disabled = true;
        }
      }
    };
    const onRun = () => {
      void run();
    }, onCancel = () => controller?.abort(), onCsv = () => {
      if (report) downloadBlob(new Blob([visualReportCsv(report)], { type: "text/csv;charset=utf-8" }), "prevlev-similaridade-visual.csv");
    }, onJson = () => {
      if (report) downloadBlob(new Blob([visualReportJson(report)], { type: "application/json;charset=utf-8" }), "prevlev-similaridade-visual.json");
    };
    reference.addEventListener("change", changed);
    candidates.addEventListener("change", changed);
    compare.addEventListener("click", onRun);
    cancel.addEventListener("click", onCancel);
    csv.addEventListener("click", onCsv);
    json.addEventListener("click", onJson);
    return () => {
      disposed = true;
      controller?.abort();
      clean();
      reference.removeEventListener("change", changed);
      candidates.removeEventListener("change", changed);
      compare.removeEventListener("click", onRun);
      cancel.removeEventListener("click", onCancel);
      csv.removeEventListener("click", onCsv);
      json.removeEventListener("click", onJson);
    };
  }

  // src/ui/studio-overview.ts
  var DAY = 864e5;
  var PRESETS = [7, 14, 28, 60, 90, 180, 365];
  function completedPublicationPeriod(publication, days, now2 = /* @__PURE__ */ new Date()) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(publication) || !Number.isInteger(days) || days < 1 || !Number.isFinite(now2.getTime())) return void 0;
    const start = Date.parse(`${publication}T00:00:00.000Z`);
    if (!Number.isFinite(start) || new Date(start).toISOString().slice(0, 10) !== publication) return void 0;
    const end = start + (days - 1) * DAY;
    const today = Date.UTC(now2.getUTCFullYear(), now2.getUTCMonth(), now2.getUTCDate());
    if (end >= today) return void 0;
    return { start: publication, end: new Date(end).toISOString().slice(0, 10) };
  }
  function initStudioOverview({ snapshot: snapshot2 }) {
    const studio = document.querySelector("#studio");
    const start = document.querySelector("#period-start");
    const end = document.querySelector("#period-end");
    if (!studio || !start || !end) throw new Error("Controles do Studio ausentes.");
    const panel = document.createElement("div");
    panel.id = "studio-overview";
    panel.className = "card";
    panel.innerHTML = `<h2>Vis\xE3o geral observada no Studio</h2>
    <p class="muted">Dados vis\xEDveis na p\xE1gina coletada. O per\xEDodo exibido \xE9 contexto observado e n\xE3o comprova, por si s\xF3, que cada m\xE9trica pertence a ele.</p>
    <dl id="studio-overview-fields"></dl>
    <ul id="studio-overview-warnings"></ul>
    <p>Na calculadora, a quantidade de v\xEDdeos \xE9 informada por voc\xEA; uma contagem observada n\xE3o \xE9 usada como quantidade do per\xEDodo.</p>
    <h3>Primeiros dias ap\xF3s a publica\xE7\xE3o</h3>
    <p class="muted">Informe a data de publica\xE7\xE3o do v\xEDdeo. Os intervalos incluem essa data e usam dias UTC completos. Escolher um intervalo preenche apenas os campos desta tela; use \u201CPreencher per\xEDodo aberto\u201D para enviar as datas aos campos abertos no Studio.</p>
    <label>Data de publica\xE7\xE3o informada por voc\xEA <input id="studio-publication-date" type="date"></label>
    <div id="studio-period-presets"></div><p id="studio-period-status" role="status"></p>`;
    studio.prepend(panel);
    const fields = panel.querySelector("#studio-overview-fields");
    const warnings = panel.querySelector("#studio-overview-warnings");
    const publication = panel.querySelector("#studio-publication-date");
    const presets = panel.querySelector("#studio-period-presets");
    const status = panel.querySelector("#studio-period-status");
    for (const days of PRESETS) {
      const button = document.createElement("button");
      button.type = "button";
      button.dataset.days = String(days);
      button.textContent = `${days} dias`;
      button.addEventListener("click", () => {
        const period = completedPublicationPeriod(publication.value, days);
        if (!period) {
          updatePresets();
          return;
        }
        start.value = period.start;
        end.value = period.end;
        start.dispatchEvent(new Event("input", { bubbles: true }));
        end.dispatchEvent(new Event("input", { bubbles: true }));
        status.textContent = `Intervalo ${period.start} a ${period.end} preenchido nesta tela. Use \u201CPreencher per\xEDodo aberto\u201D para enviar ao Studio.`;
      });
      presets.append(button);
    }
    function updatePresets() {
      for (const button of presets.querySelectorAll("button")) {
        button.disabled = !completedPublicationPeriod(publication.value, Number(button.dataset.days));
      }
      status.textContent = publication.value ? "Intervalos indispon\xEDveis ainda n\xE3o completaram seu \xFAltimo dia UTC, ou a data \xE9 inv\xE1lida." : "Informe a data de publica\xE7\xE3o para habilitar intervalos completos.";
    }
    publication.addEventListener("input", updatePresets);
    function render2() {
      const data = snapshot2().studio;
      fields.replaceChildren();
      const row3 = (label, value2) => {
        const term = document.createElement("dt");
        term.textContent = label;
        const description = document.createElement("dd");
        description.textContent = value2;
        fields.append(term, description);
      };
      const source = (metric) => metric ? ` \xB7 fonte: ${metric.label} (${metric.selector}; exibido: ${metric.raw})` : " \xB7 fonte espec\xEDfica desconhecida";
      row3("Fonte da coleta", data?.source === "studio-dom" ? "P\xE1gina vis\xEDvel do YouTube Studio (studio-dom)" : "Desconhecida");
      row3("Data da observa\xE7\xE3o", data?.observedAt ?? "Desconhecida");
      row3("Per\xEDodo exibido", data?.period ? `${data.period.label}${data.period.start && data.period.end ? ` (${data.period.start} a ${data.period.end})` : ""}${source(data.sources?.period)}` : "Desconhecido");
      row3("Receita observada", data?.revenue !== void 0 ? `${data.revenue}${source(data.sources?.revenue)}` : "Desconhecida");
      row3("Moeda observada", data?.currency || data?.currencyCode ? `${[data.currency, data.currencyCode].filter(Boolean).join(" \xB7 ")}${source(data.sources?.currency)}` : "Desconhecida");
      row3("Quantidade observada de v\xEDdeos", data?.videoCount !== void 0 ? `${data.videoCount}${source(data.sources?.videoCount)} \xB7 escopo da contagem n\xE3o confirmado` : "Desconhecida");
      warnings.replaceChildren(...(data?.warnings ?? []).map((message) => {
        const item = document.createElement("li");
        item.textContent = message;
        return item;
      }));
      updatePresets();
    }
    render2();
    return { render: render2 };
  }

  // src/ui/capture-options.ts
  var CAPTURE_REDACTION_CATEGORIES = [
    "channel",
    "revenue",
    "subscribers",
    "views",
    "video-info"
  ];
  function initCaptureOptions() {
    const toggle = document.querySelector("#redact");
    if (!toggle) throw new Error("Controle de oculta\xE7\xE3o n\xE3o encontrado.");
    let fieldset = document.querySelector("#capture-redaction-categories");
    if (!fieldset) {
      fieldset = document.createElement("fieldset");
      fieldset.id = "capture-redaction-categories";
      const legend = document.createElement("legend");
      legend.textContent = "Campos a ocultar no card capturado";
      fieldset.append(legend);
      const labels2 = {
        channel: "Canal",
        revenue: "Receita",
        subscribers: "Inscritos",
        views: "Visualiza\xE7\xF5es",
        "video-info": "Informa\xE7\xF5es do v\xEDdeo"
      };
      for (const category of CAPTURE_REDACTION_CATEGORIES) {
        const label = document.createElement("label");
        const checkbox = document.createElement("input");
        checkbox.type = "checkbox";
        checkbox.value = category;
        checkbox.checked = true;
        label.append(checkbox, document.createTextNode(` ${labels2[category]} `));
        fieldset.append(label);
      }
      const note = document.createElement("p");
      note.textContent = "A oculta\xE7\xE3o cobre campos reconhecidos dentro do card; pode usar \xE1reas maiores quando necess\xE1rio. Revise a imagem antes de compartilhar: isso n\xE3o garante anonimiza\xE7\xE3o completa.";
      fieldset.append(note);
      (toggle.closest("label") ?? toggle).insertAdjacentElement("afterend", fieldset);
    }
    const controls = fieldset;
    const sync = () => {
      controls.disabled = !toggle.checked;
    };
    toggle.addEventListener("change", sync);
    sync();
    return () => Array.from(controls.querySelectorAll("input:checked")).map((input) => input.value);
  }

  // src/ui/transcript-extra.ts
  var mounted2 = /* @__PURE__ */ new WeakMap();
  var labels = { "transcript-summary": "Resumo", "transcript-topics": "T\xF3picos", "transcript-script": "Roteiro" };
  function initTranscriptExtras(deps) {
    const textarea = document.getElementById("transcript-text"), card = textarea?.closest(".card");
    if (!textarea || !card) throw new Error("O painel de transcri\xE7\xE3o n\xE3o est\xE1 dispon\xEDvel.");
    const existing = mounted2.get(card);
    if (existing) return existing;
    let cache = /* @__PURE__ */ new Map(), pending, serial = 0;
    const host = document.createElement("div");
    host.id = "transcript-extras";
    host.innerHTML = `<div class="actions"><button id="transcript-copy-timestamps">Copiar timestamps + texto</button><button id="transcript-export-json">JSON com metadados</button><button id="transcript-export-csv">CSV com timestamps</button><button id="transcript-metadata-md">Markdown com metadados</button><button id="transcript-srt">Baixar SRT</button></div><p class="muted">Metadados usam o contexto da coleta atual. Hor\xE1rios s\xF3 acompanham o texto original sem edi\xE7\xE3o ou legendas importadas com timestamps. Finais desconhecidos n\xE3o recebem dura\xE7\xE3o inventada.</p><div class="actions"><button id="transcript-copy-summary" disabled>Copiar resumo</button><button id="transcript-copy-topics" disabled>Copiar t\xF3picos</button><button id="transcript-copy-script" disabled>Copiar roteiro</button><button id="transcript-ai-back">Voltar \xE0 transcri\xE7\xE3o</button></div><p id="transcript-ai-state" role="status" aria-live="polite">Resumo, t\xF3picos e roteiro s\xF3 s\xE3o gerados ap\xF3s os bot\xF5es expl\xEDcitos de IA. Nenhum resultado em cache foi carregado.</p>`;
    card.append(host);
    const get = (id) => host.querySelector(`#transcript-${id}`);
    const output = document.getElementById("transcript-result");
    const status = (value2, error = false) => {
      get("ai-state").textContent = value2;
      get("ai-state").classList.toggle("error", error);
    };
    const timed = () => {
      const current = deps.text(), segments2 = deps.segments();
      return current === transcriptText(segments2) ? segments2 : parseTranscript(current);
    };
    const metadata = () => {
      const snapshot2 = deps.metadata();
      return { title: snapshot2.title || "Transcri\xE7\xE3o", videoUrl: snapshot2.url, videoId: snapshot2.videoId };
    };
    const context = () => JSON.stringify({ text: deps.text(), segments: timed(), url: deps.metadata().url, videoId: deps.metadata().videoId, ai: deps.aiContext?.() ?? "" });
    const updateCopies = () => {
      for (const [feature, id] of [["transcript-summary", "copy-summary"], ["transcript-topics", "copy-topics"], ["transcript-script", "copy-script"]]) get(id).disabled = !cache.has(feature);
    };
    const invalidate = () => {
      cache = /* @__PURE__ */ new Map();
      pending = void 0;
      serial++;
      output.textContent = "";
      output.hidden = false;
      updateCopies();
      status("Conte\xFAdo ou contexto alterado. Os resultados anteriores foram descartados.");
    };
    const show = (feature, entry, cached = false) => {
      output.hidden = false;
      output.textContent = entry.text;
      status(`${labels[feature]} ${cached ? "recuperado do cache desta sess\xE3o" : "conclu\xEDdo"} \xB7 ${entry.source}. Revise o conte\xFAdo gerado.`);
    };
    const controller = {
      invalidate,
      beginAi(feature) {
        const key = context(), stored = cache.get(feature);
        if (stored?.key === key) {
          show(feature, stored, true);
          return { cached: true, requestId: 0 };
        }
        if (pending) throw new Error("Aguarde a an\xE1lise atual concluir antes de iniciar outra.");
        if (!deps.text().trim()) throw new Error("Colete ou importe uma transcri\xE7\xE3o antes de solicitar IA.");
        for (const [name, entry] of cache) if (entry.key !== key) cache.delete(name);
        updateCopies();
        const requestId = ++serial;
        pending = { feature, requestId, key };
        output.hidden = false;
        output.textContent = "";
        status(`${labels[feature]} em processamento no backend escolhido\u2026`);
        return { cached: false, requestId };
      },
      completeAi(feature, result, requestId) {
        if (!pending || pending.feature !== feature || pending.requestId !== requestId) return;
        const active = pending;
        pending = void 0;
        if (active.key !== context()) {
          invalidate();
          status("A entrada mudou durante a an\xE1lise. O resultado antigo foi descartado.");
          return;
        }
        const data = result.data && typeof result.data === "object" ? result.data : {};
        if (result.status !== "ok" || typeof data.text !== "string" || !data.text.trim()) {
          status(result.error ?? "A IA n\xE3o retornou texto conclu\xEDdo. Nenhum resultado foi colocado em cache.", true);
          return;
        }
        const entry = { key: active.key, text: data.text, source: result.source };
        cache.set(feature, entry);
        show(feature, entry);
        updateCopies();
      },
      failAi(feature, error, requestId) {
        if (pending?.feature !== feature || pending.requestId !== requestId) return;
        pending = void 0;
        status(error instanceof Error ? error.message : "N\xE3o foi poss\xEDvel concluir a an\xE1lise.", true);
      }
    };
    const perform = (task) => {
      void Promise.resolve().then(task).catch((error) => status(error instanceof Error ? error.message : "A opera\xE7\xE3o local falhou.", true));
    };
    const copy = async (text2) => {
      if (!navigator.clipboard?.writeText) throw new Error("\xC1rea de transfer\xEAncia indispon\xEDvel neste navegador.");
      await navigator.clipboard.writeText(text2);
    };
    get("copy-timestamps").addEventListener("click", () => perform(async () => {
      const segments2 = timed();
      if (!segments2.length) throw new Error("Timestamps originais indispon\xEDveis para o texto atual.");
      await copy(transcriptText(segments2, true));
      status("Texto com timestamps originais copiado.");
    }));
    for (const [feature, id] of [["transcript-summary", "copy-summary"], ["transcript-topics", "copy-topics"], ["transcript-script", "copy-script"]]) get(id).addEventListener("click", () => perform(async () => {
      const entry = cache.get(feature);
      if (!entry || entry.key !== context()) {
        invalidate();
        throw new Error("O conte\xFAdo mudou; gere novamente antes de copiar este resultado.");
      }
      await copy(entry.text);
      status(`${labels[feature]} copiado separadamente da transcri\xE7\xE3o.`);
    }));
    get("ai-back").addEventListener("click", () => {
      output.textContent = "";
      status("Transcri\xE7\xE3o original exibida. Resultados v\xE1lidos continuam dispon\xEDveis para c\xF3pia nesta sess\xE3o.");
      textarea.focus();
    });
    const save = (content, name, type) => downloadBlob(new Blob([content], { type }), name);
    get("export-json").addEventListener("click", () => perform(() => {
      if (!deps.text().trim()) throw new Error("Nenhum texto dispon\xEDvel.");
      save(JSON.stringify(transcriptExport(timed(), metadata(), {}, deps.text()), null, 2), "prevlev-transcricao.json", "application/json");
      status("JSON exportado com contexto, hor\xE1rios conhecidos e finais desconhecidos expl\xEDcitos.");
    }));
    get("export-csv").addEventListener("click", () => perform(() => {
      const segments2 = timed();
      if (!segments2.length) throw new Error("CSV de timestamps exige segmentos conhecidos para o texto atual.");
      save(toCsv(transcriptRows(segments2, metadata())), "prevlev-transcricao.csv", "text/csv;charset=utf-8");
      status("CSV com timestamps e metadados exportado.");
    }));
    get("metadata-md").addEventListener("click", () => perform(() => {
      const text2 = deps.text(), segments2 = timed();
      if (!text2.trim()) throw new Error("Nenhum texto dispon\xEDvel.");
      const report = transcriptExport(segments2, metadata(), {}, text2), fence = "`".repeat(Math.max(3, ...[...text2.matchAll(/`+/g)].map((match) => match[0].length + 1)));
      save(segments2.length ? transcriptMarkdown(segments2, report.title, metadata()) : `# Transcri\xE7\xE3o sem timestamps

V\xEDdeo: ${report.videoUrl ?? "n\xE3o informado"}

Exportado em: ${report.exportedAt}

${fence}text
${text2}
${fence}
`, "prevlev-transcricao-metadados.md", "text/markdown;charset=utf-8");
      status("Markdown exportado com metadados; hor\xE1rios ausentes permanecem desconhecidos.");
    }));
    get("srt").addEventListener("click", () => perform(() => {
      const segments2 = timed(), report = transcriptExport(segments2, metadata()), content = transcriptSrt(segments2);
      if (!content) throw new Error("Nenhum cue tem fim conhecido. Use JSON para conservar texto e in\xEDcios desconhecidos.");
      save(content, "prevlev-transcricao.srt", "application/x-subrip;charset=utf-8");
      const omitted = report.segments.filter((segment) => segment.end === null).length;
      status(`SRT exportado.${omitted ? ` ${omitted} cue(s) sem fim conhecido foram omitidos; JSON conserva todos os textos.` : ""}`);
    }));
    textarea.addEventListener("input", invalidate);
    const file = document.getElementById("transcript-file");
    if (file && !file.accept.includes(".srt")) file.accept += ",.srt";
    mounted2.set(card, controller);
    return controller;
  }

  // src/ui/workspace.ts
  var $ = (id) => document.getElementById(id);
  var value = (id) => $(id).value;
  var num = (id) => Number(value(id));
  var snapshot = {
    url: "",
    title: "",
    videos: [],
    comments: [],
    transcript: [],
    warnings: []
  };
  var segments = [];
  var transcriptStamp = "";
  function invalidateTranscriptContext() {
    const stamp = JSON.stringify([segments, document.getElementById("transcript-text")?.textContent, $("transcript-text")?.value, snapshot.url, snapshot.videoId]);
    if (stamp !== transcriptStamp) {
      transcriptExtras?.invalidate();
      transcriptStamp = stamp;
    }
  }
  var planId;
  var studioPreviewGeneration = 0;
  var planTab;
  var runningPlan;
  var channelVideos = [];
  var timeline;
  var aiCatalog;
  var selectedAiModel = "";
  var selectedAiOrigin = "http://127.0.0.1:7814";
  var selectedAiStreaming = false;
  var aiSelectionSaving = false;
  var aiRequestRunning = false;
  var transcriptExtras = initTranscriptExtras({ segments: () => segments, text: transcriptContent, metadata: () => snapshot, aiContext: () => JSON.stringify([selectedAiOrigin, selectedAiModel, selectedAiStreaming]) });
  var commentTools = initCommentTools({ snapshot: () => snapshot, onAi: async () => {
    showPage("remote");
    await remote("comment-analysis");
  } });
  var swipeTools = initSwipeTools();
  var renderComments = () => commentTools.render();
  var currentComments = () => commentTools.currentComments();
  var renderSwipe = () => swipeTools.render();
  async function saveVideo(video) {
    await swipeTools.saveVideo(video);
    notice("Refer\xEAncia salva na biblioteca local.");
  }
  var filterIds = [
    "video-filter",
    "channel-filter",
    "min-views",
    "max-views",
    "min-subscribers",
    "max-subscribers",
    "min-duration",
    "max-duration",
    "min-vph",
    "max-vph",
    "min-outlier",
    "max-outlier",
    "published-after",
    "published-before",
    "short-filter",
    "sort"
  ];
  var compact = (n) => n === void 0 ? "\u2014" : new Intl.NumberFormat("pt-BR", {
    notation: "compact",
    maximumFractionDigits: 1
  }).format(n);
  function notice(message, error = false) {
    $("notice").textContent = message;
    $("notice").classList.toggle("error", error);
  }
  function on(id, task) {
    $(id).addEventListener("click", () => {
      void Promise.resolve().then(task).catch(fail);
    });
  }
  function fail(error) {
    notice(error instanceof Error ? error.message : String(error), true);
  }
  function textFile(content, name, type = "text/plain") {
    downloadBlob(new Blob([content], { type }), name);
  }
  var safeLink = (url) => {
    try {
      const u = new URL(url);
      return ["http:", "https:"].includes(u.protocol) ? u.href : "#";
    } catch {
      return "#";
    }
  };
  function element3(tag, text2) {
    const el = document.createElement(tag);
    if (text2 !== void 0) el.textContent = text2;
    return el;
  }
  function showPage(id) {
    for (const page of document.querySelectorAll(".page"))
      page.hidden = page.id !== id;
    for (const b of document.querySelectorAll("nav [data-page]"))
      b.classList.toggle("active", b.dataset.page === id);
    $("page-title").textContent = document.querySelector(`[data-page="${id}"]`)?.textContent?.trim().replace(/^\S+\s*/, "") ?? id;
  }
  for (const b of document.querySelectorAll("[data-page]"))
    b.addEventListener("click", () => showPage(b.dataset.page));
  async function tabs() {
    const all = await chrome.tabs.query({});
    const target = Number(new URL(location.href).searchParams.get("tab"));
    const select = $("tab-select");
    select.replaceChildren();
    for (const tab of all.filter(
      (t) => /^https:\/\/(www|studio)\.youtube\.com\//.test(t.url ?? "")
    )) {
      const option = element3("option", tab.title ?? tab.url);
      option.value = String(tab.id);
      option.selected = tab.id === target;
      select.append(option);
    }
    if (!select.options.length) {
      const option = element3("option", "Abra uma aba YouTube / Studio");
      option.value = "";
      select.append(option);
    }
  }
  function targetTab() {
    const id = Number(value("tab-select"));
    if (!id) throw new Error("Abra o YouTube ou Studio e atualize este painel.");
    return id;
  }
  async function tabMessage(type, extra = {}) {
    const response = await chrome.tabs.sendMessage(targetTab(), {
      type,
      ...extra
    });
    if (response?.status === "error") throw new Error(response.error);
    return response;
  }
  async function scan() {
    const result = await tabMessage("GET_SNAPSHOT");
    if (!result.snapshot)
      throw new Error(
        "N\xE3o foi poss\xEDvel coletar. Recarregue a aba YouTube ap\xF3s instalar a extens\xE3o."
      );
    snapshot = {
      ...result.snapshot,
      videos: result.snapshot.videos.map((video) => ({
        ...video,
        source: video.source ?? "youtube-dom",
        observedAt: video.observedAt ?? (/* @__PURE__ */ new Date()).toISOString()
      }))
    };
    nicheTools.invalidate();
    cardComposer.invalidateSnapshot();
    segments = snapshot.transcript;
    await chrome.storage.local.set({ snapshot });
    render();
    notice(
      `Coletados ${snapshot.videos.length} v\xEDdeos e ${snapshot.comments.length} coment\xE1rios. ${snapshot.warnings.join(" ")}`
    );
  }
  on("scan", scan);
  on("enrich", async () => {
    if (!snapshot.videos.length) throw new Error("Colete v\xEDdeos primeiro.");
    $("enrich").disabled = true;
    notice(
      "Consultando at\xE9 10 canais p\xFAblicos no YouTube, sem enviar credenciais\u2026"
    );
    try {
      const tabId = targetTab();
      const result = await chrome.runtime.sendMessage({
        type: "ENRICH_CHANNELS",
        videos: snapshot.videos
      });
      if (result.status !== "ok") throw new Error(result.error);
      snapshot.videos = result.videos;
      nicheTools.invalidate();
      cardComposer.invalidateSnapshot();
      await chrome.tabs.sendMessage(tabId, {
        type: "SET_ENRICHMENT",
        videos: snapshot.videos
      });
      await chrome.storage.local.set({ snapshot });
      renderVideos();
      notice(
        `Consulta de inscritos conclu\xEDda. ${result.warnings.join(" ")}`
      );
    } finally {
      $("enrich").disabled = false;
    }
  });
  function readVideoFilter() {
    const optional = (id) => value(id) === "" ? void 0 : num(id);
    const mode = value("short-filter");
    return {
      query: value("video-filter"),
      channel: value("channel-filter"),
      minViews: optional("min-views"),
      maxViews: optional("max-views"),
      minSubscribers: optional("min-subscribers"),
      maxSubscribers: optional("max-subscribers"),
      minDurationSeconds: optional("min-duration"),
      maxDurationSeconds: optional("max-duration"),
      minVph: optional("min-vph"),
      maxVph: optional("max-vph"),
      minOutlier: optional("min-outlier"),
      maxOutlier: optional("max-outlier"),
      publishedAfter: value("published-after") || void 0,
      publishedBefore: value("published-before") || void 0,
      shorts: mode === "shorts" ? "only" : mode === "long" ? "exclude" : "all",
      ...researchTools?.readOptions()
    };
  }
  function visibleVideos() {
    return selectResearchVideos(snapshot.videos, { ...readVideoFilter(), sort: value("sort") });
  }
  function renderVideos() {
    researchTools?.refresh();
    const videos = visibleVideos(), body = $("video-rows");
    renderMetrics(videos);
    body.replaceChildren();
    $("video-count").textContent = `(${videos.length})`;
    const mode = readVideoFilter().comparisonMode ?? "sample-median";
    const excludedApi = snapshot.videos.filter((video) => video.source === "youtube-data-api").length;
    $("outlier-details").textContent = `Modo selecionado: ${mode}. Amostra: ${snapshot.videos.length} registros recebidos, ${videos.length} inclu\xEDdos; ${excludedApi} da API oficial e ${snapshot.videos.length - excludedApi - videos.length} pelos filtros exclu\xEDdos. Refer\xEAncias: observa\xE7\xF5es carregadas eleg\xEDveis antes dos filtros. O alvo \xE9 exclu\xEDdo por ID; outras observa\xE7\xF5es repetidas podem ser contadas. O denominador \xE9 a refer\xEAncia da amostra, n\xE3o a refer\xEAncia completa do canal. Valores desconhecidos aparecem como desconhecido.${videos.length ? "" : " Exporta\xE7\xF5es sem linhas n\xE3o incluem esses totais; consulte este resumo."}`;
    for (const video of videos) {
      const row3 = element3("tr"), title = element3("td"), a = element3("a", video.title);
      a.href = safeLink(video.url);
      a.target = "_blank";
      a.rel = "noopener noreferrer";
      title.append(a, element3("small", video.channel ?? "Canal indispon\xEDvel"));
      row3.append(title);
      for (const val of [
        compact(video.views),
        compact(lifetimeVph(video)),
        (() => {
          const comparison = researchComparison(video, snapshot.videos, readVideoFilter().comparisonMode);
          return `${comparison.score?.toFixed(1).concat("\xD7") ?? "desconhecido"} \xB7 m\xE9todo previsto ${comparison.method} \xB7 denominador ${comparison.reference === void 0 ? "desconhecido" : String(comparison.reference)} \xB7 ${comparison.referenceCount} candidatos (${comparison.positiveReferenceCount} positivas) \xB7 origem ${comparison.provenance}`;
        })(),
        compact(video.subscribers),
        video.durationSeconds === void 0 ? "\u2014" : `${Math.floor(video.durationSeconds / 60)}:${String(Math.floor(video.durationSeconds % 60)).padStart(2, "0")}`,
        video.publishedAt ? new Date(video.publishedAt).toLocaleDateString("pt-BR") : "\u2014"
      ])
        row3.append(element3("td", val));
      const action = element3("td"), save = element3("button", "+ Salvar");
      save.addEventListener("click", () => {
        void saveVideo(video).catch(fail);
      });
      action.append(save);
      row3.append(action);
      body.append(row3);
    }
    if (!videos.length) {
      const row3 = element3("tr"), cell = element3(
        "td",
        "Nenhum v\xEDdeo carregado corresponde aos filtros. Abra o YouTube e colete a aba."
      );
      cell.colSpan = 8;
      row3.append(cell);
      body.append(row3);
    }
  }
  function renderMetrics(videos) {
    const summary = summarizeVideos(videos);
    $("metrics").replaceChildren();
    for (const [name, val, note] of [
      [
        "V\xCDDEOS FILTRADOS",
        compact(summary.count),
        `${summary.shorts} Shorts identificados`
      ],
      [
        "VIEWS CONHECIDAS",
        compact(summary.knownViews ? summary.totalViews : void 0),
        `${summary.knownViews} v\xEDdeos com dados`
      ],
      [
        "MEDIANA DE VIEWS",
        compact(summary.medianViews),
        `M\xE9dia ${compact(summary.meanViews)} \xB7 amostra filtrada`
      ],
      [
        "MEDIANA DE VPH M\xC9DIO",
        compact(summary.medianVph),
        "Desde a publica\xE7\xE3o; n\xE3o \xE9 a \xFAltima hora"
      ]
    ]) {
      const card = element3("div");
      card.className = "metric";
      card.append(
        element3("span", name),
        element3("strong", val),
        element3("small", note)
      );
      $("metrics").append(card);
    }
  }
  function render() {
    studioOverview.render();
    renderVideos();
    renderComments();
    $("current-video").textContent = `${snapshot.title || "Nenhum v\xEDdeo selecionado"}${snapshot.videoId ? " \xB7 " + snapshot.videoId : ""}`;
    $("transcript-text").value = transcriptText(segments);
    invalidateTranscriptContext();
    if (snapshot.studio?.revenue !== void 0)
      $("revenue").value = String(snapshot.studio.revenue);
    $("swipe-title").value = snapshot.title;
    $("swipe-url").value = snapshot.url;
    if (!value("channel-url"))
      $("channel-url").value = snapshot.videos.find((v) => v.id === snapshot.videoId)?.channelUrl ?? snapshot.videos.find((v) => v.channelUrl)?.channelUrl ?? (/^https:\/\/www\.youtube\.com\/(?:@|channel\/)/.test(snapshot.url) ? snapshot.url.replace(
        /\/(?:videos|shorts|featured|about)(?:[?#].*)?$/,
        ""
      ) : "");
  }
  for (const id of filterIds)
    $(id).addEventListener("input", () => {
      try {
        renderVideos();
        if ($("notice").classList.contains("error"))
          notice("Filtros atualizados na amostra coletada.");
      } catch (error) {
        fail(error);
      }
    });
  on("reset-filters", () => {
    for (const id of filterIds)
      $(id).value = id === "short-filter" ? "all" : id === "sort" ? "views" : "";
    researchTools?.reset();
    renderVideos();
    notice("Filtros do painel limpos.");
  });
  on("apply-page-filter", async () => {
    visibleVideos();
    const result = await tabMessage(
      "APPLY_FILTER",
      {
        filter: {
          ...readVideoFilter(),
          sort: value("sort") === "date" ? "recent" : value("sort")
        }
      }
    );
    notice(
      `Filtros aplicados na aba: ${result.visible} de ${result.total} cards vis\xEDveis.`
    );
  });
  on("clear-page-filter", async () => {
    await tabMessage("CLEAR_FILTER");
    notice(
      "Filtros da aba YouTube removidos. A prefer\xEAncia Ocultar Shorts continua ativa se selecionada."
    );
  });
  function workspaceExportRows() {
    const mode = readVideoFilter().comparisonMode ?? "sample-median";
    const excludedApi = snapshot.videos.filter((video) => video.source === "youtube-data-api").length;
    const videos = visibleVideos();
    return videos.map((video) => {
      const comparison = researchComparison(video, snapshot.videos, mode);
      return {
        ...video,
        vph: lifetimeVph(video),
        outlier: comparison.score ?? null,
        outlier_status: comparison.score === void 0 ? "desconhecido" : "conhecido",
        outlier_reference_count: comparison.referenceCount,
        outlier_comparison_mode: mode,
        outlier_method: comparison.method,
        outlier_reference_status: comparison.reference === void 0 ? "desconhecido" : comparison.reference === 0 ? "zero" : "conhecido",
        observation_source: video.source ?? "desconhecido",
        outlier_target_exclusion: "same-video-id",
        outlier_count_unit: "observations",
        outlier_reference: comparison.reference ?? "desconhecido",
        outlier_positive_reference_count: comparison.positiveReferenceCount,
        outlier_provenance: comparison.provenance,
        outlier_limitation: comparison.limitation,
        sample_input_count: snapshot.videos.length,
        sample_included_count: videos.length,
        excluded_api_count: excludedApi,
        excluded_by_filter_count: snapshot.videos.length - excludedApi - videos.length
      };
    });
  }
  on(
    "export-json",
    () => textFile(
      JSON.stringify(workspaceExportRows(), null, 2),
      "prevlev-videos.json",
      "application/json"
    )
  );
  on("export-csv", () => {
    const rows = workspaceExportRows();
    const columns = rows.length ? [...new Set(rows.flatMap((row3) => Object.keys(row3)))] : [
      "id",
      "title",
      "url",
      "channel",
      "channelId",
      "channelUrl",
      "views",
      "publishedAt",
      "durationSeconds",
      "subscribers",
      "isShort",
      "thumbnail",
      "source",
      "observedAt",
      "vph",
      "outlier",
      "outlier_status",
      "outlier_reference_count",
      "outlier_comparison_mode",
      "outlier_method",
      "outlier_reference_status",
      "observation_source",
      "outlier_target_exclusion",
      "outlier_count_unit",
      "outlier_reference",
      "outlier_positive_reference_count",
      "outlier_provenance",
      "outlier_limitation",
      "sample_input_count",
      "sample_included_count",
      "excluded_api_count",
      "excluded_by_filter_count"
    ];
    textFile(toCsv(rows, columns), "prevlev-videos.csv", "text/csv");
  });
  on("copy-title", async () => {
    const result = await tabMessage("GET_CURRENT_METADATA");
    if (!result.metadata) throw new Error("A aba selecionada n\xE3o devolveu metadados atuais.");
    await navigator.clipboard.writeText(`${result.metadata.title}
${result.metadata.id ?? result.metadata.url}`);
    notice("T\xEDtulo e ID copiados.");
  });
  on("monetization", async () => {
    $("video-result").textContent = JSON.stringify(
      await tabMessage("GET_MONETIZATION"),
      null,
      2
    );
  });
  on("frame", async () => {
    const r = await tabMessage("CAPTURE_FRAME");
    downloadBlob(await (await fetch(r.dataUrl)).blob(), "prevlev-frame.png");
    notice("Frame capturado localmente.");
  });
  async function screenshot(kind) {
    const tabId = targetTab();
    const capture = await chrome.runtime.sendMessage({
      type: "CAPTURE_SCREENSHOT",
      tabId,
      kind,
      redact: $("redact").checked,
      ...$("redact").checked && kind !== "video" ? { redactionCategories: getRedactionCategories() } : {}
    });
    if (capture.status !== "ok") throw new Error(capture.error);
    const details = capture.capture;
    if (!details?.captureStamp || !details.rect || !details.viewportWidth)
      throw new Error(
        "A captura n\xE3o retornou uma medi\xE7\xE3o validada; imagem descartada."
      );
    const image = await loadImage(capture.dataUrl);
    downloadBlob(
      await cropScreenshot(
        capture.dataUrl,
        details.rect,
        image.naturalWidth / details.viewportWidth,
        details.redactions
      ),
      `prevlev-${kind}.png`
    );
    notice(
      details.coarse ? `Captura salva com oculta\xE7\xE3o ampla (${(details.coarseSelectors ?? []).join(", ")}). Confira a imagem antes de compartilhar.` : "Captura da \xE1rea vis\xEDvel salva. Confira a oculta\xE7\xE3o antes de compartilhar."
    );
  }
  on("card-shot", () => screenshot("video"));
  on("analytics-shot", () => screenshot("analytics"));
  on("latest-shot", () => screenshot("latest-performance"));
  function renderChannel() {
    for (const [id, sort] of [
      ["channel-recent", "recent"],
      ["channel-popular", "views"]
    ]) {
      const container = $(id);
      container.replaceChildren();
      const records = sortVideos(channelVideos, sort).slice(0, 10);
      for (const video of records) {
        const row3 = element3("article");
        row3.className = "channel-video";
        const a = element3("a", video.title);
        a.href = safeLink(video.url);
        a.target = "_blank";
        a.rel = "noopener noreferrer";
        row3.append(
          a,
          element3(
            "small",
            `${compact(video.views)} views \xB7 ${video.publishedAt ? new Date(video.publishedAt).toLocaleDateString("pt-BR") : "data indispon\xEDvel"}`
          )
        );
        const save = element3("button", "+ Salvar refer\xEAncia");
        save.addEventListener("click", () => {
          void saveVideo(video).catch(fail);
        });
        row3.append(save);
        container.append(row3);
      }
      if (!records.length)
        container.append(element3("p", "Nenhum v\xEDdeo dispon\xEDvel nesta amostra."));
    }
    $("channel-use").disabled = !channelVideos.length;
  }
  on("channel-load", async () => {
    $("channel-load").disabled = true;
    notice("Consultando a primeira p\xE1gina p\xFAblica do canal no YouTube\u2026");
    try {
      const r = await chrome.runtime.sendMessage({
        type: "CHANNEL_RESEARCH",
        channelUrl: value("channel-url").trim()
      });
      if (r.status !== "ok") throw new Error(r.error);
      const data = r.data;
      channelVideos = data.videos.map((video) => ({
        ...video,
        source: video.source ?? "public-page",
        observedAt: video.observedAt ?? (/* @__PURE__ */ new Date()).toISOString()
      }));
      renderChannel();
      $("channel-source").textContent = `${data.channelName ?? data.channelUrl} \xB7 ${channelVideos.length} v\xEDdeos encontrados na primeira resposta p\xFAblica. ${data.warnings.join(" ")}`;
      notice(
        "Amostra p\xFAblica carregada. A lista n\xE3o representa todo o cat\xE1logo do canal."
      );
    } finally {
      $("channel-load").disabled = false;
    }
  });
  on("channel-loaded", () => {
    const url = value("channel-url").trim().replace(/\/$/, "");
    channelVideos = snapshot.videos.filter(
      (v) => !url || v.channelUrl?.replace(/\/$/, "") === url
    );
    renderChannel();
    $("channel-source").textContent = `${channelVideos.length} v\xEDdeos da coleta atual${url ? " com URL de canal correspondente" : ""}. N\xE3o foi feita consulta de rede.`;
  });
  on("channel-use", async () => {
    const videos = new Map(snapshot.videos.map((v) => [v.id, v]));
    for (const video of channelVideos)
      videos.set(video.id, { ...videos.get(video.id), ...video });
    snapshot.videos = [...videos.values()];
    nicheTools.invalidate();
    cardComposer.invalidateSnapshot();
    await chrome.storage.local.set({ snapshot });
    render();
    notice(
      `${channelVideos.length} v\xEDdeos da amostra do canal adicionados \xE0 pesquisa.`
    );
  });
  on("sample-monetization", async () => {
    const videos = channelVideos.length ? channelVideos : snapshot.videos;
    if (!videos.length)
      throw new Error("Colete v\xEDdeos ou consulte um canal primeiro.");
    $("sample-monetization").disabled = true;
    notice("Examinando marcadores em p\xE1ginas p\xFAblicas de uma amostra limitada\u2026");
    try {
      const r = await chrome.runtime.sendMessage({
        type: "SAMPLE_MONETIZATION",
        videos,
        maxSamples: num("monetization-count")
      });
      if (r.status !== "ok") throw new Error(r.error);
      $("channel-monetization").textContent = JSON.stringify(r.data, null, 2);
      notice(
        "Amostra examinada. O resultado n\xE3o confirma receita nem monetiza\xE7\xE3o do canal."
      );
    } finally {
      $("sample-monetization").disabled = false;
    }
  });
  function timeLabel(seconds) {
    const value2 = Math.max(0, Math.floor(seconds));
    return `${Math.floor(value2 / 60)}:${String(value2 % 60).padStart(2, "0")}`;
  }
  function renderTimeline() {
    const state = timeline;
    const slider = $("timeline-range");
    slider.disabled = !state?.available || !state.duration;
    slider.max = String(state?.duration ?? 0);
    slider.value = String(state?.currentTime ?? 0);
    $("timeline-state").textContent = state?.available ? `${timeLabel(state.currentTime)} / ${state.duration ? timeLabel(state.duration) : "dura\xE7\xE3o indispon\xEDvel"} \xB7 ${state.paused ? "Pausado" : "Reproduzindo"} \xB7 ${state.limitations.join(" ")}` : "Nenhum v\xEDdeo carregado na aba selecionada.";
    const list = $("timeline-segments");
    list.replaceChildren();
    const query = value("timeline-query").toLocaleLowerCase();
    for (const segment of (state?.segments ?? []).filter((s) => !query || s.text.toLocaleLowerCase().includes(query)).slice(0, 500)) {
      const b = element3(
        "button",
        `${timeLabel(segment.start)} \xB7 ${segment.text}`
      );
      b.addEventListener("click", () => {
        void updateTimeline("SEEK_VIDEO", {
          seconds: segment.start,
          expectedVideoId: state?.videoId
        }).catch(fail);
      });
      list.append(b);
    }
    if (!list.childNodes.length)
      list.append(
        element3(
          "p",
          "Abra a transcri\xE7\xE3o no YouTube e atualize a timeline para navegar por trechos."
        )
      );
  }
  async function updateTimeline(type = "GET_TIMELINE", extra = {}) {
    const r = await tabMessage(type, extra);
    if (!r.state)
      throw new Error(
        "O content script n\xE3o disponibilizou a timeline. Recarregue a aba YouTube."
      );
    timeline = r.state;
    renderTimeline();
  }
  on("timeline-refresh", () => updateTimeline());
  on(
    "timeline-toggle",
    () => updateTimeline("TOGGLE_PLAYBACK", { expectedVideoId: timeline?.videoId })
  );
  for (const [id, delta] of [
    ["timeline-back", -5],
    ["timeline-forward", 5],
    ["timeline-frame-back", -1 / 30],
    ["timeline-frame-forward", 1 / 30]
  ])
    on(id, async () => {
      if (!timeline?.available) await updateTimeline();
      if (!timeline?.available)
        throw new Error("Abra um v\xEDdeo na aba selecionada.");
      await updateTimeline("SEEK_VIDEO", {
        seconds: Math.max(0, timeline.currentTime + delta),
        expectedVideoId: timeline.videoId
      });
    });
  $("timeline-range").addEventListener("change", () => {
    void updateTimeline("SEEK_VIDEO", {
      seconds: num("timeline-range"),
      expectedVideoId: timeline?.videoId
    }).catch(fail);
  });
  $("timeline-query").addEventListener("input", renderTimeline);
  $("tab-select").addEventListener("change", () => {
    timeline = void 0;
    renderTimeline();
  });
  on("timeline-capture", async () => {
    const r = await tabMessage("CAPTURE_FRAME");
    downloadBlob(await (await fetch(r.dataUrl)).blob(), "prevlev-frame.png");
    notice("Frame capturado localmente.");
  });
  $("transcript-file").addEventListener("change", () => {
    void (async () => {
      const file = $("transcript-file").files?.[0];
      if (!file) return;
      if (file.size > 5e6) throw new Error("Use arquivo de at\xE9 5 MB.");
      const text2 = await file.text(), parsed = parseTranscript(text2);
      segments = parsed;
      $("transcript-text").value = parsed.length ? transcriptText(parsed) : text2;
      invalidateTranscriptContext();
      notice(
        parsed.length ? `${parsed.length} segmentos importados.` : "Texto importado sem timestamps reconhecidos."
      );
    })().catch(fail);
  });
  function transcriptContent() {
    return $("transcript-text").value;
  }
  function timedSegments() {
    if (!segments.length || transcriptContent() !== transcriptText(segments))
      throw new Error(
        "Timestamps originais necess\xE1rios. Colete ou importe segmentos e mantenha o texto sem edi\xE7\xE3o para exportar VTT."
      );
    return segments;
  }
  on("transcript-copy", async () => {
    await navigator.clipboard.writeText(transcriptContent());
    notice("Transcri\xE7\xE3o copiada.");
  });
  on(
    "transcript-txt",
    () => textFile(transcriptContent(), "prevlev-transcricao.txt")
  );
  on(
    "transcript-vtt",
    () => textFile(
      transcriptVtt(timedSegments()),
      "prevlev-transcricao.vtt",
      "text/vtt"
    )
  );
  on(
    "transcript-md",
    () => textFile(
      segments.length && transcriptContent() === transcriptText(segments) ? transcriptMarkdown(segments, snapshot.title) : transcriptContent(),
      "prevlev-transcricao.md",
      "text/markdown"
    )
  );
  on("profit", () => {
    const r = netProfit(num("revenue"), num("cost"), num("video-total"));
    $("profit-output").textContent = `${r.profit.toLocaleString("pt-BR", { maximumFractionDigits: 2 })} ${snapshot.studio?.currency ?? "(mesma moeda da receita)"}`;
  });
  on("period", async () => {
    $("studio-plan").textContent = JSON.stringify(
      await tabMessage("STUDIO_PERIOD", {
        start: value("period-start"),
        end: value("period-end")
      }),
      null,
      2
    );
  });
  function invalidateStudioPreview() {
    studioPreviewGeneration++;
    planId = void 0;
    planTab = void 0;
    $("studio-plan").textContent = "";
    $("studio-confirm").disabled = true;
  }
  on("studio-preview", async () => {
    invalidateStudioPreview();
    $("studio-plan").textContent = "Preparando pr\xE9via\u2026";
    const generation = studioPreviewGeneration;
    const tabId = targetTab();
    const action = value("studio-action");
    const localPlan = action === "midrolls" ? midrollTools.getPlan() : void 0;
    const positions = localPlan?.positions;
    let plan;
    try {
      plan = await chrome.tabs.sendMessage(tabId, {
        type: "STUDIO_PREVIEW",
        action,
        input: { limit: num("action-limit"), positions, ...value("studio-fps") ? { fps: num("studio-fps") } : {} }
      });
    } catch (error) {
      if (generation !== studioPreviewGeneration) return;
      throw error;
    }
    if (generation !== studioPreviewGeneration) return;
    if (plan.status === "error") throw new Error(plan.error);
    planId = plan.status === "ready" ? plan.id : void 0;
    planTab = tabId;
    $("studio-plan").textContent = JSON.stringify(localPlan ? { ...plan, planejamentoLocal: localPlan } : plan, null, 2);
    $("studio-confirm").disabled = !planId;
  });
  on("studio-confirm", async () => {
    if (runningPlan) throw new Error("Aguarde a a\xE7\xE3o atual terminar.");
    if (!planId || targetTab() !== planTab || !planTab)
      throw new Error("Prepare uma nova pr\xE9via para a aba selecionada.");
    const active = { id: planId, tabId: planTab };
    runningPlan = active;
    planId = void 0;
    $("studio-confirm").disabled = true;
    $("studio-preview").disabled = true;
    try {
      $("studio-plan").textContent = JSON.stringify(
        await chrome.tabs.sendMessage(active.tabId, {
          type: "STUDIO_EXECUTE",
          planId: active.id
        }),
        null,
        2
      );
    } finally {
      runningPlan = void 0;
      $("studio-preview").disabled = false;
    }
  });
  on("studio-cancel", async () => {
    const active = runningPlan ?? (planId && planTab ? { id: planId, tabId: planTab } : void 0);
    invalidateStudioPreview();
    if (active)
      await chrome.tabs.sendMessage(active.tabId, {
        type: "STUDIO_CANCEL",
        planId: active.id
      });
    notice("Cancelamento solicitado. A\xE7\xF5es j\xE1 enviadas n\xE3o s\xE3o desfeitas.");
  });
  for (const id of [
    "studio-action",
    "action-limit",
    "studio-fps",
    "duration",
    "interval",
    "tab-select"
  ]) {
    $(id).addEventListener("input", invalidateStudioPreview);
    $(id).addEventListener("change", invalidateStudioPreview);
  }
  $("studio").addEventListener("input", (event) => {
    if (event.target instanceof Element && (event.target.closest("#midroll-tools") || event.target.id === "midroll-audio")) invalidateStudioPreview();
  });
  function displayRemote(response, output) {
    $("remote-images").replaceChildren();
    const data = response.data && typeof response.data === "object" ? response.data : void 0;
    const images = Array.isArray(data?.images) ? data.images : [];
    for (const raw of images.slice(0, 1)) {
      if (!raw || typeof raw !== "object") continue;
      const result = raw;
      const base64 = typeof result.base64 === "string" && result.base64.length < 24e6 && /^[A-Za-z0-9+/=]+$/.test(result.base64) ? result.base64 : void 0;
      const url = base64 ? `data:${["image/png", "image/jpeg", "image/webp"].includes(String(result.mime)) ? result.mime : "image/png"};base64,${base64}` : typeof result.url === "string" && result.url.startsWith("https://") ? safeLink(result.url) : void 0;
      if (!url || url === "#") continue;
      const image = element3("img");
      image.alt = "Thumbnail gerada pelo provedor configurado";
      image.src = url;
      image.style.cssText = "max-width:100%;max-height:500px;border-radius:8px";
      const link = element3("a", "Abrir / salvar imagem gerada");
      link.href = url;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      if (base64)
        link.download = `prevlev-gerada.${result.mime === "image/jpeg" ? "jpg" : result.mime === "image/webp" ? "webp" : "png"}`;
      $("remote-images").append(image, element3("p"), link);
    }
    $(output).textContent = JSON.stringify(
      images.length ? {
        ...response,
        data: {
          ...data,
          images: images.map(() => ({ image: "Veja a imagem acima." }))
        }
      } : response,
      null,
      2
    );
  }
  async function remote(feature, output = "remote-result", extra = {}) {
    const ai = isAiFeature(feature);
    if (ai && (aiRequestRunning || aiSelectionSaving))
      throw new Error(
        "Aguarde a an\xE1lise ou o salvamento da sele\xE7\xE3o atual concluir."
      );
    if (ai) {
      aiRequestRunning = true;
      updateAiButtons();
    }
    try {
      notice("Enviando ao backend configurado\u2026");
      const query = value("remote-query");
      const current = snapshot.videos.find((v) => v.id === snapshot.videoId);
      let payload;
      if (feature === "comment-analysis")
        payload = { comments: currentComments() };
      else if (feature === "thumbnail-generation") payload = { prompt: query };
      else if (feature.startsWith("transcript-"))
        payload = { text: transcriptContent() };
      else if (feature === "sponsorships") payload = { text: query };
      else if (feature === "view-history")
        payload = {
          videoId: snapshot.videoId ?? query.trim(),
          views: current?.views
        };
      else
        payload = {
          videos: snapshot.videos,
          query,
          targetId: feature === "similar-channels" ? current?.channelId ?? current?.channel : snapshot.videoId
        };
      const settings = await getSettings();
      const response = await callBackend(settings, feature, {
        ...payload,
        ...extra,
        ...isAiFeature(feature) ? {
          model: settings.aiModel,
          stream: feature === "thumbnail-generation" ? false : settings.aiStreaming,
          expectedOrigin: settings.aiOrigin
        } : {}
      });
      if (output !== null) displayRemote(response, output);
      notice(
        response.status === "ok" ? `An\xE1lise conclu\xEDda \xB7 ${response.source}` : response.error ?? "Recurso n\xE3o configurado.",
        response.status === "error"
      );
      return response;
    } finally {
      if (ai) {
        aiRequestRunning = false;
        updateAiButtons();
      }
    }
  }
  on("remote-run", () => remote(value("remote-feature")));
  for (const b of document.querySelectorAll("[data-ai]"))
    b.addEventListener("click", () => {
      void (async () => {
        const feature = b.dataset.ai;
        const request = transcriptExtras?.beginAi(feature);
        if (!request || request.cached) return;
        try {
          const response = await remote(feature, null, { text: transcriptContent() });
          transcriptExtras?.completeAi(feature, response, request.requestId);
        } catch (error) {
          transcriptExtras?.failAi(feature, error, request.requestId);
          throw error;
        }
      })().catch(fail);
    });
  function updateAiButtons() {
    const model = aiCatalog?.models.find((m) => m.id === selectedAiModel);
    const busy = aiRequestRunning || aiSelectionSaving;
    const textBlocked = busy || !!aiCatalog && (!model?.textSupported || selectedAiStreaming && !(model.streaming && model.operations.includes("responses")));
    for (const button of document.querySelectorAll(
      "[data-ai]"
    ))
      button.disabled = textBlocked;
    $("comments-ai").disabled = textBlocked;
    const feature = value("remote-feature");
    $("remote-run").disabled = isAiFeature(feature) && (busy || !!aiCatalog && (feature === "thumbnail-generation" ? !model?.imageSupported : textBlocked));
    $("ai-selected-label").textContent = selectedAiModel ? `${selectedAiModel} \xB7 ${selectedAiStreaming ? "streaming solicitado" : "JSON"} \xB7 backend revalida antes de enviar` : "Nenhum modelo selecionado. Consulte o OmniProviders na aba Conex\xE3o.";
  }
  async function persistAiSelection() {
    aiSelectionSaving = true;
    updateAiButtons();
    $("ai-provider-select").disabled = true;
    $("ai-model-select").disabled = true;
    $("ai-stream").disabled = true;
    try {
      const old = await getSettings();
      await saveSettings({
        ...old,
        aiModel: selectedAiModel,
        aiOrigin: selectedAiOrigin,
        aiStreaming: selectedAiStreaming
      });
    } catch (error) {
      const old = await getSettings();
      selectedAiModel = old.aiModel;
      selectedAiOrigin = old.aiOrigin;
      selectedAiStreaming = old.aiStreaming;
      throw error;
    } finally {
      aiSelectionSaving = false;
      $("ai-provider-select").disabled = false;
      renderAiSelection();
    }
  }
  function renderAiSelection(providerFilter) {
    const provider = $("ai-provider-select");
    const chosenProvider = providerFilter ?? (provider.value || selectedAiModel.split(":")[0] || "");
    provider.replaceChildren();
    const placeholder = element3("option", "Selecione um provedor");
    placeholder.value = "";
    provider.append(placeholder);
    const providers = aiCatalog ? [...new Set(aiCatalog.models.map((m) => m.provider))].sort() : selectedAiModel ? [selectedAiModel.split(":")[0]] : [];
    for (const id of providers) {
      const option = element3("option", id);
      option.value = id;
      provider.append(option);
    }
    provider.value = chosenProvider;
    const models = $("ai-model-select");
    models.replaceChildren();
    const empty = element3("option", "Nenhum modelo selecionado");
    empty.value = "";
    models.append(empty);
    for (const model of (aiCatalog?.models ?? []).filter(
      (m) => m.provider === chosenProvider
    )) {
      const option = element3(
        "option",
        `${model.label} \xB7 ${model.id}${model.textSupported ? " \xB7 texto" : ""}${model.imageSupported ? " \xB7 imagem" : ""}${!model.textSupported && !model.imageSupported ? " \xB7 capacidade n\xE3o utilizada pelo Prevlev" : ""}`
      );
      option.value = model.id;
      option.disabled = !model.textSupported && !model.imageSupported;
      models.append(option);
    }
    if (selectedAiModel && !Array.from(models.options).some((o) => o.value === selectedAiModel)) {
      const saved = element3(
        "option",
        `${selectedAiModel} \xB7 ${aiCatalog ? "indispon\xEDvel no cat\xE1logo atual" : "salvo; cat\xE1logo ainda n\xE3o consultado"}`
      );
      saved.value = selectedAiModel;
      saved.disabled = true;
      models.append(saved);
    }
    models.value = selectedAiModel;
    models.disabled = !aiCatalog || !chosenProvider;
    const selected = aiCatalog?.models.find((m) => m.id === selectedAiModel);
    const supportsStream = selected?.textSupported && selected.streaming && selected.operations.includes("responses");
    const streaming = $("ai-stream");
    streaming.checked = selectedAiStreaming;
    streaming.disabled = !selected?.textSupported || !supportsStream && !selectedAiStreaming;
    $("ai-origin").value = aiCatalog?.origin ?? selectedAiOrigin;
    $("ai-capabilities").textContent = selected ? `Sa\xEDda: ${selected.outputModalities.join(", ") || "n\xE3o anunciada"}. Opera\xE7\xF5es: ${selected.operations.join(", ") || "nenhuma"}.${selectedAiStreaming && !supportsStream ? " O streaming salvo n\xE3o est\xE1 dispon\xEDvel; desmarque a op\xE7\xE3o ou escolha outro modelo." : ""}` : aiCatalog ? selectedAiModel ? "O modelo salvo n\xE3o est\xE1 dispon\xEDvel. Escolha um modelo do cat\xE1logo; nenhuma alternativa foi selecionada." : "Escolha provedor e modelo. Apenas capacidades anunciadas s\xE3o habilitadas." : "Capacidades ainda n\xE3o consultadas. A origem exibida \xE9 configura\xE7\xE3o, n\xE3o uma confirma\xE7\xE3o de conex\xE3o.";
    updateAiButtons();
  }
  on("ai-discover", async () => {
    $("ai-discover").disabled = true;
    $("ai-catalog-status").textContent = "Consultando o cat\xE1logo pela ponte Prevlev\u2026";
    try {
      const response = await fetchAiCatalog(await getSettings());
      if (response.status !== "ok" || !response.data) {
        $("ai-catalog-status").textContent = response.error ?? "Cat\xE1logo n\xE3o dispon\xEDvel.";
        throw new Error(response.error ?? "Cat\xE1logo n\xE3o dispon\xEDvel.");
      }
      aiCatalog = response.data;
      if (selectedAiModel && selectedAiOrigin !== aiCatalog.origin) {
        selectedAiModel = "";
        selectedAiStreaming = false;
        const old = await getSettings();
        await saveSettings({ ...old, aiModel: "", aiStreaming: false });
        $("ai-catalog-status").textContent = "A origem do OmniProviders mudou. Selecione novamente o provedor e modelo antes de enviar dados.";
      } else
        $("ai-catalog-status").textContent = `${aiCatalog.models.length} modelos anunciados. ${aiCatalog.warnings.join(" ")} Cat\xE1logo n\xE3o comprova saldo nem aceita\xE7\xE3o de gera\xE7\xE3o.`;
      renderAiSelection();
      notice("Cat\xE1logo consultado. Nenhuma gera\xE7\xE3o foi iniciada.");
    } catch (error) {
      $("ai-catalog-status").textContent = error instanceof Error ? error.message : String(error);
      throw error;
    } finally {
      $("ai-discover").disabled = false;
    }
  });
  $("ai-provider-select").addEventListener("change", () => {
    void (async () => {
      if (aiSelectionSaving) return;
      const provider = value("ai-provider-select");
      selectedAiModel = "";
      selectedAiStreaming = false;
      await persistAiSelection();
      renderAiSelection(provider);
    })().catch(fail);
  });
  $("ai-model-select").addEventListener("change", () => {
    void (async () => {
      if (aiSelectionSaving) return;
      const model = aiCatalog?.models.find(
        (m) => m.id === value("ai-model-select")
      );
      if (!model || !model.textSupported && !model.imageSupported)
        throw new Error(
          "Escolha um modelo com capacidade anunciada para texto ou imagem."
        );
      selectedAiModel = model.id;
      selectedAiOrigin = aiCatalog.origin;
      selectedAiStreaming = false;
      await persistAiSelection();
      renderAiSelection(model.provider);
      $("ai-catalog-status").textContent = `Sele\xE7\xE3o salva: ${model.id}. O cat\xE1logo ser\xE1 revalidado no pr\xF3ximo envio.`;
    })().catch(fail);
  });
  $("ai-stream").addEventListener("change", () => {
    void (async () => {
      if (aiSelectionSaving) return;
      const selected = aiCatalog?.models.find((m) => m.id === selectedAiModel);
      const checked = $("ai-stream").checked;
      if (checked && (!selected?.streaming || !selected.textSupported || !selected.operations.includes("responses"))) {
        $("ai-stream").checked = selectedAiStreaming;
        throw new Error("Este modelo n\xE3o anuncia streaming Responses de texto.");
      }
      selectedAiStreaming = checked;
      await persistAiSelection();
    })().catch(fail);
  });
  $("remote-feature").addEventListener("change", updateAiButtons);
  on("save-settings", async () => {
    const url = value("backend-url").trim(), origin = url ? backendOrigin(url) : "";
    if (origin) {
      const granted = await chrome.permissions.request({
        origins: [`${origin}/*`]
      });
      if (!granted)
        throw new Error("Acesso ao backend n\xE3o concedido pelo navegador.");
    }
    const old = await getSettings();
    await saveSettings({
      ...old,
      backendUrl: origin,
      backendToken: value("backend-token").trim(),
      ...old.backendUrl !== origin ? { aiModel: "", aiStreaming: false } : {}
    });
    if (old.backendUrl !== origin) {
      aiCatalog = void 0;
      selectedAiModel = "";
      selectedAiStreaming = false;
      renderAiSelection();
    }
    notice("Configura\xE7\xE3o salva. O envio continua sendo manual.");
  });
  on("clear-connection", async () => {
    const old = await getSettings();
    if (old.backendUrl)
      await chrome.permissions.remove({
        origins: [`${backendOrigin(old.backendUrl)}/*`]
      });
    await saveSettings({
      ...old,
      backendUrl: "",
      backendToken: "",
      aiModel: "",
      aiStreaming: false
    });
    aiCatalog = void 0;
    selectedAiModel = "";
    selectedAiStreaming = false;
    renderAiSelection();
    $("backend-url").value = "";
    $("backend-token").value = "";
    notice("Backend desconectado.");
  });
  on("clear-data", async () => {
    if (!window.confirm(
      "Apagar a coleta e toda a biblioteca deste perfil? Exporte antes de continuar."
    ))
      return;
    await chrome.storage.local.remove(["snapshot"]);
    await saveSwipe([]);
    snapshot = {
      url: "",
      title: "",
      videos: [],
      comments: [],
      transcript: [],
      warnings: []
    };
    nicheTools.invalidate();
    cardComposer.invalidateSnapshot();
    segments = [];
    render();
    await renderSwipe();
    notice("Dados locais apagados.");
  });
  var getRedactionCategories = initCaptureOptions();
  var midrollTools = mountMidrollTools(document, invalidateStudioPreview);
  var studioOverview = initStudioOverview({ snapshot: () => snapshot });
  var nicheTools = initNicheTools({ snapshot: () => snapshot });
  var cardComposer = initCardCompositionTools({ snapshot: () => snapshot });
  initVisualSimilarityTools();
  initImageTools({ notice, contextVideos: () => snapshot.videos });
  initCollectionTools({ targetTab, snapshot: () => snapshot, notice, adopt: async (next) => {
    snapshot = next;
    nicheTools.invalidate();
    cardComposer.invalidateSnapshot();
    segments = next.transcript;
    await chrome.storage.local.set({ snapshot });
    render();
  } });
  initSponsorshipTools();
  var researchTools = initResearchTools({ getUrl: () => snapshot.url, getVisibleVideos: visibleVideos, getAllVideos: () => snapshot.videos, onChange: () => {
    try {
      renderVideos();
      if ($("notice").classList.contains("error")) notice("Filtros de pesquisa atualizados.");
    } catch (error) {
      fail(error);
    }
  } });
  initSwipeSync(renderSwipe);
  initOfficialSearch();
  initAnalyticsTools({ snapshot: () => snapshot, filter: readVideoFilter });
  initHistoryTools({ snapshot: () => snapshot, filter: readVideoFilter });
  void (async () => {
    await tabs();
    const saved = await getSnapshot();
    if (saved) {
      snapshot = saved;
      nicheTools.invalidate();
      cardComposer.invalidateSnapshot();
      segments = saved.transcript;
    }
    const settings = await getSettings();
    $("backend-url").value = settings.backendUrl;
    $("backend-token").value = settings.backendToken;
    selectedAiModel = settings.aiModel;
    selectedAiOrigin = settings.aiOrigin;
    selectedAiStreaming = settings.aiStreaming;
    renderAiSelection();
    render();
    await renderSwipe();
  })().catch(fail);
})();
