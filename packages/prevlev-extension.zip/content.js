"use strict";
(() => {
  // src/shared/types.ts
  var defaultSettings = {
    hideShorts: false,
    showMetrics: true,
    backendUrl: "",
    backendToken: "",
    aiModel: "",
    aiStreaming: false,
    aiOrigin: "http://127.0.0.1:7814"
  };

  // src/core/parse.ts
  function parseCount(text2) {
    const cleaned = text2.normalize("NFKC").trim().toLocaleLowerCase().replace(/\u00a0/g, " ");
    const match = cleaned.match(
      /(\d[\d.,\s]*)\s*(bilh(?:ão|ões|ao|oes)|billions?|milh(?:ão|ões|ao|oes)|millions?|mil|[kmb])?(?=\s|$|[^a-zá-ú])/i
    );
    if (!match) return void 0;
    let digits = match[1].replace(/\s/g, "");
    const suffix = match[2] ?? "";
    const factor = /^(b|bilh|billion)/.test(suffix) ? 1e9 : /^(m$|milh|million)/.test(suffix) ? 1e6 : /^(k|mil$)/.test(suffix) ? 1e3 : 1;
    if (factor === 1) {
      digits = digits.replace(/[.,]/g, "");
    } else {
      const lastDot = digits.lastIndexOf("."), lastComma = digits.lastIndexOf(",");
      if (lastDot >= 0 && lastComma >= 0) {
        const decimal = Math.max(lastDot, lastComma);
        digits = digits.slice(0, decimal).replace(/[.,]/g, "") + "." + digits.slice(decimal + 1);
      } else digits = digits.replace(",", ".");
    }
    const value = Number(digits) * factor;
    return Number.isFinite(value) && value >= 0 ? Math.round(value) : void 0;
  }
  function parseDuration(value) {
    const text2 = value.trim();
    const iso = text2.match(
      /^PT(?:(\d+(?:\.\d+)?)H)?(?:(\d+(?:\.\d+)?)M)?(?:(\d+(?:\.\d+)?)S)?$/i
    );
    if (iso && iso.slice(1).some(Boolean))
      return Number(iso[1] ?? 0) * 3600 + Number(iso[2] ?? 0) * 60 + Number(iso[3] ?? 0);
    if (!/^\d+(?::\d{1,2}){1,2}$/.test(text2)) return void 0;
    const parts = text2.split(":").map(Number);
    if (parts.slice(1).some((number) => number >= 60)) return void 0;
    return parts.reduce((sum, number) => sum * 60 + number, 0);
  }
  function parsePublishedAt(text2, now = Date.now()) {
    const clean = text2.trim().toLowerCase();
    const relative = clean.match(
      /(?:há\s+)?(\d+)\s*(seconds?|segundos?|minutes?|minutos?|hours?|horas?|days?|dias?|weeks?|semanas?|months?|mês|meses|years?|anos?)(?:\s+ago)?/
    );
    if (relative) {
      const unit = relative[2], amount = Number(relative[1]);
      const seconds = /^(second|segundo)/.test(unit) ? 1 : /^(minute|minuto)/.test(unit) ? 60 : /^(hour|hora)/.test(unit) ? 3600 : /^(day|dia)/.test(unit) ? 86400 : /^(week|semana)/.test(unit) ? 604800 : /^(month|mês|mes)/.test(unit) ? 2629800 : 31557600;
      return new Date(now - amount * seconds * 1e3).toISOString();
    }
    if (!/\d{4}-\d{2}-\d{2}/.test(clean)) return void 0;
    const value = Date.parse(clean);
    return Number.isFinite(value) ? new Date(value).toISOString() : void 0;
  }
  function videoIdFromUrl(raw) {
    try {
      const url = new URL(raw, "https://www.youtube.com");
      if (!["youtube.com", "www.youtube.com", "m.youtube.com", "youtu.be"].includes(
        url.hostname
      ))
        return void 0;
      const id = url.hostname === "youtu.be" ? url.pathname.slice(1).split("/")[0] : url.searchParams.get("v") ?? url.pathname.match(/^\/(?:shorts|embed|live)\/([^/?]+)/)?.[1];
      return id && /^[\w-]{11}$/.test(id) ? id : void 0;
    } catch {
      return void 0;
    }
  }

  // src/core/export.ts
  function toCsv(rows, columns = rows.length ? Object.keys(rows[0]) : []) {
    const cell = (value) => {
      let text2 = value === void 0 || value === null ? "" : typeof value === "object" ? JSON.stringify(value) : String(value);
      if (typeof value === "string" && /^[\s]*[=+@-]/.test(text2))
        text2 = `'${text2}`;
      return `"${text2.replace(/"/g, '""')}"`;
    };
    return "\uFEFF" + [
      columns.map(cell).join(","),
      ...rows.map(
        (row) => columns.map((column) => cell(row[column])).join(",")
      )
    ].join("\r\n");
  }

  // src/core/observations.ts
  var normalizedName = (value) => value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase();
  function observedLifetimeVph(video, now = Date.now()) {
    if (video.views === void 0 || !Number.isFinite(video.views) || video.views < 0 || !video.publishedAt) return void 0;
    const published = knownPublication(video.publishedAt, now);
    if (published === void 0 || published >= now) return void 0;
    const result = video.views / ((now - published) / 36e5);
    return Number.isFinite(result) ? result : void 0;
  }
  function isoBoundary(value, endOfDay) {
    if (typeof value !== "string")
      throw new Error(
        "Informe uma data ISO v\xE1lida: AAAA-MM-DD ou timestamp com fuso hor\xE1rio."
      );
    const dateOnly = /^\d{4}-\d{2}-\d{2}$/.test(value);
    const timestamp3 = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::(\d{2})(?:\.(\d{1,3}))?)?(Z|[+-]\d{2}:\d{2})$/.exec(
      value
    );
    if (!dateOnly && !timestamp3)
      throw new Error(
        "Informe uma data ISO v\xE1lida: AAAA-MM-DD ou timestamp com fuso hor\xE1rio."
      );
    const [year, month, day] = value.slice(0, 10).split("-").map(Number);
    const leap = year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
    const days = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    if (month < 1 || month > 12 || day < 1 || day > days[month - 1])
      throw new Error("A data de publica\xE7\xE3o cont\xE9m um dia ou m\xEAs inv\xE1lido.");
    if (timestamp3) {
      const zone = timestamp3[8];
      if (Number(timestamp3[4]) > 23 || Number(timestamp3[5]) > 59 || Number(timestamp3[6] ?? 0) > 59 || zone !== "Z" && (Number(zone.slice(1, 3)) > 23 || Number(zone.slice(4)) > 59))
        throw new Error("O hor\xE1rio ou fuso da data de publica\xE7\xE3o \xE9 inv\xE1lido.");
    }
    const parsed = Date.parse(
      dateOnly ? `${value}T${endOfDay ? "23:59:59.999" : "00:00:00.000"}Z` : value
    );
    if (!Number.isFinite(parsed))
      throw new Error("A data de publica\xE7\xE3o \xE9 inv\xE1lida.");
    return parsed;
  }
  function knownPublication(value, now) {
    if (!Number.isFinite(now)) return void 0;
    try {
      const timestamp3 = isoBoundary(value, false);
      return timestamp3 <= now ? timestamp3 : void 0;
    } catch {
      return void 0;
    }
  }
  function channelIdentity(video) {
    const explicitId = video.channelId?.trim();
    let id = explicitId && /^[A-Za-z0-9_-]{1,128}$/.test(explicitId) ? explicitId : void 0;
    let handle;
    if (video.channelUrl) {
      try {
        const url = new URL(video.channelUrl);
        if (url.protocol === "https:" && ["www.youtube.com", "youtube.com", "m.youtube.com"].includes(
          url.hostname
        ) && !url.username && !url.password && !url.port) {
          const path = decodeURIComponent(url.pathname).replace(/\/$/, "");
          const linkedId = /^\/channel\/([A-Za-z0-9_-]{1,128})$/.exec(path)?.[1];
          if (id && linkedId && id !== linkedId) return { ambiguous: true };
          id ??= linkedId;
          handle = /^\/@([\p{L}\p{N}_.\-·]{1,100})$/u.exec(path)?.[1].normalize("NFC").toLocaleLowerCase();
        }
      } catch {
      }
    }
    const name = video.channel ? normalizedName(video.channel).trim().replace(/\s+/g, " ") || void 0 : void 0;
    return { id, handle, name };
  }
  function comparableChannel(target, peer) {
    if (target.ambiguous || peer.ambiguous) return false;
    if (!target.id && !target.handle && !target.name) return true;
    if (target.id && peer.id) return target.id === peer.id;
    if (target.handle && peer.handle) return target.handle === peer.handle;
    if (target.id || target.handle || peer.id || peer.handle) return false;
    return !!target.name && target.name === peer.name;
  }

  // src/core/swipe.ts
  var SWIPE_MAX_BYTES = 4 * 1024 * 1024;

  // src/shared/storage.ts
  var getSettings = async () => {
    const stored = (await chrome.storage.local.get("settings")).settings;
    return {
      ...defaultSettings,
      ...stored && typeof stored === "object" ? stored : {}
    };
  };
  var saveSettings = async (settings) => chrome.storage.local.set({ settings });
  var swipeWrites = Promise.resolve();

  // src/core/metrics.ts
  function median(values) {
    const sorted = values.filter(Number.isFinite).sort((a, b) => a - b);
    const middle = Math.floor(sorted.length / 2);
    return sorted.length ? sorted.length % 2 ? sorted[middle] : sorted[middle - 1] / 2 + sorted[middle] / 2 : void 0;
  }
  function lifetimeVph(video, now = Date.now()) {
    return observedLifetimeVph(video, now);
  }
  function outlierScore(video, baseline) {
    if (video.views === void 0 || !Number.isFinite(video.views) || video.views < 0)
      return void 0;
    const channel = channelIdentity(video);
    const values = baseline.filter(
      (other) => other.id !== video.id && other.isShort === video.isShort && comparableChannel(channel, channelIdentity(other))
    ).map((other) => other.views).filter(
      (value) => value !== void 0 && Number.isFinite(value) && value >= 0
    );
    if (values.length < 3) return void 0;
    const reference = median(values);
    return reference && reference > 0 ? video.views / reference : void 0;
  }
  function validateVideoFilter(filter) {
    const pairs = [
      ["minViews", "maxViews", "visualiza\xE7\xF5es"],
      ["minSubscribers", "maxSubscribers", "inscritos"],
      ["minVph", "maxVph", "VPH"],
      ["minOutlier", "maxOutlier", "outlier"],
      ["minDurationSeconds", "maxDurationSeconds", "dura\xE7\xE3o em segundos"]
    ];
    for (const [minKey, maxKey, label2] of pairs) {
      const min = filter[minKey], max = filter[maxKey];
      for (const value of [min, max]) {
        if (value !== void 0 && (typeof value !== "number" || !Number.isFinite(value) || value < 0))
          throw new Error(
            `O filtro de ${label2} exige valores finitos n\xE3o negativos.`
          );
      }
      if (min !== void 0 && max !== void 0 && min > max)
        throw new Error(
          `No filtro de ${label2}, o m\xEDnimo n\xE3o pode superar o m\xE1ximo.`
        );
    }
    const after = filter.publishedAfter === void 0 ? void 0 : isoBoundary(filter.publishedAfter, false);
    const before = filter.publishedBefore === void 0 ? void 0 : isoBoundary(filter.publishedBefore, true);
    if (after !== void 0 && before !== void 0 && after > before)
      throw new Error(
        "A data inicial de publica\xE7\xE3o n\xE3o pode superar a data final."
      );
    if (filter.shorts !== void 0 && !["all", "only", "exclude"].includes(filter.shorts))
      throw new Error("Selecione um filtro de Shorts v\xE1lido.");
  }
  function filterVideos(videos, filter, now = Date.now()) {
    validateVideoFilter(filter);
    const after = filter.publishedAfter === void 0 ? void 0 : isoBoundary(filter.publishedAfter, false);
    const before = filter.publishedBefore === void 0 ? void 0 : isoBoundary(filter.publishedBefore, true);
    const query = normalize(filter.query ?? "");
    return videos.filter((video) => {
      if (query && !normalize(`${video.title} ${video.channel ?? ""}`).includes(query))
        return false;
      if (filter.channel && !normalize(
        `${video.channel ?? ""} ${video.channelId ?? ""} ${video.channelUrl ?? ""}`
      ).includes(normalize(filter.channel)))
        return false;
      if (filter.shorts === "only" && video.isShort !== true || filter.shorts === "exclude" && video.isShort !== false)
        return false;
      if (after !== void 0 || before !== void 0) {
        const published = video.publishedAt ? knownPublication(video.publishedAt, now) : void 0;
        if (published === void 0 || after !== void 0 && published < after || before !== void 0 && published > before)
          return false;
      }
      const constraints = [
        [video.views, filter.minViews, filter.maxViews],
        [video.subscribers, filter.minSubscribers, filter.maxSubscribers],
        [
          video.durationSeconds,
          filter.minDurationSeconds,
          filter.maxDurationSeconds
        ],
        [lifetimeVph(video, now), filter.minVph, filter.maxVph],
        [outlierScore(video, videos), filter.minOutlier, filter.maxOutlier]
      ];
      return constraints.every(
        ([value, min, max]) => min === void 0 && max === void 0 || value !== void 0 && Number.isFinite(value) && value >= 0 && (min === void 0 || value >= min) && (max === void 0 || value <= max)
      );
    });
  }
  function sortVideos(videos, by, now = Date.now(), baseline = videos) {
    if (by === "title")
      return [...videos].sort((a, b) => a.title.localeCompare(b.title));
    const get = (video) => {
      if (by === "recent")
        return video.publishedAt ? knownPublication(video.publishedAt, now) : void 0;
      const value = by === "views" ? video.views : by === "duration" ? video.durationSeconds : by === "subscribers" ? video.subscribers : by === "vph" ? lifetimeVph(video, now) : outlierScore(video, baseline);
      return value !== void 0 && Number.isFinite(value) && value >= 0 ? value : void 0;
    };
    return [...videos].sort((a, b) => {
      const left = get(a), right = get(b);
      const knownLeft = left !== void 0 && Number.isFinite(left), knownRight = right !== void 0 && Number.isFinite(right);
      return knownLeft && knownRight ? right - left : knownLeft ? -1 : knownRight ? 1 : 0;
    });
  }
  function inferMonetization(html) {
    const patterns = [
      ["adPlacements", /"adPlacements"\s*:\s*\[\s*\{/],
      ["playerAds", /"playerAds"\s*:\s*\[\s*\{/],
      ["adSlots", /"adSlots"\s*:\s*\[\s*\{/],
      ["music-metadata", /"musicDescriptionShelfRenderer"\s*:/]
    ];
    const markers = patterns.filter(([, pattern]) => pattern.test(html)).map(([name]) => name);
    return {
      status: markers.length ? "markers-present" : "unknown",
      confidence: "low",
      markers,
      explanation: markers.length ? "Marcadores de an\xFAncio ou m\xFAsica encontrados. Isso n\xE3o confirma participa\xE7\xE3o no YPP, monetiza\xE7\xE3o do canal nem recebimento de receita pelo criador." : "Nenhum marcador reconhecido foi encontrado nesta resposta. Aus\xEAncia de marcadores n\xE3o prova desmonetiza\xE7\xE3o."
    };
  }
  function normalize(value) {
    return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase();
  }

  // src/core/research.ts
  function describeResearchComparison(comparison, mode = "sample-median") {
    return `Modo: ${mode}; m\xE9todo previsto: ${comparison.method}; refer\xEAncia: ${comparison.reference ?? "desconhecida"}; ${comparison.referenceCount} observa\xE7\xF5es candidatas (${comparison.positiveReferenceCount} positivas). Fonte: observa\xE7\xF5es carregadas anteriores aos filtros; formato declarado igual ou formato desconhecido em ambos, e canal compar\xE1vel. Alvo sem identidade usa candidatos da amostra geral, mas o modo de canal n\xE3o calcula refer\xEAncia sem identidade. Alvo exclu\xEDdo por ID; outras observa\xE7\xF5es repetidas podem ser contadas. API oficial exclu\xEDda. ${comparison.limitation}`;
  }
  var researchSortKeys = ["views", "vph", "outlier", "recent", "duration", "subscribers", "title", "viewsPerSubscriber"];
  var researchSurfaces = ["home", "subscriptions", "search", "channel", "other"];
  function researchSurface(rawUrl) {
    try {
      const url = new URL(rawUrl);
      if (url.protocol !== "https:" || !["www.youtube.com", "youtube.com", "m.youtube.com"].includes(url.hostname) || url.username || url.password || url.port) return "other";
      if (url.pathname === "/results") return "search";
      if (url.pathname === "/feed/subscriptions") return "subscriptions";
      if (url.pathname === "/") return "home";
      if (/^\/(?:@[^/]+|channel\/[^/]+|c\/[^/]+|user\/[^/]+)(?:\/|$)/.test(url.pathname)) return "channel";
      return "other";
    } catch {
      return "other";
    }
  }
  function validateResearchFilter(filter) {
    validateVideoFilter(filter);
    if (filter.surface !== void 0 && !researchSurfaces.includes(filter.surface)) throw new Error("Contexto de pesquisa desconhecido.");
    if (filter.criteria !== void 0 && (!Array.isArray(filter.criteria) || filter.criteria.length > 2)) throw new Error("Use no m\xE1ximo dois crit\xE9rios de ordena\xE7\xE3o.");
    const keys = /* @__PURE__ */ new Set();
    for (const criterion of filter.criteria ?? []) {
      if (!criterion || !researchSortKeys.includes(criterion.key) || !["asc", "desc"].includes(criterion.direction)) throw new Error("Crit\xE9rio ou dire\xE7\xE3o de ordena\xE7\xE3o inv\xE1lidos.");
      if (keys.has(criterion.key)) throw new Error("Os dois crit\xE9rios de ordena\xE7\xE3o devem ser diferentes.");
      if (criterion.key === "viewsPerSubscriber" && filter.surface === "channel") throw new Error("A raz\xE3o views por inscrito s\xF3 est\xE1 dispon\xEDvel fora de p\xE1ginas de canal.");
      keys.add(criterion.key);
    }
    if (filter.priority !== void 0 && !["none", "views-per-subscriber"].includes(filter.priority)) throw new Error("Prioridade de pesquisa inv\xE1lida.");
    if (filter.priority === "views-per-subscriber" && filter.surface === "channel") throw new Error("A prioridade views por inscrito s\xF3 est\xE1 dispon\xEDvel fora de p\xE1ginas de canal.");
    if (filter.comparisonMode !== void 0 && !["sample-median", "sample-channel-reference"].includes(filter.comparisonMode)) throw new Error("Modo de compara\xE7\xE3o de outlier desconhecido.");
    if (filter.subscribersBelow !== void 0 && (typeof filter.subscribersBelow !== "number" || !Number.isFinite(filter.subscribersBelow) || filter.subscribersBelow <= 0)) throw new Error("O limite exclusivo de inscritos deve ser finito e positivo.");
    if (filter.subscribersBelow !== void 0 && filter.minSubscribers !== void 0 && filter.minSubscribers >= filter.subscribersBelow) throw new Error("O m\xEDnimo de inscritos deve ser menor que o limite exclusivo.");
    if (filter.publishedBeforeExclusive !== void 0) {
      const before = isoBoundary(filter.publishedBeforeExclusive, false);
      if (filter.publishedAfter !== void 0 && isoBoundary(filter.publishedAfter, false) >= before) throw new Error("O in\xEDcio da publica\xE7\xE3o deve preceder o limite final exclusivo.");
    }
    for (const key of ["hideShortsOnFeed", "hideShortsOnSearch"]) if (filter[key] !== void 0 && typeof filter[key] !== "boolean") throw new Error("As prefer\xEAncias de Shorts devem ser booleanas.");
  }
  function viewsPerSubscriber(video) {
    if (video.source === "youtube-data-api") return void 0;
    const views = count(video.views), subscribers = count(video.subscribers);
    if (views === void 0 || subscribers === void 0 || subscribers <= 0) return void 0;
    return finite(views / subscribers);
  }
  function researchComparison(video, fullBaseline, mode = "sample-median") {
    const baseline = fullBaseline.filter((item) => item.source !== "youtube-data-api");
    const identity = channelIdentity(video);
    const peers = baseline.filter((peer) => peer.id !== video.id && peer.isShort === video.isShort && comparableChannel(identity, channelIdentity(peer)) && count(peer.views) !== void 0);
    const values = peers.map((peer) => peer.views);
    const positive2 = values.filter((value) => value > 0);
    const limitation = "Compara\xE7\xE3o aproximada de observa\xE7\xF5es carregadas. A refer\xEAncia completa do canal n\xE3o \xE9 conhecida; n\xE3o equivale ao \xEDndice propriet\xE1rio da Nexlev.";
    if (video.source === "youtube-data-api") return { referenceCount: 0, positiveReferenceCount: 0, method: "sample-median", provenance: "loaded-observations", limitation: "Dados da API oficial n\xE3o recebem m\xE9tricas derivadas." };
    if (mode === "sample-median") {
      const reference2 = values.length >= 3 ? sampleMedian(values) : void 0, views2 = count(video.views);
      return { score: views2 !== void 0 && reference2 !== void 0 && reference2 > 0 ? finite(views2 / reference2) : void 0, reference: reference2, referenceCount: values.length, positiveReferenceCount: positive2.length, method: "sample-median", provenance: "loaded-observations", limitation };
    }
    const method = video.isShort === true && positive2.length >= 10 ? "sample-shorts-median" : "sample-channel-mean";
    const knownIdentity = !identity.ambiguous && !!(identity.id || identity.handle || identity.name);
    const reference = knownIdentity && values.length >= 3 ? method === "sample-shorts-median" ? sampleMedian(positive2) : finite(values.reduce((sum, value) => sum + value / values.length, 0)) : void 0;
    const views = count(video.views);
    return { score: views !== void 0 && reference !== void 0 && reference > 0 ? finite(views / reference) : void 0, reference, referenceCount: values.length, positiveReferenceCount: positive2.length, method, provenance: "loaded-observations", limitation };
  }
  function sortResearchVideos(videos, filter = {}, now = Date.now(), fullBaseline = videos) {
    validateResearchFilter(filter);
    const eligible = videos.filter((video) => video.source !== "youtube-data-api");
    const baseline = fullBaseline.filter((video) => video.source !== "youtube-data-api");
    const legacy = filter.sort === "date" ? "recent" : filter.sort;
    const criteria = filter.criteria ?? (legacy && legacy !== "default" && researchSortKeys.includes(legacy) ? [{ key: legacy, direction: legacy === "title" ? "asc" : "desc" }] : []);
    const rankedCriteria = filter.priority === "views-per-subscriber" ? [{ key: "viewsPerSubscriber", direction: "desc" }, ...criteria.filter((criterion) => criterion.key !== "viewsPerSubscriber")] : criteria;
    const scores = /* @__PURE__ */ new Map();
    for (const video of eligible) {
      const values = /* @__PURE__ */ new Map();
      for (const { key } of rankedCriteria) values.set(key, key === "title" ? video.title.normalize("NFC").toLocaleLowerCase() : key === "views" ? count(video.views) : key === "subscribers" ? count(video.subscribers) : key === "duration" ? count(video.durationSeconds) : key === "recent" ? video.publishedAt ? knownPublication(video.publishedAt, now) : void 0 : key === "vph" ? lifetimeVph(video, now) : key === "viewsPerSubscriber" ? viewsPerSubscriber(video) : researchComparison(video, baseline, filter.comparisonMode).score);
      scores.set(video, values);
    }
    return [...eligible].sort((left, right) => {
      for (const criterion of rankedCriteria) {
        const a = scores.get(left).get(criterion.key), b = scores.get(right).get(criterion.key);
        if (a === void 0 || b === void 0) {
          if (a !== b) return a === void 0 ? 1 : -1;
          continue;
        }
        const comparison = typeof a === "string" && typeof b === "string" ? a.localeCompare(b) : a - b;
        if (comparison) return criterion.direction === "asc" ? comparison : -comparison;
      }
      return 0;
    });
  }
  function selectResearchVideos(videos, filter = {}, now = Date.now()) {
    validateResearchFilter(filter);
    const baseline = videos.filter((video) => video.source !== "youtube-data-api");
    const basic = { ...filter, minOutlier: void 0, maxOutlier: void 0 };
    const selected = filterVideos(baseline, basic, now).filter((video) => {
      if (filter.subscribersBelow !== void 0 && (count(video.subscribers) === void 0 || video.subscribers >= filter.subscribersBelow)) return false;
      if (filter.publishedBeforeExclusive !== void 0 && (!video.publishedAt || knownPublication(video.publishedAt, now) === void 0 || knownPublication(video.publishedAt, now) >= isoBoundary(filter.publishedBeforeExclusive, false))) return false;
      if (video.isShort === true && (filter.hideShortsOnSearch && filter.surface === "search" || filter.hideShortsOnFeed && (filter.surface === "home" || filter.surface === "subscriptions"))) return false;
      if (filter.minOutlier !== void 0 || filter.maxOutlier !== void 0) {
        const score = researchComparison(video, baseline, filter.comparisonMode).score;
        if (score === void 0 || filter.minOutlier !== void 0 && score < filter.minOutlier || filter.maxOutlier !== void 0 && score > filter.maxOutlier) return false;
      }
      return true;
    });
    return sortResearchVideos(selected, filter, now, baseline);
  }
  function researchPresets(surface, now = Date.now()) {
    if (!Number.isFinite(now) || Math.abs(now) > 864e13) throw new Error("Instante atual inv\xE1lido para os atalhos.");
    const since = (days) => new Date(now - days * 864e5).toISOString();
    const sorted = (key) => ({ surface, criteria: [{ key, direction: "desc" }] });
    return [
      { id: "day-views", label: "Views nas publica\xE7\xF5es de 24 horas", description: "Publicados nas \xFAltimas 24 horas, por views observadas. N\xE3o mede tr\xE1fego nas \xFAltimas 24 horas.", available: true, filter: { ...sorted("views"), publishedAfter: since(1) } },
      { id: "week-recent", label: "Publica\xE7\xF5es recentes de 7 dias", description: "Publicados nos \xFAltimos 7 dias, mais recentes primeiro.", available: true, filter: { ...sorted("recent"), publishedAfter: since(7) } },
      { id: "million-month", label: "Um milh\xE3o em publica\xE7\xF5es de 30 dias", description: "Pelo menos 1 milh\xE3o de views e publica\xE7\xE3o nos \xFAltimos 30 dias.", available: true, filter: { ...sorted("views"), minViews: 1e6, publishedAfter: since(30) } },
      { id: "small-channel-50k", label: "50 mil views, canal abaixo de 10 mil", description: "Pelo menos 50 mil views e menos de 10 mil inscritos conhecidos.", available: true, filter: { ...sorted("views"), minViews: 5e4, subscribersBelow: 1e4 } },
      { id: "micro-channel-90d", label: "10 mil views em canal pequeno, 90 dias", description: "Pelo menos 10 mil views, menos de 5 mil inscritos e publica\xE7\xE3o nos \xFAltimos 90 dias.", available: true, filter: { ...sorted("views"), minViews: 1e4, subscribersBelow: 5e3, publishedAfter: since(90) } },
      { id: "growing-channel", label: "100 mil views, canal de 10 a 100 mil", description: "Pelo menos 100 mil views e entre 10 mil e 100 mil inscritos, incluindo os limites.", available: true, filter: { ...sorted("views"), minViews: 1e5, minSubscribers: 1e4, maxSubscribers: 1e5 } },
      { id: "lifetime-vph", label: "Maior VPH m\xE9dio desde publica\xE7\xE3o", description: "Ordena pelo VPH m\xE9dio hist\xF3rico; n\xE3o mede os \xFAltimos 60 minutos.", available: true, filter: sorted("vph") },
      { id: "sample-outlier", label: "Outlier da amostra a partir de 5\xD7", description: surface === "channel" ? "Outlier local de pelo menos 5\xD7." : "Outlier local de pelo menos 5\xD7 e canal abaixo de 50 mil inscritos.", available: true, filter: { ...sorted("outlier"), minOutlier: 5, ...surface === "channel" ? {} : { subscribersBelow: 5e4 } } },
      { id: "evergreen-vph", label: "Mais de 365 dias por VPH m\xE9dio", description: "Publicados h\xE1 mais de 365 dias, com maior VPH m\xE9dio primeiro.", available: true, filter: { ...sorted("vph"), publishedBeforeExclusive: since(365) } },
      { id: "search-shorts", label: "Shorts por VPH na busca", description: "Somente na busca: Shorts por VPH m\xE9dio hist\xF3rico.", available: surface === "search", filter: { ...sorted("vph"), shorts: "only" } },
      { id: "deep-dives", label: "Explorar v\xEDdeos longos", description: surface === "channel" ? "Na p\xE1gina de canal: dura\xE7\xE3o conhecida de pelo menos 20 minutos." : "Na busca: v\xEDdeos conhecidos como n\xE3o Shorts.", available: surface === "search" || surface === "channel", filter: { ...sorted("views"), ...surface === "channel" ? { minDurationSeconds: 1200 } : { shorts: "exclude" } } }
    ];
  }
  function researchPreset(id, surface, now = Date.now()) {
    const preset = researchPresets(surface, now).find((preset2) => preset2.id === id);
    if (!preset || !preset.available) throw new Error("Atalho indispon\xEDvel neste contexto de p\xE1gina.");
    return preset;
  }
  function researchRows(videos, fullBaseline, filter, now = Date.now()) {
    return videos.filter((video) => video.source !== "youtube-data-api").map((video) => {
      const comparison = researchComparison(video, fullBaseline, filter.comparisonMode);
      return { id: video.id, title: video.title, url: video.url, channel: video.channel, source: video.source, views: count(video.views), subscribers: count(video.subscribers), publishedAt: video.publishedAt, durationSeconds: count(video.durationSeconds), lifetimeVph: lifetimeVph(video, now), viewsPerSubscriber: viewsPerSubscriber(video), sampleOutlier: comparison.score, outlierReferenceCount: comparison.referenceCount, outlierMethod: comparison.method, outlierComparisonMode: filter.comparisonMode ?? "sample-median", outlierReference: comparison.reference ?? null, outlierReferenceStatus: comparison.reference === void 0 ? "unknown" : comparison.reference === 0 ? "zero" : "available", outlierScoreStatus: comparison.score === void 0 ? "unknown" : "available", outlierPositiveReferenceCount: comparison.positiveReferenceCount, outlierProvenance: comparison.provenance, outlierScope: "eligible-input-before-filters", outlierTargetExclusion: "same-video-id", outlierCountUnit: "observations" };
    });
  }
  function researchMarkdown(videos, fullBaseline, filter, now = Date.now()) {
    const escape = (text2) => String(text2 ?? "desconhecido").replace(/[\\`*_{}[\]<>#|]/g, "\\$&").replace(/\r?\n/g, " ");
    const rows = researchRows(videos, fullBaseline, filter, now);
    return ["# Pesquisa local Prevlev", "", `${rows.length} v\xEDdeos de observa\xE7\xF5es locais; contexto: ${filter.surface ?? "n\xE3o informado"}. Modo de outlier: ${filter.comparisonMode ?? "sample-median"}.`, "", "| V\xEDdeo | Canal | Views observadas | VPH m\xE9dio hist\xF3rico | Outlier local | Refer\xEAncia | Observa\xE7\xF5es candidatas | Positivas | M\xE9todo previsto |", "| --- | --- | --- | --- | --- | --- | --- | --- | --- |", ...rows.map((row) => `| ${escape(row.title)} | ${escape(row.channel)} | ${escape(row.views)} | ${escape(row.lifetimeVph)} | ${escape(row.sampleOutlier)} | ${escape(row.outlierReference)} | ${escape(row.outlierReferenceCount)} | ${escape(row.outlierPositiveReferenceCount)} | ${escape(row.outlierMethod)} |`), "", "Fonte: observa\xE7\xF5es carregadas eleg\xEDveis anteriores aos filtros, com formato declarado igual ou formato desconhecido em ambos, e canal compar\xE1vel. Alvo sem identidade usa candidatos da amostra geral, mas o modo de canal n\xE3o calcula refer\xEAncia sem identidade. Todos os registros com o ID do alvo s\xE3o exclu\xEDdos; outras observa\xE7\xF5es repetidas podem ser contadas. API oficial exclu\xEDda dos c\xE1lculos derivados. A amostra pode ser parcial e n\xE3o \xE9 a refer\xEAncia completa do canal. Views n\xE3o representam tr\xE1fego no per\xEDodo; VPH \xE9 m\xE9dio desde a publica\xE7\xE3o. Receita/RPM n\xE3o estimados.", ""].join("\n");
  }
  function count(value) {
    return typeof value === "number" && Number.isFinite(value) && value >= 0 ? value : void 0;
  }
  function finite(value) {
    return value !== void 0 && Number.isFinite(value) && value >= 0 ? value : void 0;
  }
  function sampleMedian(values) {
    const result = finite(median(values));
    if (result !== void 0 || !values.length) return result;
    const sorted = [...values].sort((left, right) => left - right), middle = Math.floor(sorted.length / 2);
    return finite(sorted[middle - 1] / 2 + sorted[middle] / 2);
  }

  // src/core/media.ts
  var MAX_PIXELS = 32e6;
  var MAX_DIMENSION = 16384;
  var MAX_BYTES = 50 * 1024 * 1024;
  function positive(value, name) {
    if (!Number.isFinite(value) || value <= 0)
      throw new Error(`${name} deve ser um n\xFAmero maior que zero.`);
    return value;
  }
  function validateDimensions(width, height) {
    positive(width, "Largura");
    positive(height, "Altura");
    if (width > MAX_DIMENSION || height > MAX_DIMENSION || width * height > MAX_PIXELS)
      throw new Error(
        "Imagem grande demais para processar com seguran\xE7a. Limite: 32 megapixels e 16384 pixels por lado."
      );
  }
  function fitDimensions(width, height, maxWidth, maxHeight) {
    positive(width, "Largura");
    positive(height, "Altura");
    positive(maxWidth, "Largura m\xE1xima");
    positive(maxHeight, "Altura m\xE1xima");
    const ratio = Math.min(1, maxWidth / width, maxHeight / height);
    return {
      width: Math.max(1, Math.round(width * ratio)),
      height: Math.max(1, Math.round(height * ratio))
    };
  }
  function createCanvas(width, height) {
    validateDimensions(width, height);
    const canvas = document.createElement("canvas");
    canvas.width = Math.round(width);
    canvas.height = Math.round(height);
    const context = canvas.getContext("2d");
    if (!context) throw new Error("O navegador n\xE3o disponibilizou o canvas 2D.");
    return { canvas, context };
  }
  function encode(canvas, type = "image/png", quality = 0.9) {
    return new Promise((resolve, reject) => {
      try {
        canvas.toBlob(
          (blob) => blob ? resolve(blob) : reject(
            new Error("O navegador n\xE3o conseguiu codificar a imagem.")
          ),
          type,
          quality
        );
      } catch (error) {
        reject(mediaError(error));
      }
    });
  }
  function mediaError(error) {
    if (error instanceof DOMException && error.name === "SecurityError")
      return new Error(
        "O navegador bloqueou a captura por origem da m\xEDdia (canvas protegido). Use uma captura da aba ou uma imagem local."
      );
    return error instanceof Error ? error : new Error("Falha ao processar a imagem.");
  }
  function loadImage(input) {
    let ownedUrl;
    let source;
    if (typeof input === "string") {
      if (/^data:image\/(?:png|jpe?g|webp);base64,/i.test(input)) source = input;
      else {
        let url;
        try {
          url = new URL(input);
        } catch {
          return Promise.reject(new Error("URL de imagem inv\xE1lida."));
        }
        if (url.protocol !== "https:" || url.hostname !== "i.ytimg.com" || url.username || url.password)
          return Promise.reject(
            new Error(
              "Use uma imagem local ou uma thumbnail p\xFAblica do YouTube."
            )
          );
        source = url.href;
      }
    } else {
      if (!/^image\/(?:png|jpeg|webp|avif|gif)$/.test(input.type))
        return Promise.reject(
          new Error(
            "Formato de imagem n\xE3o suportado. Use PNG, JPEG, WebP, AVIF ou GIF."
          )
        );
      if (input.size === 0 || input.size > MAX_BYTES)
        return Promise.reject(
          new Error("A imagem deve ter entre 1 byte e 50 MB.")
        );
      ownedUrl = URL.createObjectURL(input);
      source = ownedUrl;
    }
    return new Promise((resolve, reject) => {
      const image = new Image();
      const cleanup = () => {
        image.onload = null;
        image.onerror = null;
        if (ownedUrl) URL.revokeObjectURL(ownedUrl);
      };
      image.crossOrigin = "anonymous";
      image.onload = () => {
        cleanup();
        try {
          validateDimensions(image.naturalWidth, image.naturalHeight);
          resolve(image);
        } catch (error) {
          reject(mediaError(error));
        }
      };
      image.onerror = () => {
        cleanup();
        reject(
          new Error(
            "N\xE3o foi poss\xEDvel abrir a imagem. Verifique o arquivo ou as permiss\xF5es do CDN."
          )
        );
      };
      image.src = source;
    });
  }
  async function compressImage(blob, options = {}) {
    const {
      maxWidth = 1280,
      maxHeight = 720,
      quality = 0.85,
      type = "image/jpeg"
    } = options;
    positive(maxWidth, "Largura m\xE1xima");
    positive(maxHeight, "Altura m\xE1xima");
    if (!Number.isFinite(quality) || quality < 0.1 || quality > 1)
      throw new Error("Qualidade deve ficar entre 0,1 e 1.");
    if (!["image/jpeg", "image/webp", "image/png"].includes(type))
      throw new Error("Formato de sa\xEDda n\xE3o suportado.");
    const image = await loadImage(blob);
    const size = fitDimensions(
      image.naturalWidth,
      image.naturalHeight,
      maxWidth,
      maxHeight
    );
    const { canvas, context } = createCanvas(size.width, size.height);
    if (type === "image/jpeg") {
      context.fillStyle = "#ffffff";
      context.fillRect(0, 0, size.width, size.height);
    }
    context.imageSmoothingEnabled = true;
    context.imageSmoothingQuality = "high";
    try {
      context.drawImage(image, 0, 0, size.width, size.height);
    } catch (error) {
      throw mediaError(error);
    }
    return encode(canvas, type, quality);
  }
  async function captureFrame(video) {
    if (video.readyState < 2 || !video.videoWidth || !video.videoHeight)
      throw new Error("Aguarde um frame do v\xEDdeo carregar antes de capturar.");
    const { canvas, context } = createCanvas(video.videoWidth, video.videoHeight);
    try {
      context.drawImage(video, 0, 0);
    } catch (error) {
      throw mediaError(error);
    }
    return encode(canvas);
  }
  function validateRect(rect) {
    if (!Number.isFinite(rect.x) || !Number.isFinite(rect.y))
      throw new Error("Posi\xE7\xE3o de captura inv\xE1lida.");
    positive(rect.width, "Largura da captura");
    positive(rect.height, "Altura da captura");
  }
  async function cropScreenshot(dataUrl, rect, scale = 1, redactions = []) {
    validateRect(rect);
    positive(scale, "Escala da captura");
    redactions.forEach(validateRect);
    if (!/^data:image\/(?:png|jpe?g|webp);base64,/i.test(dataUrl))
      throw new Error("A captura deve ser uma imagem local v\xE1lida.");
    const image = await loadImage(dataUrl);
    const left = Math.max(0, Math.round(rect.x * scale)), top = Math.max(0, Math.round(rect.y * scale));
    const right = Math.min(
      image.naturalWidth,
      Math.round((rect.x + rect.width) * scale)
    );
    const bottom = Math.min(
      image.naturalHeight,
      Math.round((rect.y + rect.height) * scale)
    );
    if (right <= left || bottom <= top)
      throw new Error(
        "O elemento est\xE1 fora da parte vis\xEDvel da aba. Role a p\xE1gina e tente novamente."
      );
    const width = right - left, height = bottom - top;
    const { canvas, context } = createCanvas(width, height);
    context.drawImage(image, left, top, width, height, 0, 0, width, height);
    context.fillStyle = "#111827";
    for (const redaction of redactions)
      context.fillRect(
        redaction.x * scale - left,
        redaction.y * scale - top,
        redaction.width * scale,
        redaction.height * scale
      );
    return encode(canvas);
  }
  async function copyImage(blob) {
    if (!navigator.clipboard?.write || typeof ClipboardItem === "undefined")
      throw new Error(
        "C\xF3pia de imagem indispon\xEDvel. Baixe o arquivo ou permita acesso \xE0 \xE1rea de transfer\xEAncia."
      );
    let png = blob;
    if (blob.type !== "image/png") {
      const image = await loadImage(blob);
      const { canvas, context } = createCanvas(
        image.naturalWidth,
        image.naturalHeight
      );
      context.drawImage(image, 0, 0);
      png = await encode(canvas);
    }
    try {
      await navigator.clipboard.write([new ClipboardItem({ "image/png": png })]);
    } catch {
      throw new Error(
        "O navegador bloqueou a \xE1rea de transfer\xEAncia. Use o bot\xE3o novamente ou baixe a imagem."
      );
    }
  }
  function normalizeFilename(filename) {
    const normalized2 = filename.normalize("NFKC").replace(/[<>:"/\\|?*]/g, "_").replace(new RegExp("\\p{Cc}", "gu"), "_").replace(/^\.+/, "").trim().slice(0, 180);
    return normalized2 || "prevlev.png";
  }
  function downloadBlob(blob, filename) {
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = normalizeFilename(filename);
    anchor.style.display = "none";
    document.body.append(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 3e4);
  }

  // src/core/comments.ts
  function normalizeCommentText(value) {
    return value.normalize("NFC").replace(/\s+/g, " ").trim();
  }
  function stableCommentFingerprint(author, text2) {
    const value = `${search(author)}\0${normalizeCommentText(text2)}`;
    let hash = 2166136261;
    for (let index = 0; index < value.length; index++) {
      hash ^= value.charCodeAt(index);
      hash = Math.imul(hash, 16777619);
    }
    return `local:${(hash >>> 0).toString(16).padStart(8, "0")}:${value.length}`;
  }
  function search(value) {
    return normalizeCommentText(value).normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase();
  }

  // src/core/transcript.ts
  var TRANSCRIPT_ROW_SELECTOR = "ytd-transcript-segment-renderer,transcript-segment-view-model,[data-transcript-segment],[data-prevlev-transcript-segment]";
  var numeric = (value) => typeof value === "number" && Number.isFinite(value) && value >= 0 ? value : typeof value === "string" && /^\d+(?:\.\d+)?$/.test(value.trim()) ? Number(value) : void 0;
  function captionTime(value) {
    const parts = value.trim().replace(",", ".").split(":");
    if (parts.length < 2 || parts.length > 3 || !parts.every((part, index) => index === parts.length - 1 ? /^\d{1,2}(?:\.\d{1,9})?$/.test(part) : /^\d+$/.test(part)) || parts.slice(1).some((part) => Number(part) >= 60)) return void 0;
    return parts.reduce((total, part) => total * 60 + Number(part), 0);
  }
  function captionDecode(value) {
    return value.replace(/&(?:amp|lt|gt|quot|apos|nbsp|#\d+|#x[0-9a-f]+);/gi, (entity) => {
      const named = { "&amp;": "&", "&lt;": "<", "&gt;": ">", "&quot;": '"', "&apos;": "'", "&nbsp;": " " };
      if (named[entity.toLowerCase()]) return named[entity.toLowerCase()];
      const code = entity[2]?.toLowerCase() === "x" ? parseInt(entity.slice(3, -1), 16) : Number(entity.slice(2, -1));
      return code > 0 && code <= 1114111 && !(code >= 55296 && code <= 57343) ? String.fromCodePoint(code) : "\uFFFD";
    });
  }
  function captionFile(value) {
    const blocks = value.replace(/^\uFEFF/, "").replace(/\r\n?/g, "\n").split(/\n[ \t]*\n+/), segments = [];
    for (const block of blocks) {
      const lines = block.split("\n");
      if (/^(?:WEBVTT|NOTE(?:\s|$)|STYLE(?:\s|$)|REGION(?:\s|$))/.test(lines[0]?.trim() ?? "")) continue;
      const index = lines.findIndex((line) => line.includes("-->"));
      if (index < 0 || index > 1) continue;
      const timing = /^\s*(\d+(?::\d{1,2}){1,2}[.,]\d{1,9})\s+-->\s+(\d+(?::\d{1,2}){1,2}[.,]\d{1,9})(?:\s+.*)?$/.exec(lines[index]);
      if (!timing) continue;
      const start = captionTime(timing[1]), end = captionTime(timing[2]);
      if (start === void 0 || end === void 0 || end <= start) continue;
      const text2 = captionDecode(lines.slice(index + 1).join("\n").replace(/<\/?(?:c(?:\.[^\s>]*)?|v(?:\s+[^>]*)?|lang(?:\s+[^>]*)?|b|i|u|ruby|rt)>/gi, ""));
      segments.push({ start, duration: end - start, text: text2 });
      if (segments.length >= 5e3) break;
    }
    return validate(segments);
  }
  function parseTranscript(input) {
    if (typeof input === "string") {
      if (input.length > 5e6) throw new Error("Transcri\xE7\xE3o acima do limite de 5 milh\xF5es de caracteres.");
      const text2 = input.trim();
      if (text2.startsWith("{") || text2.startsWith("[")) {
        try {
          return parseTranscript(JSON.parse(text2));
        } catch {
          return [];
        }
      }
      if (/^WEBVTT(?:\s|$)/.test(text2) || /\d{1,2}:\d{2}[.,]\d{1,9}\s+-->/.test(text2)) return captionFile(text2);
      if (text2.startsWith("<") && typeof DOMParser !== "undefined")
        return parseTranscript(new DOMParser().parseFromString(text2, "text/xml"));
      return [];
    }
    if (input && typeof input === "object" && input.nodeType === 9 && typeof input.querySelectorAll === "function") {
      const document2 = input;
      const xml = Array.from(document2.querySelectorAll("text[start], p[t]")).map(
        (node) => ({
          start: node.hasAttribute("start") ? numeric(node.getAttribute("start")) ?? NaN : (numeric(node.getAttribute("t")) ?? NaN) / 1e3,
          duration: node.hasAttribute("dur") ? Number(node.getAttribute("dur")) : Number(node.getAttribute("d") ?? 0) / 1e3,
          text: node.textContent ?? ""
        })
      );
      if (xml.length) return validate(xml);
      const rows = Array.from(
        document2.querySelectorAll(TRANSCRIPT_ROW_SELECTOR)
      ).filter((row) => !row.parentElement?.closest(TRANSCRIPT_ROW_SELECTOR));
      const readTime = (row) => {
        if (!row) return void 0;
        const time2 = row.querySelector('.segment-timestamp,[class*="ytwTranscriptSegmentViewModelTimestamp"],[data-start],[data-start-ms]');
        for (const item of [row, time2]) {
          if (!item) continue;
          for (const [attribute, factor] of [["data-start-ms", 1e3], ["data-start", 1], ["data-start-time", 1]]) {
            const raw = numeric(item.getAttribute(attribute));
            if (raw !== void 0) return raw / factor;
          }
        }
        return captionTime(time2?.textContent ?? "") ?? parseDuration(time2?.textContent ?? "");
      };
      return validate(
        rows.map((row, index) => {
          const start = readTime(row), end = readTime(rows[index + 1]);
          return {
            start: start ?? NaN,
            duration: end !== void 0 && start !== void 0 ? Math.max(0, end - start) : 0,
            text: row.querySelector('.segment-text,[class*="ytwTranscriptSegmentViewModelText"],[data-text]')?.textContent ?? row.getAttribute("data-text") ?? ""
          };
        })
      );
    }
    if (!input || typeof input !== "object") return [];
    if (Array.isArray(input))
      return validate(
        input.map((entry) => {
          const item = asRecord(entry);
          return {
            start: numeric(item.start) ?? NaN,
            duration: item.duration === void 0 ? 0 : numeric(item.duration) ?? NaN,
            text: typeof item.text === "string" ? item.text : ""
          };
        })
      );
    const root = asRecord(input);
    if (Array.isArray(root.events))
      return validate(
        root.events.map((event) => {
          const item = asRecord(event);
          const segments = Array.isArray(item.segs) ? item.segs : [];
          return {
            start: (numeric(item.tStartMs) ?? NaN) / 1e3,
            duration: item.dDurationMs === void 0 ? 0 : (numeric(item.dDurationMs) ?? NaN) / 1e3,
            text: segments.map((segment) => String(asRecord(segment).utf8 ?? "")).join("")
          };
        })
      );
    return [];
  }
  function transcriptText(segments, timestamps = false) {
    return segments.map(
      (segment) => `${timestamps ? `[${timestamp(segment.start, false)}] ` : ""}${segment.text}`
    ).join("\n");
  }
  function transcriptVtt(segments, options = {}) {
    const resolved = resolveTranscriptEnds(segments, options), notes = resolved.filter((segment) => segment.end === null).map((segment) => `NOTE Prevlev: trecho iniciado em ${timestamp(segment.start)} omitido porque o fim e desconhecido.
`);
    if (resolved.some((segment) => segment.endBasis === "estimated-opt-in")) notes.unshift("NOTE Prevlev: duracao final estimada por opcao explicita do usuario.\n");
    return `WEBVTT

${notes.length ? notes.join("\n") + "\n" : ""}${resolved.filter((segment) => segment.end !== null).map((segment, index) => `${index + 1}
${timestamp(segment.start)} --> ${timestamp(segment.end)}
${segment.text.replace(/-->/g, "\u2192").replace(/\r?\n\r?\n/g, "\n")}
`).join("\n")}`;
  }
  function validate(segments) {
    return segments.filter(
      (segment) => Number.isFinite(segment.start) && segment.start >= 0 && Number.isFinite(segment.duration) && segment.duration >= 0 && segment.text.trim()
    ).map((segment) => ({
      ...segment,
      text: segment.text.replace(/\s+/g, " ").trim()
    })).sort((a, b) => a.start - b.start).slice(0, 5e3);
  }
  function resolveTranscriptEnds(segments, options = {}) {
    const sorted = validate([...segments]);
    if (options.playerEndSeconds !== void 0 && (!Number.isFinite(options.playerEndSeconds) || options.playerEndSeconds <= 0)) throw new Error("Dura\xE7\xE3o real do player inv\xE1lida.");
    if (options.estimateFinalSeconds !== void 0 && (!Number.isFinite(options.estimateFinalSeconds) || options.estimateFinalSeconds <= 0 || options.estimateFinalSeconds > 300)) throw new Error("A estimativa expl\xEDcita deve ficar entre 0 e 300 segundos.");
    return sorted.map((segment, index) => {
      const next = sorted.slice(index + 1).find((other) => other.start > segment.start)?.start;
      let end = null, endBasis = "unknown";
      if (segment.duration > 0) {
        end = segment.start + segment.duration;
        endBasis = "provided-duration";
      } else if (next !== void 0) {
        end = next;
        endBasis = "next-segment";
      } else if (options.playerEndSeconds !== void 0 && options.playerEndSeconds > segment.start) {
        end = options.playerEndSeconds;
        endBasis = "player-end";
      } else if (options.estimateFinalSeconds !== void 0) {
        end = segment.start + options.estimateFinalSeconds;
        endBasis = "estimated-opt-in";
      }
      return { ...segment, end, endBasis };
    });
  }
  function timestamp(seconds, milliseconds = true) {
    const ms = Math.max(0, Math.round(seconds * 1e3));
    const hours = Math.floor(ms / 36e5), minutes = Math.floor(ms / 6e4) % 60, secs = Math.floor(ms / 1e3) % 60;
    return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}:${String(secs).padStart(2, "0")}${milliseconds ? `.${String(ms % 1e3).padStart(3, "0")}` : ""}`;
  }
  function asRecord(value) {
    return value && typeof value === "object" ? value : {};
  }

  // src/content/youtube.ts
  var CARD_SELECTOR = "ytd-rich-item-renderer,ytd-video-renderer,ytd-grid-video-renderer,ytd-compact-video-renderer,yt-lockup-view-model,ytd-reel-item-renderer,ytm-shorts-lockup-view-model";
  function text(node) {
    return node?.textContent?.replace(/\s+/g, " ").trim() ?? "";
  }
  function firstText(element, selectors) {
    for (const selector of selectors) {
      const value = text(element.querySelector(selector));
      if (value) return value;
    }
    return "";
  }
  function visibleMetadata(card) {
    const values = Array.from(
      card.querySelectorAll(
        "#metadata-line span,.yt-content-metadata-view-model__metadata-text,.inline-metadata-item"
      )
    ).map((el) => text(el)).filter(Boolean);
    return values.length ? values : [text(card)];
  }
  function countFromMetadata(values, pattern) {
    return parseCount(values.find((value) => pattern.test(value)) ?? "");
  }
  function safeChannelUrl(anchor) {
    const raw = anchor?.getAttribute("href");
    if (!raw) return void 0;
    try {
      const url = new URL(raw, "https://www.youtube.com");
      if (url.protocol !== "https:" || !["www.youtube.com", "youtube.com"].includes(url.hostname) || url.username || url.password || !/^\/(?:@[^/?#]+|channel\/[^/?#]+|c\/[^/?#]+|user\/[^/?#]+)\/?$/.test(
        url.pathname
      ))
        return void 0;
      return `https://www.youtube.com${url.pathname.replace(/\/$/, "")}`;
    } catch {
      return void 0;
    }
  }
  function readVideoCards(document2, now = /* @__PURE__ */ new Date()) {
    const all = Array.from(document2.querySelectorAll(CARD_SELECTOR));
    return all.filter((card) => !card.parentElement?.closest(CARD_SELECTOR)).flatMap((element) => {
      const anchor = element.querySelector(
        'a#video-title-link,a#video-title,a.yt-lockup-metadata-view-model__title,a[href*="/watch?"],a[href*="/shorts/"]'
      );
      if (!anchor) return [];
      let url;
      try {
        url = new URL(
          anchor.getAttribute("href") ?? "",
          document2.location?.href ?? "https://www.youtube.com"
        ).href;
      } catch {
        return [];
      }
      const id = videoIdFromUrl(url);
      if (!id) return [];
      const title = anchor.getAttribute("title") ?? text(anchor) ?? "";
      const metadata = visibleMetadata(element);
      const dateValue = metadata.map((value) => parsePublishedAt(value, now.getTime())).find((value) => value !== void 0);
      const thumbnail2 = element.querySelector(
        'img[src*="ytimg"],img'
      )?.src;
      const channelAnchor = element.querySelector(
        'ytd-channel-name a,a.yt-content-metadata-view-model__metadata-text,a[href^="/@"],a[href^="/channel/"]'
      );
      const channelUrl = safeChannelUrl(channelAnchor);
      const subscriberText = firstText(element, [
        "#subscriber-count",
        ".subscriber-count",
        "[data-subscribers]"
      ]);
      const durationText = firstText(element, [
        "ytd-thumbnail-overlay-time-status-renderer",
        ".yt-badge-shape__text",
        "[data-duration]"
      ]);
      const video = {
        id,
        title: title || id,
        url,
        channel: text(channelAnchor) || void 0,
        channelId: channelUrl?.match(/\/channel\/([^/?]+)/)?.[1],
        channelUrl,
        views: countFromMetadata(metadata, /views|visualizaç|visualizac/i),
        publishedAt: dateValue,
        durationSeconds: parseDuration(durationText),
        subscribers: parseCount(subscriberText),
        isShort: url.includes("/shorts/") || element.matches(
          "ytd-reel-item-renderer,ytm-shorts-lockup-view-model"
        ),
        thumbnail: thumbnail2
      };
      return [{ element, video }];
    });
  }
  function readComments(root) {
    const component = "ytd-comment-view-model,ytd-comment-renderer,ytcp-comment,[data-prevlev-comment]";
    const selector = `${component},ytd-comment-thread-renderer`;
    const containers = Array.from(root.querySelectorAll(selector));
    if (root.nodeType === 1 && root.matches(selector)) containers.unshift(root);
    const document2 = root.nodeType === 9 ? root : root.ownerDocument;
    const comments = /* @__PURE__ */ new Map();
    for (const owner of containers) {
      const ownNodes = (query) => {
        const nodes = Array.from(owner.querySelectorAll(query));
        if (owner.matches(query)) nodes.unshift(owner);
        return nodes.filter((node) => node.closest(selector) === owner);
      };
      const ownValue = (queries, attribute) => {
        for (const query of queries) for (const node of ownNodes(query)) {
          const value = normalizeCommentText(attribute ? node.getAttribute(attribute) ?? node.textContent ?? "" : node.textContent ?? "");
          if (value) return value;
        }
        return "";
      };
      const bodyNode = ownNodes("#content-text,[data-comment-text]")[0] ?? ownNodes('.yt-core-attributed-string[role="text"]').find((node) => !node.closest("#author-text,[data-author],#published-time-text,#vote-count-middle"));
      const body = normalizeCommentText(bodyNode?.textContent ?? "");
      if (!body) continue;
      const author = ownValue(["#author-text", "[data-author]"], "data-author");
      const likesText = ownValue(["[data-likes]"], "data-likes") || ownValue(["#vote-count-middle", "#vote-count-left", '[aria-label*=" likes"]', '[aria-label*=" curtidas"]'], "aria-label");
      const repliesText = ownValue(["[data-replies]"], "data-replies") || ownValue(["#more-replies", "ytd-comment-replies-renderer #text", '[aria-label*=" replies"]', '[aria-label*=" respostas"]'], "aria-label");
      const trueHeart = ownNodes('[data-hearted="true"],ytd-creator-heart-renderer button[aria-pressed="true"],ytd-creator-heart-renderer #hearted').length > 0;
      const falseHeart = ownNodes('[data-hearted="false"],ytd-creator-heart-renderer button[aria-pressed="false"]').length > 0;
      let id = owner.getAttribute("data-comment-id") ?? owner.getAttribute("comment-id") ?? ownNodes("[data-comment-id],[comment-id]").map((node) => node.getAttribute("data-comment-id") ?? node.getAttribute("comment-id")).find(Boolean);
      const thread = owner.closest("ytd-comment-thread-renderer");
      if (!id && thread && (thread === owner || thread.querySelector(component) === owner)) id = thread.getAttribute("data-comment-id") ?? thread.getAttribute("comment-id");
      if (id && !/^[A-Za-z0-9_.:-]{1,256}$/.test(id)) id = void 0;
      if (!id) {
        const anchors = ownNodes('a[href*="lc="]');
        for (const anchor of anchors) {
          if (bodyNode?.contains(anchor)) continue;
          try {
            const url = new URL(anchor.getAttribute("href") ?? "", document2.location?.href.startsWith("https://") ? document2.location.href : "https://www.youtube.com");
            const commentId = url.searchParams.get("lc");
            if (url.protocol === "https:" && ["www.youtube.com", "youtube.com", "m.youtube.com"].includes(url.hostname) && !url.username && !url.password && commentId && /^[A-Za-z0-9_.-]{1,256}$/.test(commentId)) {
              id = commentId;
              break;
            }
          } catch {
          }
        }
      }
      id ??= stableCommentFingerprint(author, body);
      if (!comments.has(id)) comments.set(id, { id, text: body, author, likes: parseCount(likesText), replies: parseCount(repliesText), hearted: trueHeart ? true : falseHeart ? false : void 0 });
    }
    return [...comments.values()];
  }
  function readVisibleTranscript(document2) {
    return parseTranscript(document2);
  }
  function readYouTubeSnapshot(document2, now = /* @__PURE__ */ new Date()) {
    const videos = readVideoCards(document2, now).map((card) => card.video);
    const title = firstText(document2.documentElement, [
      "ytd-watch-metadata h1",
      "h1.ytd-video-primary-info-renderer",
      'meta[itemprop="name"]'
    ]) || document2.title.replace(/\s*- YouTube$/, "");
    const transcript = readVisibleTranscript(document2);
    const currentId = videoIdFromUrl(document2.location.href);
    if (currentId && !videos.some((v) => v.id === currentId)) {
      const meta = (name) => document2.querySelector(`meta[itemprop="${name}"]`)?.content;
      const viewText = firstText(document2.documentElement, [
        "ytd-watch-info-text #view-count",
        "ytd-video-view-count-renderer",
        ".view-count"
      ]);
      const ownerAnchor = document2.querySelector(
        'ytd-video-owner-renderer ytd-channel-name a,#owner #channel-name a,#owner a[href^="/@"],#owner a[href^="/channel/"]'
      );
      const channelUrl = safeChannelUrl(ownerAnchor);
      videos.unshift({
        id: currentId,
        title,
        url: document2.location.href,
        views: parseCount(meta("interactionCount") ?? viewText),
        publishedAt: meta("datePublished"),
        durationSeconds: parseDuration(meta("duration") ?? ""),
        channel: firstText(document2.documentElement, [
          "ytd-video-owner-renderer ytd-channel-name",
          "#owner #channel-name"
        ]) || void 0,
        channelUrl,
        channelId: channelUrl?.match(/\/channel\/([^/?]+)/)?.[1],
        subscribers: parseCount(
          firstText(document2.documentElement, [
            "#owner-sub-count",
            "#subscriber-count"
          ])
        ),
        thumbnail: `https://i.ytimg.com/vi/${currentId}/hqdefault.jpg`,
        isShort: document2.location.pathname.startsWith("/shorts/")
      });
    }
    return {
      url: document2.location.href,
      title,
      videoId: videoIdFromUrl(document2.location.href),
      videos,
      comments: readComments(document2),
      transcript,
      warnings: [
        "Somente itens j\xE1 carregados na p\xE1gina s\xE3o inclu\xEDdos.",
        "Datas relativas e contagens arredondadas do YouTube s\xE3o estimativas.",
        ...transcript.length ? ["O tempo final da \xFAltima linha da transcri\xE7\xE3o n\xE3o est\xE1 dispon\xEDvel."] : ["Abra a transcri\xE7\xE3o do YouTube para ler e exportar seu texto."],
        ...videos.some(
          (v) => v.views === void 0 || v.publishedAt === void 0
        ) ? [
          "Alguns v\xEDdeos n\xE3o exibem views ou data; suas m\xE9tricas ficam indispon\xEDveis."
        ] : []
      ]
    };
  }
  var cardSorts = [
    "default",
    "views",
    "vph",
    "outlier",
    "recent",
    "duration",
    "subscribers",
    "viewsPerSubscriber",
    "title"
  ];
  var cardNumericFields = [
    "minViews",
    "maxViews",
    "minSubscribers",
    "maxSubscribers",
    "minDurationSeconds",
    "maxDurationSeconds",
    "minVph",
    "maxVph",
    "minOutlier",
    "maxOutlier",
    "subscribersBelow"
  ];
  function normalizeCardFilter(input) {
    if (!input || typeof input !== "object" || Array.isArray(input))
      throw new Error("Filtro inv\xE1lido.");
    const raw = input;
    const result = {
      sort: "default",
      shorts: "all",
      query: "",
      channel: ""
    };
    if (raw.sort !== void 0) {
      if (!cardSorts.includes(raw.sort))
        throw new Error("Ordena\xE7\xE3o desconhecida.");
      result.sort = raw.sort;
    }
    if (raw.shorts !== void 0) {
      if (!["all", "only", "exclude"].includes(String(raw.shorts)))
        throw new Error("Formato de v\xEDdeo desconhecido.");
      result.shorts = raw.shorts;
    }
    for (const key of [
      "query",
      "channel",
      "publishedAfter",
      "publishedBefore",
      "publishedBeforeExclusive"
    ])
      if (raw[key] !== void 0 && raw[key] !== "") {
        if (typeof raw[key] !== "string")
          throw new Error("Use texto e datas v\xE1lidas no filtro.");
        result[key] = raw[key];
      }
    for (const key of cardNumericFields)
      if (raw[key] !== void 0) {
        if (typeof raw[key] !== "number")
          throw new Error("Os limites do filtro devem ser n\xFAmeros.");
        result[key] = raw[key];
      }
    if (raw.minimumViews !== void 0 && raw.minViews === void 0) {
      if (typeof raw.minimumViews !== "number")
        throw new Error("O m\xEDnimo de views deve ser num\xE9rico.");
      result.minViews = raw.minimumViews;
    }
    for (const key of ["surface", "priority", "comparisonMode"]) if (raw[key] !== void 0) {
      if (typeof raw[key] !== "string") throw new Error("Op\xE7\xE3o de pesquisa inv\xE1lida.");
      Object.assign(result, { [key]: raw[key] });
    }
    if (raw.criteria !== void 0) {
      if (!Array.isArray(raw.criteria)) throw new Error("Ordena\xE7\xE3o m\xFAltipla inv\xE1lida.");
      result.criteria = raw.criteria.map((value) => {
        if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("Crit\xE9rio de ordena\xE7\xE3o inv\xE1lido.");
        const criterion = value;
        return { key: criterion.key, direction: criterion.direction };
      });
    }
    for (const key of ["hideShortsOnFeed", "hideShortsOnSearch"]) if (raw[key] !== void 0) {
      if (typeof raw[key] !== "boolean") throw new Error("Prefer\xEAncia de Shorts inv\xE1lida.");
      result[key] = raw[key];
    }
    validateResearchFilter(result);
    return result;
  }
  function filterAndSortCards(cards, filter, _vph, now = Date.now()) {
    const normalized2 = normalizeCardFilter(filter), baseline = cards.map((card) => card.video);
    const sorted = selectResearchVideos(baseline, normalized2, now);
    const byVideo = new Map(cards.map((card) => [card.video, card]));
    return sorted.map((video) => byVideo.get(video));
  }

  // src/content/studio.ts
  var plans = /* @__PURE__ */ new Map();
  var maxActions = 50;
  var ttl = 12e4;
  var warnings = [
    "O layout do Studio pode mudar. Controles desconhecidos s\xE3o recusados.",
    "Altera\xE7\xF5es j\xE1 enviadas n\xE3o s\xE3o desfeitas ao cancelar."
  ];
  function normalize2(value) {
    return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim().toLowerCase();
  }
  function label(element) {
    return (element.getAttribute("aria-label") ?? element.getAttribute("title") ?? element.textContent ?? "").trim();
  }
  function visible(element) {
    if (!element.isConnected || element.closest('[hidden], [aria-hidden="true"]'))
      return false;
    for (let node = element; node; node = node.parentElement) {
      const style = element.ownerDocument.defaultView?.getComputedStyle(node);
      if (style?.display === "none" || style?.visibility === "hidden") return false;
    }
    return true;
  }
  function enabled(element) {
    return visible(element) && !element.hasAttribute("disabled") && !element.matches(":disabled") && !element.closest('[aria-disabled="true"]');
  }
  function signature(element) {
    const value = element.tagName === "INPUT" ? `${element.value}|${element.checked}` : "";
    return [
      element.tagName,
      element.id,
      label(element),
      element.getAttribute("aria-pressed"),
      element.getAttribute("aria-checked"),
      value
    ].join("|");
  }
  function studioDocument(doc) {
    return doc.location?.hostname === "studio.youtube.com";
  }
  function unique(items) {
    return [...new Set(items)];
  }
  function heartState(element) {
    const text2 = normalize2(label(element));
    if (/^(remove heart|unheart|remover coracao|retirar coracao|remove creator heart)/.test(
      text2
    ))
      return true;
    if (/^(heart|give heart|add heart|coracao|marcar com coracao|adicionar coracao)(\s|$)/.test(
      text2
    )) {
      const pressed = element.getAttribute("aria-pressed");
      return pressed === "true";
    }
    return void 0;
  }
  function findHeartButtons(doc) {
    const comments = Array.from(
      doc.querySelectorAll(
        "ytcp-comment-thread, ytcp-comment, ytcp-comment-thread-row"
      )
    );
    const candidates = unique(
      comments.flatMap(
        (comment) => Array.from(
          comment.querySelectorAll(
            'button, ytcp-icon-button, [role="button"]'
          )
        )
      )
    ).filter((button) => enabled(button) && heartState(button) !== void 0);
    return candidates.filter(
      (button) => !candidates.some((other) => other !== button && button.contains(other))
    );
  }
  function compactText(value) {
    return (value ?? "").replace(/\s+/g, " ").trim();
  }
  function commentContext(button) {
    const container = button.closest(
      "ytcp-comment, ytcp-comment-thread-row, ytcp-comment-thread"
    );
    if (!container || !visible(container)) return void 0;
    const thread = container.closest(
      "ytcp-comment-thread, ytcp-comment-thread-row"
    ) ?? container;
    const authorElement = container.querySelector(
      '[id="author-text"], [id="author-name"], .author-text, .author-name, [data-author]'
    );
    const textElement = container.querySelector(
      '[id="content-text"], [id="comment-text"], .comment-text, .content-text, ytcp-comment-text, [data-comment-text]'
    );
    const author = compactText(authorElement?.textContent);
    const authorUrl = authorElement?.getAttribute("href") ?? authorElement?.querySelector("a")?.getAttribute("href") ?? "";
    const text2 = compactText(textElement?.textContent);
    const identity = [container, thread].map((element) => [
      element.tagName,
      element.id,
      element.getAttribute("comment-id"),
      element.getAttribute("data-comment-id"),
      element.getAttribute("data-thread-id")
    ]);
    const permalink = container.querySelector('a[href*="lc="]')?.getAttribute("href") ?? "";
    if (!author || !text2) return void 0;
    return {
      container,
      thread,
      fingerprint: JSON.stringify({
        identity,
        permalink,
        author,
        authorUrl,
        text: text2
      }),
      preview: `${author}: ${text2}`
    };
  }
  function stepIsCurrent(step) {
    if (!enabled(step.element) || signature(step.element) !== step.signature)
      return false;
    if (!step.comment) return true;
    const current = commentContext(step.element);
    return current?.container === step.comment.container && current.thread === step.comment.thread && current.fingerprint === step.comment.fingerprint;
  }
  var editorSelector = "ytcp-ad-breaks-editor, ytcp-ad-break-editor, ytcp-video-ad-breaks-editor";
  function modernParts(doc) {
    const panels = Array.from(doc.querySelectorAll("ytve-ad-breaks-editor-options-panel")).filter(visible);
    const times = Array.from(doc.querySelectorAll("ytve-toolbar ytcp-media-timestamp-input")).filter(visible);
    const additions = Array.from(doc.querySelectorAll("#add-ad-break")).filter(enabled);
    if (panels.length !== 1 || times.length !== 1 || additions.length !== 1) return void 0;
    const fields = Array.from(times[0].querySelectorAll("input")).filter(visible), toolbar = times[0].closest("ytve-toolbar");
    if (fields.length !== 1 || !toolbar || !writable(fields[0])) return void 0;
    const format = fields[0].value || fields[0].placeholder;
    if (!/^\d{1,3}:\d{2}:\d{2}:\d{2}$/.test(format) && !/^h{1,3}:mm:ss:ff$/i.test(format)) return void 0;
    return { panel: panels[0], toolbar, timeControl: times[0], field: fields[0], addButton: additions[0] };
  }
  function modernFingerprint(parts, doc) {
    if (!parts) return "";
    const identity = (element) => [element.tagName, ...["id", "video-id", "data-video-id", "channel-id", "data-channel-id", "aria-label", "data-fps", "fps", "frame-rate"].map((key) => element.getAttribute(key))];
    const scope = parts.panel.closest("[video-id],[data-video-id],[channel-id],[data-channel-id]") ?? doc.body;
    return JSON.stringify([identity(parts.panel), identity(parts.toolbar), identity(parts.timeControl), identity(scope), dateIdentity(parts.field), parts.field.placeholder, compactText(doc.querySelector("#entity-snapshot-title")?.textContent)]);
  }
  function validModernFps(parts, fps) {
    if (typeof fps !== "number" || ![24, 25, 30, 48, 50, 60].includes(fps)) return false;
    const declared = [parts.panel, parts.timeControl].flatMap((element) => ["data-fps", "fps", "frame-rate"].flatMap((key) => element.hasAttribute(key) ? [Number(element.getAttribute(key))] : []));
    return declared.every((value) => value === fps);
  }
  function frameTimestamp(seconds, fps) {
    const frames = Math.round(seconds * fps), whole = Math.floor(frames / fps);
    return `${Math.floor(whole / 3600)}:${String(Math.floor(whole / 60) % 60).padStart(2, "0")}:${String(whole % 60).padStart(2, "0")}:${String(frames % fps).padStart(2, "0")}`;
  }
  function frameSeconds(value, fps) {
    const match = /^(\d{1,3}):(\d{2}):(\d{2}):(\d{2})$/.exec(value);
    if (!match) return void 0;
    const [, hours, minutes, seconds, frames] = match.map(Number);
    if (minutes > 59 || seconds > 59 || frames >= fps) return void 0;
    return hours * 3600 + minutes * 60 + seconds + frames / fps;
  }
  function modernIsCurrent(context, doc, replaceField = false) {
    const parts = modernParts(doc);
    return !!parts && parts.panel === context.panel && parts.toolbar === context.toolbar && parts.timeControl === context.timeControl && parts.addButton === context.addButton && modernFingerprint(parts, doc) === context.fingerprint && validModernFps(parts, context.fps) && signature(parts.addButton) === context.addSignature && (replaceField || parts.field === context.field && signature(parts.field) === context.fieldSignature);
  }
  function midrollEditors(doc) {
    const editors = Array.from(
      doc.querySelectorAll(editorSelector)
    ).filter(visible);
    return editors.filter(
      (editor) => !editors.some((other) => other !== editor && other.contains(editor))
    );
  }
  function midrollFields(editor) {
    return Array.from(editor.querySelectorAll("input")).filter(
      (field) => enabled(field) && !field.readOnly && ["text", "time"].includes(field.type) && (field.type === "time" || /time|horario|inicio|timestamp/.test(normalize2(label(field))) || /^\d{1,2}:\d{2}(?::\d{2})?$/.test(field.value || field.placeholder))
    );
  }
  function addMidrollButtons(editor, requireEnabled = true) {
    const candidates = Array.from(
      editor.querySelectorAll(
        'button, ytcp-button, [role="button"]'
      )
    ).filter(
      (button) => (requireEnabled ? enabled(button) : visible(button)) && /^(insert ad slot|insert ad break|add ad slot|add ad break|inserir intervalo(?: de anuncios?)?|adicionar intervalo(?: de anuncios?)?|inserir anuncio)$/.test(
        normalize2(label(button))
      )
    );
    return candidates.filter(
      (button) => !candidates.some((other) => other !== button && button.contains(other))
    );
  }
  function editorFingerprint(editor) {
    const scope = editor.closest(
      "ytcp-video-monetization, ytcp-video-monetization-editor, ytcp-uploads-dialog"
    ) ?? editor;
    const identity = (element) => [
      element.tagName,
      element.id,
      element.getAttribute("video-id"),
      element.getAttribute("data-video-id"),
      element.getAttribute("channel-id"),
      element.getAttribute("data-channel-id"),
      element.getAttribute("aria-label")
    ];
    const title = compactText(
      scope.querySelector("#video-title, #video-name, [data-video-title]")?.textContent
    );
    return JSON.stringify({
      editor: identity(editor),
      scope: identity(scope),
      title
    });
  }
  function midrollContextIsCurrent(context, doc) {
    const editors = midrollEditors(doc);
    return editors.length === 1 && editors[0] === context.editor && editorFingerprint(context.editor) === context.fingerprint && (!context.addButton || visible(context.addButton) && context.editor.contains(context.addButton) && signature(context.addButton) === context.addSignature && addMidrollButtons(context.editor, false).length === 1);
  }
  function timestamp2(seconds) {
    const rounded = Math.floor(seconds);
    return [
      Math.floor(rounded / 3600),
      Math.floor(rounded % 3600 / 60),
      rounded % 60
    ].map((n) => String(n).padStart(2, "0")).join(":");
  }
  function displayedMoney(value) {
    if (/\d\s*(?:[kmb]|mil|milhao|milhão|million)\b/i.test(value))
      return parseCount(value);
    const raw = value.match(/-?\d[\d.,\s]*/)?.[0].replace(/\s/g, "");
    if (!raw) return void 0;
    const lastSeparator = Math.max(raw.lastIndexOf(","), raw.lastIndexOf("."));
    const decimalLength = lastSeparator < 0 ? 0 : raw.length - lastSeparator - 1;
    const normalized2 = lastSeparator >= 0 && decimalLength > 0 && decimalLength <= 2 ? raw.slice(0, lastSeparator).replace(/[.,]/g, "") + "." + raw.slice(lastSeparator + 1) : raw.replace(/[.,]/g, "");
    const result = Number(normalized2);
    return Number.isFinite(result) ? result : void 0;
  }
  function readStudioMetrics(doc = document) {
    const result = { source: "studio-dom", observedAt: (/* @__PURE__ */ new Date()).toISOString(), sources: {}, warnings: [] };
    if (!studioDocument(doc)) {
      result.warnings.push("Abra o YouTube Studio para ler m\xE9tricas exibidas.");
      return result;
    }
    const revenueCandidates = [];
    const quantityCandidates = [];
    const addRevenue = (element, selector, metricLabel) => {
      if (!visible(element)) return;
      const raw = compactText(element.textContent), value = displayedMoney(raw);
      if (value === void 0) return;
      const currency = raw.match(/R\$|US\$|€|£|\$/)?.[0];
      const declared = element.closest("[data-currency], [currency]")?.getAttribute("data-currency") ?? element.closest("[currency]")?.getAttribute("currency");
      const code = declared && /^[A-Z]{3}$/.test(declared) ? declared : currency === "R$" ? "BRL" : currency === "US$" ? "USD" : currency === "\u20AC" ? "EUR" : currency === "\xA3" ? "GBP" : void 0;
      revenueCandidates.push({ value, currency, code, source: { selector, label: metricLabel, raw } });
    };
    for (const element of doc.querySelectorAll("#TOTAL_ESTIMATED_EARNINGS-tab #metric-total")) addRevenue(element, "#TOTAL_ESTIMATED_EARNINGS-tab #metric-total", "Receita estimada exibida");
    for (const card of doc.querySelectorAll("yta-key-metric-card, yta-key-metric-block, [data-metric]")) {
      if (!visible(card)) continue;
      const metricLabel = compactText(card.getAttribute("data-metric") ?? card.querySelector("#title, #metric-title, .metric-title, [data-label]")?.textContent);
      const valueElement = card.querySelector("#metric-value, #metric-total, #value, .metric-value, [data-value]");
      if (!valueElement || !visible(valueElement)) continue;
      if (/estimated revenue|receita estimada|^revenue$|^receita$/.test(normalize2(metricLabel))) addRevenue(valueElement, `${card.tagName.toLowerCase()} #metric-value/#metric-total`, metricLabel);
      if (/^videos$|video count|quantidade de videos/.test(normalize2(metricLabel))) {
        const raw = compactText(valueElement.textContent), value = parseCount(raw);
        if (value !== void 0 && Number.isInteger(value) && value >= 0) quantityCandidates.push({ value, source: { selector: `${card.tagName.toLowerCase()} #metric-value/#metric-total`, label: metricLabel, raw } });
      }
    }
    const revenueKeys = new Set(revenueCandidates.map((item) => JSON.stringify([item.value, item.currency ?? "", item.code ?? ""])));
    if (revenueKeys.size === 1) {
      const candidate = revenueCandidates[0];
      result.revenue = candidate.value;
      result.currency = candidate.currency;
      result.currencyCode = candidate.code;
      result.sources.revenue = candidate.source;
      if (candidate.currency || candidate.code) result.sources.currency = candidate.source;
      if (candidate.currency === "$" && !candidate.code) result.warnings.push("O s\xEDmbolo $ n\xE3o identifica sozinho a moeda; nenhum c\xF3digo ISO foi presumido.");
    } else if (revenueKeys.size > 1) result.warnings.push("Mais de um valor de receita vis\xEDvel diverge. A receita permanece desconhecida; escolha o valor e o per\xEDodo manualmente.");
    const quantities = new Set(quantityCandidates.map((item) => item.value));
    if (quantities.size === 1) {
      result.videoCount = quantityCandidates[0].value;
      result.sources.videoCount = quantityCandidates[0].source;
    } else if (quantities.size > 1) result.warnings.push("H\xE1 quantidades de v\xEDdeos divergentes na p\xE1gina; nenhuma foi escolhida automaticamente.");
    const periods = Array.from(doc.querySelectorAll("#date-range-label, yta-date-range-selector #label, yta-date-range-picker #label")).filter(visible).map((element) => ({ element, raw: compactText(element.textContent) })).filter((item) => item.raw);
    const periodLabels = new Set(periods.map((item) => item.raw));
    if (periodLabels.size === 1) {
      const first = periods[0], selector = first.element.id === "date-range-label" ? "#date-range-label" : `${first.element.parentElement?.tagName.toLowerCase()} #label`;
      result.period = { label: first.raw, selector };
      result.sources.period = { selector, label: "Per\xEDodo exibido no Studio", raw: first.raw };
    } else if (periodLabels.size > 1) result.warnings.push("Mais de um per\xEDodo vis\xEDvel foi encontrado; nenhum foi associado \xE0 receita.");
    if (result.revenue === void 0) result.warnings.push("Receita n\xE3o identificada em um card vis\xEDvel. Informe o valor manualmente na calculadora.");
    if (result.videoCount === void 0) result.warnings.push("Quantidade de v\xEDdeos n\xE3o identificada em um card expl\xEDcito. O valor 1 da calculadora \xE9 padr\xE3o do usu\xE1rio, n\xE3o uma contagem lida.");
    if (!result.period) result.warnings.push("Per\xEDodo das m\xE9tricas n\xE3o identificado em um r\xF3tulo vis\xEDvel. Campos de data em edi\xE7\xE3o n\xE3o comprovam o per\xEDodo aplicado.");
    result.warnings.push("Somente m\xE9tricas atualmente renderizadas; nenhuma consulta privada ao Studio foi feita.");
    return result;
  }
  function previewStudioAction(action, input = {}, doc = document) {
    const now = Date.now();
    for (const [id, stored] of plans)
      if (stored.state === "pending" && stored.expires <= now) plans.delete(id);
    const steps = [];
    const guards = [];
    let midroll;
    let modernMidroll;
    const notes = [...warnings];
    let description = "";
    let unsupported = "";
    if (!studioDocument(doc))
      unsupported = "Esta a\xE7\xE3o exige uma p\xE1gina aberta em studio.youtube.com.";
    else if (action === "hearts-add" || action === "hearts-remove") {
      const desired = action === "hearts-add";
      const limit = Math.min(
        maxActions,
        Math.max(1, Math.floor(input.limit ?? 20))
      );
      const targets = findHeartButtons(doc).filter((button) => heartState(button) !== desired).slice(0, limit);
      for (const element of targets) {
        const comment = commentContext(element);
        if (comment)
          steps.push({ element, signature: signature(element), comment });
      }
      description = `${desired ? "Dar" : "Remover"} cora\xE7\xE3o em ${steps.length} coment\xE1rios vis\xEDveis.`;
      notes.push(
        "Cada clique pode publicar a rea\xE7\xE3o no canal. Apenas os coment\xE1rios vis\xEDveis da pr\xE9via ser\xE3o processados."
      );
      if (steps.length !== targets.length)
        notes.push(
          "Coment\xE1rios sem autor e texto reconhecidos foram exclu\xEDdos da pr\xE9via."
        );
      if (steps.length === 0)
        unsupported = "Nenhum coment\xE1rio com autor, texto e bot\xE3o de cora\xE7\xE3o reconhecidos foi encontrado.";
    } else if (action === "skip-monetization") {
      const step = doc.querySelector(
        "ytcp-video-monetization, ytcp-video-monetization-editor, #monetization-step"
      );
      const nextButtons = step && Array.from(
        doc.querySelectorAll(
          'ytcp-button, button, [role="button"]'
        )
      ).filter(
        (button) => enabled(button) && /^(next|proximo|avancar)$/.test(normalize2(label(button)))
      );
      const next = nextButtons?.length === 1 ? nextButtons[0] : void 0;
      const selected = step?.querySelector(
        '[aria-checked="true"], input[type="radio"]:checked'
      );
      if (!step || !visible(step) || !next || !selected)
        unsupported = "Abra a etapa Monetiza\xE7\xE3o, escolha a op\xE7\xE3o desejada e deixe o bot\xE3o Pr\xF3ximo vis\xEDvel.";
      else {
        steps.push({ element: next, signature: signature(next) });
        guards.push({ element: selected, signature: signature(selected) });
        description = "Avan\xE7ar uma etapa usando a escolha de monetiza\xE7\xE3o j\xE1 selecionada.";
        notes.push(
          "N\xE3o seleciona monetiza\xE7\xE3o nem preenche declara\xE7\xF5es de adequa\xE7\xE3o. Revise a op\xE7\xE3o selecionada antes de confirmar."
        );
      }
    } else if (action === "midrolls") {
      const positions = input.positions ?? [];
      if (positions.length === 0 || positions.length > maxActions || positions.some(
        (value, index) => !Number.isFinite(value) || value < 1 || index > 0 && Math.floor(value) <= Math.floor(positions[index - 1])
      )) {
        unsupported = "Informe de 1 a 50 posi\xE7\xF5es positivas em segundos, distintas ap\xF3s arredondamento e em ordem crescente.";
      } else {
        const modernPresent = !!doc.querySelector("ytve-ad-breaks-editor-options-panel, ytve-toolbar ytcp-media-timestamp-input, #add-ad-break");
        const modern = modernParts(doc);
        if (modernPresent) {
          if (!modern) unsupported = "O editor moderno exige um painel, um timestamp H:MM:SS:FF edit\xE1vel e um \xFAnico controle #add-ad-break vis\xEDvel.";
          else if (!validModernFps(modern, input.fps)) unsupported = "O timestamp usa frames. Informe explicitamente FPS 24, 25, 30, 48, 50 ou 60 e confira se corresponde ao editor; FPS ausente, fracion\xE1rio ou divergente n\xE3o \xE9 presumido.";
          else {
            modernMidroll = { ...modern, fingerprint: modernFingerprint(modern, doc), addSignature: signature(modern.addButton), fieldSignature: signature(modern.field), positions: Object.freeze([...positions]), fps: input.fps };
            description = `Posicionar o cursor e solicitar ${positions.length} intervalos a ${input.fps} FPS: ${positions.map((value) => frameTimestamp(value, input.fps)).join(", ")}.`;
            notes.push("Usa os controles vis\xEDveis de timestamp e Adicionar intervalo. Intervalos existentes n\xE3o s\xE3o deduplicados; revise a timeline antes de confirmar.", "A execu\xE7\xE3o conta cliques enviados, sem inventar confirma\xE7\xE3o da cria\xE7\xE3o dos intervalos. N\xE3o clica em Continuar, Salvar ou question\xE1rios.");
          }
        } else {
          const editors = midrollEditors(doc);
          if (editors.length !== 1)
            unsupported = `Abra um \xFAnico editor de intervalos reconhecido. Foram encontrados ${editors.length} editores vis\xEDveis.`;
          else if (Array.from(editors[0].querySelectorAll("input")).some((field) => visible(field) && /^\d{1,3}:\d{2}:\d{2}:\d{2}$/.test(field.value || field.placeholder))) unsupported = "O editor cont\xE9m timestamps com frames, mas n\xE3o possui o conjunto de controles modernos reconhecido. Nenhum FPS foi presumido.";
          else {
            const editor = editors[0];
            const fields = midrollFields(editor);
            const missing = positions.length - fields.length;
            const addButtons = addMidrollButtons(editor);
            if (missing < 0)
              unsupported = `O editor cont\xE9m ${fields.length} intervalos; a pr\xE9via possui ${positions.length} posi\xE7\xF5es. Nenhum intervalo ser\xE1 apagado automaticamente.`;
            else if (missing > 0 && addButtons.length !== 1)
              unsupported = `S\xE3o necess\xE1rios ${missing} novos intervalos, mas n\xE3o h\xE1 um \xFAnico bot\xE3o Inserir intervalo reconhecido dentro do editor. Foram encontrados ${addButtons.length} controles eleg\xEDveis.`;
            else {
              midroll = {
                editor,
                fingerprint: editorFingerprint(editor),
                ...missing > 0 ? {
                  addButton: addButtons[0],
                  addSignature: signature(addButtons[0])
                } : {},
                positions: Object.freeze([...positions]),
                initialFields: fields
              };
              steps.push(
                ...fields.map((element, index) => ({
                  element,
                  signature: signature(element),
                  value: timestamp2(positions[index])
                }))
              );
              description = `Preencher ${positions.length} intervalos (${missing} a criar): ${positions.map(timestamp2).join(", ")}.`;
              notes.push(
                "Cria somente rascunhos por controles reconhecidos e preenche os hor\xE1rios. N\xE3o clica em Continuar nem Salvar; revise o resultado no Studio. A entrega de an\xFAncios n\xE3o \xE9 garantida."
              );
            }
          }
        }
      }
    } else unsupported = "A\xE7\xE3o de Studio desconhecida.";
    if (unsupported) notes.unshift(unsupported);
    const publicPlan = Object.freeze({
      id: globalThis.crypto.randomUUID(),
      action,
      status: unsupported ? "unsupported" : "ready",
      targetCount: unsupported ? 0 : modernMidroll?.positions.length ?? midroll?.positions.length ?? steps.length,
      ...modernMidroll ? { slotsToCreate: modernMidroll.positions.length, positions: Object.freeze(modernMidroll.positions.map((value) => frameTimestamp(value, modernMidroll.fps))) } : midroll ? {
        slotsToCreate: midroll.positions.length - midroll.initialFields.length,
        positions: Object.freeze(midroll.positions.map(timestamp2))
      } : {},
      targets: Object.freeze(
        unsupported ? [] : modernMidroll ? modernMidroll.positions.map((position) => Object.freeze({ control: "#add-ad-break + ytcp-media-timestamp-input", context: description, value: frameTimestamp(position, modernMidroll.fps) })) : midroll ? midroll.positions.map(
          (position, index) => Object.freeze({
            control: index < midroll.initialFields.length ? label(midroll.initialFields[index]) : `Criar: ${label(midroll.addButton)}`,
            context: description,
            value: timestamp2(position)
          })
        ) : steps.map(
          (step) => Object.freeze({
            control: label(step.element),
            context: (step.comment?.preview ?? description).replace(/\s+/g, " ").trim().slice(0, 220),
            ...step.value ? { value: step.value } : {}
          })
        )
      ),
      description: description || unsupported,
      warnings: Object.freeze(notes),
      expiresAt: new Date(now + ttl).toISOString()
    });
    if (!unsupported)
      plans.set(publicPlan.id, {
        publicPlan,
        document: doc,
        url: doc.location.href,
        expires: now + ttl,
        steps,
        guards,
        midroll,
        modernMidroll,
        controller: new AbortController(),
        state: "pending"
      });
    return publicPlan;
  }
  function wait(delay, signal) {
    return new Promise((resolve, reject) => {
      if (signal.aborted) {
        reject(new Error("cancelled"));
        return;
      }
      const abort = () => {
        clearTimeout(timer);
        reject(new Error("cancelled"));
      };
      const timer = setTimeout(() => {
        signal.removeEventListener("abort", abort);
        resolve();
      }, delay);
      signal.addEventListener("abort", abort, { once: true });
    });
  }
  var StudioContextChanged = class extends Error {
  };
  function setFieldValue(doc, field, value) {
    const setter = Object.getOwnPropertyDescriptor(
      doc.defaultView.HTMLInputElement.prototype,
      "value"
    )?.set;
    if (!setter) throw new Error("Campo sem setter de valor reconhecido.");
    setter.call(field, value);
    field.dispatchEvent(new doc.defaultView.Event("input", { bubbles: true }));
    field.dispatchEvent(new doc.defaultView.Event("change", { bubbles: true }));
  }
  async function executeMidrolls(stored) {
    const context = stored.midroll;
    const doc = stored.document;
    const signal = stored.controller.signal;
    const total = context.positions.length;
    let submitted = 0;
    let created = 0;
    let addClicks = 0;
    let expected = [...context.initialFields];
    const signatures = new Map(
      expected.map((field) => [field, signature(field)])
    );
    const result = (status, message) => ({
      status,
      submitted,
      total,
      created,
      addClicks,
      message
    });
    const checkContext = () => {
      if (signal.aborted) throw new Error("cancelled");
      if (doc.location.href !== stored.url || !midrollContextIsCurrent(context, doc))
        throw new StudioContextChanged(
          "O v\xEDdeo, editor ou bot\xE3o de inserir mudou. A rotina foi interrompida."
        );
    };
    const checkFields = (allowNew = false) => {
      checkContext();
      const current = midrollFields(context.editor);
      const oldInCurrentOrder = current.filter(
        (field) => expected.includes(field)
      );
      if (oldInCurrentOrder.length !== expected.length || oldInCurrentOrder.some((field, index) => field !== expected[index]) || expected.some((field) => signature(field) !== signatures.get(field)) || current.length < expected.length || current.length > expected.length + (allowNew ? 1 : 0)) {
        throw new StudioContextChanged(
          "Os campos de intervalo mudaram ou surgiram controles inesperados. Confira os rascunhos antes de continuar manualmente."
        );
      }
      return current;
    };
    try {
      for (let index = 0; index < total; index++) {
        checkFields();
        let field = context.initialFields[index];
        if (!field) {
          const add = context.addButton;
          if (!add || !enabled(add))
            throw new StudioContextChanged(
              "O bot\xE3o Inserir intervalo n\xE3o est\xE1 dispon\xEDvel. Nenhum pr\xF3ximo clique ser\xE1 enviado."
            );
          add.click();
          addClicks++;
          const deadline = Date.now() + 1e3;
          while (true) {
            const current = checkFields(true);
            const added = current.filter((item) => !expected.includes(item));
            if (added.length === 1) {
              field = added[0];
              expected = current;
              signatures.set(field, signature(field));
              created++;
              break;
            }
            if (Date.now() >= deadline)
              throw new Error(
                "O clique Inserir foi enviado, mas um \xFAnico campo novo n\xE3o apareceu em at\xE9 1 segundo. O estado do rascunho \xE9 incerto; confira o Studio. Nenhum pr\xF3ximo clique foi enviado."
              );
            await wait(Math.min(25, deadline - Date.now()), signal);
          }
        }
        checkFields();
        setFieldValue(doc, field, timestamp2(context.positions[index]));
        submitted++;
        if (!field.isConnected || parseDuration(field.value) !== Math.floor(context.positions[index]))
          throw new StudioContextChanged(
            "O campo n\xE3o preservou o hor\xE1rio preenchido. A rotina foi interrompida; confira o rascunho."
          );
        signatures.set(field, signature(field));
        checkFields();
        if (index + 1 < total) await wait(150, signal);
      }
      return result(
        "completed",
        "Intervalos criados/preenchidos em rascunho. Revise e use Continuar/Salvar manualmente no Studio; isto n\xE3o confirma aceita\xE7\xE3o do servidor nem entrega de an\xFAncios."
      );
    } catch (error) {
      return result(
        signal.aborted ? "cancelled" : error instanceof StudioContextChanged ? "stale" : "error",
        signal.aborted ? "Execu\xE7\xE3o cancelada. Um clique de inser\xE7\xE3o j\xE1 enviado ainda pode criar um rascunho; confira o Studio. Nenhuma a\xE7\xE3o posterior foi enviada." : error instanceof Error ? error.message : "Falha ao preencher intervalos."
      );
    }
  }
  async function executeModernMidrolls(stored) {
    const context = stored.modernMidroll, doc = stored.document, signal = stored.controller.signal, total = context.positions.length;
    let submitted = 0, addClicks = 0;
    const check = (replaceField = false) => {
      if (signal.aborted) throw new Error("cancelled");
      if (doc.location.href !== stored.url || !modernIsCurrent(context, doc, replaceField)) throw new StudioContextChanged("O v\xEDdeo, o painel moderno, FPS ou os controles mudaram; nenhum pr\xF3ximo clique foi enviado.");
    };
    try {
      for (const position of context.positions) {
        check();
        const value = frameTimestamp(position, context.fps), expected = frameSeconds(value, context.fps);
        if (expected === void 0) throw new Error("Posi\xE7\xE3o fora do formato de timestamp reconhecido.");
        const setter = Object.getOwnPropertyDescriptor(doc.defaultView.HTMLInputElement.prototype, "value")?.set;
        if (!setter) throw new Error("Setter nativo do timestamp indispon\xEDvel.");
        setter.call(context.field, value);
        context.field.dispatchEvent(new doc.defaultView.Event("input", { bubbles: true }));
        check(true);
        let field = modernParts(doc).field;
        if (frameSeconds(field.value, context.fps) !== expected) throw new StudioContextChanged("O timestamp n\xE3o preservou a posi\xE7\xE3o; a rotina foi interrompida antes de adicionar o intervalo.");
        field.dispatchEvent(new doc.defaultView.Event("change", { bubbles: true }));
        check(true);
        field = modernParts(doc).field;
        if (frameSeconds(field.value, context.fps) !== expected) throw new StudioContextChanged("O Studio alterou o timestamp durante a edi\xE7\xE3o; confira o cursor antes de continuar.");
        context.field = field;
        context.fieldSignature = signature(field);
        check();
        context.addButton.click();
        addClicks++;
        submitted++;
        check();
        if (submitted < total) await wait(150, signal);
      }
      return { status: "completed", submitted, total, addClicks, message: "Posi\xE7\xF5es preenchidas e cliques Adicionar enviados. A cria\xE7\xE3o dos intervalos n\xE3o foi confirmada por este adaptador. Revise a timeline e use Continuar/Salvar manualmente; nenhuma entrega de an\xFAncios \xE9 garantida." };
    } catch (error) {
      return { status: signal.aborted ? "cancelled" : error instanceof StudioContextChanged ? "stale" : "error", submitted, total, addClicks, message: signal.aborted ? "Execu\xE7\xE3o cancelada. Um clique j\xE1 enviado pode ter criado um rascunho; confira o Studio. Nenhum pr\xF3ximo clique foi enviado." : error instanceof Error ? error.message : "N\xE3o foi poss\xEDvel operar o editor moderno." };
    }
  }
  async function executeStudioPlan(planId, signal) {
    const stored = plans.get(planId);
    if (!stored)
      return {
        status: "unsupported",
        submitted: 0,
        total: 0,
        message: "Pr\xE9via ausente, cancelada ou j\xE1 consumida. Gere uma nova pr\xE9via."
      };
    if (stored.state === "running")
      return {
        status: "unsupported",
        submitted: 0,
        total: stored.modernMidroll?.positions.length ?? stored.midroll?.positions.length ?? stored.steps.length,
        message: "Esta pr\xE9via j\xE1 est\xE1 em execu\xE7\xE3o."
      };
    const { document: doc, steps, controller } = stored;
    const total = stored.modernMidroll?.positions.length ?? stored.midroll?.positions.length ?? steps.length;
    if (Date.now() > stored.expires || doc.location.href !== stored.url || [...steps, ...stored.guards].some((step) => !stepIsCurrent(step)) || stored.modernMidroll && !modernIsCurrent(stored.modernMidroll, doc) || stored.midroll && (!midrollContextIsCurrent(stored.midroll, doc) || midrollFields(stored.midroll.editor).length !== stored.midroll.initialFields.length || midrollFields(stored.midroll.editor).some(
      (field, index) => field !== stored.midroll.initialFields[index]
    ))) {
      plans.delete(planId);
      return {
        status: "stale",
        submitted: 0,
        total,
        message: "A p\xE1gina ou os controles mudaram. Gere uma nova pr\xE9via antes de confirmar."
      };
    }
    stored.state = "running";
    const onAbort = () => controller.abort();
    signal?.addEventListener("abort", onAbort, { once: true });
    if (signal?.aborted) controller.abort();
    let submitted = 0;
    try {
      if (stored.modernMidroll) return await executeModernMidrolls(stored);
      if (stored.midroll) return await executeMidrolls(stored);
      for (const step of steps) {
        if (controller.signal.aborted)
          return {
            status: "cancelled",
            submitted,
            total: steps.length,
            message: "Execu\xE7\xE3o cancelada. Comandos anteriores podem j\xE1 ter sido aplicados pelo YouTube."
          };
        if (doc.location.href !== stored.url || !stepIsCurrent(step) || stored.guards.some((guard) => !stepIsCurrent(guard)))
          return {
            status: "stale",
            submitted,
            total: steps.length,
            message: "Um controle mudou durante a execu\xE7\xE3o. A rotina foi interrompida; confira o resultado no Studio."
          };
        if (step.value !== void 0) {
          setFieldValue(doc, step.element, step.value);
        } else step.element.click();
        submitted++;
        if (submitted < steps.length) await wait(150, controller.signal);
      }
      return {
        status: "completed",
        submitted,
        total: steps.length,
        message: stored.publicPlan.action === "midrolls" ? "Campos preenchidos. Revise e salve manualmente no Studio." : "Cliques enviados. Confira o estado final no Studio; o envio n\xE3o confirma a aceita\xE7\xE3o do servidor."
      };
    } catch (error) {
      return {
        status: controller.signal.aborted ? "cancelled" : "error",
        submitted,
        total: steps.length,
        message: controller.signal.aborted ? "Execu\xE7\xE3o cancelada; confira altera\xE7\xF5es j\xE1 enviadas." : error instanceof Error ? error.message : "Falha ao operar o controle do Studio."
      };
    } finally {
      signal?.removeEventListener("abort", onAbort);
      plans.delete(planId);
    }
  }
  function cancelStudioPlan(planId) {
    const stored = plans.get(planId);
    if (!stored) return false;
    stored.controller.abort();
    plans.delete(planId);
    return true;
  }
  var validStudioDate = (value) => /^\d{4}-\d{2}-\d{2}$/.test(value) && Number.isFinite(Date.parse(value)) && new Date(value).toISOString().slice(0, 10) === value;
  function dateIdentity(field) {
    return JSON.stringify(["id", "name", "type", "aria-label", "min", "max", "step"].map((name) => field.getAttribute(name)));
  }
  function writable(field) {
    return enabled(field) && !field.readOnly && field.getAttribute("aria-readonly") !== "true" && !field.closest("ytcp-media-timestamp-input[disabled],ytcp-media-timestamp-input[readonly]");
  }
  function openDateDialog(doc) {
    const dialogs = Array.from(doc.querySelectorAll('yta-date-range-dialog, yta-date-picker-dialog, yta-date-range-picker, [role="dialog"]')).filter(visible);
    const candidates = dialogs.map((dialog) => ({ dialog, fields: Array.from(dialog.querySelectorAll('input[type="date"]')).filter(visible) })).filter((item) => item.fields.length === 2);
    const inner = candidates.filter((item) => !candidates.some((other) => other !== item && item.dialog.contains(other.dialog)));
    return inner.length === 1 ? inner[0] : void 0;
  }
  function periodContext(doc, dialog) {
    const root = dialog.closest("[video-id],[data-video-id],[channel-id],[data-channel-id]") ?? dialog;
    return JSON.stringify({ url: doc.location?.href, dialog: ["id", "role", "aria-label", "data-date-context", "data-period", "data-context-id"].map((key) => dialog.getAttribute(key)), root: [root.tagName, ...["id", "video-id", "data-video-id", "channel-id", "data-channel-id"].map((key) => root.getAttribute(key))] });
  }
  function fillPeriod(start, end, doc) {
    const bad = (message, filled2 = 0) => ({ result: { status: "unsupported", message, filled: filled2, source: "studio-dom" } });
    if (!validStudioDate(start) || !validStudioDate(end) || start > end) return bad("Use datas v\xE1lidas no formato AAAA-MM-DD, com in\xEDcio anterior ao fim.");
    if (!studioDocument(doc)) return bad("Abra o YouTube Studio.");
    const initial = openDateDialog(doc);
    if (!initial || initial.fields.some((field) => !writable(field))) return bad("Abra um \xFAnico seletor de per\xEDodo personalizado com dois campos nativos de data edit\xE1veis. Campos somente leitura, desativados ou desconhecidos n\xE3o s\xE3o alterados.");
    const context = periodContext(doc, initial.dialog), identities = initial.fields.map(dateIdentity), originalValues = initial.fields.map((field) => field.value);
    let filled = 0;
    const current = () => {
      const next = openDateDialog(doc);
      if (!next || next.dialog !== initial.dialog || periodContext(doc, next.dialog) !== context || next.fields.some((field, index) => !writable(field) || dateIdentity(field) !== identities[index])) throw new Error("O di\xE1logo, a identidade do canal/v\xEDdeo ou os controles de data mudaram.");
      return next.fields;
    };
    const setter = Object.getOwnPropertyDescriptor(doc.defaultView.HTMLInputElement.prototype, "value")?.set;
    if (!setter) return bad("O setter nativo dos campos de data n\xE3o est\xE1 dispon\xEDvel.");
    try {
      for (let index = 0; index < 2; index++) {
        let fields = current();
        if (fields[index].value !== originalValues[index]) throw new Error("O contexto dos valores de data mudou antes do preenchimento.");
        const value = index === 0 ? start : end;
        setter.call(fields[index], value);
        filled++;
        fields[index].dispatchEvent(new doc.defaultView.Event("input", { bubbles: true }));
        fields = current();
        if (fields[index].value !== value) throw new Error("O campo n\xE3o preservou a data ap\xF3s o evento input.");
        fields[index].dispatchEvent(new doc.defaultView.Event("change", { bubbles: true }));
        fields = current();
        if (fields[index].value !== value || index === 1 && fields[0].value !== start) throw new Error("O per\xEDodo foi alterado pela p\xE1gina durante o preenchimento.");
      }
      const verify = () => {
        try {
          const fields = current();
          return fields[0].value === start && fields[1].value === end;
        } catch {
          return false;
        }
      };
      return { result: { status: "ready", message: "Per\xEDodo preenchido. Revise e clique em Aplicar manualmente no Studio.", filled, source: "studio-dom" }, verify };
    } catch (error) {
      return bad(`${error instanceof Error ? error.message : "O preenchimento foi interrompido."} ${filled ? "Pode haver preenchimento parcial; confira as duas datas no Studio." : "Nenhum campo foi preenchido."} Nenhum bot\xE3o Aplicar foi acionado.`, filled);
    }
  }
  async function setStudioPeriodVerified(start, end, doc = document) {
    const operation = fillPeriod(start, end, doc);
    if (operation.result.status !== "ready") return operation.result;
    await new Promise((resolve) => setTimeout(resolve, 40));
    if (!operation.verify?.()) return { status: "unsupported", source: "studio-dom", filled: operation.result.filled, message: "O Studio refez ou alterou o per\xEDodo ap\xF3s o preenchimento. O estado pode ser parcial; confira as datas e aplique manualmente. Nenhum bot\xE3o Aplicar foi acionado." };
    return operation.result;
  }
  function getStudioScreenshotTargets(kind, doc = document) {
    if (!studioDocument(doc)) return [];
    const selectors = kind === "latest-performance" ? [".main #video-snapshot", "ytcp-video-performance-card,ytcp-latest-video-card,ytcd-video-snapshot"] : ["#top-section", "ytcp-analytics-section,ytcp-channel-analytics,#analytics-content"];
    for (const selector of selectors) {
      const candidates = unique(Array.from(doc.querySelectorAll(selector))).filter(visible);
      if (candidates.length === 1) return candidates;
      if (candidates.length > 1) return [];
    }
    return [];
  }
  function getStudioRedactionDetails(doc = document, categories = ["channel", "revenue", "subscribers", "views", "video-info"]) {
    const selected = new Set(categories), elements = [], coarseSelectors = [];
    const add = (selector, coarse = false) => {
      const found = Array.from(doc.querySelectorAll(selector)).filter(visible);
      elements.push(...found);
      if (coarse && found.length) coarseSelectors.push(selector);
    };
    if (!studioDocument(doc)) return { elements: [], coarse: false, coarseSelectors: [], categories: [] };
    if (selected.has("channel")) {
      add("#channel-name, #channel-avatar, ytcp-avatar");
      if (!elements.length) add("#right-side-bar", true);
    }
    if (selected.has("video-info")) add("#entity-snapshot-title");
    if (selected.has("revenue")) add("#TOTAL_ESTIMATED_EARNINGS-tab #metric-total");
    const allMetrics = ["revenue", "subscribers", "views"].every((category) => selected.has(category));
    for (const card of doc.querySelectorAll("yta-key-metric-card, yta-key-metric-block, [data-metric]")) {
      if (!visible(card)) continue;
      const metric = normalize2(card.getAttribute("data-metric") ?? card.querySelector("#title,#metric-title,.metric-title,[data-label]")?.textContent ?? "");
      if (selected.has("revenue") && /revenue|receita/.test(metric) || selected.has("subscribers") && /subscribers|inscritos/.test(metric) || selected.has("views") && /views|visualiz/.test(metric)) elements.push(card);
      else if (allMetrics && !metric) {
        elements.push(card);
        coarseSelectors.push("card de m\xE9tricas sem r\xF3tulo reconhecido");
      }
    }
    if (allMetrics) add("#key-metric-header", true);
    if (selected.size === 5) add("[data-prevlev-sensitive]", true);
    return { elements: unique(elements), coarse: coarseSelectors.length > 0, coarseSelectors: unique(coarseSelectors), categories: [...selected] };
  }

  // src/content/timeline.ts
  var HOST_ID = "prevlev-timeline";
  var controllers = /* @__PURE__ */ new WeakMap();
  var MEDIA_EVENTS = [
    "timeupdate",
    "durationchange",
    "loadedmetadata",
    "play",
    "pause",
    "emptied"
  ];
  var MAX_SEGMENTS = 5e3;
  var MAX_VISIBLE_SEGMENTS = 200;
  function time(seconds) {
    const value = Math.max(0, Math.floor(seconds));
    const hours = Math.floor(value / 3600);
    const minutes = Math.floor(value / 60) % 60;
    const secondsPart = String(value % 60).padStart(2, "0");
    return `${hours ? `${hours}:` : ""}${String(minutes).padStart(2, "0")}:${secondsPart}`;
  }
  function normalized(value) {
    return value.normalize("NFD").replace(new RegExp("\\p{M}", "gu"), "").toLocaleLowerCase("pt-BR");
  }
  function mountTimeline(doc = document) {
    const mounted = controllers.get(doc);
    if (mounted) return mounted;
    let video = null;
    let host;
    let shadow;
    let segments = [];
    let segmentSignature = "";
    let videoIdentity2 = "";
    let transcriptTruncated = false;
    const accumulated = /* @__PURE__ */ new Map();
    let lastLoadedSignature = "", staleSignature = "";
    let query = "";
    let destroyed = false;
    const selected = /* @__PURE__ */ new Set();
    const segmentKey = (segment) => Math.round(segment.start * 1e3);
    const field = (id) => shadow?.getElementById(id);
    const status = (message) => {
      const output = field("status");
      if (output) output.textContent = message;
    };
    const getState = () => {
      const duration = video && Number.isFinite(video.duration) && video.duration > 0 ? video.duration : void 0;
      return {
        available: !!video?.isConnected,
        currentTime: video && Number.isFinite(video.currentTime) ? video.currentTime : 0,
        duration,
        paused: video?.paused ?? true,
        videoId: videoIdFromUrl(doc.location?.href ?? ""),
        segments: segments.map((segment) => ({ ...segment })),
        limitations: [
          "Passo de frame estimado em 1/30 s; a taxa de quadros real n\xE3o \xE9 conhecida.",
          "Transcri\xE7\xE3o usa somente trechos j\xE1 carregados pelo YouTube. Abra Mostrar transcri\xE7\xE3o para disponibiliz\xE1-los.",
          "Trechos observados s\xE3o acumulados por timestamp at\xE9 mudar de v\xEDdeo. Conflitos no mesmo timestamp usam o \xFAltimo texto observado; a lista \xE9 ordenada pelo in\xEDcio.",
          ...!duration ? [
            "Dura\xE7\xE3o ainda n\xE3o dispon\xEDvel ou transmiss\xE3o ao vivo. Busca temporal desativada."
          ] : [],
          ...transcriptTruncated ? [`Leitura limitada a ${MAX_SEGMENTS} trechos carregados.`] : []
        ]
      };
    };
    function renderTime() {
      const state = getState();
      const label2 = field("time");
      if (label2)
        label2.textContent = `${time(state.currentTime)} / ${state.duration === void 0 ? "dura\xE7\xE3o indispon\xEDvel" : time(state.duration)}`;
      const slider = field("seek");
      if (slider) {
        slider.disabled = !state.available || state.duration === void 0;
        slider.max = String(state.duration ?? 0);
        if (shadow?.activeElement !== slider)
          slider.value = String(state.currentTime);
        slider.setAttribute(
          "aria-valuetext",
          `${time(state.currentTime)} de ${state.duration ? time(state.duration) : "dura\xE7\xE3o indispon\xEDvel"}`
        );
      }
      const play = field("play");
      if (play) {
        play.textContent = state.paused ? "Reproduzir" : "Pausar";
        play.disabled = !state.available;
      }
      for (const button of shadow?.querySelectorAll(
        "[data-seek]"
      ) ?? [])
        button.disabled = !state.available || state.duration === void 0;
      for (const row of shadow?.querySelectorAll("[data-segment]") ?? []) {
        const index = Number(row.dataset.segment);
        const segment = segments[index];
        const end = segment ? segments[index + 1]?.start ?? (segment.duration > 0 ? segment.start + segment.duration : state.duration ?? segment.start) : 0;
        if (segment && state.currentTime >= segment.start && state.currentTime < end)
          row.setAttribute("aria-current", "true");
        else row.removeAttribute("aria-current");
      }
    }
    function filteredIndices() {
      const needle = normalized(query.trim());
      return segments.flatMap(
        (segment, index) => !needle || normalized(segment.text).includes(needle) ? [index] : []
      );
    }
    function selectedSegments() {
      return segments.filter((segment) => selected.has(segmentKey(segment)));
    }
    function exportSegments() {
      return selected.size ? selectedSegments() : filteredIndices().map((index) => segments[index]);
    }
    function updateCount() {
      const count2 = field("count");
      const filtered = filteredIndices();
      if (count2)
        count2.textContent = segments.length ? `${filtered.length} de ${segments.length} trechos \xB7 ${selected.size} selecionados${filtered.length > MAX_VISIBLE_SEGMENTS ? ` \xB7 exibindo os primeiros ${MAX_VISIBLE_SEGMENTS}; refine a busca` : ""}` : "Abra Mostrar transcri\xE7\xE3o no YouTube. Nenhum trecho carregado foi encontrado.";
      const copy = field("copy");
      if (copy) copy.disabled = selected.size === 0;
      for (const id of ["txt", "vtt", "select-filtered"]) {
        const button = field(id);
        if (button) button.disabled = exportSegments().length === 0;
      }
    }
    function renderTranscript() {
      const list = field("segments");
      if (!list) return;
      list.replaceChildren();
      for (const index of filteredIndices().slice(0, MAX_VISIBLE_SEGMENTS)) {
        const segment = segments[index];
        const row = doc.createElement("div");
        row.className = "segment";
        row.dataset.segment = String(index);
        const checkbox = doc.createElement("input");
        checkbox.type = "checkbox";
        checkbox.checked = selected.has(segmentKey(segment));
        checkbox.setAttribute(
          "aria-label",
          `Selecionar trecho ${time(segment.start)}: ${segment.text}`
        );
        checkbox.addEventListener("change", () => {
          if (checkbox.checked) selected.add(segmentKey(segment));
          else selected.delete(segmentKey(segment));
          updateCount();
        });
        const button = doc.createElement("button");
        button.className = "transcript-seek";
        button.textContent = `${time(segment.start)}  ${segment.text}`;
        button.setAttribute(
          "aria-label",
          `Ir para ${time(segment.start)}: ${segment.text}`
        );
        button.addEventListener("click", () => {
          try {
            seek(segment.start);
          } catch (error) {
            showError(error);
          }
        });
        row.append(checkbox, button);
        list.append(row);
      }
      updateCount();
      renderTime();
    }
    function showError(error) {
      status(error instanceof Error ? error.message : String(error));
    }
    function seek(seconds) {
      if (!video?.isConnected)
        throw new Error("Nenhum player de v\xEDdeo est\xE1 dispon\xEDvel nesta p\xE1gina.");
      const duration = getState().duration;
      if (duration === void 0)
        throw new Error(
          "Aguarde a dura\xE7\xE3o do v\xEDdeo carregar. Transmiss\xF5es ao vivo n\xE3o t\xEAm busca temporal nesta ferramenta."
        );
      if (!Number.isFinite(seconds))
        throw new Error("Informe uma posi\xE7\xE3o v\xE1lida em segundos.");
      video.currentTime = Math.max(0, Math.min(duration, seconds));
      renderTime();
      status(
        `Posi\xE7\xE3o: ${time(video.currentTime)}. A reprodu\xE7\xE3o n\xE3o foi iniciada automaticamente.`
      );
      return getState();
    }
    async function togglePlayback() {
      if (!video?.isConnected)
        throw new Error("Nenhum player de v\xEDdeo est\xE1 dispon\xEDvel nesta p\xE1gina.");
      if (video.paused) {
        try {
          await video.play();
        } catch {
          throw new Error(
            "O navegador ou o player bloqueou a reprodu\xE7\xE3o. Use o bot\xE3o de reprodu\xE7\xE3o do YouTube."
          );
        }
      } else video.pause();
      renderTime();
      return getState();
    }
    function mountPanel() {
      if (host?.isConnected) return;
      doc.getElementById(HOST_ID)?.remove();
      host = doc.createElement("div");
      host.id = HOST_ID;
      host.style.cssText = "position:fixed;right:18px;bottom:18px;z-index:2147483645;max-width:calc(100vw - 36px)";
      shadow = host.attachShadow({ mode: "open" });
      shadow.innerHTML = `<style>:host{font:13px/1.5 system-ui;color:#f5f5fa}*{box-sizing:border-box}details{background:#15161e;border:1px solid #454050;border-radius:12px;width:390px;max-width:calc(100vw - 36px);box-shadow:0 8px 30px #0006}summary{padding:12px;cursor:pointer;font-weight:700;color:#c3baff}section{display:grid;gap:8px;padding:0 12px 12px;max-height:75vh;overflow:auto}button,input{font:inherit}button{border:0;border-radius:6px;padding:8px;background:#403564;color:#fff;cursor:pointer}button:disabled{opacity:.5;cursor:default}button:focus-visible,input:focus-visible,summary:focus-visible{outline:2px solid #c3baff;outline-offset:2px}.row{display:flex;gap:6px;flex-wrap:wrap}label{display:grid;gap:4px}input[type=range]{width:100%}input[type=search]{width:100%;padding:8px;background:#242532;color:#fff;border:1px solid #626277;border-radius:6px}p{margin:0;color:#bdc0d0;font-size:11px}.segments{max-height:230px;overflow:auto;display:grid;gap:4px}.segment{display:flex;align-items:flex-start;gap:6px;border-radius:5px}.segment[aria-current=true]{background:#373052}.segment input{margin:11px 0 0}.transcript-seek{background:transparent;text-align:left;line-height:1.5;width:100%}#status{color:#c3baff;min-height:16px}</style><details><summary>Prevlev \xB7 Timeline e transcri\xE7\xE3o</summary><section aria-label="Ferramentas locais do player"><label>Posi\xE7\xE3o do v\xEDdeo <output id="time"></output><input id="seek" type="range" min="0" max="0" step="0.1" value="0" aria-label="Posi\xE7\xE3o do v\xEDdeo"></label><div class="row"><button id="play">Reproduzir</button><button data-seek="-5">\u22125 s</button><button data-seek="5">+5 s</button><button data-seek="-0.03333333333333333">\u22121/30 s</button><button data-seek="0.03333333333333333">+1/30 s</button></div><p>Passo de frame estimado em 1/30 s. A taxa de quadros real n\xE3o \xE9 conhecida. Mover a posi\xE7\xE3o n\xE3o inicia o v\xEDdeo.</p><button id="frame">Capturar e baixar frame PNG</button><label>Buscar na transcri\xE7\xE3o carregada<input id="search" type="search" placeholder="Palavra ou frase"></label><p id="count"></p><div class="row"><button id="select-filtered">Selecionar filtro</button><button id="clear">Limpar sele\xE7\xE3o</button></div><div id="segments" class="segments" aria-label="Trechos da transcri\xE7\xE3o"></div><div class="row"><button id="copy" disabled>Copiar selecionados</button><button id="txt">Baixar TXT</button><button id="vtt">Baixar VTT</button></div><p>TXT e VTT exportam a sele\xE7\xE3o; sem sele\xE7\xE3o, exportam o filtro atual. Somente texto j\xE1 carregado. Os trechos clic\xE1veis movem o player.</p><p id="status" role="status" aria-live="polite"></p></section></details>`;
      field("seek")?.addEventListener("change", () => {
        try {
          seek(Number(field("seek")?.value));
        } catch (error) {
          showError(error);
        }
      });
      field("play")?.addEventListener("click", () => {
        void togglePlayback().catch(showError);
      });
      for (const button of shadow.querySelectorAll(
        "[data-seek]"
      ))
        button.addEventListener("click", () => {
          try {
            seek((video?.currentTime ?? 0) + Number(button.dataset.seek));
          } catch (error) {
            showError(error);
          }
        });
      field("frame")?.addEventListener("click", () => {
        if (!video?.isConnected) {
          status("Nenhum player de v\xEDdeo dispon\xEDvel.");
          return;
        }
        const currentVideo = video;
        const timestamp3 = time(video.currentTime).replace(/:/g, "-");
        void captureFrame(currentVideo).then((blob) => {
          downloadBlob(blob, `prevlev-frame-${timestamp3}.png`);
          status("Frame PNG capturado localmente.");
        }).catch(showError);
      });
      field("search")?.addEventListener("input", () => {
        query = field("search")?.value ?? "";
        renderTranscript();
      });
      const restoredSearch = field("search");
      if (restoredSearch) restoredSearch.value = query;
      field("select-filtered")?.addEventListener("click", () => {
        filteredIndices().forEach((index) => selected.add(segmentKey(segments[index])));
        renderTranscript();
      });
      field("clear")?.addEventListener("click", () => {
        selected.clear();
        renderTranscript();
      });
      field("copy")?.addEventListener("click", () => {
        const chosen = selectedSegments();
        if (!chosen.length) {
          status("Selecione um ou mais trechos para copiar.");
          return;
        }
        const clipboard = doc.defaultView?.navigator.clipboard;
        if (!clipboard?.writeText) {
          status("\xC1rea de transfer\xEAncia indispon\xEDvel. Baixe o TXT.");
          return;
        }
        void clipboard.writeText(transcriptText(chosen)).then(() => status(`${chosen.length} trechos copiados.`)).catch(
          () => status("A c\xF3pia foi bloqueada pelo navegador. Baixe o TXT.")
        );
      });
      for (const format of ["txt", "vtt"])
        field(format)?.addEventListener("click", () => {
          const chosen = exportSegments();
          if (!chosen.length) {
            status("Nenhum trecho dispon\xEDvel para exportar.");
            return;
          }
          const text2 = format === "vtt" ? transcriptVtt(chosen, { playerEndSeconds: getState().duration }) : transcriptText(chosen);
          downloadBlob(
            new Blob([text2], {
              type: format === "vtt" ? "text/vtt;charset=utf-8" : "text/plain;charset=utf-8"
            }),
            `prevlev-transcricao.${format}`
          );
          status(
            `${chosen.length} trechos exportados localmente em ${format.toUpperCase()}.`
          );
        });
      doc.documentElement.append(host);
    }
    function refresh() {
      if (destroyed) return getState();
      const youtubePage = /(^|\.)youtube\.com$/.test(
        doc.location?.hostname ?? ""
      );
      const playbackRoute = /^\/(?:watch(?:\/|$)|shorts\/|live\/|embed\/)/.test(
        doc.location?.pathname ?? ""
      );
      const nextVideo = youtubePage && (doc.location?.hostname === "studio.youtube.com" || !playbackRoute) ? null : doc.querySelector(
        "video.html5-main-video,#movie_player video,video"
      );
      const nextIdentity = videoIdFromUrl(doc.location?.href ?? "") ?? "";
      const identityChanged = nextIdentity !== videoIdentity2;
      if (identityChanged) {
        staleSignature = videoIdentity2 ? lastLoadedSignature : "";
        videoIdentity2 = nextIdentity;
        accumulated.clear();
        segments = [];
        selected.clear();
        query = "";
        segmentSignature = "";
        transcriptTruncated = false;
        const search2 = field("search");
        if (search2) search2.value = "";
        status("");
      }
      if (nextVideo !== video) {
        if (video)
          MEDIA_EVENTS.forEach(
            (event) => video?.removeEventListener(event, renderTime)
          );
        video = nextVideo;
        if (video)
          MEDIA_EVENTS.forEach(
            (event) => video?.addEventListener(event, renderTime)
          );
      }
      if (!video) {
        host?.remove();
        host = void 0;
        shadow = void 0;
        return getState();
      }
      mountPanel();
      const loaded = parseTranscript(doc);
      const loadedSignature = JSON.stringify(loaded);
      const stale = !!staleSignature && loadedSignature === staleSignature;
      if (!stale) {
        staleSignature = "";
        lastLoadedSignature = loadedSignature;
        for (const segment of loaded) {
          const key = segmentKey(segment);
          if (!accumulated.has(key) && accumulated.size >= MAX_SEGMENTS) {
            transcriptTruncated = true;
            continue;
          }
          accumulated.set(key, { ...segment });
        }
      }
      transcriptTruncated ||= doc.querySelectorAll(TRANSCRIPT_ROW_SELECTOR).length > MAX_SEGMENTS;
      const ordered = [...accumulated.values()].sort((a, b) => a.start - b.start);
      const nextSegments = ordered.map((segment, index) => {
        const next = ordered[index + 1]?.start;
        return { ...segment, duration: next !== void 0 && next > segment.start ? Math.min(segment.duration > 0 ? segment.duration : Infinity, next - segment.start) : segment.duration };
      });
      const signature2 = JSON.stringify(nextSegments);
      if (signature2 !== segmentSignature) {
        segments = nextSegments;
        segmentSignature = signature2;
        renderTranscript();
      } else {
        updateCount();
        renderTime();
      }
      return getState();
    }
    const onNavigation = () => {
      refresh();
    };
    function cleanup() {
      if (destroyed) return;
      destroyed = true;
      if (video)
        MEDIA_EVENTS.forEach(
          (event) => video?.removeEventListener(event, renderTime)
        );
      doc.removeEventListener("yt-navigate-finish", onNavigation);
      doc.defaultView?.removeEventListener("pagehide", cleanup);
      host?.remove();
      video = null;
      host = void 0;
      shadow = void 0;
      selected.clear();
      accumulated.clear();
      segments = [];
      controllers.delete(doc);
    }
    const controller = {
      refresh,
      getState,
      seek,
      togglePlayback,
      cleanup
    };
    controllers.set(doc, controller);
    doc.addEventListener("yt-navigate-finish", onNavigation);
    doc.defaultView?.addEventListener("pagehide", cleanup);
    refresh();
    return controller;
  }
  function refreshTimeline(doc = document) {
    return mountTimeline(doc).refresh();
  }
  async function dispatchTimeline(message, doc = document) {
    if (!["GET_TIMELINE", "SEEK_VIDEO", "TOGGLE_PLAYBACK"].includes(message.type))
      return void 0;
    const controller = mountTimeline(doc);
    controller.refresh();
    if (message.type === "GET_TIMELINE") return controller.getState();
    if (message.expectedVideoId !== void 0 && (typeof message.expectedVideoId !== "string" || controller.getState().videoId !== message.expectedVideoId))
      throw new Error(
        "O v\xEDdeo da aba mudou desde a leitura do painel. Atualize a timeline antes de controlar o player."
      );
    if (message.type === "TOGGLE_PLAYBACK") return controller.togglePlayback();
    if (typeof message.seconds !== "number")
      throw new Error("Informe uma posi\xE7\xE3o num\xE9rica em segundos.");
    return controller.seek(message.seconds);
  }

  // src/content/collection.ts
  var limitations = [
    "Coleta parcial dos itens reconhecidos pelo DOM; n\xE3o garante o cat\xE1logo completo nem todos os coment\xE1rios.",
    "Rola somente o feed ou a se\xE7\xE3o de coment\xE1rios reconhecida. N\xE3o clica em bot\xF5es, recomenda\xE7\xF5es ou expans\xE3o de respostas.",
    "A p\xE1gina do YouTube pode carregar itens pela sua sess\xE3o normal ao rolar; o Prevlev n\xE3o chama APIs privadas nem servi\xE7os de IA nesta coleta.",
    "Limites m\xE1ximos: 500 itens, 30 rolagens e 60 segundos. Tr\xEAs etapas sem novos IDs encerram a coleta."
  ];
  var controllers2 = /* @__PURE__ */ new WeakMap();
  function bounded(value, fallback, min, max, name) {
    if (value === void 0) return fallback;
    if (typeof value !== "number" || !Number.isInteger(value) || value < min || value > max) throw new Error(`${name} deve ser um inteiro entre ${min} e ${max}.`);
    return value;
  }
  function normalize3(input) {
    if (!input || !["videos", "comments"].includes(input.kind)) throw new Error("Escolha v\xEDdeos ou coment\xE1rios para coletar.");
    return { kind: input.kind, maxItems: bounded(input.maxItems, 200, 1, 500, "Quantidade"), maxSteps: bounded(input.maxSteps, 10, 1, 30, "Etapas"), timeoutMs: bounded(input.timeoutMs, 3e4, 1e3, 6e4, "Tempo em milissegundos") };
  }
  function videoIdentity(doc) {
    const route = videoIdFromUrl(doc.location.href);
    if (!route) return "";
    const raw = doc.querySelector("ytd-watch-flexy[video-id]")?.getAttribute("video-id") ?? doc.querySelector('meta[itemprop="videoId"]')?.content;
    const displayed = raw && /^[\w-]{11}$/.test(raw) ? raw : route;
    return `${route}:${displayed}`;
  }
  function regionFor(doc, kind) {
    if (doc.location?.hostname !== "www.youtube.com") throw new Error("Esta coleta exige uma p\xE1gina p\xFAblica do YouTube aberta.");
    const selectors = kind === "comments" ? "ytd-comments ytd-item-section-renderer #contents,ytd-comments #contents,ytd-comments" : "ytd-rich-grid-renderer,ytd-grid-renderer,ytd-search ytd-item-section-renderer,ytd-browse ytd-section-list-renderer,ytd-search ytd-section-list-renderer";
    const regions = Array.from(doc.querySelectorAll(selectors));
    const found = kind === "videos" ? regions.find((region) => readVideoCards(doc).some((card) => region.contains(card.element))) : regions.find((region) => readComments(region).length > 0) ?? regions[0];
    if (!found) throw new Error(kind === "comments" ? "Abra a se\xE7\xE3o de coment\xE1rios do YouTube. O feed n\xE3o foi reconhecido." : "Abra uma grade ou feed de v\xEDdeos do YouTube reconhecido para coletar.");
    return found;
  }
  function pause(milliseconds, signal) {
    return new Promise((resolve, reject) => {
      if (signal.aborted) {
        reject(new Error("cancelled"));
        return;
      }
      const abort = () => {
        clearTimeout(timer);
        reject(new Error("cancelled"));
      };
      const timer = setTimeout(() => {
        signal.removeEventListener("abort", abort);
        resolve();
      }, milliseconds);
      signal.addEventListener("abort", abort, { once: true });
    });
  }
  function createCollectionController(doc = document) {
    const existing = controllers2.get(doc);
    if (existing) return existing;
    let current;
    const subscribers = /* @__PURE__ */ new Set();
    const contextMatches = (job) => !job.invalidContext && doc.location.href === job.state.url && videoIdentity(doc) === job.videoIdentity;
    const getState = () => current ? { ...current.state, limitations: [...current.state.limitations] } : { phase: "idle", collectedCount: 0, steps: 0, maxItems: 0, maxSteps: 0, timeoutMs: 0, url: doc.location?.href ?? "", reason: "Nenhuma coleta iniciada.", limitations: [...limitations] };
    const emit = () => {
      const state = getState();
      for (const listener of subscribers) try {
        listener(state);
      } catch {
      }
    };
    function selected(jobId) {
      if (jobId !== void 0 && (!current || current.state.jobId !== jobId)) throw new Error("Esta coleta n\xE3o \xE9 mais a coleta atual da aba.");
      return current;
    }
    function finish(job, phase, reason, restore = true) {
      if (job.state.phase !== "running") return;
      job.state.phase = phase;
      job.state.reason = reason;
      job.state.finishedAt = (/* @__PURE__ */ new Date()).toISOString();
      job.abort.abort();
      if (job.timer) clearTimeout(job.timer);
      job.timer = void 0;
      job.cleanup();
      if (restore && contextMatches(job) && job.region.isConnected) {
        try {
          if (job.internalScroll) {
            job.region.scrollTop = job.original.top;
            job.region.scrollLeft = job.original.left;
          } else doc.defaultView?.scrollTo({ left: job.original.x, top: job.original.y, behavior: "instant" });
        } catch {
        }
      }
      emit();
    }
    function scan(job) {
      if (!contextMatches(job) || !job.region.isConnected) {
        finish(job, "cancelled", "A p\xE1gina, o v\xEDdeo ou o feed mudou; a coleta foi interrompida.", false);
        return 0;
      }
      const at = (/* @__PURE__ */ new Date()).toISOString();
      const entries = job.state.kind === "videos" ? readVideoCards(doc).filter((card) => job.region.contains(card.element)).map((card) => ({ ...card.video, source: "youtube-dom", observedAt: at })) : readComments(job.region);
      let added = 0;
      for (const record3 of entries) {
        if (!record3.id || job.records.has(record3.id)) continue;
        job.records.set(record3.id, { ...record3 });
        added++;
        if (job.records.size >= job.state.maxItems) break;
      }
      job.state.collectedCount = job.records.size;
      emit();
      return added;
    }
    async function run(job) {
      try {
        scan(job);
        if (job.state.phase !== "running") return;
        if (job.records.size >= job.state.maxItems) {
          finish(job, "completed", "Limite de itens atingido; o resultado continua sendo uma amostra parcial.");
          return;
        }
        let stalls = 0;
        while (job.state.phase === "running" && job.state.steps < job.state.maxSteps) {
          if (!contextMatches(job) || !job.region.isConnected) {
            finish(job, "cancelled", "O contexto da p\xE1gina mudou; nenhuma nova rolagem foi feita.", false);
            return;
          }
          job.state.steps++;
          if (job.internalScroll) job.region.scrollTop = Math.max(job.region.scrollHeight - job.region.clientHeight, 0);
          else {
            if (typeof job.region.scrollIntoView !== "function") throw new Error("unsupported-scroll");
            job.region.scrollIntoView({ block: "end", behavior: "instant" });
          }
          emit();
          await pause(500, job.abort.signal);
          if (job.state.phase !== "running") return;
          const added = scan(job);
          if (job.state.phase !== "running") return;
          if (job.records.size >= job.state.maxItems) {
            finish(job, "completed", "Limite de itens atingido; o resultado continua sendo uma amostra parcial.");
            return;
          }
          stalls = added ? 0 : stalls + 1;
          if (stalls >= 3) {
            finish(job, "stopped", "Tr\xEAs etapas sem novos IDs reconhecidos. Isso n\xE3o comprova que todos os itens foram carregados.");
            return;
          }
        }
        if (job.state.phase === "running") finish(job, "stopped", "Limite de rolagens atingido; a coleta \xE9 parcial.");
      } catch {
        if (job.state.phase === "running") finish(job, "error", "N\xE3o foi poss\xEDvel continuar a leitura ou rolagem neste layout. Os itens j\xE1 observados foram preservados.");
      }
    }
    const controller = {
      start(input) {
        if (current?.state.phase === "running") throw new Error("Uma coleta j\xE1 est\xE1 em andamento nesta aba. Cancele-a ou aguarde.");
        const options = normalize3(input), region = regionFor(doc, options.kind), identity = videoIdentity(doc);
        if (identity && new Set(identity.split(":")).size !== 1) throw new Error("A identidade do v\xEDdeo ainda est\xE1 mudando. Aguarde o YouTube terminar a navega\xE7\xE3o.");
        const job = { state: { jobId: crypto.randomUUID(), ...options, phase: "running", collectedCount: 0, steps: 0, url: doc.location.href, videoId: videoIdFromUrl(doc.location.href), startedAt: (/* @__PURE__ */ new Date()).toISOString(), reason: "Lendo os itens carregados e rolando somente o feed reconhecido.", limitations: [...limitations] }, title: doc.title.replace(/\s*- YouTube$/, ""), videoIdentity: identity, region, abort: new AbortController(), records: /* @__PURE__ */ new Map(), original: { x: doc.defaultView?.scrollX ?? 0, y: doc.defaultView?.scrollY ?? 0, top: region.scrollTop, left: region.scrollLeft }, internalScroll: region.scrollHeight > region.clientHeight && /auto|scroll/.test(doc.defaultView?.getComputedStyle(region).overflowY ?? ""), invalidContext: false, cleanup: () => {
        } };
        const onNavigate = () => {
          job.invalidContext = true;
          finish(job, "cancelled", "Navega\xE7\xE3o detectada. Os resultados pertencem \xE0 p\xE1gina anterior e n\xE3o foram mesclados.", false);
        };
        const onHide = () => {
          job.invalidContext = true;
          finish(job, "cancelled", "A p\xE1gina foi fechada ou suspensa; a coleta foi encerrada.", false);
        };
        doc.addEventListener("yt-navigate-start", onNavigate);
        doc.addEventListener("yt-navigate-finish", onNavigate);
        doc.defaultView?.addEventListener("pagehide", onHide);
        job.cleanup = () => {
          doc.removeEventListener("yt-navigate-start", onNavigate);
          doc.removeEventListener("yt-navigate-finish", onNavigate);
          doc.defaultView?.removeEventListener("pagehide", onHide);
        };
        current = job;
        job.timer = setTimeout(() => finish(job, "stopped", "Tempo m\xE1ximo atingido; a coleta \xE9 parcial."), options.timeoutMs);
        emit();
        job.promise = run(job);
        return getState();
      },
      status(jobId) {
        selected(jobId);
        return getState();
      },
      cancel(jobId) {
        const job = selected(jobId);
        if (job?.state.phase === "running") finish(job, "cancelled", "Coleta cancelada pelo usu\xE1rio; itens j\xE1 observados foram preservados.");
        return getState();
      },
      snapshot(jobId) {
        const job = selected(jobId);
        if (!job || job.state.phase === "running") return void 0;
        return { url: job.state.url, title: job.title, videoId: job.state.videoId, videos: job.state.kind === "videos" ? Array.from(job.records.values(), (record3) => ({ ...record3 })) : [], comments: job.state.kind === "comments" ? Array.from(job.records.values(), (record3) => ({ ...record3 })) : [], transcript: [], warnings: [...limitations, job.state.reason, `Foram observados ${job.records.size} IDs em ${job.state.steps} rolagens. Nenhum dado foi preenchido para itens ausentes.`] };
      },
      subscribe(listener) {
        subscribers.add(listener);
        listener(getState());
        return () => subscribers.delete(listener);
      },
      dispose() {
        const job = current;
        if (job?.state.phase === "running") {
          job.invalidContext = true;
          finish(job, "cancelled", "A p\xE1gina foi suspensa ou substitu\xEDda; a coleta foi encerrada.", false);
        }
        job?.cleanup();
      }
    };
    controllers2.set(doc, controller);
    return controller;
  }
  function mountCollectionControls(container, collector, onUse) {
    container.innerHTML = '<fieldset><legend>Coleta assistida, por rolagem</legend><label>Itens<select id="prevlev-collection-kind"><option value="videos">V\xEDdeos do feed/grade</option><option value="comments">Coment\xE1rios abertos</option></select></label><label>M\xE1ximo de itens<input id="prevlev-collection-limit" type="number" min="1" max="500" value="200"></label><div class="row"><button id="prevlev-collection-start">Iniciar coleta</button><button id="prevlev-collection-cancel" disabled>Cancelar</button><button id="prevlev-collection-use" disabled>Abrir coleta no painel</button></div><p id="prevlev-collection-status" role="status"></p><p>At\xE9 30 rolagens e 60 s; n\xE3o expande respostas. O resultado \xE9 parcial. A posi\xE7\xE3o \xE9 restaurada quando o contexto permanece igual.</p></fieldset>';
    const field = (id) => container.querySelector(`#prevlev-collection-${id}`);
    let using = false;
    const unsubscribe = collector.subscribe((state) => {
      const running = state.phase === "running";
      field("start").disabled = running;
      field("cancel").disabled = !running;
      field("use").disabled = running || !state.collectedCount || using;
      field("status").textContent = `${state.collectedCount} itens \xB7 ${state.steps} rolagens \xB7 ${state.reason}`;
    });
    field("start").addEventListener("click", () => {
      try {
        collector.start({ kind: field("kind").value, maxItems: Number(field("limit").value), maxSteps: 30, timeoutMs: 6e4 });
      } catch (error) {
        field("status").textContent = error instanceof Error ? error.message : String(error);
      }
    });
    field("cancel").addEventListener("click", () => {
      collector.cancel();
    });
    field("use").addEventListener("click", () => {
      const snapshot = collector.snapshot();
      if (!snapshot || using) return;
      using = true;
      field("use").disabled = true;
      void onUse(snapshot).catch((error) => {
        field("status").textContent = error instanceof Error ? error.message : String(error);
      }).finally(() => {
        using = false;
        field("use").disabled = false;
      });
    });
    return unsubscribe;
  }

  // src/core/enrichment.ts
  var MAX_PAGE_BYTES = 3 * 1024 * 1024;
  function parsePublicChannelPage(html) {
    const result = { source: "public-youtube", warnings: [] };
    if (html.length > MAX_PAGE_BYTES)
      return {
        ...result,
        warnings: ["P\xE1gina de canal acima do limite de 3 MiB."]
      };
    for (const match of html.matchAll(/"subscriberCountText"\s*:\s*/g)) {
      const value = readLiteral(html, match.index + match[0].length);
      const text2 = literalText(value);
      const subscribers = text2 === void 0 ? void 0 : parseCount(text2);
      if (subscribers !== void 0) {
        result.subscribers = subscribers;
        break;
      }
    }
    if (result.subscribers === void 0) {
      for (const match of html.matchAll(
        /"(?:content|simpleText|text)"\s*:\s*("(?:\\.|[^"\\])*")/g
      )) {
        const value = parseJsonString(match[1]);
        if (!value || !/^\s*\d[\d.,\s]*(?:bilh(?:ão|ões|ao|oes)|billions?|milh(?:ão|ões|ao|oes)|millions?|mil|[kmb])?\s+(?:de\s+)?(?:subscribers?|inscritos?|assinantes?)\s*$/iu.test(
          value
        ))
          continue;
        const subscribers = parseCount(value);
        if (subscribers !== void 0) {
          result.subscribers = subscribers;
          break;
        }
      }
    }
    for (const key of ["channelMetadataRenderer", "c4TabbedHeaderRenderer"]) {
      const match = new RegExp(`"${key}"\\s*:\\s*`).exec(html);
      if (!match) continue;
      const literal = record(readLiteral(html, match.index + match[0].length));
      const title = literalText(literal.title);
      if (title) {
        result.channelName = title;
        break;
      }
    }
    for (const match of html.matchAll(/<meta\b[^>]*>/gi)) {
      const attributes = {};
      for (const attribute of match[0].matchAll(
        /([\w:-]+)\s*=\s*(?:"([^"]*)"|'([^']*)')/g
      ))
        attributes[attribute[1].toLowerCase()] = decodeEntities(
          attribute[2] ?? attribute[3]
        );
      const key = (attributes.property ?? attributes.name ?? attributes.itemprop ?? "").toLowerCase();
      if (!result.channelName && key === "og:title" && attributes.content)
        result.channelName = attributes.content.replace(/\s+- YouTube$/, "");
      if (result.subscribers === void 0 && /^(?:subscribercount|subscriber_count|subscribers)$/.test(key))
        result.subscribers = parseCount(attributes.content ?? "");
    }
    if (result.subscribers === void 0)
      result.warnings.push(
        "Inscritos n\xE3o encontrados ou n\xE3o publicados nesta p\xE1gina; valor permanece desconhecido."
      );
    return result;
  }
  function buildChannelUrl(video) {
    if (video.channelId && /^UC[A-Za-z0-9_-]{22}$/.test(video.channelId))
      return `https://www.youtube.com/channel/${video.channelId}`;
    if (!video.channelUrl || !/^https:\/\/www\.youtube\.com\//.test(video.channelUrl) || video.channelUrl.includes("\\") || [...video.channelUrl].some(
      (character) => character.charCodeAt(0) <= 32 || character.charCodeAt(0) === 127
    ))
      return void 0;
    try {
      const url = new URL(video.channelUrl);
      if (url.protocol !== "https:" || url.hostname !== "www.youtube.com" || url.username || url.password || url.port || url.search || url.hash)
        return void 0;
      const path = decodeURIComponent(url.pathname).replace(/\/$/, "");
      const rawPath = decodeURIComponent(
        video.channelUrl.slice("https://www.youtube.com".length)
      ).replace(/\/$/, "");
      if (path !== rawPath) return void 0;
      if (/^\/channel\/UC[A-Za-z0-9_-]{22}$/.test(path))
        return `https://www.youtube.com${path}`;
      if (!/^\/@[\p{L}\p{N}_.\-·]{1,100}$/u.test(path)) return void 0;
      return new URL(path, "https://www.youtube.com").href;
    } catch {
      return void 0;
    }
  }
  function readLiteral(text2, offset) {
    if (text2[offset] === '"') {
      const match = /^"(?:\\.|[^"\\])*"/.exec(
        text2.slice(offset, offset + 65536)
      );
      return match ? parseJsonString(match[0]) : void 0;
    }
    if (text2[offset] !== "{") return void 0;
    let depth = 0, quoted = false, escaped = false;
    for (let index = offset; index < Math.min(text2.length, offset + 65536); index++) {
      const character = text2[index];
      if (quoted) {
        if (escaped) escaped = false;
        else if (character === "\\") escaped = true;
        else if (character === '"') quoted = false;
        continue;
      }
      if (character === '"') quoted = true;
      else if (character === "{") depth++;
      else if (character === "}" && --depth === 0) {
        try {
          return JSON.parse(text2.slice(offset, index + 1));
        } catch {
          return void 0;
        }
      }
    }
    return void 0;
  }
  function parseJsonString(value) {
    try {
      const parsed = JSON.parse(value);
      return typeof parsed === "string" ? parsed : void 0;
    } catch {
      return void 0;
    }
  }
  function record(value) {
    return value !== null && typeof value === "object" ? value : {};
  }
  function literalText(value) {
    if (typeof value === "string") return value;
    const object = record(value);
    if (typeof object.simpleText === "string") return object.simpleText;
    if (Array.isArray(object.runs)) {
      const text2 = object.runs.map((run) => record(run).text).filter((item) => typeof item === "string").join("");
      return text2 || void 0;
    }
    return void 0;
  }
  function decodeEntities(text2) {
    return text2.replace(
      /&(?:amp|quot|apos|lt|gt|#\d+|#x[0-9a-f]+);/gi,
      (match) => {
        const named = {
          "&amp;": "&",
          "&quot;": '"',
          "&apos;": "'",
          "&lt;": "<",
          "&gt;": ">"
        };
        if (named[match.toLowerCase()]) return named[match.toLowerCase()];
        const value = match.toLowerCase().startsWith("&#x") ? parseInt(match.slice(3, -1), 16) : Number(match.slice(2, -1));
        return Number.isInteger(value) && value > 0 && value <= 1114111 ? String.fromCodePoint(value) : match;
      }
    );
  }

  // src/core/channel-research.ts
  var MAX_BYTES2 = 3 * 1024 * 1024;
  var VIDEO_ID = /^[A-Za-z0-9_-]{11}$/;
  var COVERAGE = "initial-public-page";
  var record2 = (value) => value !== null && typeof value === "object" && !Array.isArray(value) ? value : {};
  function literalText2(value) {
    if (typeof value === "string") return value;
    const object = record2(value);
    for (const key of ["simpleText", "content", "text"])
      if (typeof object[key] === "string") return object[key];
    if (Array.isArray(object.runs))
      return object.runs.map((run) => record2(run).text).filter((text2) => typeof text2 === "string").join("") || void 0;
    return void 0;
  }
  function readInitialData(html) {
    if (new TextEncoder().encode(html).byteLength > MAX_BYTES2)
      throw new Error("P\xE1gina acima do limite de 3 MiB.");
    const assignments = /(?:\b(?:window\.)?ytInitialData|window\s*\[\s*["']ytInitialData["']\s*\])\s*=\s*/g;
    let candidates = 0;
    for (const match of html.matchAll(assignments)) {
      if (++candidates > 16) break;
      const start = match.index + match[0].length;
      if (html[start] !== "{") continue;
      let depth = 0, quoted = false, escaped = false;
      for (let index = start; index < html.length; index++) {
        const char = html[index];
        if (quoted) {
          if (escaped) escaped = false;
          else if (char === "\\") escaped = true;
          else if (char === '"') quoted = false;
          continue;
        }
        if (char === '"') quoted = true;
        else if (char === "{" || char === "[") depth++;
        else if ((char === "}" || char === "]") && --depth === 0) {
          try {
            return JSON.parse(html.slice(start, index + 1));
          } catch {
            break;
          }
        }
      }
    }
    return void 0;
  }
  function strings(value) {
    const result = [], pending = [value];
    let count2 = 0;
    while (pending.length && count2++ < 1e4) {
      const item = pending.pop();
      if (typeof item === "string") result.push(item);
      else if (Array.isArray(item)) {
        for (const child of item.slice(0, 1e4).reverse()) pending.push(child);
      } else if (item !== null && typeof item === "object") {
        for (const child of Object.values(item).slice(0, 1e4).reverse())
          pending.push(child);
      }
    }
    return result;
  }
  function chosenContent(initial) {
    const contents = record2(record2(initial).contents);
    for (const rendererName of [
      "twoColumnBrowseResultsRenderer",
      "singleColumnBrowseResultsRenderer"
    ]) {
      const tabs = record2(contents[rendererName]).tabs;
      if (!Array.isArray(tabs)) continue;
      for (const item of tabs) {
        const tab = record2(record2(item).tabRenderer);
        if (tab.selected === true && tab.content)
          return { content: tab.content, scoped: true };
      }
    }
    return { content: initial, scoped: false };
  }
  function parseVideo(renderer, modern, channelUrl, now) {
    const id = modern ? renderer.contentId : renderer.videoId;
    if (typeof id !== "string" || !VIDEO_ID.test(id)) return void 0;
    if (modern && renderer.contentType && renderer.contentType !== "LOCKUP_CONTENT_TYPE_VIDEO")
      return void 0;
    const lockupMetadata = record2(
      record2(renderer.metadata).lockupMetadataViewModel
    );
    const title = literalText2(modern ? lockupMetadata.title : renderer.title);
    if (!title) return void 0;
    const metadata = modern ? strings(lockupMetadata.metadata) : [
      literalText2(renderer.viewCountText),
      literalText2(renderer.shortViewCountText),
      literalText2(renderer.publishedTimeText)
    ].filter((value) => !!value);
    const viewsText = metadata.find(
      (value) => /views|visualizaç|visualizac/i.test(value)
    );
    const publishedAt = metadata.map((value) => parsePublishedAt(value, now)).find((value) => value !== void 0);
    const overlayText = strings(
      modern ? renderer.contentImage : renderer.thumbnailOverlays
    );
    const duration = literalText2(renderer.lengthText) ?? overlayText.find((value) => /^\d+(?::\d{1,2}){1,2}$/.test(value));
    const video = {
      id,
      title,
      url: `https://www.youtube.com/watch?v=${id}`,
      channelUrl,
      views: viewsText ? parseCount(viewsText) : void 0,
      publishedAt,
      durationSeconds: duration ? parseDuration(duration) : void 0,
      isShort: false,
      thumbnail: `https://i.ytimg.com/vi/${id}/hqdefault.jpg`
    };
    return video;
  }
  function parseChannelVideos(html, channelUrl, now = Date.now()) {
    const canonical2 = buildChannelUrl({ id: "", title: "", url: "", channelUrl });
    if (!canonical2)
      throw new Error(
        "Use uma URL p\xFAblica can\xF4nica de canal do YouTube (/ @handle ou /channel/UC...)."
      );
    const initial = readInitialData(html), info = parsePublicChannelPage(html);
    const warnings2 = [
      ...info.warnings,
      "Amostra limitada aos v\xEDdeos presentes no HTML inicial p\xFAblico; sem pagina\xE7\xE3o, contas ou cat\xE1logo completo.",
      "Datas e contagens p\xFAblicas podem estar arredondadas. Recentes e populares s\xE3o ordenados somente dentro desta amostra."
    ];
    if (!initial)
      warnings2.push(
        "ytInitialData JSON n\xE3o encontrado; o YouTube pode exigir consentimento ou ter alterado o layout."
      );
    const chosen = chosenContent(initial);
    if (initial && !chosen.scoped)
      warnings2.push(
        "A aba selecionada n\xE3o foi identificada; os cards reconhecidos podem incluir outras se\xE7\xF5es desta p\xE1gina."
      );
    const pending = [
      { value: chosen.content, depth: 0 }
    ], seen = /* @__PURE__ */ new Set(), videos = [];
    let visited = 0;
    while (pending.length && visited++ < 1e5 && videos.length < 2e3) {
      const { value, depth } = pending.pop();
      if (depth > 100) continue;
      if (Array.isArray(value)) {
        for (let index = value.length - 1; index >= 0; index--)
          pending.push({ value: value[index], depth: depth + 1 });
        continue;
      }
      const object = record2(value);
      for (const [key, child] of Object.entries(object).reverse()) {
        if (/^(?:adSlotRenderer|displayAdRenderer|inFeedAdLayoutRenderer|promotedVideoRenderer)$/.test(
          key
        ))
          continue;
        if (["videoRenderer", "gridVideoRenderer", "lockupViewModel"].includes(key)) {
          const video = parseVideo(
            record2(child),
            key === "lockupViewModel",
            canonical2,
            now
          );
          if (video && !seen.has(video.id)) {
            seen.add(video.id);
            videos.push({
              ...video,
              channel: info.channelName,
              subscribers: info.subscribers,
              channelId: canonical2.match(
                /\/channel\/(UC[A-Za-z0-9_-]{22})$/
              )?.[1]
            });
          }
        } else if (child && typeof child === "object")
          pending.push({ value: child, depth: depth + 1 });
      }
    }
    if (pending.length)
      warnings2.push(
        "Limite de leitura estrutural atingido; a cobertura \xE9 parcial."
      );
    if (!videos.length)
      warnings2.push(
        "Nenhum v\xEDdeo p\xFAblico reconhecido nesta resposta; n\xE3o significa que o canal n\xE3o tenha v\xEDdeos."
      );
    return {
      channelUrl: canonical2,
      channelName: info.channelName,
      subscribers: info.subscribers,
      videos,
      recent: sortVideos(videos, "recent", now),
      popular: sortVideos(videos, "views", now),
      coverage: COVERAGE,
      warnings: warnings2
    };
  }

  // src/content/contextual.ts
  var instances = /* @__PURE__ */ new WeakMap();
  var HOST_ID2 = "prevlev-contextual";
  var MAX_HTML = 3 * 1024 * 1024;
  var cleanText = (value) => value.replace(/[&<>]/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" })[char]).replace(/\|/g, "\\|").replace(/\r?\n/g, " ");
  function canonical(value) {
    try {
      const url = new URL(value, "https://www.youtube.com");
      if (url.origin !== "https://www.youtube.com" || url.username || url.password) return void 0;
      const path = url.pathname.replace(/\/(?:videos|shorts|featured)\/?$/, "").replace(/\/$/, "");
      return buildChannelUrl({ id: "", title: "", url: "", channelUrl: `https://www.youtube.com${path}` });
    } catch {
      return void 0;
    }
  }
  function channelSample(videos, channelUrl) {
    const target = canonical(channelUrl), seen = /* @__PURE__ */ new Set();
    if (!target) return [];
    return videos.filter((video) => {
      if (video.source === "youtube-data-api" || seen.has(video.id)) return false;
      const identities = [video.channelUrl ? canonical(video.channelUrl) : void 0, video.channelId ? canonical(`https://www.youtube.com/channel/${video.channelId}`) : void 0];
      if (!identities.includes(target)) return false;
      seen.add(video.id);
      return true;
    }).map((video) => ({ ...video }));
  }
  function channelMarkdown(videos, channelUrl, scope) {
    return [`# Canal observado`, "", `Canal: ${cleanText(channelUrl)}`, `Escopo: ${cleanText(scope)}. ${videos.length} v\xEDdeos observados; n\xE3o \xE9 o cat\xE1logo completo.`, "", "| V\xEDdeo | ID | Views observadas | Publica\xE7\xE3o |", "| --- | --- | --- | --- |", ...videos.map((video) => `| ${cleanText(video.title)} | ${video.id} | ${video.views === void 0 ? "desconhecido" : video.views} | ${cleanText(video.publishedAt ?? "desconhecida")} |`), ""].join("\n");
  }
  async function fetchChannelPreview(channelUrl, signal, fetcher = fetch) {
    const url = canonical(channelUrl);
    if (!url) throw new Error("URL p\xFAblica de canal inv\xE1lida.");
    const combined = AbortSignal.any([signal, AbortSignal.timeout(8e3)]);
    combined.throwIfAborted();
    const response = await fetcher(`${url}/videos`, { credentials: "omit", redirect: "error", cache: "no-store", headers: { Accept: "text/html" }, signal: combined });
    if (!response.ok || response.redirected) throw new Error("A p\xE1gina p\xFAblica do canal n\xE3o p\xF4de ser consultada.");
    const type = response.headers.get("content-type");
    if (type && !/^(text\/html|application\/xhtml\+xml)(;|$)/i.test(type)) throw new Error("O canal n\xE3o retornou HTML p\xFAblico.");
    if (Number(response.headers.get("content-length")) > MAX_HTML) {
      await response.body?.cancel();
      throw new Error("A p\xE1gina excedeu o limite de 3 MiB.");
    }
    if (!response.body) throw new Error("A p\xE1gina p\xFAblica est\xE1 vazia.");
    const reader = response.body.getReader(), decoder = new TextDecoder();
    const onAbort = () => {
      void reader.cancel().catch(() => {
      });
    };
    combined.addEventListener("abort", onAbort, { once: true });
    let bytes = 0, html = "";
    try {
      for (; ; ) {
        combined.throwIfAborted();
        const part = await reader.read();
        if (part.done) break;
        bytes += part.value.byteLength;
        if (bytes > MAX_HTML) throw new Error("A p\xE1gina excedeu o limite de 3 MiB.");
        html += decoder.decode(part.value, { stream: true });
      }
      html += decoder.decode();
      combined.throwIfAborted();
    } finally {
      combined.removeEventListener("abort", onAbort);
      await reader.cancel().catch(() => {
      });
      reader.releaseLock();
    }
    const result = parseChannelVideos(html, url), observedAt = (/* @__PURE__ */ new Date()).toISOString();
    const videos = result.videos.map((video) => ({ ...video, source: "public-page", observedAt }));
    return { ...result, videos, recent: sortVideos(videos, "recent"), popular: sortVideos(videos, "views") };
  }
  async function thumbnail(id, signal) {
    const result = await chrome.runtime.sendMessage({ type: "FETCH_THUMBNAIL", videoId: id });
    signal.throwIfAborted();
    if (result?.status !== "ok" || typeof result.dataUrl !== "string" || !/^data:image\/(?:png|jpeg|webp);base64,/i.test(result.dataUrl) || result.dataUrl.length > 8 * 1024 * 1024) throw new Error(result?.error ?? "A thumbnail p\xFAblica n\xE3o p\xF4de ser obtida.");
    const response = await fetch(result.dataUrl, { signal, credentials: "omit" });
    return response.blob();
  }
  async function capture(id, signal) {
    const result = await chrome.runtime.sendMessage({ type: "CAPTURE_SCREENSHOT", kind: "video", targetVideoId: id, redact: false });
    signal.throwIfAborted();
    if (result?.status !== "ok") throw new Error(result?.error ?? "Captura indispon\xEDvel.");
    const measurement = result.capture;
    if (!measurement || !Number.isFinite(measurement.viewportWidth) || measurement.viewportWidth <= 0) throw new Error("A medi\xE7\xE3o do card n\xE3o foi retornada.");
    const image = await loadImage(result.dataUrl);
    signal.throwIfAborted();
    return cropScreenshot(result.dataUrl, measurement.rect, image.naturalWidth / measurement.viewportWidth, measurement.redactions);
  }
  function mountContextualTools(doc = document, deps = {}) {
    const existing = instances.get(doc);
    if (existing) return existing;
    const host = doc.createElement("div");
    host.id = HOST_ID2;
    host.hidden = true;
    host.style.cssText = "position:fixed;z-index:2147483647;max-width:calc(100vw - 16px)";
    const shadow = host.attachShadow({ mode: "open" });
    shadow.innerHTML = '<style>:host{font:13px/1.5 system-ui;color:#f8f7fc}*{box-sizing:border-box}.popup{width:370px;max-width:calc(100vw - 16px);max-height:calc(100vh - 24px);overflow:auto;background:#181721;border:1px solid #62517d;border-radius:12px;box-shadow:0 10px 35px #0007;padding:12px;display:grid;gap:8px}h3,p{margin:0}button,a{font:inherit;color:inherit}button{background:#3e335b;border:0;border-radius:6px;padding:8px;text-align:left;cursor:pointer}button:disabled{opacity:.5;cursor:default}button:focus-visible,a:focus-visible{outline:2px solid #c5b5ff;outline-offset:2px}a{color:#d2c2ff;text-decoration:underline}.row{display:flex;gap:6px;flex-wrap:wrap}.hint{font-size:11px;color:#c2bdce}#context-status{min-height:18px;color:#d5c5ff}ul{margin:0;padding-left:20px}li{margin:6px 0}</style><section class="popup" role="dialog" aria-label="Ferramentas do card ou canal"><div id="context-body"></div><p id="context-status" role="status" aria-live="polite"></p><button id="context-close">Fechar</button></section>';
    const body = shadow.getElementById("context-body"), output = shadow.getElementById("context-status");
    const create = (tag, text2) => {
      const el = doc.createElement(tag);
      if (text2 !== void 0) el.textContent = text2;
      return el;
    };
    let disposed = false, token = 0, anchor, mode, expectedUrl = "", expectedChannel = "", activeCard, abort, hoverTimer, leaveTimer, channelRecords = [], channelScope = "", order = "recent", busy = false;
    const clearTimers = () => {
      if (hoverTimer) clearTimeout(hoverTimer);
      if (leaveTimer) clearTimeout(leaveTimer);
      hoverTimer = void 0;
      leaveTimer = void 0;
    };
    function close(returnFocus = false) {
      clearTimers();
      token++;
      abort?.abort();
      abort = void 0;
      host.hidden = true;
      mode = void 0;
      activeCard = void 0;
      busy = false;
      output.textContent = "";
      if (returnFocus && anchor?.isConnected) anchor.focus();
      anchor = void 0;
    }
    function status(text2) {
      output.textContent = text2;
    }
    function position(target) {
      const rect = target.getBoundingClientRect(), win = doc.defaultView;
      host.style.left = `${Math.max(8, Math.min(rect.left, win.innerWidth - 386))}px`;
      host.style.top = `${Math.max(8, Math.min(rect.bottom + 6, win.innerHeight - host.getBoundingClientRect().height - 8))}px`;
    }
    function validCard() {
      return !!activeCard && expectedUrl === doc.location.href && activeCard.element.isConnected && readVideoCards(doc).some((card) => card.element === activeCard.element && card.video.id === activeCard.video.id && card.video.url === activeCard.video.url && card.video.title === activeCard.video.title);
    }
    function validChannel() {
      return mode === "channel" && !!anchor?.isConnected && expectedUrl === doc.location.href && canonical(anchor.href) === expectedChannel;
    }
    function action(label2, run, hide = false) {
      const button = create("button", label2);
      button.addEventListener("click", () => {
        if (busy) return;
        if (mode === "menu" && !validCard() || mode === "channel" && !validChannel()) {
          close();
          return;
        }
        const mine = token, signal = abort.signal, previousMessage = output.textContent;
        busy = true;
        for (const el of body.querySelectorAll("button")) el.disabled = true;
        if (hide) host.hidden = true;
        void Promise.resolve().then(() => {
          signal.throwIfAborted();
          if (mode === "menu" && !validCard() || mode === "channel" && !validChannel()) {
            close();
            return;
          }
          return run(signal);
        }).then(() => {
          if (mine === token && !signal.aborted && output.textContent === previousMessage) status("A\xE7\xE3o conclu\xEDda.");
        }).catch((error) => {
          if (mine === token && !signal.aborted) status(error instanceof Error ? error.message : String(error));
        }).finally(() => {
          if (mine === token && !signal.aborted) {
            busy = false;
            host.hidden = false;
            for (const el of body.querySelectorAll("button")) el.disabled = false;
          }
        });
      });
      return button;
    }
    function begin(target, next) {
      close();
      anchor = target;
      mode = next;
      expectedUrl = doc.location.href;
      abort = new AbortController();
      host.hidden = false;
      body.replaceChildren();
      status("");
    }
    function openMenu(card, button) {
      begin(button, "menu");
      activeCard = { element: card.element, video: { ...card.video } };
      body.append(create("h3", card.video.title));
      const id = card.video.id, thumbnailUrl = `https://i.ytimg.com/vi/${id}/hqdefault.jpg`;
      body.append(action("Copiar t\xEDtulo", async (signal) => {
        signal.throwIfAborted();
        if (!validCard()) throw new Error("O card mudou. Abra o menu novamente.");
        await doc.defaultView.navigator.clipboard.writeText(card.video.title);
      }), action("Copiar ID", async (signal) => {
        signal.throwIfAborted();
        if (!validCard()) throw new Error("O card mudou. Abra o menu novamente.");
        await doc.defaultView.navigator.clipboard.writeText(id);
      }), action("Copiar URL da thumbnail", async (signal) => {
        signal.throwIfAborted();
        await doc.defaultView.navigator.clipboard.writeText(thumbnailUrl);
      }), action("Copiar imagem da thumbnail", async (signal) => {
        const image = await (deps.thumbnail ?? thumbnail)(id, signal);
        signal.throwIfAborted();
        if (!validCard()) throw new Error("O card mudou; a imagem n\xE3o foi copiada.");
        const png = image.type === "image/png" ? image : await compressImage(image, { type: "image/png", maxWidth: 8192, maxHeight: 8192 });
        signal.throwIfAborted();
        if (!validCard()) throw new Error("O card mudou; a imagem n\xE3o foi copiada.");
        await copyImage(png);
      }), action("Baixar thumbnail", async (signal) => {
        const image = await (deps.thumbnail ?? thumbnail)(id, signal);
        signal.throwIfAborted();
        if (!validCard()) throw new Error("O card mudou; o download foi descartado.");
        downloadBlob(image, `prevlev-${id}.${image.type === "image/png" ? "png" : image.type === "image/webp" ? "webp" : "jpg"}`);
      }), action("Capturar este card", async (signal) => {
        const image = await (deps.capture ?? capture)(id, signal);
        signal.throwIfAborted();
        if (!validCard()) throw new Error("O card mudou; a captura foi descartada.");
        downloadBlob(image, `prevlev-card-${id}.png`);
      }, true));
      const search2 = create("a", "Busca visual no Google Lens \u2197");
      search2.href = `https://lens.google.com/uploadbyurl?url=${encodeURIComponent(thumbnailUrl)}`;
      search2.target = "_blank";
      search2.rel = "noopener noreferrer";
      search2.addEventListener("click", (event) => {
        if (!validCard()) {
          event.preventDefault();
          close();
        }
      });
      body.append(search2, create("p", "A busca visual abre outro servi\xE7o com a URL p\xFAblica da thumbnail. Nenhuma imagem \xE9 carregada pelo menu ao abrir."));
      position(button);
      body.querySelector("button")?.focus();
    }
    function renderChannel() {
      body.replaceChildren(create("h3", anchor?.textContent?.trim() || "Canal observado"));
      const hint = create("p", `${channelScope} \xB7 ${channelRecords.length} v\xEDdeos observados. Recentes/populares consideram somente esta amostra.`);
      hint.className = "hint";
      body.append(hint);
      const tabs = create("div");
      tabs.className = "row";
      for (const key2 of ["recent", "popular"]) {
        const button = create("button", key2 === "recent" ? "Recentes (amostra)" : "Populares (amostra)");
        button.setAttribute("aria-pressed", String(order === key2));
        button.addEventListener("click", () => {
          order = key2;
          renderChannel();
        });
        tabs.append(button);
      }
      body.append(tabs);
      const list = create("ul");
      for (const video of sortVideos(channelRecords, order === "recent" ? "recent" : "views").slice(0, 4)) {
        const row = create("li"), link = create("a", video.title);
        link.href = video.url;
        link.target = "_blank";
        link.rel = "noopener noreferrer";
        row.append(link, create("small", ` \xB7 ${video.views === void 0 ? "views indispon\xEDveis" : `${video.views} views`}${video.isShort ? " \xB7 Short" : ""}`));
        list.append(row);
      }
      if (!list.childNodes.length) list.append(create("li", "Nenhum v\xEDdeo desta identidade de canal foi reconhecido na amostra carregada."));
      body.append(list);
      body.append(action("Consultar uma p\xE1gina p\xFAblica deste canal", async (signal) => {
        const mine = token;
        status("Consultando uma p\xE1gina p\xFAblica sem credenciais\u2026");
        const result = await (deps.channel ?? fetchChannelPreview)(expectedChannel, signal);
        signal.throwIfAborted();
        if (mine !== token || !validChannel() || canonical(result.channelUrl) !== expectedChannel) return;
        channelRecords = result.videos.map((video) => ({ ...video }));
        channelScope = "HTML p\xFAblico inicial, sem pagina\xE7\xE3o";
        renderChannel();
        status(result.warnings.join(" "));
      }));
      const exports = create("div");
      exports.className = "row";
      for (const format of ["csv", "json", "md"]) exports.append(action(`Exportar ${format.toUpperCase()}`, () => {
        if (!validChannel()) throw new Error("O canal mudou; abra a pr\xE9via novamente.");
        const text2 = format === "json" ? JSON.stringify({ channelUrl: expectedChannel, scope: channelScope, videos: channelRecords }, null, 2) : format === "csv" ? toCsv(channelRecords.map((video) => ({ ...video, scope: channelScope }))) : channelMarkdown(channelRecords, expectedChannel, channelScope);
        downloadBlob(new Blob([text2], { type: format === "json" ? "application/json" : format === "csv" ? "text/csv;charset=utf-8" : "text/markdown;charset=utf-8" }), `prevlev-canal.${format}`);
      }));
      body.append(exports);
      if (anchor) position(anchor);
    }
    function openChannel(target, url) {
      begin(target, "channel");
      expectedChannel = url;
      const at = (/* @__PURE__ */ new Date()).toISOString();
      channelRecords = channelSample(deps.getVideos?.() ?? readVideoCards(doc).map((card) => ({ ...card.video, source: "youtube-dom", observedAt: at })), url);
      channelScope = "Cards j\xE1 carregados nesta p\xE1gina";
      order = "recent";
      renderChannel();
    }
    function over(event) {
      if (disposed || doc.location.hostname !== "www.youtube.com") return;
      const target = event.target instanceof Element ? event.target.closest("a[href]") : null;
      if (!target || host.contains(target)) return;
      const channelUrl = canonical(target.href);
      if (!channelUrl) return;
      if (event.relatedTarget instanceof Node && target.contains(event.relatedTarget)) return;
      clearTimers();
      hoverTimer = setTimeout(() => {
        hoverTimer = void 0;
        if (target.isConnected && canonical(target.href) === channelUrl) openChannel(target, channelUrl);
      }, 300);
    }
    function out(event) {
      const target = event.target instanceof Element ? event.target.closest("a[href]") : null;
      if (!target || !canonical(target.href)) return;
      if (event.relatedTarget instanceof Node && (target.contains(event.relatedTarget) || host.contains(event.relatedTarget))) return;
      if (hoverTimer) clearTimeout(hoverTimer);
      hoverTimer = void 0;
      leaveTimer = setTimeout(() => close(), 180);
    }
    function click(event) {
      const button = event.target instanceof Element ? event.target.closest("[data-prevlev-context-menu]") : null;
      if (!button) return;
      const element = button.closest(CARD_SELECTOR), card = readVideoCards(doc).find((card2) => card2.element === element);
      if (!card) return;
      event.preventDefault();
      event.stopPropagation();
      openMenu(card, button);
    }
    function outside(event) {
      const target = event.target;
      if (!(target instanceof Node) || host.contains(target) || anchor?.contains(target)) return;
      close();
    }
    function viewport(event) {
      if (event.composedPath().includes(host)) return;
      close();
    }
    function key(event) {
      if (event.key !== "Escape" || mode === void 0) return;
      const focused = shadow.activeElement !== null;
      close(focused);
      if (focused) event.preventDefault();
    }
    const controller = { refresh() {
      if (disposed || doc.location.hostname !== "www.youtube.com") return;
      for (const card of readVideoCards(doc)) {
        let button = card.element.querySelector("[data-prevlev-context-menu]");
        if (!button) {
          button = create("button", "\u22EE Prevlev");
          button.type = "button";
          button.dataset.prevlevContextMenu = "";
          button.style.cssText = "cursor:pointer;border:1px solid #75628e;background:#252030;color:#e4d7ff;border-radius:6px;padding:5px 9px;font:12px system-ui";
          card.element.append(button);
        }
        const label2 = `Ferramentas Prevlev: ${card.video.title}`;
        if (button.getAttribute("aria-label") !== label2) button.setAttribute("aria-label", label2);
      }
      if (mode === "menu" && !validCard() || mode === "channel" && !validChannel()) close();
    }, cleanup() {
      if (disposed) return;
      disposed = true;
      close();
      doc.removeEventListener("click", click, true);
      doc.removeEventListener("mouseover", over);
      doc.removeEventListener("mouseout", out);
      doc.removeEventListener("pointerdown", outside);
      doc.removeEventListener("keydown", key);
      doc.removeEventListener("yt-navigate-start", closeNavigation);
      doc.removeEventListener("yt-navigate-finish", closeNavigation);
      doc.defaultView?.removeEventListener("scroll", viewport, true);
      doc.defaultView?.removeEventListener("resize", viewport);
      doc.defaultView?.removeEventListener("pagehide", controller.cleanup);
      for (const button of doc.querySelectorAll("[data-prevlev-context-menu]")) button.remove();
      host.remove();
      instances.delete(doc);
    } };
    const closeNavigation = () => close();
    shadow.getElementById("context-close").addEventListener("click", () => close(true));
    host.addEventListener("mouseenter", () => {
      if (leaveTimer) clearTimeout(leaveTimer);
      leaveTimer = void 0;
    });
    host.addEventListener("mouseleave", () => {
      leaveTimer = setTimeout(() => close(), 180);
    });
    doc.addEventListener("click", click, true);
    doc.addEventListener("mouseover", over);
    doc.addEventListener("mouseout", out);
    doc.addEventListener("pointerdown", outside);
    doc.addEventListener("keydown", key);
    doc.addEventListener("yt-navigate-start", closeNavigation);
    doc.addEventListener("yt-navigate-finish", closeNavigation);
    doc.defaultView?.addEventListener("scroll", viewport, true);
    doc.defaultView?.addEventListener("resize", viewport);
    doc.defaultView?.addEventListener("pagehide", controller.cleanup);
    doc.documentElement.append(host);
    instances.set(doc, controller);
    controller.refresh();
    return controller;
  }

  // src/ui/research.ts
  var researchLabels = { views: "Visualiza\xE7\xF5es", vph: "VPH m\xE9dio hist\xF3rico", outlier: "Outlier da amostra", recent: "Data de publica\xE7\xE3o", duration: "Dura\xE7\xE3o", subscribers: "Inscritos conhecidos", title: "T\xEDtulo", viewsPerSubscriber: "Views por inscrito conhecido" };

  // src/content/research-overlay.ts
  function mountResearchOverlay(container, deps) {
    const shell = document.createElement("div");
    shell.dataset.prevlevResearchOverlay = "";
    const choices = Object.entries(researchLabels).map(([key, label2]) => `<option value="${key}">${label2}</option>`).join("");
    shell.innerHTML = `<style>[data-prevlev-research-overlay] fieldset{min-width:0;border:1px solid #46435b;border-radius:8px;margin:8px 0;padding:9px}[data-prevlev-research-overlay] label{display:grid;gap:3px}[data-prevlev-research-overlay] .smallrow{display:flex;flex-wrap:wrap;gap:5px}[data-prevlev-research-overlay] .smallrow>*{flex:1;min-width:70px}[data-prevlev-research-overlay] .sample{display:grid;gap:7px;max-height:400px;overflow:auto}[data-prevlev-research-overlay] .sample[data-layout=grid]{grid-template-columns:repeat(2,minmax(0,1fr))}[data-prevlev-research-overlay] .sample[data-layout=sidebar]{position:fixed;right:min(350px,45vw);top:80px;bottom:20px;width:min(400px,48vw);max-height:none;z-index:2147483646;background:#181923;border:1px solid #79718e;border-radius:10px;padding:12px}[data-prevlev-research-overlay] article{min-width:0;background:#292a38;border:1px solid #454257;border-radius:7px;padding:8px;overflow-wrap:anywhere}[data-prevlev-research-overlay] article a{display:block;font-weight:600}[data-prevlev-research-overlay] article small{display:block;font-size:11px;color:#c2bed4}[data-prevlev-research-overlay] progress{width:100%}[data-prevlev-research-overlay] [hidden]{display:none!important}</style>
    <details><summary>Pesquisa avan\xE7ada e amostra</summary><fieldset><legend>Atalhos por contexto</legend><label>Atalho<select id="prevlev-research-preset"><option value="">Manual</option></select></label><p id="prevlev-research-context"></p></fieldset>
    <fieldset><legend>Dois crit\xE9rios de ordena\xE7\xE3o</legend><label>Primeiro<select id="prevlev-research-first"><option value="default">Ordem da coleta</option>${choices}</select></label><label>Dire\xE7\xE3o<select id="prevlev-research-first-direction"><option value="desc">Maior primeiro / Z\u2013A</option><option value="asc">Menor primeiro / A\u2013Z</option></select></label><button id="prevlev-research-add">Adicionar segundo</button><div id="prevlev-research-second-row" hidden><label>Segundo<select id="prevlev-research-second">${choices}</select></label><label>Dire\xE7\xE3o<select id="prevlev-research-second-direction"><option value="desc">Maior primeiro / Z\u2013A</option><option value="asc">Menor primeiro / A\u2013Z</option></select></label><button id="prevlev-research-remove">Remover segundo</button></div><label><input id="prevlev-research-priority" type="checkbox"> Priorizar views por inscrito conhecido, fora de canais</label><label>Outlier local<select id="prevlev-research-comparison"><option value="sample-median">Mediana da amostra, m\xEDnimo 3 (padr\xE3o)</option><option value="sample-channel-reference">Refer\xEAncia m\xE9dia da amostra do canal</option></select></label></fieldset>
    <fieldset><legend>Datas de publica\xE7\xE3o UTC</legend><div class="smallrow"><button data-prevlev-range="7">7 dias</button><button data-prevlev-range="30">30 dias</button><button data-prevlev-range="90">90 dias</button><button data-prevlev-range="all">Todo per\xEDodo</button></div><label>Desde UTC<input id="prevlev-research-after" type="datetime-local" step="1"></label><label>At\xE9 UTC<input id="prevlev-research-before" type="datetime-local" step="1"></label></fieldset>
    <fieldset><legend>Apresenta\xE7\xE3o e Shorts</legend><label>Apresenta\xE7\xE3o da amostra neste painel<select id="prevlev-research-layout"><option value="list">Lista</option><option value="grid">Grade</option><option value="sidebar">Barra lateral</option></select></label><label><input id="prevlev-research-badges" type="checkbox"> Mostrar badges existentes nos cards</label><label><input id="prevlev-research-hide-feed" type="checkbox"> Ocultar Shorts no feed / inscri\xE7\xF5es</label><label><input id="prevlev-research-hide-search" type="checkbox"> Ocultar Shorts na busca</label><button id="prevlev-research-reset">Limpar filtros locais</button></fieldset>
    <fieldset><legend>Carregar mais por rolagem expl\xEDcita</legend><label>Limite de itens<input id="prevlev-research-limit" type="number" min="1" max="500" value="200"></label><div class="smallrow"><button id="prevlev-research-load">Carregar mais</button><button id="prevlev-research-cancel" disabled>Cancelar</button></div><progress id="prevlev-research-progress" max="1" value="0"></progress><p id="prevlev-research-collection" role="status"></p></fieldset>
    <p id="prevlev-research-status" role="status"></p><div class="smallrow"><button id="prevlev-research-json">JSON</button><button id="prevlev-research-csv">CSV</button><button id="prevlev-research-md">Markdown</button></div><details><summary id="prevlev-research-count">Amostra carregada</summary><div id="prevlev-research-results" class="sample" data-layout="list"></div></details><p>Exporta somente a amostra real dispon\xEDvel. Nenhum atalho inicia coleta ou IA. Views s\xE3o contadores observados; VPH \xE9 m\xE9dio hist\xF3rico. Outlier \xE9 aproxima\xE7\xE3o da amostra, n\xE3o refer\xEAncia do canal completo. Dados da API oficial s\xE3o exclu\xEDdos dos c\xE1lculos derivados.</p></details>`;
    container.append(shell);
    const get = (id) => shell.querySelector(`#prevlev-research-${id}`);
    let state = deps.collector.status(), secondEnabled = false, activePreset = "", disposed = false;
    const selected = () => {
      const filter = { ...deps.getFilter(), surface: researchSurface(deps.getUrl()) };
      const baseline = deps.getVideos();
      return { filter, baseline, rows: selectResearchVideos(baseline, filter) };
    };
    const status = (text2) => {
      get("status").textContent = text2;
    };
    const commit = (filter) => {
      try {
        deps.setFilter({ ...filter, surface: researchSurface(deps.getUrl()) });
        refresh();
      } catch (error) {
        status(error instanceof Error ? error.message : "N\xE3o foi poss\xEDvel aplicar o filtro.");
      }
    };
    const criteria = () => {
      const first = get("first").value;
      return [...first === "default" ? [] : [{ key: first, direction: get("first-direction").value }], ...secondEnabled ? [{ key: get("second").value, direction: get("second-direction").value }] : []];
    };
    function applyControls() {
      activePreset = "";
      commit({ ...deps.getFilter(), criteria: criteria(), priority: get("priority").checked ? "views-per-subscriber" : "none", comparisonMode: get("comparison").value, hideShortsOnFeed: get("hide-feed").checked, hideShortsOnSearch: get("hide-search").checked });
    }
    function refresh() {
      if (disposed) return;
      const filter = deps.getFilter(), surface = researchSurface(deps.getUrl());
      const preset = get("preset");
      preset.replaceChildren(option("", "Manual"));
      for (const item of researchPresets(surface)) {
        const entry = option(item.id, item.label);
        entry.disabled = !item.available;
        preset.append(entry);
      }
      preset.value = researchPresets(surface).find((item) => item.id === activePreset)?.available ? activePreset : "";
      get("context").textContent = `Contexto: ${{ home: "in\xEDcio", subscriptions: "inscri\xE7\xF5es", search: "busca", channel: "canal", other: "outra p\xE1gina" }[surface]}. ${activePreset ? researchPresets(surface).find((item) => item.id === activePreset)?.description ?? "" : "Filtros manuais na amostra."}`;
      const sorting = filter.criteria ?? (filter.sort === "default" ? [] : [{ key: filter.sort, direction: filter.sort === "title" ? "asc" : "desc" }]);
      get("first").value = sorting[0]?.key ?? "default";
      get("first-direction").value = sorting[0]?.direction ?? "desc";
      secondEnabled = sorting.length > 1;
      get("second-row").hidden = !secondEnabled;
      get("add").hidden = secondEnabled;
      get("second").value = sorting[1]?.key ?? (sorting[0]?.key === "title" ? "views" : "title");
      get("second-direction").value = sorting[1]?.direction ?? "asc";
      get("priority").checked = filter.priority === "views-per-subscriber";
      get("priority").disabled = surface === "channel";
      for (const id of ["first", "second"]) for (const entry of get(id).options) if (entry.value === "viewsPerSubscriber") entry.disabled = surface === "channel";
      get("comparison").value = filter.comparisonMode ?? "sample-median";
      get("hide-feed").checked = !!filter.hideShortsOnFeed;
      get("hide-search").checked = !!filter.hideShortsOnSearch;
      get("badges").checked = deps.getMetrics?.() ?? false;
      get("badges").disabled = !deps.setMetrics;
      get("after").value = filter.publishedAfter?.slice(0, 19) ?? "";
      get("before").value = filter.publishedBefore?.slice(0, 19) ?? "";
      try {
        const sample = selected();
        get("count").textContent = `${sample.rows.length} correspondem / ${sample.baseline.length} observados \xB7 exibindo at\xE9 100`;
        const list = get("results");
        list.replaceChildren();
        for (const video of sample.rows.slice(0, 100)) {
          const card = document.createElement("article"), id = videoIdFromUrl(video.url), title = document.createElement(id ? "a" : "strong");
          title.textContent = video.title;
          if (title instanceof HTMLAnchorElement && id) {
            title.href = `https://www.youtube.com/watch?v=${id}`;
            title.target = "_blank";
            title.rel = "noopener noreferrer";
          }
          const detail = document.createElement("small"), comparison = researchComparison(video, sample.baseline, sample.filter.comparisonMode);
          detail.textContent = `${video.channel ?? "Canal desconhecido"} \xB7 ${video.views ?? "?"} views \xB7 outlier ${comparison.score?.toFixed(2) ?? "?"}\xD7 (${comparison.referenceCount} observa\xE7\xF5es)`;
          detail.title = describeResearchComparison(comparison, sample.filter.comparisonMode);
          card.append(title, detail);
          list.append(card);
        }
        if (!sample.rows.length) {
          const paragraph = document.createElement("p");
          paragraph.textContent = "Nenhum item reconhecido corresponde aos filtros.";
          list.append(paragraph);
        }
        for (const id of ["json", "csv", "md"]) get(id).disabled = state.phase === "running" || !sample.rows.length;
      } catch (error) {
        status(error instanceof Error ? error.message : "N\xE3o foi poss\xEDvel ler a amostra.");
      }
      get("load").disabled = state.phase === "running";
      get("cancel").disabled = state.phase !== "running";
      const progress = get("progress");
      progress.max = state.maxItems || 1;
      progress.value = state.collectedCount;
      get("collection").textContent = `${state.collectedCount} IDs observados \xB7 ${state.steps} rolagens \xB7 ${state.reason}`;
    }
    get("preset").addEventListener("change", () => {
      const id = get("preset").value;
      if (!id) return;
      try {
        const preset = researchPreset(id, researchSurface(deps.getUrl()));
        activePreset = id;
        commit({ ...preset.filter, comparisonMode: deps.getFilter().comparisonMode, sort: preset.filter.criteria?.[0].key ?? "default" });
      } catch (error) {
        status(error instanceof Error ? error.message : "Atalho indispon\xEDvel.");
      }
    });
    for (const id of ["first", "first-direction", "second", "second-direction", "priority", "comparison", "hide-feed", "hide-search"]) get(id).addEventListener("change", applyControls);
    get("add").addEventListener("click", () => {
      secondEnabled = true;
      get("second-row").hidden = false;
      get("add").hidden = true;
      applyControls();
    });
    get("remove").addEventListener("click", () => {
      secondEnabled = false;
      applyControls();
    });
    get("layout").addEventListener("change", () => {
      get("results").dataset.layout = get("layout").value;
    });
    get("badges").addEventListener("change", () => deps.setMetrics?.(get("badges").checked));
    get("reset").addEventListener("click", () => {
      activePreset = "";
      const old = deps.getFilter();
      commit({ sort: "default", criteria: [], hideShortsOnFeed: old.hideShortsOnFeed, hideShortsOnSearch: old.hideShortsOnSearch });
      status("Filtros locais limpos; prefer\xEAncias espec\xEDficas de Shorts preservadas.");
    });
    for (const button of shell.querySelectorAll("[data-prevlev-range]")) button.addEventListener("click", () => {
      const days = button.dataset.prevlevRange;
      activePreset = "";
      commit({ ...deps.getFilter(), publishedAfter: days === "all" ? void 0 : new Date(Date.now() - Number(days) * 864e5).toISOString(), publishedBefore: void 0, publishedBeforeExclusive: void 0 });
    });
    for (const id of ["after", "before"]) get(id).addEventListener("change", () => {
      activePreset = "";
      const value = get(id).value;
      commit({ ...deps.getFilter(), [id === "after" ? "publishedAfter" : "publishedBefore"]: value ? `${value}Z` : void 0, ...id === "before" ? { publishedBeforeExclusive: void 0 } : {} });
    });
    get("load").addEventListener("click", () => {
      try {
        deps.collector.start({ kind: "videos", maxItems: Number(get("limit").value), maxSteps: 30, timeoutMs: 6e4 });
        status("Coleta por rolagem iniciada explicitamente. A amostra continua parcial.");
      } catch (error) {
        status(error instanceof Error ? error.message : "N\xE3o foi poss\xEDvel iniciar a coleta.");
      }
    });
    get("cancel").addEventListener("click", () => {
      deps.collector.cancel();
    });
    for (const format of ["json", "csv", "md"]) get(format).addEventListener("click", () => {
      try {
        const sample = selected();
        if (state.phase === "running") throw new Error("Aguarde ou cancele a coleta antes de exportar.");
        const rows = researchRows(sample.rows, sample.baseline, sample.filter);
        const content = format === "json" ? JSON.stringify({ source: "local-observations", url: deps.getUrl(), filter: sample.filter, count: sample.rows.length, videos: sample.rows, comparisons: rows }, null, 2) : format === "csv" ? toCsv(rows) : researchMarkdown(sample.rows, sample.baseline, sample.filter);
        downloadBlob(new Blob([content], { type: format === "json" ? "application/json" : format === "csv" ? "text/csv;charset=utf-8" : "text/markdown;charset=utf-8" }), `prevlev-pesquisa-local.${format}`);
      } catch (error) {
        status(error instanceof Error ? error.message : "N\xE3o foi poss\xEDvel exportar.");
      }
    });
    const unsubscribe = deps.collector.subscribe((value) => {
      state = value;
      refresh();
    });
    refresh();
    return { refresh, dispose: () => {
      disposed = true;
      unsubscribe();
      shell.remove();
    } };
  }
  function option(value, text2) {
    const option2 = document.createElement("option");
    option2.value = value;
    option2.textContent = text2;
    return option2;
  }

  // src/ui/capture-options.ts
  var CAPTURE_REDACTION_CATEGORIES = [
    "channel",
    "revenue",
    "subscribers",
    "views",
    "video-info"
  ];
  function validateCaptureCategories(value) {
    if (!Array.isArray(value) || value.length === 0 || value.length > CAPTURE_REDACTION_CATEGORIES.length || value.some((item) => typeof item !== "string" || !CAPTURE_REDACTION_CATEGORIES.includes(item)) || new Set(value).size !== value.length) {
      throw new Error("Selecione categorias de oculta\xE7\xE3o v\xE1lidas, sem repeti\xE7\xF5es.");
    }
    return value;
  }

  // src/content/index.ts
  var contentScope = globalThis;
  if (!contentScope.__prevlevContentInitialized) {
    let shortsPreferences = function() {
      return { hideShortsOnFeed: typeof settings.hideShortsOnFeed === "boolean" ? settings.hideShortsOnFeed : settings.hideShorts, hideShortsOnSearch: typeof settings.hideShortsOnSearch === "boolean" ? settings.hideShortsOnSearch : settings.hideShorts };
    }, setFilter = function(candidate) {
      const before = shortsPreferences();
      filter = { ...before, ...candidate };
      if (filter.hideShortsOnFeed !== before.hideShortsOnFeed || filter.hideShortsOnSearch !== before.hideShortsOnSearch) {
        settings = { ...settings, hideShortsOnFeed: filter.hideShortsOnFeed, hideShortsOnSearch: filter.hideShortsOnSearch };
        void saveSettings(settings).catch((error) => {
          filterError = error instanceof Error ? error.message : String(error);
          updatePanel();
        });
      }
    }, elementIdentity = function(element) {
      let identity = elementIdentities.get(element);
      if (identity === void 0) {
        identity = ++identitySequence;
        elementIdentities.set(element, identity);
      }
      return identity;
    }, channelKeys = function(video) {
      const keys = [];
      if (video.channelId && /^UC[\w-]{1,100}$/.test(video.channelId))
        keys.push(`id:${video.channelId}`);
      if (video.channelUrl)
        try {
          const url = new URL(video.channelUrl);
          if (url.origin === "https://www.youtube.com" && !url.search && !url.hash && /^\/(?:@[^/]+|channel\/[^/]+)$/.test(url.pathname))
            keys.push(url.href);
        } catch {
        }
      return keys;
    }, enrichedVideo = function(video) {
      const info = channelKeys(video).map((key) => channelEnrichment.get(key)).find(Boolean);
      return info ? {
        ...video,
        subscribers: video.subscribers ?? info.subscribers,
        channel: video.channel ?? info.channel
      } : video;
    }, loadedCards = function() {
      return readVideoCards(document).map((card) => ({
        ...card,
        video: enrichedVideo(card.video)
      }));
    }, listen = function() {
      if (!suspended)
        observer?.observe(document.documentElement, {
          childList: true,
          subtree: true,
          attributes: true,
          characterData: true
        });
    }, schedule = function() {
      if (suspended || !settings) return;
      if (timer) clearTimeout(timer);
      timer = setTimeout(() => {
        timer = void 0;
        apply();
      }, 300);
    }, navigation = function(enabled2) {
      if (navigationListening === enabled2) return;
      navigationListening = enabled2;
      if (enabled2) {
        document.addEventListener("yt-navigate-finish", schedule);
        window.addEventListener("scroll", captureViewportChanged, true);
        window.addEventListener("resize", captureViewportChanged);
        window.visualViewport?.addEventListener("scroll", captureViewportChanged);
        window.visualViewport?.addEventListener("resize", captureViewportChanged);
      } else {
        document.removeEventListener("yt-navigate-finish", schedule);
        window.removeEventListener("scroll", captureViewportChanged, true);
        window.removeEventListener("resize", captureViewportChanged);
        window.visualViewport?.removeEventListener(
          "scroll",
          captureViewportChanged
        );
        window.visualViewport?.removeEventListener(
          "resize",
          captureViewportChanged
        );
      }
    }, captureViewportChanged = function() {
      if (!suspended) pageRevision++;
    }, apply = function() {
      if (!settings || suspended) return;
      if (observer?.takeRecords().length) pageRevision++;
      observer?.disconnect();
      try {
        mount();
        mountTimeline(document).refresh();
        const surface = researchSurface(location.href);
        if (filter.surface !== void 0 && filter.surface !== surface) {
          filter = normalizeCardFilter({ sort: "default", surface, hideShortsOnFeed: filter.hideShortsOnFeed, hideShortsOnSearch: filter.hideShortsOnSearch });
          filterError = "O contexto da p\xE1gina mudou. Os filtros espec\xEDficos foram reiniciados.";
          syncFilterForm();
        }
        const effectiveFilter = { ...filter, surface };
        const hideShorts = surface === "search" ? effectiveFilter.hideShortsOnSearch ?? settings.hideShorts : surface === "home" || surface === "subscriptions" ? effectiveFilter.hideShortsOnFeed ?? settings.hideShorts : settings.hideShorts;
        const cards = loadedCards();
        const base = cards.map((card) => card.video);
        for (const { element } of cards)
          if (!originalOrder.has(element)) originalOrder.set(element, nextOrder++);
        const allowed = new Set(
          filterAndSortCards(cards, effectiveFilter).map((card) => card.element)
        );
        for (const { element, video } of cards) {
          const hidden = !allowed.has(element) || hideShorts && !!video.isShort;
          if (hidden) element.setAttribute(HIDDEN, "true");
          else element.removeAttribute(HIDDEN);
          let badge = element.querySelector("[data-prevlev-metric]");
          if (!settings.showMetrics) {
            badge?.remove();
            continue;
          }
          if (!badge) {
            badge = document.createElement("span");
            badge.dataset.prevlevMetric = "";
            badge.style.cssText = "display:block;color:#8e83ff;font:12px/1.5 system-ui;padding:3px 0";
            element.append(badge);
          }
          const vph = lifetimeVph(video), comparison = researchComparison(video, base, effectiveFilter.comparisonMode), outlier = comparison.score;
          const label2 = `Prevlev \xB7 ${video.subscribers === void 0 ? "inscritos indispon\xEDveis" : `${number(video.subscribers)} inscritos`} \xB7 ${vph === void 0 ? "VPH indispon\xEDvel" : `${number(vph)} VPH m\xE9dio`} \xB7 ${outlier === void 0 ? "outlier indispon\xEDvel" : `${outlier.toFixed(1)}\xD7 outlier aproximado da amostra`}`;
          if (badge.textContent !== label2) badge.textContent = label2;
          badge.title = `VPH m\xE9dio desde a publica\xE7\xE3o; n\xE3o mede a \xFAltima hora. ${describeResearchComparison(comparison, effectiveFilter.comparisonMode)}`;
        }
        for (const element of document.querySelectorAll(
          "ytd-rich-shelf-renderer[is-shorts],ytd-reel-shelf-renderer,ytm-shorts-lockup-view-model"
        )) {
          if (hideShorts) element.setAttribute(HIDDEN, "true");
          else if (!cards.some((c) => c.element === element))
            element.removeAttribute(HIDDEN);
        }
        const ranked = sortResearchVideos(base, effectiveFilter, Date.now(), base);
        const rank = new Map(ranked.map((video, index) => [video, index]));
        const groups = /* @__PURE__ */ new Map();
        for (const card of cards)
          if (card.element.parentElement) {
            const parent = card.element.parentElement;
            groups.set(parent, [...groups.get(parent) ?? [], card]);
          }
        for (const [parent, group] of groups) {
          const sorted = filter.sort === "default" && !filter.criteria?.length && filter.priority !== "views-per-subscriber" ? [...group].sort(
            (a, b) => (originalOrder.get(a.element) ?? 0) - (originalOrder.get(b.element) ?? 0)
          ) : [...group].sort(
            (a, b) => (rank.get(a.video) ?? 0) - (rank.get(b.video) ?? 0)
          );
          const slots = Array.from(parent.childNodes).filter(
            (node) => group.some((card) => card.element === node)
          );
          if (slots.some((node, index) => node !== sorted[index]?.element)) {
            const placeholders = slots.map((node) => {
              const slot = document.createComment("prevlev-order");
              parent.replaceChild(slot, node);
              return slot;
            });
            placeholders.forEach(
              (slot, index) => parent.replaceChild(sorted[index].element, slot)
            );
          }
        }
        updatePanel();
        contextual ??= mountContextualTools(document, { getVideos: () => {
          const at = (/* @__PURE__ */ new Date()).toISOString();
          return loadedCards().map((card) => ({ ...card.video, source: "youtube-dom", observedAt: at }));
        } });
        contextual.refresh();
        ensureResearchOverlay();
        researchOverlay?.refresh();
      } finally {
        listen();
      }
    }, observedVideos = function() {
      const result = collector.snapshot();
      const saved = result?.url === location.href ? result.videos : [];
      const at = (/* @__PURE__ */ new Date()).toISOString();
      const current = loadedCards().map((card) => ({ ...card.video, source: "youtube-dom", observedAt: at }));
      return [...new Map([...saved, ...current].map((video) => [video.id, video])).values()];
    }, ensureResearchOverlay = function() {
      const shadow = document.getElementById(HOST_ID3)?.shadowRoot;
      if (!shadow) return;
      let container = shadow.getElementById("prevlev-research-overlay-tools");
      if (!container) {
        container = document.createElement("div");
        container.id = "prevlev-research-overlay-tools";
        shadow.querySelector("section").append(container);
      }
      researchOverlay ??= mountResearchOverlay(container, { getVideos: observedVideos, getFilter: () => filter, getUrl: () => location.href, collector, getMetrics: () => settings.showMetrics, setMetrics: (enabled2) => {
        settings.showMetrics = enabled2;
        void saveSettings(settings).catch(() => {
        });
        apply();
      }, setFilter: (value) => {
        const normalized2 = normalizeCardFilter(value);
        if (normalized2.surface !== void 0 && normalized2.surface !== researchSurface(location.href)) throw new Error("O filtro pertence a outro contexto de p\xE1gina.");
        filterError = "";
        setFilter(normalized2);
        syncFilterForm();
        apply();
      } });
    }, number = function(value) {
      return new Intl.NumberFormat("pt-BR", {
        maximumFractionDigits: 1,
        notation: "compact"
      }).format(value);
    }, mount = function() {
      if (document.getElementById(HOST_ID3)) return;
      collectionControlsCleanup?.();
      if (!document.getElementById("prevlev-page-style")) {
        const style = document.createElement("style");
        style.id = "prevlev-page-style";
        style.textContent = `[${HIDDEN}="true"]{display:none!important}`;
        document.head.append(style);
      }
      const host = document.createElement("div");
      host.id = HOST_ID3;
      host.style.cssText = "position:fixed;bottom:18px;left:18px;z-index:2147483646";
      const shadow = host.attachShadow({ mode: "open" });
      const numericControls = [
        ["minViews", "min-views", "Views m\xEDn."],
        ["maxViews", "max-views", "Views m\xE1x."],
        ["minSubscribers", "min-subscribers", "Inscritos m\xEDn."],
        ["maxSubscribers", "max-subscribers", "Inscritos m\xE1x."],
        ["minDurationSeconds", "min-duration", "Dura\xE7\xE3o m\xEDn. (s)"],
        ["maxDurationSeconds", "max-duration", "Dura\xE7\xE3o m\xE1x. (s)"],
        ["minVph", "min-vph", "VPH m\xE9dio m\xEDn."],
        ["maxVph", "max-vph", "VPH m\xE9dio m\xE1x."],
        ["minOutlier", "min-outlier", "Outlier m\xEDn."],
        ["maxOutlier", "max-outlier", "Outlier m\xE1x."]
      ];
      shadow.innerHTML = `<style>:host{font:13px/1.4 system-ui;color:#f5f5fa}*{box-sizing:border-box}button,input,select{font:inherit}button{cursor:pointer;background:#8b7bff;border:0;border-radius:8px;padding:9px 12px;color:#fff}button.secondary{background:#30313c}details{background:#15161e;border:1px solid #454050;border-radius:12px;box-shadow:0 8px 30px #0006;width:320px;max-height:calc(100vh - 60px);overflow:auto}summary{cursor:pointer;padding:12px;font-weight:700;color:#c3baff}section{padding:0 12px 12px;display:grid;gap:9px}label{display:flex;align-items:center;gap:8px}label.stack{display:grid;gap:4px}.ranges{display:grid;grid-template-columns:1fr 1fr;gap:8px}input[type=text],input[type=number],input[type=date],select{width:100%;min-width:0;color:#fff;background:#242532;border:1px solid #484959;border-radius:6px;padding:7px}p{margin:0;color:#bfc0cd;font-size:11px}.row{display:flex;gap:6px;flex-wrap:wrap}#status{color:#c5c0ff}a{color:#b7aaff}</style><details><summary>Prevlev \xB7 Ferramentas</summary><section><label><input id="shorts" type="checkbox"> Ocultar Shorts</label><label><input id="metrics" type="checkbox"> Mostrar m\xE9tricas nos cards</label><label class="stack">T\xEDtulo ou texto<input id="query" type="text" placeholder="Filtrar v\xEDdeos carregados"></label><label class="stack">Canal<input id="channel" type="text" placeholder="Nome, ID ou handle"></label><div class="ranges">${numericControls.map(([, id, label2]) => `<label class="stack">${label2}<input id="${id}" type="number" min="0" step="any"></label>`).join("")}<label class="stack">Publicado a partir de<input id="published-after" type="date"></label><label class="stack">Publicado at\xE9<input id="published-before" type="date"></label></div><label class="stack">Formato<select id="format"><option value="all">Todos</option><option value="only">S\xF3 Shorts</option><option value="exclude">Sem Shorts</option></select></label><label class="stack">Ordena\xE7\xE3o<select id="sort"><option value="default">Ordem original</option><option value="views">Mais visualizados</option><option value="vph">Maior VPH m\xE9dio</option><option value="outlier">Maior outlier</option><option value="recent">Mais recentes</option><option value="duration">Maior dura\xE7\xE3o</option><option value="subscribers">Mais inscritos</option><option value="title">T\xEDtulo</option></select></label><div class="row"><button id="clear-filter" class="secondary">Limpar filtros</button><button id="scan">Analisar p\xE1gina</button><button id="workspace" class="secondary">Abrir painel</button></div><p id="status" role="status"></p><p>Somente conte\xFAdo j\xE1 carregado. VPH m\xE9dio desde a publica\xE7\xE3o; datas relativas s\xE3o aproximadas. Campos ausentes ficam fora quando seu limite est\xE1 ativo. Nenhuma altera\xE7\xE3o no canal \xE9 feita por estes filtros.</p></section></details>`;
      const field = (id) => shadow.getElementById(id);
      syncFilterForm = () => {
        field("query").value = filter.query ?? "";
        field("channel").value = filter.channel ?? "";
        for (const [key, id] of numericControls)
          field(id).value = filter[key] === void 0 ? "" : String(filter[key]);
        field("published-after").value = filter.publishedAfter ?? "";
        field("published-before").value = filter.publishedBefore ?? "";
        field("format").value = filter.shorts ?? "all";
        field("sort").value = filter.sort;
      };
      syncFilterForm();
      field("shorts").checked = settings.hideShorts;
      field("metrics").checked = settings.showMetrics;
      field("shorts").addEventListener("change", () => {
        settings.hideShorts = field("shorts").checked;
        settings.hideShortsOnFeed = settings.hideShorts;
        settings.hideShortsOnSearch = settings.hideShorts;
        filter = { ...filter, ...shortsPreferences() };
        void saveSettings(settings).catch(showError);
        apply();
      });
      field("metrics").addEventListener("change", () => {
        settings.showMetrics = field("metrics").checked;
        void saveSettings(settings).catch(showError);
        apply();
      });
      const readForm = () => {
        try {
          const input = {
            ...filter,
            query: field("query").value,
            channel: field("channel").value,
            shorts: field("format").value,
            sort: field("sort").value,
            publishedAfter: field("published-after").value,
            publishedBefore: field("published-before").value
          };
          for (const [key, id] of numericControls) {
            const control = field(id);
            if (!control.validity.valid)
              throw new Error("Use limites num\xE9ricos n\xE3o negativos.");
            input[key] = control.value === "" ? void 0 : Number(control.value);
          }
          filter = normalizeCardFilter(input);
          filterError = "";
          schedule();
        } catch (error) {
          filterError = error instanceof Error ? error.message : String(error);
          updatePanel();
        }
      };
      for (const id of [
        "query",
        "channel",
        "published-after",
        "published-before",
        ...numericControls.map(([, id2]) => id2)
      ])
        field(id).addEventListener("input", readForm);
      for (const id of ["format", "sort"])
        field(id).addEventListener("change", readForm);
      field("clear-filter").addEventListener("click", () => {
        setFilter(normalizeCardFilter({}));
        filterError = "";
        syncFilterForm();
        apply();
      });
      field("scan").addEventListener("click", () => {
        void snapshot().then(() => {
          field("status").textContent = "P\xE1gina analisada e salva neste navegador.";
        }).catch(showError);
      });
      field("workspace").addEventListener("click", () => {
        void chrome.runtime.sendMessage({ type: "OPEN_WORKSPACE" }).catch(showError);
      });
      updatePanel = () => {
        const cards = loadedCards();
        field("status").textContent = filterError || `${cards.filter((c) => !c.element.hasAttribute(HIDDEN)).length} de ${cards.length} v\xEDdeos carregados vis\xEDveis`;
        const preferences = shortsPreferences(), shortsControl = field("shorts");
        shortsControl.checked = preferences.hideShortsOnFeed === true && preferences.hideShortsOnSearch === true;
        shortsControl.indeterminate = preferences.hideShortsOnFeed !== preferences.hideShortsOnSearch;
        field("metrics").checked = settings.showMetrics;
      };
      const collectionContainer = document.createElement("div");
      collectionContainer.id = "prevlev-collection-tools";
      shadow.querySelector("section").append(collectionContainer);
      collectionControlsCleanup = mountCollectionControls(collectionContainer, collector, async (value) => {
        await chrome.storage.local.set({ snapshot: value });
        await chrome.runtime.sendMessage({ type: "OPEN_WORKSPACE" });
      });
      document.documentElement.append(host);
      function showError(error) {
        field("status").textContent = error instanceof Error ? error.message : String(error);
      }
    };
    shortsPreferences2 = shortsPreferences, setFilter2 = setFilter, elementIdentity2 = elementIdentity, channelKeys2 = channelKeys, enrichedVideo2 = enrichedVideo, loadedCards2 = loadedCards, listen2 = listen, schedule2 = schedule, navigation2 = navigation, captureViewportChanged2 = captureViewportChanged, apply2 = apply, observedVideos2 = observedVideos, ensureResearchOverlay2 = ensureResearchOverlay, number2 = number, mount2 = mount;
    contentScope.__prevlevContentInitialized = true;
    const HOST_ID3 = "prevlev-controls";
    const HIDDEN = "data-prevlev-hidden";
    const collector = createCollectionController(document);
    let collectionControlsCleanup;
    let contextual;
    let researchOverlay;
    let settings;
    let observer;
    let timer;
    let suspended = false;
    let navigationListening = false;
    let updatePanel = () => {
    };
    let filter = {
      query: "",
      shorts: "all",
      sort: "default"
    };
    let filterError = "";
    let syncFilterForm = () => {
    };
    const channelEnrichment = /* @__PURE__ */ new Map();
    let pageRevision = 0;
    let identitySequence = 0;
    const elementIdentities = /* @__PURE__ */ new WeakMap();
    const originalOrder = /* @__PURE__ */ new WeakMap();
    let nextOrder = 0;
    window.addEventListener("pagehide", () => {
      suspended = true;
      observer?.disconnect();
      if (timer) clearTimeout(timer);
      timer = void 0;
      navigation(false);
      collector.dispose();
      contextual?.cleanup();
      contextual = void 0;
      researchOverlay?.dispose();
      researchOverlay = void 0;
    });
    window.addEventListener("pageshow", (event) => {
      if (!event.persisted || !suspended) return;
      suspended = false;
      if (settings) {
        navigation(true);
        apply();
      }
    });
    async function snapshot() {
      const value = readYouTubeSnapshot(document);
      value.videos = value.videos.map(enrichedVideo);
      const timeline = refreshTimeline(document);
      if (value.videoId && timeline.videoId === value.videoId && (timeline.available || timeline.segments.length > 0)) value.transcript = timeline.segments;
      if (location.hostname === "studio.youtube.com") {
        const metrics = readStudioMetrics(document);
        value.studio = metrics;
        value.warnings.push(...metrics.warnings);
      }
      await chrome.storage.local.set({ snapshot: value });
      return value;
    }
    async function blobData(blob) {
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result));
        reader.onerror = () => reject(new Error("N\xE3o foi poss\xEDvel ler a imagem."));
        reader.readAsDataURL(blob);
      });
    }
    async function dispatch(message) {
      switch (message.type) {
        case "START_COLLECTION": {
          if (suspended) throw new Error("Ative a p\xE1gina antes de iniciar a coleta.");
          return { status: "ok", collection: collector.start({ kind: message.kind, maxItems: message.maxItems, maxSteps: message.maxSteps, timeoutMs: message.timeoutMs }) };
        }
        case "COLLECTION_STATUS": {
          if (message.includeResults !== void 0 && typeof message.includeResults !== "boolean") throw new Error("includeResults deve ser booleano.");
          const collection = collector.status(message.jobId);
          return { status: "ok", collection, ...message.includeResults && collection.phase !== "running" ? { snapshot: collector.snapshot(message.jobId) } : {} };
        }
        case "CANCEL_COLLECTION":
          return { status: "ok", collection: collector.cancel(message.jobId) };
        case "GET_CURRENT_METADATA": {
          const title = document.querySelector("ytd-watch-metadata h1,h1.ytd-video-primary-info-renderer")?.textContent?.replace(/\s+/g, " ").trim() || document.title.replace(/\s*- YouTube$/, "");
          const id = videoIdFromUrl(location.href);
          return { status: "ok", metadata: { title, id, videoId: id, url: location.href } };
        }
        case "APPLY_FILTER":
        case "CLEAR_FILTER": {
          if (!settings) throw new Error("Aguarde a extens\xE3o carregar.");
          const candidate = normalizeCardFilter(
            message.type === "CLEAR_FILTER" ? {} : message.filter
          );
          if (candidate.surface !== void 0 && candidate.surface !== researchSurface(location.href)) throw new Error("O filtro foi preparado para outro contexto de p\xE1gina. Confira a aba e prepare-o novamente.");
          filterError = "";
          setFilter(candidate);
          syncFilterForm();
          apply();
          const cards = loadedCards();
          return {
            status: "ok",
            visible: cards.filter((card) => !card.element.hasAttribute(HIDDEN)).length,
            total: cards.length,
            filter
          };
        }
        case "SET_ENRICHMENT": {
          if (!Array.isArray(message.videos) || message.videos.length > 2e3)
            throw new Error("Envie at\xE9 2000 v\xEDdeos para atualizar os inscritos.");
          const entries = [];
          for (const raw of message.videos) {
            if (!raw || typeof raw !== "object")
              throw new Error("Dados de canal inv\xE1lidos.");
            const record3 = raw;
            if (record3.subscribers === void 0) continue;
            if (typeof record3.subscribers !== "number" || !Number.isFinite(record3.subscribers) || record3.subscribers < 0)
              throw new Error("Contagem de inscritos inv\xE1lida.");
            const identity = {
              channelId: typeof record3.channelId === "string" ? record3.channelId : void 0,
              channelUrl: typeof record3.channelUrl === "string" ? record3.channelUrl : void 0
            };
            for (const key of channelKeys(identity))
              entries.push([
                key,
                {
                  subscribers: record3.subscribers,
                  channel: typeof record3.channel === "string" ? record3.channel : void 0
                }
              ]);
          }
          for (const [key, info] of entries) {
            channelEnrichment.set(key, info);
            while (channelEnrichment.size > 2e3)
              channelEnrichment.delete(channelEnrichment.keys().next().value);
          }
          apply();
          return { status: "ok", updated: entries.length };
        }
        case "GET_TIMELINE":
        case "SEEK_VIDEO":
        case "TOGGLE_PLAYBACK":
          return { status: "ok", state: await dispatchTimeline(message, document) };
        case "GET_SNAPSHOT":
          return { status: "ok", snapshot: await snapshot() };
        case "COPY_TITLE_ID": {
          const value = readYouTubeSnapshot(document);
          await navigator.clipboard.writeText(
            `${value.title}
${value.videoId ?? value.url}`
          );
          return { status: "ok" };
        }
        case "CAPTURE_FRAME": {
          const video = document.querySelector("video");
          if (!video) throw new Error("Nenhum v\xEDdeo carregado nesta p\xE1gina.");
          return {
            status: "ok",
            dataUrl: await blobData(await captureFrame(video))
          };
        }
        case "CAPTURE_CARD": {
          if (suspended)
            throw new Error(
              "A p\xE1gina est\xE1 suspensa. Ative a aba e tente novamente."
            );
          if (message.targetVideoId !== void 0 && (typeof message.targetVideoId !== "string" || !/^[\w-]{11}$/.test(message.targetVideoId))) throw new Error("ID do card solicitado inv\xE1lido.");
          if (message.targetVideoId !== void 0 && message.kind !== void 0 && message.kind !== "video") throw new Error("Um ID de v\xEDdeo s\xF3 pode selecionar um card de v\xEDdeo.");
          if (message.redact !== void 0 && typeof message.redact !== "boolean") throw new Error("Op\xE7\xE3o de oculta\xE7\xE3o inv\xE1lida.");
          const categories = message.redactionCategories === void 0 ? void 0 : validateCaptureCategories(message.redactionCategories);
          if (categories && !message.redact) throw new Error("Ative a oculta\xE7\xE3o para selecionar categorias.");
          const studioKind = message.kind === "analytics" || message.kind === "latest-performance" ? message.kind : void 0;
          const element = studioKind ? getStudioScreenshotTargets(studioKind, document)[0] : readVideoCards(document).find((c) => {
            const r2 = c.element.getBoundingClientRect();
            return (message.targetVideoId === void 0 || c.video.id === message.targetVideoId) && r2.width > 0 && r2.height > 0 && r2.top >= 0 && r2.left >= 0 && r2.bottom <= innerHeight && r2.right <= innerWidth;
          })?.element;
          if (!element)
            throw new Error(
              "O card solicitado n\xE3o est\xE1 dispon\xEDvel. Role at\xE9 ele e tente novamente."
            );
          const r = element.getBoundingClientRect();
          if (r.top < 0 || r.left < 0 || r.bottom > innerHeight || r.right > innerWidth || r.width === 0 || r.height === 0)
            throw new Error(
              "O card precisa estar inteiro vis\xEDvel na janela para capturar. Ajuste a rolagem ou o zoom."
            );
          const intersects = (el) => {
            const box = el.getBoundingClientRect();
            return box.width > 0 && box.height > 0 && box.x < r.right && box.y < r.bottom && box.x + box.width > r.left && box.y + box.height > r.top;
          };
          if (categories) {
            for (const category of categories) {
              const categoryDetails = getStudioRedactionDetails(document, [category]);
              if (categoryDetails.coarse || !categoryDetails.elements.some(intersects))
                throw new Error(`A categoria ${category} n\xE3o foi reconhecida dentro do card. Captura interrompida; revise a sele\xE7\xE3o e o layout.`);
            }
          }
          const redactionDetails = message.redact ? getStudioRedactionDetails(document, categories) : void 0;
          const redactionNodes = redactionDetails ? redactionDetails.elements.map((el) => {
            const box = el.getBoundingClientRect();
            return {
              element: el,
              x: box.x,
              y: box.y,
              width: box.width,
              height: box.height
            };
          }).filter(
            (box) => box.width > 0 && box.height > 0 && box.x < r.right && box.y < r.bottom && box.x + box.width > r.left && box.y + box.height > r.top
          ) : [];
          const redactions = redactionNodes.map(({ x, y, width, height }) => ({
            x,
            y,
            width,
            height
          }));
          if (message.redact && (message.kind === "analytics" || message.kind === "latest-performance") && redactions.length === 0)
            throw new Error(
              "Nenhum campo sens\xEDvel vis\xEDvel foi reconhecido neste card. A captura foi interrompida para evitar uma imagem sem oculta\xE7\xE3o. Confira o layout do Studio ou desative a oculta\xE7\xE3o conscientemente."
            );
          if (observer?.takeRecords().length) pageRevision++;
          const captureVideo = studioKind ? void 0 : readVideoCards(document).find((card) => card.element === element)?.video;
          const captureStamp = JSON.stringify({
            url: location.href,
            redactionCategories: categories ?? (message.redact ? "legacy" : null),
            video: captureVideo ? { id: captureVideo.id, url: captureVideo.url, title: captureVideo.title } : void 0,
            revision: pageRevision,
            element: elementIdentity(element),
            content: element.textContent,
            rect: { x: r.x, y: r.y, width: r.width, height: r.height },
            viewport: {
              width: innerWidth,
              height: innerHeight,
              scrollX: window.scrollX,
              scrollY: window.scrollY,
              visual: window.visualViewport ? {
                x: window.visualViewport.offsetLeft,
                y: window.visualViewport.offsetTop,
                width: window.visualViewport.width,
                height: window.visualViewport.height,
                scale: window.visualViewport.scale
              } : null
            },
            redactions: redactionNodes.map(({ element: target, ...box }) => ({
              ...box,
              identity: elementIdentity(target),
              content: target.textContent
            }))
          });
          return {
            status: "ok",
            rect: { x: r.x, y: r.y, width: r.width, height: r.height },
            viewportWidth: innerWidth,
            redactions,
            captureStamp,
            coarse: redactionDetails?.coarse ?? false,
            coarseSelectors: redactionDetails?.coarseSelectors ?? []
          };
        }
        case "GET_MONETIZATION":
          return {
            status: "ok",
            result: inferMonetization(
              Array.from(document.scripts).map((s) => s.textContent ?? "").join("\n")
            )
          };
        case "STUDIO_PREVIEW":
          if (!message.action) throw new Error("Selecione uma a\xE7\xE3o.");
          return previewStudioAction(message.action, message.input, document);
        case "STUDIO_EXECUTE":
          if (!message.planId) throw new Error("Uma pr\xE9via \xE9 necess\xE1ria.");
          return executeStudioPlan(message.planId);
        case "STUDIO_CANCEL":
          return {
            status: cancelStudioPlan(message.planId ?? "") ? "cancelled" : "not_found"
          };
        case "STUDIO_PERIOD":
          return setStudioPeriodVerified(message.start ?? "", message.end ?? "", document);
        default:
          return { status: "unsupported", error: "A\xE7\xE3o desconhecida." };
      }
    }
    chrome.runtime.onMessage.addListener(
      (message, sender, sendResponse) => {
        if (sender.id !== chrome.runtime.id) return false;
        if (!message || typeof message.type !== "string") return false;
        void dispatch(message).then(sendResponse).catch(
          (error) => sendResponse({
            status: "error",
            error: error instanceof Error ? error.message : String(error)
          })
        );
        return true;
      }
    );
    chrome.storage.onChanged.addListener((changes, areaName) => {
      const value = changes.settings?.newValue;
      if (areaName === "local" && settings && value && typeof value === "object") {
        settings = { ...settings, ...value };
        filter = { ...filter, ...shortsPreferences() };
        schedule();
      }
    });
    void getSettings().then((value) => {
      settings = value;
      filter = { ...filter, ...shortsPreferences() };
      observer = new MutationObserver((records) => {
        if (records.length) {
          pageRevision++;
          schedule();
        }
      });
      if (!suspended) {
        navigation(true);
        apply();
      }
    }).catch(() => {
    });
  }
  var shortsPreferences2;
  var setFilter2;
  var elementIdentity2;
  var channelKeys2;
  var enrichedVideo2;
  var loadedCards2;
  var listen2;
  var schedule2;
  var navigation2;
  var captureViewportChanged2;
  var apply2;
  var observedVideos2;
  var ensureResearchOverlay2;
  var number2;
  var mount2;
})();
